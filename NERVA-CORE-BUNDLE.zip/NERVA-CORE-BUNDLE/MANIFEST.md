# NERVA Core Bundle

A self-contained, offline-verifiable NERVA nuclear core modelling package,
extracted from the `NUKE-main` working tree.

```
NERVA-CORE-BUNDLE/
├── ntr/nerva/          the package (348 .py modules)
│   └── heritage/       cited source data + ARCHITECTURE.md
├── audit/              PDF extraction scripts + page-indexed corpus
├── run_suite.ps1       one-command verification runner
├── RUNBOOK.md          how to validate on a new machine
└── MANIFEST.md         this file
```

**Verified state: 36/36 suites, 934 checks, from a cold bundle.**

---

## Why the whole package is here, not just the new files

57 files were created in the session that produced this bundle. They are *not*
standalone: they import from 325 pre-existing modules in the same package (783
relative imports, zero absolute `ntr.nerva` references). Shipping only the 57
new files would produce a bundle that cannot import.

What makes the bundle relocatable anyway is that the package uses **only**
relative imports. It moves as a unit and needs nothing from `NUKE-main`.

The 57 new files are listed in the appendix and flagged in
`manifest_new_files.json`.

---

## What was built, by area

### Heritage layer — the book, as data

| File | Contents |
|---|---|
| `heritage/citation.py`, `registry.py` | `Citation` / `SourcedValue` / `HeritageRegistry`. An uncited value cannot be constructed — validation is in `__post_init__`, not in a linter. |
| `heritage/data/emrich2023_nerva.json` | NERVA/XE0/Pewee figures, including the Appendix III tables |
| `heritage/data/emrich2023_materials.json` | Table 15.2 graphite 1000–3500 K, ZrH decomposition |
| `heritage/data/emrich2023_delayed_neutrons.json` | Table 11.1 six-group precursors |
| `heritage/data/emrich2023_hydrogen.json` | hydrogen properties |
| `heritage/data/emrich2023_cycles.json` | cycle parameters |

Methods are code; heritage numbers are cited JSON. The two are never mixed.

### Textbook physics, oracle-checked

| Module | Source |
|---|---|
| `heritage/turbomachinery.py` | Ch. 10 Eqs 10.1–10.7 |
| `heritage/cycles.py` | Ch. 3 Eqs 3.1–3.2 (hot bleed — NERVA's actual cycle) |
| `heritage/kinetics.py` | Ch. 11 Eqs 11.3–11.12, RK4 point kinetics |
| `fission_product_poisoning.py` | Ch. 13 Eqs 13.16–13.32 |
| `shielding.py` | Ch. 14 Eqs 14.7–14.21, Taylor coefficients Table 14.1 |
| `diffusion.py` | Ch. 8 Eqs 8.21/8.22, bucklings Table 8.2, 8.27–8.29 |
| `flow_stability.py` | Ch. 12 Eqs 12.77–12.88, friction Table 12.1 |
| `material_properties.py` | Table 15.2 |
| `diffusion_2d.py` | 2-D r-z axisymmetric multigroup FD eigenvalue solver |

### Core physics design (standard practice, not the book)

`transport_backend.py` · `coupled_core.py` · `criticality_search.py` ·
`cycle_closure.py` · `depletion_driver.py` · `reactivity_coefficients.py` ·
`control_worth.py` · `kinetics_transient.py` · `core_metrics.py` ·
`spatial_core.py` · `delayed_parameters.py` · `startup.py` · `core_stability.py` ·
`core_life.py` · `control_system.py` · `decay.py` · `diffusion_backend.py` ·
`xenon_spatial.py` · `adjoint.py` · `property_providers.py` ·
`thermochemistry.py` · `cea_oracle.py` · `nozzle_closure.py`

> `core_stability.py` is **not** Ch. 12. Ch. 12 is thermal-fluid flow stability
> and is implemented separately in `flow_stability.py`. Conflating them was a
> real error caught during development.

### Verification and evidence

`acceptance_gates.py` (8 gates) · `numerical_studies.py` · `determinism.py` ·
`preflight.py` · `doctor.py` · `baseline.py` · 149 `validate_*.py` harnesses

---

## The declared baseline

`baseline.py` declares **one** engine — XE-Prime / XE0 — because it is the only
NERVA engine with two independent sources pinning the same quantities: NASA
TM-105252 Table 3 and Emrich Appendix III Tables III.1/III.2.

| Quantity | Preset | XE0 measured | Error | Tolerance |
|---|---|---|---|---|
| Thermal power | 1140 MW | 1137 MW | +0.26% | 1% |
| Chamber temperature | 2280.6 K | 2278 K | +0.11% | 1% |
| Chamber pressure | 3.901 MPa | 3.81 MPa | +2.39% | 5% |
| Thrust flow | 31.842 kg/s | 31.98 kg/s | −0.43% | 2% |

Tolerances were fixed before the residuals were computed. The gate refuses the
baseline if any comparison leaves tolerance, so breaking agreement cannot go
unnoticed.

---

## What this does NOT do

Read this before trusting any number.

| Not done | Why |
|---|---|
| Real neutron transport | no `openmc.exe`, no HDF5 cross sections here |
| Depletion/burnup execution | written against `openmc.deplete`; never run (no `libopenmc`) |
| CEA oracle | no CEA binary |
| CoolProp hydrogen properties | not installed in the tested interpreter |
| Hot-H₂ corrosion / fuel mass loss | **no data in either source** — deliberately not invented |
| Two-phase H₂ / CHF | **no data in either source** — deliberately not invented |

The transport layer is a seam: `MockTransportBackend` returns synthetic
coefficients and hard-codes `is_physics=False`. Every consumer of it reports
`synthetic=True`, and the acceptance gates downgrade to PARTIAL automatically.
**The mock can never claim to be physics, and no test asserts that its numbers
are right** — only that it admits what it is.

### Acceptance gates: 3/8 met

| Gate | Status | Blocker |
|---|---|---|
| 1 Reference traceability | **MET** | — |
| 2 Neutronics evidence | NOT MET | needs real transport run |
| 3 Thermal coupling | PARTIAL | deposition is synthetic |
| 4 Hydraulic closure | PARTIAL | pump characteristics synthetic |
| 5 Shaft and flow closure | PARTIAL | shaft closure synthetic |
| 6 Numerical independence | **MET** | — |
| 7 Historical validation | NOT MET | needs NASA experimental data |
| 8 Reproducible handoff | **MET** | — |

Honest split: **~95% of the writable code is written; ~40% of the physics is
validated against an external oracle.** The gap is not a coding task.

---

## Two traps found while packaging

Both were caught by running the bundle rather than assuming it worked.

1. **Cold-start ordering.** `validate_acceptance_gates` is an aggregator: gates
   6 and 8 read evidence records that `validate_numerical_independence` and
   `validate_determinism` write into `./build/`. Running the aggregator first
   made it fail for reasons unrelated to correctness. `run_suite.ps1` now runs
   it last.
2. **The station trap.** Preset flow must be compared to the nozzle-chamber flow
   (31.98 kg/s), not the tank outlet (36.15 kg/s) — the difference is the
   diluent and hot bleeds. Comparing to the wrong station reports a spurious
   −11.9%. A validator asserts that the wrong comparison really does fail.

---

## Appendix - the files created in this session

27 modules and 26 validators (53 Python files), plus 3 heritage JSON
datasets and heritage/ARCHITECTURE.md - 57 files in total.

### New modules

| Module | Purpose |
|---|---|
| `acceptance_gates.py` | 8-gate evidence reporter (3/8 met offline; refuses to overclaim) |
| `adjoint.py` | forward vs adjoint weighting for kinetics corrections |
| `baseline.py` | declares the single XE-Prime/XE0 baseline and its cross-check |
| `cea_oracle.py` | NASA CEA oracle adapter (needs the binary) |
| `control_system.py` | control drum + TPCV loop model |
| `control_worth.py` | drum worth versus angle |
| `core_life.py` | core lifetime and burnup budget |
| `core_metrics.py` | core-level performance metrics |
| `core_stability.py` | core thermal-neutronic stability (NOT Ch.12) |
| `decay.py` | decay heat and activity |
| `delayed_parameters.py` | delayed neutron parameters from heritage Table 11.1 |
| `diffusion.py` | heritage Ch.8 slab eigenvalue, bucklings Table 8.2 |
| `diffusion_2d.py` | 2-D r-z axisymmetric multigroup FD eigenvalue solver |
| `diffusion_backend.py` | 1-D multigroup diffusion backend |
| `fission_product_poisoning.py` | Xe/Sm poisoning, heritage Ch.13 Eqs 13.16-13.32 |
| `flow_stability.py` | heritage Ch.12 thermal-fluid flow stability + Table 12.1 |
| `kinetics_transient.py` | point kinetics transients on heritage Ch.11 |
| `material_properties.py` | heritage Table 15.2 graphite 1000-3500 K, ZrH decomposition |
| `nozzle_closure.py` | chamber->throat->exit closure, mass + energy |
| `property_providers.py` | CoolProp / synthetic property provider seam |
| `reactivity_coefficients.py` | Doppler/coolant/reflector/void/enrichment/poison worth |
| `shielding.py` | heritage Ch.14 dose and attenuation, Taylor coefficients Table 14.1 |
| `spatial_core.py` | per-element core state (deliberately not averaged) |
| `startup.py` | startup/shutdown sequence modelling |
| `thermochemistry.py` | CEA-style equilibrium helpers |
| `transport_backend.py` | CoreState + Mock/OpenMC transport seam |
| `xenon_spatial.py` | spatial xenon tilt and oscillation threshold |

### New validators

| Validator | Purpose |
|---|---|
| `validate_acceptance_gates.py` | proves the gate reporter cannot be talked into complete |
| `validate_adjoint.py` | verifies `adjoint.py` |
| `validate_baseline.py` | 43 checks: baseline declared, traced to registry, able to fail |
| `validate_cea_oracle.py` | verifies `cea_oracle.py` |
| `validate_control_worth.py` | verifies `control_worth.py` |
| `validate_core_life.py` | verifies `core_life.py` |
| `validate_core_metrics.py` | verifies `core_metrics.py` |
| `validate_core_stability.py` | verifies `core_stability.py` |
| `validate_decay.py` | verifies `decay.py` |
| `validate_delayed_parameters.py` | verifies `delayed_parameters.py` |
| `validate_diffusion.py` | verifies `diffusion.py` |
| `validate_diffusion_2d.py` | 22 checks: converges to analytic cylinder buckling |
| `validate_diffusion_backend.py` | verifies `diffusion_backend.py` |
| `validate_fission_product_poisoning.py` | verifies `fission_product_poisoning.py` |
| `validate_flow_stability.py` | verifies `flow_stability.py` |
| `validate_heritage_registry.py` | citation provenance, incl. the 55 in vs 132 cm resolution |
| `validate_kinetics_transient.py` | verifies `kinetics_transient.py` |
| `validate_material_properties.py` | verifies `material_properties.py` |
| `validate_nozzle_closure.py` | verifies `nozzle_closure.py` |
| `validate_property_providers.py` | verifies `property_providers.py` |
| `validate_reactivity_coefficients.py` | verifies `reactivity_coefficients.py` |
| `validate_shielding_control.py` | covers both shielding.py and control_system.py |
| `validate_spatial_core.py` | verifies `spatial_core.py` |
| `validate_startup.py` | verifies `startup.py` |
| `validate_thermochemistry.py` | verifies `thermochemistry.py` |
| `validate_xenon_spatial.py` | verifies `xenon_spatial.py` |

### New data and documentation

| File | Contents |
|---|---|
| `heritage/data/emrich2023_nerva.json` | NERVA/XE0/Pewee figures incl. Appendix III tables |
| `heritage/data/emrich2023_materials.json` | Table 15.2 graphite 1000-3500 K, ZrH decomposition |
| `heritage/data/emrich2023_hydrogen.json` | hydrogen properties |
| `heritage/ARCHITECTURE.md` | status, oracle results, gate evidence |
