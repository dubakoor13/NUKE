"""Verify peaking factors and core inventory against analytic values.

Both metrics have exact analytic answers for simple shapes, which is what makes
them testable rather than merely plausible:

* a uniform distribution has peaking factor exactly 1;
* an unchopped cosine axial shape ``cos(pi z / L)`` has peak/average = pi/2;
* inventory relations are pure arithmetic and can be cross-checked against a
  hand calculation.
"""
from __future__ import annotations

import math

from .core_metrics import (
    AVOGADRO,
    U235_MOLAR_MASS_KG_MOL,
    BurnupRate,
    CoreInventory,
    CoreMetricsError,
    peaking_factors,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- peaking factors -----------------------------------------------
    print("peaking factors:")
    uniform = peaking_factors([2.0, 2.0, 2.0, 2.0])
    results.append(_report("uniform radial distribution gives F_r = 1",
                           abs(uniform.radial - 1.0) < 1e-15,
                           f"F_r={uniform.radial:.12f}"))

    # cos(pi z / L) sampled at MIDPOINTS: peak/average = pi/2 exactly in the
    # continuum. Sampling on the endpoints instead (the first version) weights
    # the two vanishing ends and biases the mean by ~5e-4.
    nodes = 2001
    axial = [math.cos(math.pi * ((index + 0.5) / nodes - 0.5))
             for index in range(nodes)]
    radial_flat = [1.0] * 7
    cosine = peaking_factors(radial_flat, axial)
    expected = math.pi / 2.0
    relative = abs(cosine.axial - expected) / expected
    print(f"    cosine axial: F_z={cosine.axial:.6f}  analytic pi/2={expected:.6f}")
    results.append(_report("cosine axial peak/average = pi/2",
                           relative < 1e-4, f"rel {relative*100:.4f}%"))

    results.append(_report("flat radial with cosine axial keeps F_r = 1",
                           abs(cosine.radial - 1.0) < 1e-15,
                           f"F_r={cosine.radial:.12f}"))
    results.append(_report("total equals radial x axial when separable",
                           abs(cosine.total - cosine.radial * cosine.axial) < 1e-12,
                           f"F_q={cosine.total:.6f}"))
    results.append(_report("peaks coincide for a separable shape",
                           abs(cosine.coincidence_factor - 1.0) < 1e-12,
                           f"coincidence={cosine.coincidence_factor:.9f}"))

    # Non-separable: put the axial peak on the hottest element only.
    peaked = [1.0, 1.0, 3.0, 1.0, 1.0]
    factors = peaking_factors(peaked)
    results.append(_report("radial-only analysis reports F_z = 1 explicitly",
                           factors.axial == 1.0 and factors.total == factors.radial,
                           f"F_r={factors.radial:.4f} F_z=1.0"))
    results.append(_report("radial peak location is identified",
                           factors.radial_location == 2,
                           f"index {factors.radial_location}"))
    expected_radial = 3.0 / (7.0 / 5.0)
    results.append(_report("radial factor matches hand calculation",
                           abs(factors.radial - expected_radial) < 1e-12,
                           f"{factors.radial:.6f} vs {expected_radial:.6f}"))

    print("\npeaking guards:")
    for label, fn in (
        ("empty distribution", lambda: peaking_factors([])),
        ("zero total power", lambda: peaking_factors([0.0, 0.0])),
        ("negative power", lambda: peaking_factors([1.0, -1.0])),
    ):
        try:
            fn()
        except CoreMetricsError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    # ---- inventory -----------------------------------------------------
    print("\ncore inventory:")
    inventory = CoreInventory(
        fuel_volume_m3=0.10, fuel_density_kg_m3=1850.0,
        uranium_mass_fraction=0.20, enrichment_wt_percent=5.0,
        thermal_power_w=1.0e8,
    )
    print(f"    {inventory.describe()}")
    results.append(_report("fuel mass = volume x density",
                           abs(inventory.fuel_mass_kg - 185.0) < 1e-9,
                           f"{inventory.fuel_mass_kg:.4f} kg"))
    results.append(_report("uranium mass = fuel mass x fraction",
                           abs(inventory.uranium_mass_kg - 37.0) < 1e-9,
                           f"{inventory.uranium_mass_kg:.4f} kg"))
    results.append(_report("U-235 mass = uranium x enrichment",
                           abs(inventory.u235_mass_kg - 1.85) < 1e-9,
                           f"{inventory.u235_mass_kg:.4f} kg"))
    results.append(_report("U-238 is the remainder",
                           abs(inventory.u238_mass_kg
                               - (inventory.uranium_mass_kg - inventory.u235_mass_kg))
                           < 1e-12, f"{inventory.u238_mass_kg:.4f} kg"))
    expected_specific = 1.0e8 / 1000.0 / 1.85
    results.append(_report("specific power matches hand calculation",
                           abs(inventory.specific_power_kw_per_kg - expected_specific)
                           < 1e-9,
                           f"{inventory.specific_power_kw_per_kg:.1f} kW/kg(U-235)"))
    expected_atoms = 1.85 / U235_MOLAR_MASS_KG_MOL * AVOGADRO
    results.append(_report("U-235 atom count matches",
                           abs(inventory.u235_atoms - expected_atoms) / expected_atoms
                           < 1e-15,
                           f"{inventory.u235_atoms:.4e} atoms"))
    results.append(_report("U-235 mass is a plausible order for a small core",
                           0.1 < inventory.u235_mass_kg < 100.0,
                           f"{inventory.u235_mass_kg:.2f} kg"))

    print("\ninventory guards:")
    for label, fn in (
        ("zero volume", lambda: CoreInventory(0.0, 1850.0, 0.2, 5.0, 1e8)),
        ("uranium fraction above one",
         lambda: CoreInventory(0.1, 1850.0, 1.5, 5.0, 1e8)),
        ("enrichment above 100 wt%",
         lambda: CoreInventory(0.1, 1850.0, 0.2, 120.0, 1e8)),
        ("zero power", lambda: CoreInventory(0.1, 1850.0, 0.2, 5.0, 0.0)),
    ):
        try:
            fn()
        except CoreMetricsError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    # ---- burnup rate ---------------------------------------------------
    print("\nburnup rate:")
    burnup = BurnupRate(power_w=1.0e8, u235_mass_kg=1.85)
    print(f"    {burnup.fissions_per_second:.4e} fissions/s   "
          f"{burnup.burnup_fraction_per_efpd:.4e} of inventory per EFPD")
    energy_check = burnup.fissions_per_second * burnup.energy_per_fission_j
    results.append(_report("fission rate reproduces the power",
                           abs(energy_check - 1.0e8) / 1.0e8 < 1e-12,
                           f"{energy_check:.6e} W"))
    # 1 MWd of burnup corresponds to ~1.05 g of U-235 fissioned.
    expected_rate = 1.0e8 / 1e6 / 1.85
    results.append(_report("burnup rate is MWd per kg of U-235 per day",
                           abs(burnup.burnup_mwd_per_kg_u235 - expected_rate) < 1e-12,
                           f"{burnup.burnup_mwd_per_kg_u235:.5f} MWd/kg/day"))
    results.append(_report("time to full consumption is finite and positive",
                           burnup.efpd_to_full_consumption > 0.0
                           and math.isfinite(burnup.efpd_to_full_consumption),
                           f"{burnup.efpd_to_full_consumption:.1f} EFPD"))
    results.append(_report("burnup ties to the inventory's atom count",
                           abs(burnup.u235_atoms - inventory.u235_atoms)
                           / inventory.u235_atoms < 1e-15, "same inventory"))

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: peaking factors and inventory match analytic values")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
