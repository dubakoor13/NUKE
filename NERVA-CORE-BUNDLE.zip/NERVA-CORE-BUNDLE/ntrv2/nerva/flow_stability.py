"""Thermal-fluid flow stability in parallel reactor channels.

This is the one genuinely missing nuclear topic: Emrich (2023) Ch. 12, pp.243-250.
OpenMC cannot do it (it is not neutron transport) and nothing in the delivered
model covered it either. It is *reactor core* physics, not engine-cycle physics:
it is about whether coolant flow in a bundle of parallel channels is stable
against a perturbation.

The mechanism
-------------
Parallel channels share a common pressure drop. A channel whose flow is
perturbed must return to the same pressure drop as its neighbours. Writing the
channel pressure drop as ``dP2(mdot) = P_in^2 - P_out^2``:

* ``d(dP2)/d(mdot) > 0`` - a small flow reduction lowers the channel's pressure
  drop, so it is pushed back up to the header value. **Stable.**
* ``d(dP2)/d(mdot) < 0`` - a small flow reduction *raises* the pressure drop, so
  the channel must reduce flow further to match the header. **Unstable**, and
  the flow runs away to a much lower stable branch.

The transition is the laminar/turbulent boundary: dropping from turbulent into
laminar flow raises the friction factor sharply, which raises the pressure drop,
which is exactly the unstable condition. Emrich's worked case is a channel
sitting at 0.131 g/s (barely turbulent) that falls to 0.0521 g/s with the outlet
temperature rising from 3000 K to almost 7100 K (p.248).

Equations (numbering preserved)
-------------------------------
* Eq. (12.78) ``dP = f * 8 mdot^2 / (rho pi^2 D^5) dz``
* Eq. (12.79)/(12.82) ``f = a + b/Re^x``
* Eq. (12.80) ``mu = mu0 T^n``
* Eq. (12.81) ``Re = 4 mdot / (pi D mu0 T^n)``
* Eq. (12.83) ideal-gas density
* Eq. (12.85) ``T(z) = q z / (mdot cp) + T_in``
* Eq. (12.87) the integrated pressure drop
* Eq. (12.88) the laminar reduction (Hagen-Poiseuille form)
* Table 12.1 friction factor coefficients for tubes
"""
from __future__ import annotations

import math
from dataclasses import dataclass


class FlowStabilityError(ValueError):
    """Raised when a flow-stability calculation is not well posed."""


# --------------------------------------------------------------- friction


@dataclass(frozen=True)
class FrictionCoefficients:
    """Friction factor in the form of Eq. (12.79): f = a + b / Re^x."""

    a: float
    b: float
    x: float
    regime: str

    def __post_init__(self) -> None:
        for name in ("a", "b", "x"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise FlowStabilityError(f"{name} must be finite, got {value!r}")
        if self.b <= 0.0:
            raise FlowStabilityError("b must be positive")
        if self.x <= 0.0:
            raise FlowStabilityError("Reynolds exponent x must be positive")

    def factor(self, reynolds: float) -> float:
        """f = a + b / Re^x."""
        if not math.isfinite(reynolds) or reynolds <= 0.0:
            raise FlowStabilityError(
                f"Reynolds number must be finite and positive, got {reynolds!r}"
            )
        return self.a + self.b / reynolds ** self.x


def laminar_coefficients() -> FrictionCoefficients:
    """Table 12.1, laminar column: a = 0, b = 64, x = 1."""
    return FrictionCoefficients(a=0.0, b=64.0, x=1.0, regime="laminar")


def turbulent_coefficients(relative_roughness: float) -> FrictionCoefficients:
    """Table 12.1, turbulent column, as functions of relative roughness eps/D.

        a = 0.094 (eps/D)^0.225 + 0.53 (eps/D)
        b = 88 (eps/D)^0.44
        x = 1.62 (eps/D)^0.134
    """
    if not math.isfinite(relative_roughness) or relative_roughness <= 0.0:
        raise FlowStabilityError(
            f"relative roughness must be finite and positive, got "
            f"{relative_roughness!r}"
        )
    epsilon = relative_roughness
    return FrictionCoefficients(
        a=0.094 * epsilon ** 0.225 + 0.53 * epsilon,
        b=88.0 * epsilon ** 0.44,
        x=1.62 * epsilon ** 0.134,
        regime="turbulent",
    )


def viscosity_at_temperature(mu0_pa_s: float, n: float, temperature_k: float) -> float:
    """Eq. (12.80): mu = mu0 T^n."""
    if not math.isfinite(mu0_pa_s) or mu0_pa_s <= 0.0:
        raise FlowStabilityError("mu0 must be finite and positive")
    if not math.isfinite(n):
        raise FlowStabilityError("viscosity exponent must be finite")
    if not math.isfinite(temperature_k) or temperature_k <= 0.0:
        raise FlowStabilityError("temperature must be finite and positive")
    return mu0_pa_s * temperature_k ** n


def reynolds_number(mdot: float, diameter_m: float, mu0_pa_s: float,
                    n: float, temperature_k: float) -> float:
    """Eq. (12.81): Re = 4 mdot / (pi D mu0 T^n)."""
    if not math.isfinite(mdot) or mdot <= 0.0:
        raise FlowStabilityError("mass flow must be finite and positive")
    if not math.isfinite(diameter_m) or diameter_m <= 0.0:
        raise FlowStabilityError("diameter must be finite and positive")
    viscosity = viscosity_at_temperature(mu0_pa_s, n, temperature_k)
    return 4.0 * mdot / (math.pi * diameter_m * viscosity)


# ------------------------------------------------------------ channel model


@dataclass(frozen=True)
class ChannelGeometry:
    """A representative coolant channel."""

    length_m: float
    diameter_m: float
    heated_perimeter_m: float
    inlet_temperature_k: float
    inlet_pressure_pa: float
    cp_j_kg_k: float
    gas_constant_j_kg_k: float
    mu0_pa_s: float
    viscosity_exponent: float

    def __post_init__(self) -> None:
        for name in ("length_m", "diameter_m", "heated_perimeter_m",
                     "inlet_temperature_k", "inlet_pressure_pa", "cp_j_kg_k",
                     "gas_constant_j_kg_k", "mu0_pa_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise FlowStabilityError(f"{name} must be finite and positive, got {value!r}")
        if not math.isfinite(self.viscosity_exponent):
            raise FlowStabilityError("viscosity exponent must be finite")

    def outlet_temperature_k(self, mdot: float, linear_heating_w_m: float) -> float:
        """Eq. (12.85): T_out = q L / (mdot cp) + T_in."""
        if not math.isfinite(mdot) or mdot <= 0.0:
            raise FlowStabilityError("mass flow must be finite and positive")
        if not math.isfinite(linear_heating_w_m) or linear_heating_w_m < 0.0:
            raise FlowStabilityError("linear heating must be finite and non-negative")
        return (self.inlet_temperature_k
                + linear_heating_w_m * self.length_m / (mdot * self.cp_j_kg_k))


def pressure_drop_squared(geometry: ChannelGeometry, coefficients: FrictionCoefficients,
                          mdot: float, linear_heating_w_m: float) -> float:
    """Eq. (12.87): ``P_in^2 - P_out^2`` for one channel, integrated.

    Written as the book gives it:

        P_in^2 - P_out^2 = (4 mdot R L)/(pi^2 D^5) * a * (qL/cp + 2 mdot T_in)
          + (2^(3-2x) cp mdot^(3-x) R mu0^x b) / (q (2+nx) pi^(2-x) D^(5-x))
            * [ T_out^(2+nx) - T_in^(2+nx) ]

    Note the ``q`` in the denominator of the second term, so a non-heating
    channel is a separate (purely frictional) case and is refused here.
    """
    if not math.isfinite(mdot) or mdot <= 0.0:
        raise FlowStabilityError("mass flow must be finite and positive")
    if not math.isfinite(linear_heating_w_m) or linear_heating_w_m <= 0.0:
        raise FlowStabilityError(
            "the b-term carries 1/q, so Eq. (12.87) needs positive linear heating; "
            f"got {linear_heating_w_m!r}"
        )

    g = geometry
    c = coefficients
    q = linear_heating_w_m
    d5 = g.diameter_m ** 5
    t_in = g.inlet_temperature_k
    t_out = g.outlet_temperature_k(mdot, q)

    first = (4.0 * mdot * g.gas_constant_j_kg_k * g.length_m / (math.pi ** 2 * d5)
             * c.a * (q * g.length_m / g.cp_j_kg_k + 2.0 * mdot * t_in))

    exponent = 2.0 + g.viscosity_exponent * c.x
    numerator = (2.0 ** (3.0 - 2.0 * c.x) * g.cp_j_kg_k
                 * mdot ** (3.0 - c.x) * g.gas_constant_j_kg_k
                 * g.mu0_pa_s ** c.x * c.b)
    denominator = (q * exponent * math.pi ** (2.0 - c.x) * g.diameter_m ** (5.0 - c.x))
    bracket = t_out ** exponent - t_in ** exponent
    second = numerator / denominator * bracket

    return first + second


def laminar_pressure_drop_squared(geometry: ChannelGeometry, mdot: float,
                                  linear_heating_w_m: float) -> float:
    """Eq. (12.88), the Hagen-Poiseuille reduction, written independently.

    This exists purely as an oracle: substituting a = 0, b = 64, x = 1 into
    Eq. (12.87) must reproduce this expression exactly, which cross-checks the
    integrated formula against the book's separate laminar derivation.
    """
    if not math.isfinite(mdot) or mdot <= 0.0:
        raise FlowStabilityError("mass flow must be finite and positive")
    if not math.isfinite(linear_heating_w_m) or linear_heating_w_m <= 0.0:
        raise FlowStabilityError("linear heating must be positive")
    g = geometry
    q = linear_heating_w_m
    n = g.viscosity_exponent
    t_in = g.inlet_temperature_k
    t_out = g.outlet_temperature_k(mdot, q)
    return (128.0 * g.cp_j_kg_k * mdot ** 2 * g.gas_constant_j_kg_k
            / (q * (2.0 + n) * math.pi * g.diameter_m ** 4)
            * (t_out ** (2.0 + n) - t_in ** (2.0 + n)) * g.mu0_pa_s)


# ------------------------------------------------------------ stability


@dataclass(frozen=True)
class FlowPoint:
    """Channel behaviour at one mass flow."""

    mdot_kg_s: float
    pressure_drop_squared_pa2: float
    outlet_temperature_k: float
    reynolds: float
    margin_pa2_s_kg: float
    stable: bool
    regime: str


def evaluate_flow_point(geometry: ChannelGeometry, coefficients: FrictionCoefficients,
                        mdot: float, linear_heating_w_m: float,
                        derivative_step_fraction: float = 1e-4) -> FlowPoint:
    """Evaluate a channel state and its stability margin.

    The margin is ``d(dP2)/d(mdot)`` by central difference. Positive means
    stable. Reynolds is evaluated at the mean channel temperature, which is the
    temperature the friction factor should be referred to.
    """
    if not math.isfinite(derivative_step_fraction) or derivative_step_fraction <= 0.0:
        raise FlowStabilityError("derivative step must be finite and positive")
    step = mdot * derivative_step_fraction
    if step <= 0.0:
        raise FlowStabilityError("mass flow too small to differentiate")
    high = pressure_drop_squared(geometry, coefficients, mdot + step,
                                 linear_heating_w_m)
    low = pressure_drop_squared(geometry, coefficients, mdot - step,
                                linear_heating_w_m)
    margin = (high - low) / (2.0 * step)
    mean_temperature = 0.5 * (geometry.inlet_temperature_k
                              + geometry.outlet_temperature_k(mdot,
                                                              linear_heating_w_m))
    reynolds = reynolds_number(mdot, geometry.diameter_m, geometry.mu0_pa_s,
                               geometry.viscosity_exponent, mean_temperature)
    return FlowPoint(
        mdot_kg_s=mdot,
        pressure_drop_squared_pa2=pressure_drop_squared(geometry, coefficients,
                                                        mdot, linear_heating_w_m),
        outlet_temperature_k=geometry.outlet_temperature_k(mdot, linear_heating_w_m),
        reynolds=reynolds,
        margin_pa2_s_kg=margin,
        stable=margin > 0.0,
        regime=coefficients.regime,
    )


def scan_flow(geometry: ChannelGeometry, coefficients: FrictionCoefficients,
              flows_kg_s: tuple[float, ...], linear_heating_w_m: float
              ) -> tuple[FlowPoint, ...]:
    """Evaluate a set of mass flows."""
    if not flows_kg_s:
        raise FlowStabilityError("at least one mass flow is required")
    return tuple(evaluate_flow_point(geometry, coefficients, mdot,
                                     linear_heating_w_m) for mdot in flows_kg_s)


def find_unstable_band(geometry: ChannelGeometry,
                       coefficients: FrictionCoefficients,
                       linear_heating_w_m: float,
                       flow_bounds_kg_s: tuple[float, float],
                       samples: int = 400) -> tuple[float, float] | None:
    """Locate the flow range where ``d(dP2)/d(mdot) < 0``, if any.

    Returns the ``(low, high)`` bounds of the unstable band, or ``None`` when the
    whole scanned range is stable.
    """
    low, high = flow_bounds_kg_s
    if not (0.0 < low < high):
        raise FlowStabilityError("flow bounds must be positive and increasing")
    if samples < 3:
        raise FlowStabilityError("at least three samples are required")
    unstable: list[float] = []
    for index in range(samples):
        mdot = low * (high / low) ** (index / (samples - 1))
        point = evaluate_flow_point(geometry, coefficients, mdot,
                                    linear_heating_w_m)
        if not point.stable:
            unstable.append(mdot)
    if not unstable:
        return None
    return (min(unstable), max(unstable))


@dataclass(frozen=True)
class ParallelChannelState:
    """Equilibrium of a perturbed channel against a shared-header pressure drop."""

    header_pressure_drop_squared_pa2: float
    nominal_flow_kg_s: float
    perturbed_flow_kg_s: float
    settled_flow_kg_s: float
    nominal_outlet_temperature_k: float
    settled_outlet_temperature_k: float
    collapsed: bool

    @property
    def flow_ratio(self) -> float:
        return self.settled_flow_kg_s / self.nominal_flow_kg_s

    @property
    def temperature_rise_k(self) -> float:
        return self.settled_outlet_temperature_k - self.nominal_outlet_temperature_k


def settle_perturbed_channel(
    geometry: ChannelGeometry,
    coefficients_nominal: FrictionCoefficients,
    coefficients_perturbed: FrictionCoefficients,
    nominal_flow_kg_s: float,
    perturbed_flow_kg_s: float,
    linear_heating_w_m: float,
    *,
    resolution: int = 600,
) -> ParallelChannelState:
    """What flow does a perturbed channel settle at, holding the header pressure drop?

    The header fixes ``P_in^2 - P_out^2``. After the perturbation the channel
    adopts a *different* friction law (for example, it has dropped into laminar
    flow), so the flow that reproduces the same pressure drop is generally not
    the nominal flow. This searches for the lowest-flow solution below the
    nominal point, because that is the branch the instability drives the channel
    onto.
    """
    if not math.isfinite(nominal_flow_kg_s) or nominal_flow_kg_s <= 0.0:
        raise FlowStabilityError("nominal flow must be finite and positive")
    if not math.isfinite(perturbed_flow_kg_s) or perturbed_flow_kg_s <= 0.0:
        raise FlowStabilityError("perturbed flow must be finite and positive")
    if perturbed_flow_kg_s > nominal_flow_kg_s:
        raise FlowStabilityError(
            "this analysis describes a flow *reduction*; perturbed flow must not "
            "exceed the nominal flow"
        )
    if resolution < 10:
        raise FlowStabilityError("resolution is too coarse")

    header = pressure_drop_squared(geometry, coefficients_nominal,
                                   nominal_flow_kg_s, linear_heating_w_m)

    # Scan downward and take the first flow whose pressure drop matches the
    # header. Scanning downward is what distinguishes the branch the instability
    # drives to from the (unreachable) nominal one.
    low = perturbed_flow_kg_s * 1e-3
    previous_flow = perturbed_flow_kg_s
    previous_value = (pressure_drop_squared(geometry, coefficients_perturbed,
                                            perturbed_flow_kg_s,
                                            linear_heating_w_m) - header)
    for index in range(1, resolution + 1):
        mdot = perturbed_flow_kg_s * (low / perturbed_flow_kg_s) ** (index / resolution)
        value = (pressure_drop_squared(geometry, coefficients_perturbed, mdot,
                                       linear_heating_w_m) - header)
        if value == 0.0:
            settled = mdot
            break
        if (value > 0.0) != (previous_value > 0.0):
            # Bisect inside the bracket.
            lo_m, hi_m = mdot, previous_flow
            lo_v, hi_v = value, previous_value
            for _ in range(120):
                mid = math.sqrt(lo_m * hi_m)
                mid_v = (pressure_drop_squared(geometry, coefficients_perturbed,
                                               mid, linear_heating_w_m) - header)
                if (mid_v > 0.0) == (lo_v > 0.0):
                    lo_m, lo_v = mid, mid_v
                else:
                    hi_m, hi_v = mid, mid_v
                if abs(hi_m - lo_m) / mid < 1e-12:
                    break
            settled = math.sqrt(lo_m * hi_m)
            break
        previous_flow, previous_value = mdot, value
    else:
        settled = perturbed_flow_kg_s

    return ParallelChannelState(
        header_pressure_drop_squared_pa2=header,
        nominal_flow_kg_s=nominal_flow_kg_s,
        perturbed_flow_kg_s=perturbed_flow_kg_s,
        settled_flow_kg_s=settled,
        nominal_outlet_temperature_k=geometry.outlet_temperature_k(
            nominal_flow_kg_s, linear_heating_w_m),
        settled_outlet_temperature_k=geometry.outlet_temperature_k(
            settled, linear_heating_w_m),
        collapsed=settled < 0.5 * nominal_flow_kg_s,
    )
