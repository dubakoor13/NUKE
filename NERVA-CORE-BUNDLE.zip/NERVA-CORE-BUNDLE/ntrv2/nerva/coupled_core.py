"""Coupled core solve: temperature -> cross sections -> k and heating -> temperature.

This is the closure the delivered model lacked. There, power was an external
prescription and material feedback was uniform and one-way
(`resolved_openmc_feedback.py:5`: "There is no reactor kinetics or
reactivity-power feedback"). Here the loop runs to a fixed point:

    T  ->  transport  ->  k, spatial heating  ->  thermal closure  ->  T'

and reports convergence honestly. If it fails to converge,
:attr:`CoupledSolution.converged` is ``False`` and the reason is recorded;
nothing downstream may treat a non-converged solve as a result.

Scope, stated plainly
---------------------
* Reactor power magnitude is an **input** (``target_power_w``). Determining
  power from reactivity is a kinetics problem; ``heritage.kinetics`` supplies
  the Inhour/feedback machinery, and this module reports the emergent
  temperature coefficient so a power coefficient can be formed from it.
* The thermal closure is reduced-order (one representative channel per
  element, single-phase hydrogen, constant properties). It is a convergence
  vehicle, not a heat-transfer validation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from .thermal import nusselt_number
from .transport_backend import CoreState, TransportBackend, TransportResult


@dataclass(frozen=True)
class ThermalParameters:
    """Reduced-order single-channel thermal closure inputs."""

    coolant_inlet_temperature_k: float
    coolant_density_kg_m3: float
    total_mass_flow_kg_s: float
    cp_j_kg_k: float
    channel_flow_area_m2: float
    channel_heated_perimeter_m: float
    channel_length_m: float
    coolant_conductivity_w_m_k: float
    coolant_viscosity_pa_s: float
    coolant_prandtl: float
    fuel_conductivity_w_m_k: float
    ligament_thickness_m: float

    _POSITIVE = (
        "coolant_inlet_temperature_k", "coolant_density_kg_m3",
        "total_mass_flow_kg_s", "cp_j_kg_k", "channel_flow_area_m2",
        "channel_heated_perimeter_m", "channel_length_m",
        "coolant_conductivity_w_m_k", "coolant_viscosity_pa_s",
        "coolant_prandtl", "fuel_conductivity_w_m_k", "ligament_thickness_m",
    )

    def validate(self) -> None:
        for name in self._POSITIVE:
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive, got {value!r}")


@dataclass(frozen=True)
class ThermalSolution:
    """Result of one thermal closure evaluation."""

    fuel_temperature_k: float
    hydrogen_temperature_k: float
    wall_temperature_k: float
    reynolds: float
    heat_transfer_coefficient_w_m2_k: float
    peak_heat_flux_w_m2: float
    energy_balance_residual_w: float


class ThermalClosure(Protocol):
    def solve(self, power_fractions: tuple[float, ...],
              total_power_w: float) -> ThermalSolution: ...


class ChannelThermalClosure:
    """One representative coolant channel per fuel element.

    Per element, with ``m_elem = m_total / n`` and ``P_elem = P_total * f_i``:

        dT_coolant = P_elem / (m_elem * cp)                (energy balance)
        q''        = P_elem / (perimeter * length)
        Re         = rho * v * d_h / mu
        Nu         = thermal.nusselt_number(Re, Pr)
        T_wall     = T_bulk_mean + q'' / h
        T_fuel     = T_wall + q'' * t_lig / k_fuel         (ligament conduction)

    Reported fuel temperature is the hottest element; reported hydrogen
    temperature is the power-weighted bulk mean. Both are exactly the states a
    transport solve consumes, which is what makes the loop closed rather than
    one-way.
    """

    def __init__(self, parameters: ThermalParameters) -> None:
        parameters.validate()
        self.parameters = parameters

    def solve(self, power_fractions: tuple[float, ...],
              total_power_w: float) -> ThermalSolution:
        if not power_fractions:
            raise ValueError("need at least one element power fraction")
        if not math.isfinite(total_power_w) or total_power_w <= 0.0:
            raise ValueError("total reactor power must be finite and positive")
        fraction_sum = math.fsum(power_fractions)
        if abs(fraction_sum - 1.0) > 1e-9:
            raise ValueError(f"power fractions must sum to 1, got {fraction_sum!r}")
        for fraction in power_fractions:
            if fraction < 0.0:
                raise ValueError("power fractions cannot be negative")

        p = self.parameters
        n = len(power_fractions)
        m_element = p.total_mass_flow_kg_s / n
        d_h = 4.0 * p.channel_flow_area_m2 / p.channel_heated_perimeter_m
        velocity = m_element / (p.coolant_density_kg_m3 * p.channel_flow_area_m2)
        reynolds = (p.coolant_density_kg_m3 * velocity * d_h
                    / p.coolant_viscosity_pa_s)
        if reynolds <= 0.0:
            raise ValueError("non-positive Reynolds number")
        h_conv = (nusselt_number(reynolds, p.coolant_prandtl)
                  * p.coolant_conductivity_w_m_k / d_h)

        fuel_temperatures: list[float] = []
        bulk_temperatures: list[float] = []
        outlet_temperatures: list[float] = []
        wall_temperatures: list[float] = []
        heat_fluxes: list[float] = []
        for fraction in power_fractions:
            element_power = total_power_w * fraction
            bulk_out = p.coolant_inlet_temperature_k + element_power / (m_element * p.cp_j_kg_k)
            bulk_mean = 0.5 * (p.coolant_inlet_temperature_k + bulk_out)
            flux = element_power / (p.channel_heated_perimeter_m * p.channel_length_m)
            wall = bulk_mean + flux / h_conv
            fuel = wall + flux * p.ligament_thickness_m / p.fuel_conductivity_w_m_k
            outlet_temperatures.append(bulk_out)
            bulk_temperatures.append(bulk_mean)
            wall_temperatures.append(wall)
            fuel_temperatures.append(fuel)
            heat_fluxes.append(flux)

        peak = max(range(n), key=lambda index: fuel_temperatures[index])
        hydrogen_mean = math.fsum(
            fraction * temperature
            for fraction, temperature in zip(power_fractions, bulk_temperatures)
        )
        # Conservation must be checked on the OUTLET state: the coolant's total
        # enthalpy gain is m*cp*(T_out - T_in). Using the bulk mean here would
        # only account for half the rise and would report a 50% energy defect
        # for a perfectly conservative closure.
        carried = math.fsum(
            m_element * p.cp_j_kg_k * (temperature - p.coolant_inlet_temperature_k)
            for temperature in outlet_temperatures
        )
        return ThermalSolution(
            fuel_temperature_k=float(fuel_temperatures[peak]),
            hydrogen_temperature_k=float(hydrogen_mean),
            wall_temperature_k=float(wall_temperatures[peak]),
            reynolds=float(reynolds),
            heat_transfer_coefficient_w_m2_k=float(h_conv),
            peak_heat_flux_w_m2=float(max(heat_fluxes)),
            energy_balance_residual_w=float(carried - total_power_w),
        )


# ------------------------------------------------------------------ the loop


@dataclass(frozen=True)
class CouplingParameters:
    """Controls for the outer Picard iteration."""

    target_power_w: float
    temperature_tolerance_k: float = 1.0
    k_tolerance: float = 1.0e-4
    max_iterations: int = 50
    relaxation: float = 0.7

    def validate(self) -> None:
        if not math.isfinite(self.target_power_w) or self.target_power_w <= 0.0:
            raise ValueError("target power must be finite and positive")
        if self.temperature_tolerance_k <= 0.0:
            raise ValueError("temperature tolerance must be positive")
        if self.k_tolerance <= 0.0:
            raise ValueError("k tolerance must be positive")
        if self.max_iterations < 1:
            raise ValueError("max_iterations must be at least 1")
        if not 0.0 < self.relaxation <= 1.0:
            raise ValueError(
                "relaxation must lie in (0, 1]; relaxation is a damping factor, "
                "and values above 1 would amplify the iteration"
            )


@dataclass(frozen=True)
class IterationRecord:
    index: int
    fuel_temperature_k: float
    hydrogen_temperature_k: float
    k_eff: float
    temperature_change_k: float
    k_change: float
    relaxation_used: float


@dataclass(frozen=True)
class CoupledSolution:
    converged: bool
    reason: str
    iterations: int
    k_eff: float
    k_sigma: float
    fuel_temperature_k: float
    hydrogen_temperature_k: float
    wall_temperature_k: float
    power_w: float
    transport: TransportResult
    thermal: ThermalSolution
    temperature_coefficient_per_k: float | None
    records: tuple[IterationRecord, ...]

    @property
    def synthetic(self) -> bool:
        return self.transport.synthetic


def solve_coupled_core(
    backend: TransportBackend,
    initial_state: CoreState,
    thermal: ThermalClosure,
    parameters: CouplingParameters,
    *,
    thermal_parameters: ThermalParameters | None = None,
) -> CoupledSolution:
    """Iterate transport and thermal closures to a consistent temperature state.

    Convergence requires BOTH the temperature change and the eigenvalue change
    to fall below tolerance, because a loop can hold temperatures fixed while k
    still drifts (and vice versa).
    """
    parameters.validate()
    backend.require_ready()

    state = initial_state
    records: list[IterationRecord] = []
    result = backend.run(state)
    thermal_solution = thermal.solve(result.fuel_power_fraction,
                                     parameters.target_power_w)

    converged = False
    reason = f"reached max_iterations={parameters.max_iterations}"
    previous_k = result.k_eff
    previous_fuel = state.fuel_temperature_k
    previous_hydrogen = state.hydrogen_temperature_k

    for index in range(1, parameters.max_iterations + 1):
        new_fuel = (previous_fuel
                    + parameters.relaxation
                    * (thermal_solution.fuel_temperature_k - previous_fuel))
        new_hydrogen = (previous_hydrogen
                        + parameters.relaxation
                        * (thermal_solution.hydrogen_temperature_k - previous_hydrogen))
        if new_fuel <= 0.0 or new_hydrogen <= 0.0:
            return CoupledSolution(
                converged=False, reason="iteration produced a non-physical temperature",
                iterations=index, k_eff=result.k_eff, k_sigma=result.k_sigma,
                fuel_temperature_k=new_fuel, hydrogen_temperature_k=new_hydrogen,
                wall_temperature_k=thermal_solution.wall_temperature_k,
                power_w=parameters.target_power_w, transport=result,
                thermal=thermal_solution, temperature_coefficient_per_k=None,
                records=tuple(records),
            )

        state = state.with_changes(fuel_temperature_k=new_fuel,
                                   hydrogen_temperature_k=new_hydrogen)
        result = backend.run(state)
        thermal_solution = thermal.solve(result.fuel_power_fraction,
                                         parameters.target_power_w)

        temperature_change = max(
            abs(thermal_solution.fuel_temperature_k - new_fuel),
            abs(thermal_solution.hydrogen_temperature_k - new_hydrogen),
        )
        k_change = abs(result.k_eff - previous_k)
        records.append(IterationRecord(
            index=index,
            fuel_temperature_k=new_fuel,
            hydrogen_temperature_k=new_hydrogen,
            k_eff=result.k_eff,
            temperature_change_k=temperature_change,
            k_change=k_change,
            relaxation_used=parameters.relaxation,
        ))
        previous_k = result.k_eff
        previous_fuel = new_fuel
        previous_hydrogen = new_hydrogen

        if (temperature_change <= parameters.temperature_tolerance_k
                and k_change <= parameters.k_tolerance):
            converged = True
            reason = (f"temperature change {temperature_change:.4g} K <= "
                      f"{parameters.temperature_tolerance_k} K and |dk| "
                      f"{k_change:.4g} <= {parameters.k_tolerance}")
            break

    coefficient = _temperature_coefficient(backend, state, parameters)

    return CoupledSolution(
        converged=converged,
        reason=reason,
        iterations=len(records),
        k_eff=result.k_eff,
        k_sigma=result.k_sigma,
        fuel_temperature_k=previous_fuel,
        hydrogen_temperature_k=previous_hydrogen,
        wall_temperature_k=thermal_solution.wall_temperature_k,
        power_w=parameters.target_power_w,
        transport=result,
        thermal=thermal_solution,
        temperature_coefficient_per_k=coefficient,
        records=tuple(records),
    )


def _temperature_coefficient(backend: TransportBackend, state: CoreState,
                             parameters: CouplingParameters,
                             delta_k: float = 10.0) -> float | None:
    """Emergent dk/dT of the *solved* system, by central difference.

    The isothermal material coefficient and this quantity differ: here the
    heating distribution also responds, so what emerges includes the spatial
    feedback. Returns ``None`` if the perturbation leaves the valid domain.
    """
    try:
        hotter = backend.run(state.with_changes(
            fuel_temperature_k=state.fuel_temperature_k + delta_k))
        cooler = backend.run(state.with_changes(
            fuel_temperature_k=state.fuel_temperature_k - delta_k))
    except (ValueError, ArithmeticError):
        return None
    return (hotter.k_eff - cooler.k_eff) / (2.0 * delta_k)


# ------------------------------------------------- critical (power) solve


@dataclass(frozen=True)
class CriticalPowerParameters:
    """Controls for the outer power search."""

    power_lower_w: float
    power_upper_w: float
    k_tolerance: float = 1.0e-4
    inner_temperature_tolerance_k: float = 1.0
    inner_max_iterations: int = 60
    relaxation: float = 0.7
    max_outer_iterations: int = 50

    def validate(self) -> None:
        if not math.isfinite(self.power_lower_w) or self.power_lower_w <= 0.0:
            raise ValueError("power_lower_w must be finite and positive")
        if not math.isfinite(self.power_upper_w):
            raise ValueError("power_upper_w must be finite")
        if self.power_upper_w <= self.power_lower_w:
            raise ValueError("power_upper_w must exceed power_lower_w")
        if self.k_tolerance <= 0.0:
            raise ValueError("k_tolerance must be positive")
        if self.max_outer_iterations < 1:
            raise ValueError("max_outer_iterations must be at least 1")


@dataclass(frozen=True)
class CriticalPowerResult:
    """Solved steady state in which the core is exactly critical."""

    converged: bool
    reason: str
    power_w: float
    k_eff: float
    k_sigma: float
    solution: CoupledSolution | None
    history: tuple[tuple[float, float], ...] = ()

    @property
    def synthetic(self) -> bool:
        return self.solution.synthetic if self.solution else True

    @property
    def power_density_ratio(self) -> float | None:
        """k is centred on 1.0 by construction; expose the achieved offset."""
        return None if self.solution is None else self.k_eff - 1.0


def solve_critical_power(
    backend: TransportBackend,
    initial_state: CoreState,
    thermal: ThermalClosure,
    parameters: CriticalPowerParameters,
) -> CriticalPowerResult:
    """Find the steady reactor power at which the coupled core is critical.

    This is the closure that turns power into a *result*. A critical,
    steady, self-consistent reactor satisfies ``k_eff(P) = 1`` where the
    temperature inside ``k_eff`` comes from the power ``P`` itself. The solve is
    an outer bisection on power wrapping the inner temperature Picard loop.

    Because the temperature coefficient is negative for any real core, ``k``
    falls as ``P`` rises, so the root is bracketed and unique. If the bracket
    does not change sign the solve reports that instead of returning an
    arbitrary power that happens to sit in the interval.
    """
    parameters.validate()
    backend.require_ready()

    history: list[tuple[float, float]] = []
    warm_start = initial_state

    def evaluate(power: float) -> tuple[float, float, CoupledSolution | None]:
        nonlocal warm_start
        coupling = CouplingParameters(
            target_power_w=power,
            temperature_tolerance_k=parameters.inner_temperature_tolerance_k,
            max_iterations=parameters.inner_max_iterations,
            relaxation=parameters.relaxation,
        )
        solution = solve_coupled_core(backend, warm_start, thermal, coupling)
        if solution.converged:
            warm_start = warm_start.with_changes(
                fuel_temperature_k=solution.fuel_temperature_k,
                hydrogen_temperature_k=solution.hydrogen_temperature_k,
            )
        history.append((power, solution.k_eff))
        return solution.k_eff, solution.k_sigma, solution

    k_lo, _, sol_lo = evaluate(parameters.power_lower_w)
    k_hi, _, sol_hi = evaluate(parameters.power_upper_w)
    if (k_lo - 1.0) * (k_hi - 1.0) > 0.0:
        return CriticalPowerResult(
            converged=False,
            reason=(
                f"k does not bracket unity over the power range "
                f"[{parameters.power_lower_w:.4g}, {parameters.power_upper_w:.4g}] W: "
                f"k(low)={k_lo:.5f}, k(high)={k_hi:.5f}. The core is either "
                f"subcritical at all powers or supercritical at all powers; "
                f"criticality must be sought with the control drums instead."
            ),
            power_w=parameters.power_upper_w,
            k_eff=k_hi,
            k_sigma=sol_hi.k_sigma if sol_hi else float("nan"),
            solution=sol_hi,
            history=tuple(history),
        )

    lo, hi = parameters.power_lower_w, parameters.power_upper_w
    best_power, best_k, best_solution = hi, k_hi, sol_hi
    for _ in range(parameters.max_outer_iterations):
        mid = math.sqrt(lo * hi)  # geometric bisection suits power ranges
        k_mid, _, solution = evaluate(mid)
        best_power, best_k, best_solution = mid, k_mid, solution
        if abs(k_mid - 1.0) <= parameters.k_tolerance:
            return CriticalPowerResult(
                converged=True,
                reason=f"|k-1| = {abs(k_mid - 1.0):.3g} <= {parameters.k_tolerance}",
                power_w=mid,
                k_eff=k_mid,
                k_sigma=solution.k_sigma if solution else float("nan"),
                solution=solution,
                history=tuple(history),
            )
        if (k_mid - 1.0) > 0.0:
            lo = mid
        else:
            hi = mid

    return CriticalPowerResult(
        converged=False,
        reason=(f"reached max_outer_iterations={parameters.max_outer_iterations} "
                f"without |k-1| <= {parameters.k_tolerance}"),
        power_w=best_power,
        k_eff=best_k,
        k_sigma=best_solution.k_sigma if best_solution else float("nan"),
        solution=best_solution,
        history=tuple(history),
    )
