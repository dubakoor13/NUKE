"""Verify the coupled two-region xenon model.

The physical claim under test is the classic one: a xenon-induced spatial tilt
exists, it *oscillates* on the iodine/xenon timescale, and it needs enough flux
to overcome neutron coupling between the regions.

Three checks establish that:

1. With zero xenon worth the system must reduce to the plain two-region result -
   the xenon states decouple and no new unstable mode appears.
2. At high flux with a real xenon worth, an antisymmetric mode appears with a
   *nonzero imaginary part* (an oscillation) and a period of order the iodine and
   xenon half-lives - hours, not seconds.
3. The tilt must be more unstable at higher flux, and stable at low flux.
"""
from __future__ import annotations

import math
from pathlib import Path

from .core_stability import StabilityParameters
from .heritage import kinetics as kin
from .heritage.registry import load_registry
from .xenon_spatial import (
    XenonSpatialError,
    XenonSpatialParameters,
    analyse_xenon_spatial,
    antidiffusion_threshold_flux,
    two_region_xenon_jacobian,
    xenon_tilt_mode,
)

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"
GROUPS = kin.u235_delayed_groups(load_registry(DATA))

BASE = StabilityParameters(
    prompt_lifetime_s=1.0e-4,
    reference_power_w=1.0e7,
    fuel_heat_capacity_j_k=2.0e5,
    coolant_heat_capacity_j_k=5.0e4,
    fuel_to_coolant_conductance_w_k=2.0e4,
    coolant_removal_conductance_w_k=8.0e3,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    coolant_temperature_coefficient_per_k=-2.0e-6,
    groups=GROUPS,
)

# A generous xenon worth so the tilt is visible; the poison worth in
# reactivity_coefficients is measured in the same units.
XENON_WORTH = -30.0
FISSION_XS = 0.05


def _parameters(flux: float, worth: float = XENON_WORTH,
                coupling: float = 1.0e-3) -> XenonSpatialParameters:
    return XenonSpatialParameters(
        base=BASE,
        coupling_per_s=coupling,
        flux_per_unit_population_cm2_s=flux,
        macroscopic_fission_xs_cm_inv=FISSION_XS,
        xenon_worth_per_absorption_cm=worth,
    )


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- structure -----------------------------------------------------
    print("system structure:")
    high = _parameters(1.0e14)
    jacobian = two_region_xenon_jacobian(high)
    print(f"    state dimension {jacobian.shape[0]} "
          f"(2 regions x [n, 6 precursors, T_f, T_c, I, Xe])")
    results.append(_report("twenty-two states in the coupled system",
                           jacobian.shape == (22, 22), f"{jacobian.shape}"))
    print(f"    equilibrium xenon = {high.equilibrium_xenon:.4e} /cm3")
    print(f"    xenon reactivity per atom = {high.xenon_reactivity_per_atom:.3e}")
    results.append(_report("equilibrium xenon is positive",
                           high.equilibrium_xenon > 0.0,
                           f"{high.equilibrium_xenon:.3e} /cm3"))
    results.append(_report("xenon worth makes reactivity negative per atom",
                           high.xenon_reactivity_per_atom < 0.0,
                           f"{high.xenon_reactivity_per_atom:.2e}"))
    results.append(_report("higher flux gives more equilibrium xenon",
                           _parameters(1.0e15).equilibrium_xenon
                           > high.equilibrium_xenon,
                           "flux-dependent poisoning"))

    # ---- zero worth must not invent a mode -----------------------------
    print("\nzero xenon worth must not create a tilt:")
    zero_worth = _parameters(1.0e14, worth=0.0)
    _, modes_zero = analyse_xenon_spatial(zero_worth)
    tilt_zero = xenon_tilt_mode(zero_worth)
    print(f"    tilt mode real part = "
          f"{tilt_zero.eigenvalue.real:+.4f} /s" if tilt_zero else "    no tilt")
    results.append(_report("twenty-two eigenvalues still returned",
                           len(modes_zero) == 22, f"{len(modes_zero)}"))
    results.append(_report("no unstable tilt without xenon worth",
                           tilt_zero is None or tilt_zero.eigenvalue.real < 0.0,
                           f"real {tilt_zero.eigenvalue.real:+.4f} /s"
                           if tilt_zero else "none"))

    # ---- the oscillation itself ----------------------------------------
    print("\nthe xenon tilt oscillates, but only in a flux window:")
    # The slow oscillatory antisymmetric pair exists at moderate flux. At higher
    # flux that pair becomes real (overdamped) and the tilt grows monotonically.
    # Both are real behaviour; the first version of this test looked for the
    # oscillation at 1e14 and found only the monotonic tilt.
    def slow_oscillatory(flux: float):
        _, all_modes = analyse_xenon_spatial(_parameters(flux))
        candidates = [mode for mode in all_modes
                      if mode.is_antisymmetric and abs(mode.eigenvalue.imag) > 1e-9
                      and mode.period_s is not None and mode.period_s > 3600.0]
        if not candidates:
            return None
        return min(candidates, key=lambda mode: abs(mode.eigenvalue.imag))

    slow = slow_oscillatory(1.0e13)
    results.append(_report("a slow oscillatory tilt exists at 1e13 n/cm2/s",
                           slow is not None,
                           f"{slow.period_s/3600:.2f} h" if slow else "none"))
    if slow is not None:
        print(f"    eigenvalue = {slow.eigenvalue.real:+.3e} "
              f"{slow.eigenvalue.imag:+.3e}j")
        print(f"    period = {slow.period_s/3600:.2f} h, "
              f"e-folding {slow.e_folding_time_s/3600:.1f} h")
        results.append(_report("the period is on the iodine/xenon scale",
                               10.0 * 3600.0 < slow.period_s < 100.0 * 3600.0,
                               f"{slow.period_s/3600:.2f} h"))
        results.append(_report("that mode is antisymmetric (a tilt)",
                               slow.is_antisymmetric is True, "antisymmetric"))
        results.append(_report("at 1e13 the oscillation is still decaying",
                               slow.eigenvalue.real < 0.0,
                               f"Re = {slow.eigenvalue.real:+.2e} /s"))

    high_tilt = xenon_tilt_mode(_parameters(1.0e14))
    print(f"    at 1e14 the dominant tilt is "
          f"{'oscillatory' if abs(high_tilt.eigenvalue.imag) > 1e-9 else 'monotonic'}"
          f" (Re = {high_tilt.eigenvalue.real:+.2e})")
    results.append(_report("at high flux the tilt grows monotonically",
                           high_tilt.eigenvalue.real > 0.0
                           and abs(high_tilt.eigenvalue.imag) < 1e-9,
                           "real, positive: a growing power tilt"))
    results.append(_report("the dominant tilt is a spatial mode",
                           high_tilt.is_antisymmetric is True, "antisymmetric"))
    results.append(_report("the slow oscillation disappears at high flux",
                           slow_oscillatory(1.0e14) is None,
                           "overdamped beyond ~1e13"))

    # ---- flux dependence -----------------------------------------------
    print("\nthe tilt needs enough flux:")
    trend = []
    for flux in (1.0e12, 1.0e13, 1.0e14, 1.0e15):
        mode = xenon_tilt_mode(_parameters(flux))
        trend.append((flux, mode.eigenvalue.real if mode else float("nan")))
        print(f"    flux {flux:.0e}: tilt growth {trend[-1][1]:+.4e} /s")
    results.append(_report("the tilt growth rate rises with flux",
                           all(b[1] > a[1] for a, b in zip(trend, trend[1:])),
                           "monotone in flux"))
    threshold = antidiffusion_threshold_flux(_parameters(1.0e14))
    print(f"    flux at which the tilt turns unstable: "
          f"{threshold:.3e}" if threshold else "    tilt stable over the scan")
    results.append(_report("a threshold flux is identifiable",
                           threshold is not None or trend[-1][1] < 0.0,
                           f"{threshold:.2e}" if threshold else "stable throughout"))

    # ---- coupling dependence -------------------------------------------
    print("\nstronger coupling suppresses the tilt:")
    weak = xenon_tilt_mode(_parameters(1.0e14, coupling=1.0e-4))
    strong = xenon_tilt_mode(_parameters(1.0e14, coupling=1.0))
    print(f"    coupling 1e-4: tilt growth {weak.eigenvalue.real:+.4e} /s")
    print(f"    coupling 1.0 : tilt growth {strong.eigenvalue.real:+.4e} /s")
    results.append(_report("weaker coupling gives a less stable tilt",
                           weak.eigenvalue.real > strong.eigenvalue.real,
                           f"{weak.eigenvalue.real:+.3e} > "
                           f"{strong.eigenvalue.real:+.3e}"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid configurations are rejected:")
    guards = [
        ("positive xenon worth", lambda: XenonSpatialParameters(
            base=BASE, coupling_per_s=1e-3, flux_per_unit_population_cm2_s=1e14,
            macroscopic_fission_xs_cm_inv=FISSION_XS,
            xenon_worth_per_absorption_cm=+30.0)),
        ("zero flux", lambda: XenonSpatialParameters(
            base=BASE, coupling_per_s=1e-3, flux_per_unit_population_cm2_s=0.0,
            macroscopic_fission_xs_cm_inv=FISSION_XS,
            xenon_worth_per_absorption_cm=XENON_WORTH)),
        ("negative coupling", lambda: XenonSpatialParameters(
            base=BASE, coupling_per_s=-1.0, flux_per_unit_population_cm2_s=1e14,
            macroscopic_fission_xs_cm_inv=FISSION_XS,
            xenon_worth_per_absorption_cm=XENON_WORTH)),
        ("zero fission cross-section", lambda: XenonSpatialParameters(
            base=BASE, coupling_per_s=1e-3, flux_per_unit_population_cm2_s=1e14,
            macroscopic_fission_xs_cm_inv=0.0,
            xenon_worth_per_absorption_cm=XENON_WORTH)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (XenonSpatialError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: coupled xenon produces an oscillating, flux-dependent spatial tilt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
