"""Verify the acceptance-gate reporter cannot be talked into "complete".

The value of a gate reporter is entirely in its ability to say no. These checks
prove that:

* an empty evidence bundle fails every gate;
* a single missing condition blocks its gate even when everything else holds;
* a fully evidenced bundle does pass, so the gates are satisfiable in principle
  and are not written to fail forever;
* the live repository probe reports the truth about the current state.
"""
from __future__ import annotations

import json
from pathlib import Path

from .acceptance_gates import (
    MET,
    NOT_MET,
    PARTIAL,
    Evidence,
    evaluate,
    probe_repository,
)


def nerva_registry_unresolved() -> int:
    """Count heritage entries whose note still declares an open conflict.

    Read from the data files rather than from the gate's own evidence bundle, so
    the comparison is between two independent readings of the same repository.
    """
    data_dir = Path(__file__).parent / "heritage" / "data"
    count = 0
    for path in sorted(data_dir.glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        entries = payload["entries"] if isinstance(payload, dict) else payload
        count += sum(1 for e in entries
                     if "unresolved" in str(e.get("note", "")).lower())
    return count


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def _fully_evidenced() -> Evidence:
    return Evidence(
        baseline_declared=True, baseline_variant="XE-Prime PRA",
        heritage_measured=27, heritage_design_target=3,
        heritage_with_locator=31, unresolved_conflicts=0,
        transport_runs_completed=4, transport_backend_ready=True,
        transport_statepoint_hashes=20, nuclear_data_recorded=True,
        coupled_solves_converged=3, thermal_residuals_relative=[1e-9],
        deposition_source_real=True, unresolved_heat_accounted=True,
        pump_boundary_solved=True, pump_characteristics_heritage=True,
        header_inventories_conservative=True, phase_domain_verified=True,
        shaft_residuals_relative=[1e-9], shaft_closure_heritage=True,
        nozzle_throat_closed=True,
        independent_oracle_checks=70, grid_sensitivity_studies=1,
        timestep_sensitivity_studies=1,
        external_benchmarks=3, benchmark_error_bands_reported=True,
        doctor_available=True, pinned_data=True,
        deterministic_reruns_verified=True,
        reference_invocations_documented=True,
    )


def main() -> int:
    results: list[bool] = []

    # ---- empty evidence fails everything -------------------------------
    print("empty evidence bundle:")
    empty = evaluate(Evidence())
    results.append(_report("all eight gates are NOT MET",
                           all(g.status == NOT_MET for g in empty.gates),
                           empty.summary()))
    results.append(_report("report is not complete",
                           empty.complete is False, f"complete={empty.complete}"))
    results.append(_report("no gate claims satisfaction",
                           all(not g.satisfied for g in empty.gates),
                           "zero satisfied conditions"))

    # ---- full evidence passes -----------------------------------------
    print("\nfully evidenced bundle (gates must be satisfiable):")
    full = evaluate(_fully_evidenced())
    results.append(_report("all eight gates are MET",
                           all(g.status == MET for g in full.gates),
                           full.summary()))
    results.append(_report("report is complete", full.complete is True,
                           f"complete={full.complete}"))

    # ---- one missing condition blocks its gate ------------------------
    print("\na single missing condition blocks only its own gate:")
    broken = _fully_evidenced()
    broken.transport_runs_completed = 0
    report = evaluate(broken)
    gate2 = report.gates[1]
    results.append(_report("gate 2 drops out of MET", gate2.status != MET,
                           f"gate 2 = {gate2.status}"))
    results.append(_report("other gates stay MET",
                           all(g.status == MET for i, g in enumerate(report.gates)
                               if i != 1),
                           f"{report.met}/8 met"))
    results.append(_report("missing text names the actual gap",
                           any("transport run" in m for m in gate2.missing),
                           gate2.missing[0] if gate2.missing else ""))

    # ---- synthetic inputs block the physics gates ---------------------
    print("\nsynthetic inputs block the physics gates even when they converge:")
    synthetic = _fully_evidenced()
    synthetic.deposition_source_real = False
    synthetic.pump_characteristics_heritage = False
    synthetic.shaft_closure_heritage = False
    report = evaluate(synthetic)
    gates = {g.number: g.status for g in report.gates}
    results.append(_report("gate 3 (thermal) is blocked by synthetic deposition",
                           gates[3] != MET, f"gate 3 = {gates[3]}"))
    results.append(_report("gate 4 (hydraulic) is blocked by synthetic curves",
                           gates[4] != MET, f"gate 4 = {gates[4]}"))
    results.append(_report("gate 5 (shaft) is blocked by synthetic curves",
                           gates[5] != MET, f"gate 5 = {gates[5]}"))
    results.append(_report("gates that remain fully evidenced still pass",
                           gates[6] == MET and gates[8] == MET,
                           f"gate 6 = {gates[6]}, gate 8 = {gates[8]}"))

    # ---- partial status is reachable and used -------------------------
    print("\nlive repository probe:")
    partial = evaluate(probe_repository())
    statuses = {gate.number: gate.status for gate in partial.gates}
    results.append(_report("gates 6 and 8 are MET (earned offline)",
                           statuses[6] == MET and statuses[8] == MET,
                           f"gate 6 = {statuses[6]}, gate 8 = {statuses[8]}"))
    results.append(_report("gates 2 and 7 remain NOT MET",
                           statuses[2] == NOT_MET and statuses[7] == NOT_MET,
                           f"gate 2 = {statuses[2]}, gate 7 = {statuses[7]}"))
    results.append(_report("live probe has partial gates (work is visible)",
                           any(gate.status == PARTIAL for gate in partial.gates),
                           f"{sum(1 for gate in partial.gates if gate.status == PARTIAL)} partial"))
    results.append(_report("the met count matches the gate list",
                           partial.met == sum(1 for gate in partial.gates
                                              if gate.status == MET),
                           partial.summary()))
    results.append(_report("gate 1 is MET (baseline cross-checked against XE0 data)",
                           statuses[1] == MET,
                           f"gate 1 = {statuses[1]}, missing={partial.gates[0].missing}"))
    results.append(_report("report is still not complete", partial.complete is False,
                           f"complete={partial.complete}"))
    # The conflict checks are deliberately state-free in both directions: they
    # assert the gate agrees with the registry, not that a conflict exists. An
    # earlier version asserted "unresolved conflict" was reported, which turned
    # a resolved conflict into a test failure and would have punished fixing it.
    results.append(_report("gate 1 conflict status agrees with the registry",
                           ("unresolved source conflict" in partial.gates[0].missing)
                           == (nerva_registry_unresolved() > 0),
                           f"registry has {nerva_registry_unresolved()} unresolved, "
                           f"gate missing list = {partial.gates[0].missing}"))

    # ---- serialisation -------------------------------------------------
    print("\nserialisation:")
    payload = partial.to_dict()
    results.append(_report("to_dict is JSON-serialisable",
                           isinstance(payload, dict) and "gates" in payload
                           and len(payload["gates"]) == 8,
                           f"{len(payload['gates'])} gates"))
    results.append(_report("summary counts agree with gate list",
                           payload["summary"].startswith(f"{partial.met}/8"),
                           payload["summary"]))

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: acceptance gates are evidence-driven and cannot overclaim")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
