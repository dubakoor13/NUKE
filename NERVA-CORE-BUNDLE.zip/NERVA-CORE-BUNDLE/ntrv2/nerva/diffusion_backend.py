"""Deterministic diffusion backend for the coupled core.

Until now the coupled core could run only on the analytic surrogate
(``MockTransportBackend``) or on real Monte Carlo (``OpenMCTransportBackend``,
unavailable without a binary). This adds the middle ground: a deterministic
multigroup diffusion solve, so the coupled core, the reactivity coefficients and
the transients can all run on **actual physics** without needing OpenMC.

The backend maps a full cylindrical core onto a bare slab by treating the radial
direction as leakage through a geometric buckling - the standard "axial slab plus
radial buckling" reduction of Ch. 8. That is an approximation and is labelled as
one: it is not a 3-D solution.

Cross-sections are functions of temperature supplied by the caller, so no
temperature dependence is invented here.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

from .diffusion import (
    DiffusionError,
    MultigroupCrossSections,
    geometric_buckling,
    solve_slab_eigenvalue,
)
from .transport_backend import CoreState, TransportBackend, TransportResult


class DiffusionBackendError(ValueError):
    """Raised when the diffusion backend cannot evaluate a state."""


@dataclass(frozen=True)
class TemperatureDependentCrossSections:
    """Multigroup cross-sections as functions of fuel temperature.

    Each must return per-group tuples. The caller owns the temperature
    dependence entirely; the backend only evaluates it, so no Doppler model is
    smuggled in.
    """

    diffusion_coefficient_cm: Callable[[float], tuple[float, ...]]
    sigma_absorption_cm: Callable[[float], tuple[float, ...]]
    nu_sigma_fission_cm: Callable[[float], tuple[float, ...]]
    chi: tuple[float, ...]
    scatter_matrix: Callable[[float], tuple[tuple[float, ...], ...]]

    def at(self, temperature_k: float) -> MultigroupCrossSections:
        if not math.isfinite(temperature_k) or temperature_k <= 0.0:
            raise DiffusionBackendError(
                f"fuel temperature must be finite and positive, got {temperature_k!r}"
            )
        return MultigroupCrossSections(
            diffusion_coefficient_cm=self.diffusion_coefficient_cm(temperature_k),
            sigma_absorption_cm=self.sigma_absorption_cm(temperature_k),
            nu_sigma_fission_cm=self.nu_sigma_fission_cm(temperature_k),
            chi=self.chi,
            scatter_matrix=self.scatter_matrix(temperature_k),
        )


@dataclass(frozen=True)
class DiffusionTransportBackend(TransportBackend):
    """Deterministic multigroup diffusion as a transport backend.

    The slab is the axial core length; the radial direction enters as an added
    geometric buckling, so total ``B^2 = B_z^2 + B_r^2``. Element power fractions
    come from the fundamental-mode flux sampled at element centres.
    """

    cross_sections: TemperatureDependentCrossSections
    core_length_cm: float
    radius_cm: float
    element_count: int = 7
    extrapolation_cm: float = 2.0
    mesh_intervals: int = 120
    name: str = "diffusion-1d"
    synthetic: bool = False

    def __post_init__(self) -> None:
        if not math.isfinite(self.core_length_cm) or self.core_length_cm <= 0.0:
            raise DiffusionBackendError("core length must be finite and positive")
        if not math.isfinite(self.radius_cm) or self.radius_cm <= 0.0:
            raise DiffusionBackendError("core radius must be finite and positive")
        if self.element_count < 1:
            raise DiffusionBackendError("element count must be at least 1")
        if self.mesh_intervals < 4:
            raise DiffusionBackendError("at least 4 mesh intervals are required")

    def preflight(self) -> list[str]:
        # Everything this backend needs is a caller-supplied function, so there
        # is nothing environmental to check.
        return []

    @property
    def radial_buckling_squared(self) -> float:
        """Radial leakage as a buckling, from the cylinder term of Table 8.2."""
        return geometric_buckling(
            "cylinder",
            {"R": self.radius_cm, "H": self.core_length_cm},
            self.extrapolation_cm,
        ) - geometric_buckling("slab", {"L": self.core_length_cm},
                               self.extrapolation_cm)

    def run(self, state: CoreState) -> TransportResult:
        try:
            xs = self.cross_sections.at(state.fuel_temperature_k)
        except DiffusionBackendError:
            raise
        except Exception as exc:  # noqa: BLE001 - the caller's functions are foreign
            raise DiffusionBackendError(
                f"the supplied cross-section functions failed at "
                f"{state.fuel_temperature_k} K: {exc}"
            ) from exc

        # Add the radial leakage to every group's removal term by treating it as
        # an extra absorption: Sigma_a_eff = Sigma_a + D * B_r^2. This is the
        # standard reduction for a slab with transverse leakage.
        radial_b2 = self.radial_buckling_squared
        effective_absorption = tuple(
            absorption + d * radial_b2
            for absorption, d in zip(xs.sigma_absorption_cm,
                                     xs.diffusion_coefficient_cm))
        effective = MultigroupCrossSections(
            diffusion_coefficient_cm=xs.diffusion_coefficient_cm,
            sigma_absorption_cm=effective_absorption,
            nu_sigma_fission_cm=xs.nu_sigma_fission_cm,
            chi=xs.chi,
            scatter_matrix=xs.scatter_matrix,
        )

        try:
            solution = solve_slab_eigenvalue(
                effective, self.core_length_cm, self.extrapolation_cm,
                mesh_intervals=self.mesh_intervals)
        except DiffusionError as exc:
            raise DiffusionBackendError(
                f"the diffusion solve failed for fuel at "
                f"{state.fuel_temperature_k} K: {exc}"
            ) from exc

        if not solution.converged:
            raise DiffusionBackendError(
                f"the diffusion power iteration did not converge "
                f"(residual {solution.power_iteration_residual:.2e})"
            )

        return TransportResult(
            k_eff=solution.k_effective,
            # A deterministic solve carries no Monte Carlo statistical error. A
            # zero here means "not a sampled quantity", and callers must not
            # interpret it as a very precise one.
            k_sigma=0.0,
            fuel_power_fraction=self._axial_power_fractions(),
            leakage_fraction=self._leakage_fraction(xs, solution.k_effective),
            backend=self.name,
            synthetic=False,
            provenance={
                "kind": "deterministic-diffusion",
                "groups": xs.groups,
                "fuel_temperature_k": state.fuel_temperature_k,
                "core_length_cm": self.core_length_cm,
                "radius_cm": self.radius_cm,
                "radial_buckling_squared": radial_b2,
                "axial_buckling_squared": solution.buckling_squared,
                "mesh_intervals": self.mesh_intervals,
                "power_iteration_residual": solution.power_iteration_residual,
                "approximation": "1-D axial slab plus transverse radial "
                                 "buckling; NOT a 3-D solution",
                "statistics": "deterministic - k_sigma is not a sampling error",
            },
        )

    def _axial_power_fractions(self) -> tuple[float, ...]:
        """Chopped-sine axial power sampled at element centres (Eq. 8.23).

        The slab is discretised into ``element_count`` axial zones; each zone's
        share of the integral of the flux is its power fraction, which is what
        the transport-result contract requires.
        """
        extrapolated = self.core_length_cm + 2.0 * self.extrapolation_cm
        edges = [self.core_length_cm * index / self.element_count
                 for index in range(self.element_count + 1)]
        weights: list[float] = []
        for left, right in zip(edges, edges[1:]):
            # Antiderivative of sin(pi(z+d)/L~).
            scale = extrapolated / math.pi
            upper = math.pi / extrapolated * (right + self.extrapolation_cm)
            lower = math.pi / extrapolated * (left + self.extrapolation_cm)
            weights.append(scale * (math.cos(lower) - math.cos(upper)))
        total = math.fsum(weights)
        if total <= 0.0 or not math.isfinite(total):
            raise DiffusionBackendError("the axial power shape integrated to zero")
        return tuple(weight / total for weight in weights)

    def _leakage_fraction(self, true_xs: MultigroupCrossSections,
                          k_eff: float) -> float:
        """Fraction of neutrons lost to leakage, ``1 - k_eff/k_inf``.

        ``k_inf`` uses the *true* absorption cross-section (before the radial
        buckling was folded in as pseudo-absorption), so this is the genuine
        leakage share required by the transport-result contract.
        """
        nu_sigma_f = math.fsum(true_xs.nu_sigma_fission_cm)
        absorption = math.fsum(true_xs.sigma_absorption_cm)
        if absorption <= 0.0 or nu_sigma_f <= 0.0:
            return 0.0
        k_inf = nu_sigma_f / absorption
        if k_inf <= 0.0:
            return 0.0
        return max(0.0, min(1.0, 1.0 - k_eff / k_inf))


def one_group_temperature_cross_sections(
    *, d0_cm: float, d_slope_per_k: float,
    sa0_cm: float, sa_slope_per_k: float,
    nusf0_cm: float, nusf_slope_per_k: float,
) -> TemperatureDependentCrossSections:
    """A linearly temperature-dependent one-group cross-section set.

    Linear by construction so the response is exactly differentiable, which is
    what makes the reactivity coefficients measurable without interpolation
    noise. The slopes are supplied by the caller.
    """
    for name, value in (("d0_cm", d0_cm), ("sa0_cm", sa0_cm), ("nusf0_cm", nusf0_cm)):
        if not math.isfinite(value) or value <= 0.0:
            raise DiffusionBackendError(f"{name} must be finite and positive")
    for name, value in (("d_slope_per_k", d_slope_per_k),
                        ("sa_slope_per_k", sa_slope_per_k),
                        ("nusf_slope_per_k", nusf_slope_per_k)):
        if not math.isfinite(value):
            raise DiffusionBackendError(f"{name} must be finite")
    reference_k = 293.6

    def diffusion(temperature_k: float) -> tuple[float, ...]:
        return (max(1e-6, d0_cm + d_slope_per_k * (temperature_k - reference_k)),)

    def absorption(temperature_k: float) -> tuple[float, ...]:
        return (max(1e-9, sa0_cm + sa_slope_per_k * (temperature_k - reference_k)),)

    def nu_sigma_fission(temperature_k: float) -> tuple[float, ...]:
        return (max(1e-9, nusf0_cm + nusf_slope_per_k * (temperature_k - reference_k)),)

    def scatter(temperature_k: float) -> tuple[tuple[float, ...], ...]:
        del temperature_k
        return ((0.0,),)

    return TemperatureDependentCrossSections(
        diffusion_coefficient_cm=diffusion,
        sigma_absorption_cm=absorption,
        nu_sigma_fission_cm=nu_sigma_fission,
        chi=(1.0,),
        scatter_matrix=scatter,
    )
