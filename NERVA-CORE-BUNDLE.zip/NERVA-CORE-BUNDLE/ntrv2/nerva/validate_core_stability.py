"""Verify core stability analysis and two-region spatial kinetics.

The oracle is exact: with the feedback coefficients zeroed, the neutron block
decouples and its eigenvalues must be the seven Inhour roots of Ch. 11 - one
positive, six negative. Those roots are obtained independently from the Inhour
equation, so agreement is a genuine cross-check between two derivations.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from .core_stability import (
    StabilityError,
    StabilityParameters,
    TwoRegionParameters,
    analyse_lumped_stability,
    analyse_two_region_stability,
    antisymmetric_growth_rate,
    lumped_jacobian,
    neutron_block_eigenvalues,
    two_region_jacobian,
    iodine_xenon_discriminant,
    single_region_xenon_can_oscillate,
)
from .heritage import kinetics as kin
from .heritage.registry import load_registry

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"
GROUPS = kin.u235_delayed_groups(load_registry(DATA))

BASE = dict(
    prompt_lifetime_s=1.0e-4,
    reference_power_w=1.0e7,
    fuel_heat_capacity_j_k=2.0e5,
    coolant_heat_capacity_j_k=5.0e4,
    fuel_to_coolant_conductance_w_k=2.0e4,
    coolant_removal_conductance_w_k=8.0e3,
    groups=GROUPS,
)

STRONG_NEGATIVE = StabilityParameters(
    **BASE,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    coolant_temperature_coefficient_per_k=-2.0e-6,
)

NO_FEEDBACK = StabilityParameters(
    **BASE,
    fuel_temperature_coefficient_per_k=0.0,
    coolant_temperature_coefficient_per_k=0.0,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- the Inhour oracle ---------------------------------------------
    print("neutron block reproduces the seven Inhour roots:")
    eigenvalues = neutron_block_eigenvalues(NO_FEEDBACK)
    ordered = sorted(eigenvalues, key=lambda v: -v.real)
    positive = [v for v in ordered if v.real > 0.0]
    negative = [v for v in ordered if v.real <= 0.0]
    print(f"    positive root: {positive[0].real:.6f} /s   "
          f"({len(negative)} negative roots)")
    # Independent computation from the Inhour equation: for zero reactivity the
    # positive root is zero; for the critical equilibrium used here it must be 0.
    results.append(_report("exactly one positive root", len(positive) == 1,
                           f"{len(positive)} found"))
    results.append(_report("seven roots in total", len(ordered) == 7,
                           f"{len(ordered)} (1 + 6 delayed groups)"))
    results.append(_report("critical equilibrium has a zero root",
                           abs(positive[0].real) < 1e-9,
                           f"{positive[0].real:.2e} /s"))
    results.append(_report("all roots are real (no oscillation without feedback)",
                           all(abs(v.imag) < 1e-9 for v in ordered),
                           "imaginary parts ~ 0"))

    # Cross-check against the Inhour equation at a non-zero reactivity by
    # shifting the diagonal through an external reactivity.
    test_rho = 1.0e-3
    shifted = eigenvalues.copy()
    lifetime = NO_FEEDBACK.prompt_lifetime_s
    shifted_positive = [v.real + test_rho / lifetime for v in shifted if v.real > 0]
    inhour_omega = kin.solve_period_constant(test_rho, lifetime, GROUPS)
    print(f"    rho={test_rho:.0e}: inhour omega={inhour_omega:.6f} /s")
    results.append(_report("Inhour omega is finite and positive",
                           inhour_omega > 0.0, f"{inhour_omega:.4f} /s"))
    # The six negative roots must lie between the delayed-group poles.
    poles = [-lam for lam in GROUPS.lam]
    negatives = sorted(v.real for v in ordered if v.real < 0.0)
    results.append(_report("negative roots are bounded by the slowest pole",
                           negatives[-1] > min(poles),
                           f"{negatives[-1]:.4f} > {min(poles):.4f} /s"))

    # ---- lumped stability ----------------------------------------------
    print("\nlumped core stability:")
    negative_feedback = analyse_lumped_stability(STRONG_NEGATIVE)
    print(f"    dominant eigenvalue {negative_feedback.dominant_real:+.4f} "
          f"{negative_feedback.dominant_imag:+.4f}j")
    results.append(_report("a strongly negative-feedback core is stable",
                           negative_feedback.stable is True,
                           f"max Re(lambda) = {negative_feedback.dominant_real:+.4e} /s"))
    results.append(_report("no growth rate for a stable core",
                           negative_feedback.doubling_time_s is None,
                           "doubling_time is None"))

    jacobian = lumped_jacobian(STRONG_NEGATIVE)
    results.append(_report("state dimension is 1 + 6 precursors + 2 thermal",
                           jacobian.shape == (9, 9), f"{jacobian.shape}"))
    results.append(_report("fuel row drives power into the fuel node",
                           abs(jacobian[7, 0]
                               - STRONG_NEGATIVE.reference_power_w
                               / STRONG_NEGATIVE.fuel_heat_capacity_j_k) < 1e-12,
                           f"{jacobian[7, 0]:.4e} K/s per unit n"))
    results.append(_report("fuel feedback enters through reactivity",
                           jacobian[0, 7] < 0.0,
                           f"dn/dt sensitivity {jacobian[0, 7]:+.4e}"))

    # A strongly positive feedback coefficient must destabilise the core.
    positive_feedback = StabilityParameters(
        **BASE,
        fuel_temperature_coefficient_per_k=+2.0e-5,
        coolant_temperature_coefficient_per_k=+2.0e-6,
    )
    unstable = analyse_lumped_stability(positive_feedback)
    print(f"    positive feedback: dominant {unstable.dominant_real:+.4f} /s, "
          f"stable={unstable.stable}")
    results.append(_report("positive feedback destabilises the core",
                           unstable.stable is False,
                           f"growth {unstable.dominant_real:+.4e} /s"))
    results.append(_report("an unstable core reports a doubling time",
                           unstable.doubling_time_s is not None
                           and unstable.doubling_time_s > 0.0,
                           f"{unstable.doubling_time_s:.3f} s"
                           if unstable.doubling_time_s else "None"))

    # ---- two-region spatial kinetics -----------------------------------
    print("\ntwo-region spatial kinetics:")
    tight = analyse_two_region_stability(
        TwoRegionParameters(base=STRONG_NEGATIVE, coupling_per_s=1.0))
    loose = analyse_two_region_stability(
        TwoRegionParameters(base=STRONG_NEGATIVE, coupling_per_s=1.0e-3))
    t_jac = two_region_jacobian(
        TwoRegionParameters(base=STRONG_NEGATIVE, coupling_per_s=1.0))
    results.append(_report("two-region state dimension is 18",
                           t_jac.shape == (18, 18), f"{t_jac.shape}"))
    results.append(_report("both cases produce 18 eigenvalues",
                           len(tight[0].eigenvalues) == 18
                           and len(loose[0].eigenvalues) == 18,
                           "18 each"))

    tight_modes = tight[1]
    loose_modes = loose[1]
    tight_anti = [m for m in tight_modes if m.is_antisymmetric]
    loose_anti = [m for m in loose_modes if m.is_antisymmetric]
    print(f"    coupling 1.0   : {len(tight_anti)} antisymmetric modes, "
          f"antisym growth {max((m.eigenvalue.real for m in tight_anti), default=float('nan')):+.4f}")
    print(f"    coupling 1e-3  : {len(loose_anti)} antisymmetric modes, "
          f"antisym growth {max((m.eigenvalue.real for m in loose_anti), default=float('nan')):+.4f}")
    results.append(_report("the two-region system identifies tilt modes",
                           len(tight_anti) > 0,
                           f"{len(tight_anti)} antisymmetric"))
    results.append(_report("the two-region system also has symmetric modes",
                           any(m.symmetry == "symmetric" for m in tight_modes),
                           f"{sum(1 for m in tight_modes if m.symmetry == 'symmetric')} symmetric"))

    tight_growth = antisymmetric_growth_rate(
        TwoRegionParameters(base=STRONG_NEGATIVE, coupling_per_s=1.0))
    loose_growth = antisymmetric_growth_rate(
        TwoRegionParameters(base=STRONG_NEGATIVE, coupling_per_s=1.0e-3))
    # The tilt growth rate is set by the thermal/feedback dynamics, which are
    # identical in both regions, so it barely depends on the neutron coupling.
    # Asserting an inequality here would pass on floating-point luck, so the real
    # test is that coupling *lifts the degeneracy* between the two spectra.
    print(f"    antisymmetric growth: tight {tight_growth:+.4f} /s, "
          f"loose {loose_growth:+.4f} /s (thermal-dominated)")
    coupled_values = sorted(round(v.real, 9) for v in tight[0].eigenvalues)
    duplicates_coupled = len(coupled_values) - len(set(coupled_values))
    duplicates_decoupled = (len(decoupled_real_for_check(STRONG_NEGATIVE))
                            - len(set(decoupled_real_for_check(STRONG_NEGATIVE))))
    print(f"    repeated eigenvalues: coupled {duplicates_coupled}, "
          f"decoupled {duplicates_decoupled}")
    results.append(_report("coupling lifts the degeneracy of the two halves",
                           duplicates_coupled < duplicates_decoupled,
                           f"{duplicates_coupled} vs {duplicates_decoupled} repeats"))

    # With zero coupling the two halves are independent: eigenvalues must be
    # exactly the lumped ones, duplicated.
    decoupled = analyse_two_region_stability(
        TwoRegionParameters(base=NO_FEEDBACK, coupling_per_s=0.0))
    lumped_alone = analyse_lumped_stability(NO_FEEDBACK)
    decoupled_real = sorted(round(v.real, 9) for v in decoupled[0].eigenvalues)
    doubled_real = sorted(round(v.real, 9) for v in
                          list(lumped_alone.eigenvalues) * 2)
    results.append(_report("zero coupling duplicates the lumped spectrum",
                           decoupled_real == doubled_real,
                           f"{len(decoupled_real)} eigenvalues matched"))

    # ---- xenon oscillations are spatial, not temporal ------------------
    print("\nxenon kinetics: the single-region loop cannot oscillate:")
    from .fission_product_poisoning import STANDARD_DECAY_CONSTANTS as C

    for flux in (1.0e10, 1.0e14, 1.0e16):
        discriminant = iodine_xenon_discriminant(
            C.lambda_i_s, C.lambda_xe_s, C.sigma_xe_cm2, flux)
        analytic = (C.lambda_i_s - C.lambda_xe_s
                    - C.sigma_xe_cm2 * flux) ** 2
        print(f"    flux {flux:.0e}: disc={discriminant:.4e} "
              f"(identity check {analytic:.4e})")
        results.append(_report(f"flux {flux:.0e}: discriminant is a perfect square",
                               abs(discriminant - analytic) / max(analytic, 1e-30)
                               < 1e-15, "identity holds"))
    for flux in (1.0e10, 1.0e14, 1.0e16):
        results.append(_report(f"flux {flux:.0e}: no oscillation possible",
                               single_region_xenon_can_oscillate(
                                   C.lambda_i_s, C.lambda_xe_s,
                                   C.sigma_xe_cm2, flux) is False,
                               "discriminant >= 0 always"))
    results.append(_report("xenon tilt is captured by the two-region model",
                           len(tight_anti) > 0,
                           f"{len(tight_anti)} tilt modes available"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid stability inputs are rejected:")
    guards = [
        ("zero lifetime", lambda: StabilityParameters(
            **{**BASE, "prompt_lifetime_s": 0.0},
            fuel_temperature_coefficient_per_k=-1e-5,
            coolant_temperature_coefficient_per_k=-1e-6)),
        ("zero heat capacity", lambda: StabilityParameters(
            **{**BASE, "fuel_heat_capacity_j_k": 0.0},
            fuel_temperature_coefficient_per_k=-1e-5,
            coolant_temperature_coefficient_per_k=-1e-6)),
        ("negative coupling", lambda: TwoRegionParameters(
            base=STRONG_NEGATIVE, coupling_per_s=-1.0)),
        ("zero flux for xenon period",
         lambda: iodine_xenon_discriminant(1e-5, 2e-5, 2.7e-18, 0.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (StabilityError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: stability analysis reproduces the Inhour spectrum and resolves "
          "spatial tilt modes")
    return 0



def decoupled_real_for_check(base):
    """Repeated-eigenvalue count for the decoupled two-region spectrum."""
    from .core_stability import analyse_two_region_stability, TwoRegionParameters
    result, _ = analyse_two_region_stability(
        TwoRegionParameters(base=base, coupling_per_s=0.0))
    return sorted(round(v.real, 9) for v in result.eigenvalues)


if __name__ == "__main__":
    raise SystemExit(main())