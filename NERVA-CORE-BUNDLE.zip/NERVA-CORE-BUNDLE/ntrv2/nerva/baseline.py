"""The single declared NERVA baseline.

Why this module exists
----------------------
A model can be internally consistent and still be unfalsifiable. The only way
to avoid that is to pick ONE engine, pin it to sources, and require every
downstream number to be comparable to it. Prior to this module the package had
four historical presets (XE-Prime, 1972 75 klbf, graphite derivative, NESS R-1)
and no statement of which one anything was supposed to reproduce.

The declared baseline is **XE-Prime / XE0**, because it is the only NERVA
engine for which two independent sources pin the same quantities:

* NASA TM-105252 Table 3 (the "XE-PRIME" column) - a compilation of tested
  NTP systems, i.e. design/as-tested figures.
* Emrich (2023) Appendix III, Tables III.1 and III.2 - the book's reproduction
  of the XE0 full-power test data and general engine characteristics.

Two sources agreeing is what makes a baseline checkable. Declaring a baseline
whose numbers come from a single document would just relocate the ambiguity.

What this module does NOT do
----------------------------
It does not adjust the preset to match the measurements. The comparison exists
to *report* agreement; if a preset value disagreed with the XE0 test data the
correct response is to investigate, not to bend the number. Tolerances below are
declared as engineering judgement about the *measurement and definition*
quality of each quantity, before looking at the residuals:

* power and chamber temperature -- directly measured, well instrumented -> 1%
* thrust flow -- measured, but bleed accounting makes the station definition
  slightly ambiguous -> 2%
* chamber pressure -- the preset carries a nominal tabulated value while the
  test value is a station measurement downstream of injection losses -> 5%

A failure here is information, not something to widen away.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .historical_presets import (
    LBM_TO_KG,
    PSI_TO_PA,
    RANKINE_TO_K,
    XE_PRIME,
    HistoricalNervaPreset,
)

__all__ = [
    "BaselineComparison",
    "DeclaredBaseline",
    "DECLARED_BASELINE",
    "baseline_report",
]


@dataclass(frozen=True)
class BaselineComparison:
    """One preset-vs-measurement comparison, with its stated tolerance."""

    quantity: str
    preset_value: float
    measured_value: float
    unit: str
    tolerance: float
    station: str
    measured_source: str

    @property
    def relative_error(self) -> float:
        if self.measured_value == 0.0:
            raise ValueError(
                f"cannot form a relative error for {self.quantity}: measured value is 0"
            )
        return (self.preset_value - self.measured_value) / self.measured_value

    @property
    def agrees(self) -> bool:
        return abs(self.relative_error) <= self.tolerance

    def describe(self) -> str:
        verdict = "ok" if self.agrees else "DISAGREES"
        return (
            f"[{verdict}] {self.quantity:<22} preset {self.preset_value:12.4f} "
            f"vs measured {self.measured_value:12.4f} {self.unit:<5} "
            f"({self.relative_error * 100:+.3f}%, tol {self.tolerance * 100:.1f}%)"
        )


def _comparisons(preset: HistoricalNervaPreset) -> tuple[BaselineComparison, ...]:
    """Build the preset-vs-XE0 comparisons.

    Every measured value below is xE0 data from Emrich Table III.1 (p.413);
    the preset side is NASA TM-105252 Table 3. Unit conversions go through the
    constants in :mod:`historical_presets`, so the imperial-and-rankine
    provenance of the preset stays visible.
    """
    out: list[BaselineComparison] = []

    if preset.thermal_power_mw is not None:
        out.append(BaselineComparison(
            quantity="thermal power",
            preset_value=preset.thermal_power_mw,
            measured_value=1137.0,
            unit="MW",
            tolerance=0.01,
            station="reactor",
            measured_source="emrich2023 p.413 Table III.1 'Reactor power'",
        ))

    if preset.chamber_temperature_k is not None:
        out.append(BaselineComparison(
            quantity="chamber temperature",
            preset_value=preset.chamber_temperature_k,
            measured_value=2278.0,
            unit="K",
            tolerance=0.01,
            station="nozzle chamber (Tc)",
            measured_source="emrich2023 p.413 Table III.1 'Nozzle chamber'",
        ))

    if preset.chamber_pressure_pa is not None:
        out.append(BaselineComparison(
            quantity="chamber pressure",
            preset_value=preset.chamber_pressure_pa / 1.0e6,
            measured_value=3.81,
            unit="MPa",
            tolerance=0.05,
            station="nozzle chamber (Tc)",
            measured_source="emrich2023 p.413 Table III.1 'Nozzle chamber'",
        ))

    if preset.hydrogen_mass_flow_kg_s is not None:
        # Compare against the THRUST flow, not the tank outlet. The tank outlet
        # figure (36.15 kg/s) includes the diluent and hot bleeds that never
        # reach the nozzle chamber; using it would show a spurious 12% error.
        out.append(BaselineComparison(
            quantity="thrust flow",
            preset_value=preset.hydrogen_mass_flow_kg_s,
            measured_value=31.98,
            unit="kg/s",
            tolerance=0.02,
            station="nozzle chamber (Tc)",
            measured_source="emrich2023 p.413 Table III.1 'Nozzle chamber'",
        ))

    return tuple(out)


@dataclass(frozen=True)
class DeclaredBaseline:
    """The one engine everything else is measured against."""

    key: str
    name: str
    engine_designation: str
    source_title: str
    source_url: str
    rationale: str
    preset: HistoricalNervaPreset = field(repr=False)
    cross_checked_against: str

    def comparisons(self) -> tuple[BaselineComparison, ...]:
        return _comparisons(self.preset)

    @property
    def all_agree(self) -> bool:
        return all(c.agrees for c in self.comparisons())

    @property
    def worst_relative_error(self) -> float:
        comps = self.comparisons()
        if not comps:
            return 0.0
        return max(abs(c.relative_error) for c in comps)

    def report(self) -> str:
        lines = [
            f"Declared NERVA baseline: {self.name} ({self.engine_designation})",
            f"  preset key            : {self.key}",
            f"  primary source        : {self.source_title}",
            f"  cross-checked against : {self.cross_checked_against}",
            "",
            "  preset vs XE0 full-power test data:",
        ]
        lines.extend(f"    {c.describe()}" for c in self.comparisons())
        lines.append("")
        lines.append(
            f"  worst relative error  : {self.worst_relative_error * 100:.3f}%"
        )
        lines.append(
            "  verdict               : "
            + ("baseline is consistent across both sources"
               if self.all_agree else
               "BASELINE DISAGREES with measurement - investigate before use")
        )
        return "\n".join(lines)


#: Units sanity: the constants imported above are imperial/rankine inputs.
_UNIT_GUARD = (LBM_TO_KG, PSI_TO_PA, RANKINE_TO_K)

DECLARED_BASELINE = DeclaredBaseline(
    key=XE_PRIME.key,
    name=XE_PRIME.name,
    engine_designation="XE0 (XE-Prime)",
    source_title=XE_PRIME.source_title,
    source_url=XE_PRIME.source_url,
    rationale=(
        "XE0 is the only NERVA engine for which two independent documents pin "
        "the same quantities: NASA TM-105252 Table 3 supplies the as-tested "
        "figures and Emrich Appendix III Tables III.1/III.2 supply the "
        "full-power test data. Selecting an engine with a single source would "
        "have relocated the ambiguity rather than resolved it. The 1972 75 klbf "
        "and graphite-derivative presets are design studies with no test data "
        "to check against, and NESS R-1 is a design baseline, not a fired "
        "engine."
    ),
    preset=XE_PRIME,
    cross_checked_against="emrich2023 p.413 Table III.1 (XE0 full-power test)",
)


def baseline_report() -> str:
    """Human-readable baseline statement, including the cross-check."""
    return DECLARED_BASELINE.report()


def main() -> int:
    """Print the baseline statement. Exit 1 if the cross-check fails."""
    print(baseline_report())
    return 0 if DECLARED_BASELINE.all_agree else 1


if __name__ == "__main__":
    raise SystemExit(main())
