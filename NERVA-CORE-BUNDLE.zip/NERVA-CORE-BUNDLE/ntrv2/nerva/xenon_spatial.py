"""Spatially coupled xenon dynamics: the tilt oscillation itself.

``core_stability`` showed that a two-region model *can* express an antisymmetric
mode, and ``fission_product_poisoning`` modelled xenon as a single lumped
inventory. Neither produced a xenon oscillation, because the oscillation is the
coupling between the two: xenon builds where the flux is high, suppresses it,
decays, and lets it recover, with the flux shifting between regions in between.

This module closes that loop. Each region carries its own iodine and xenon
inventory, xenon absorbs in its own region only, and the regions exchange
neutrons. That is the smallest system with a genuine xenon-induced spatial
oscillation, and its linearisation shows the mode the point models cannot.

State per region: ``[n, C_1..C_6, T_fuel, T_coolant, I, Xe]`` - eleven states,
twenty-two for two regions.

The physics of the xenon coupling (Emrich Ch. 13, Eqs. 13.16/13.17 and 13.21):

    dI/dt  = gamma_I Sigma_f phi - lambda_I I
    dXe/dt = gamma_Xe Sigma_f phi + lambda_I I - (sigma_Xe phi + lambda_Xe) Xe

with ``phi`` proportional to the regional neutron population, and the xenon
absorption feeding back into that region's reactivity.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .core_stability import StabilityParameters, StabilityResult, _analyse
from .fission_product_poisoning import (
    STANDARD_DECAY_CONSTANTS,
    CorePoisoningInputs,
    PoisoningConstants,
    equilibrium_xenon,
)


class XenonSpatialError(ValueError):
    """Raised when a coupled xenon-spatial analysis is not well posed."""


@dataclass(frozen=True)
class XenonSpatialParameters:
    """Everything the coupled two-region xenon model needs.

    ``flux_per_unit_population`` converts the normalised population ``n`` into a
    neutron flux, so ``phi_region = flux_per_unit_population * n_region``. Scaling
    the flux with the regional population is what lets the tilt self-amplify.
    """

    base: StabilityParameters
    coupling_per_s: float
    flux_per_unit_population_cm2_s: float
    macroscopic_fission_xs_cm_inv: float
    xenon_worth_per_absorption_cm: float
    constants: PoisoningConstants = STANDARD_DECAY_CONSTANTS

    def __post_init__(self) -> None:
        if not math.isfinite(self.coupling_per_s) or self.coupling_per_s < 0.0:
            raise XenonSpatialError("coupling must be finite and non-negative")
        for name in ("flux_per_unit_population_cm2_s",
                     "macroscopic_fission_xs_cm_inv"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise XenonSpatialError(f"{name} must be finite and positive")
        if not math.isfinite(self.xenon_worth_per_absorption_cm):
            raise XenonSpatialError("xenon worth must be finite")
        if self.xenon_worth_per_absorption_cm > 0.0:
            raise XenonSpatialError(
                "xenon worth must be negative or zero; xenon is an absorber"
            )

    @property
    def equilibrium_flux_cm2_s(self) -> float:
        return self.flux_per_unit_population_cm2_s

    @property
    def equilibrium_xenon(self) -> float:
        inputs = CorePoisoningInputs(
            macroscopic_fission_xs_cm_inv=self.macroscopic_fission_xs_cm_inv,
            neutron_flux_cm2_s=self.equilibrium_flux_cm2_s)
        return equilibrium_xenon(inputs, self.constants)

    @property
    def equilibrium_iodine(self) -> float:
        inputs = CorePoisoningInputs(
            macroscopic_fission_xs_cm_inv=self.macroscopic_fission_xs_cm_inv,
            neutron_flux_cm2_s=self.equilibrium_flux_cm2_s)
        return (self.constants.gamma_i * inputs.fission_rate_density_cm3_s
                / self.constants.lambda_i_s)

    @property
    def xenon_reactivity_per_atom(self) -> float:
        """alpha_xe = d(rho)/d(N_Xe), from the worth and the cross-section."""
        return self.xenon_worth_per_absorption_cm * self.constants.sigma_xe_cm2


@dataclass(frozen=True)
class XenonMode:
    """One mode of the coupled system, classified by its regional symmetry."""

    eigenvalue: complex
    symmetry: str
    region_ratio: float

    @property
    def is_antisymmetric(self) -> bool:
        return self.symmetry == "antisymmetric"

    @property
    def period_s(self) -> float | None:
        if abs(self.eigenvalue.imag) < 1e-12:
            return None
        return 2.0 * math.pi / abs(self.eigenvalue.imag)

    @property
    def e_folding_time_s(self) -> float | None:
        if self.eigenvalue.real == 0.0:
            return None
        return 1.0 / self.eigenvalue.real


def two_region_xenon_jacobian(parameters: XenonSpatialParameters) -> np.ndarray:
    """Jacobian of the two-region kinetics + thermal + xenon system."""
    base = parameters.base
    groups = base.groups
    lifetime = base.prompt_lifetime_s
    m = groups.n_groups
    # Per-region block: n, precursors, fuel, coolant, iodine, xenon =
    # 1 + m + 2 + 2. Writing 4 + m + 2 here left one unused state per region,
    # whose all-zero Jacobian rows produced spurious zero eigenvalues and a
    # 24x24 system instead of 22x22.
    block = 1 + m + 2 + 2
    i_index = 1 + m + 2
    xe_index = i_index + 1
    size = 2 * block
    jacobian = np.zeros((size, size))

    flux_per_n = parameters.flux_per_unit_population_cm2_s
    fission_xs = parameters.macroscopic_fission_xs_cm_inv
    sigma_xe = parameters.constants.sigma_xe_cm2
    lambda_i = parameters.constants.lambda_i_s
    lambda_xe = parameters.constants.lambda_xe_s
    gamma_i = parameters.constants.gamma_i
    gamma_xe = parameters.constants.gamma_xe
    xenon0 = parameters.equilibrium_xenon
    iodine0 = parameters.equilibrium_iodine
    alpha_xe = parameters.xenon_reactivity_per_atom
    power = base.reference_power_w
    transfer = base.fuel_to_coolant_conductance_w_k
    capacity_f = base.fuel_heat_capacity_j_k
    capacity_c = base.coolant_heat_capacity_j_k
    removal = base.coolant_removal_conductance_w_k

    for region in range(2):
        offset = region * block
        n_row = offset
        # Neutron population, including the xenon feedback.
        jacobian[n_row, n_row] = -groups.beta_total / lifetime
        for index, lam in enumerate(groups.lam):
            jacobian[n_row, offset + 1 + index] = lam
        jacobian[n_row, offset + 1 + m] = (base.fuel_temperature_coefficient_per_k
                                           / lifetime)
        jacobian[n_row, offset + 1 + m + 1] = (base.coolant_temperature_coefficient_per_k
                                               / lifetime)
        jacobian[n_row, offset + xe_index] = alpha_xe / lifetime

        # Precursors.
        for index, (beta, lam) in enumerate(zip(groups.beta, groups.lam)):
            jacobian[offset + 1 + index, n_row] = beta / lifetime
            jacobian[offset + 1 + index, offset + 1 + index] = -lam

        # Fuel and coolant nodes.
        fuel_row = offset + 1 + m
        coolant_row = fuel_row + 1
        jacobian[fuel_row, n_row] = power / capacity_f
        jacobian[fuel_row, fuel_row] = -transfer / capacity_f
        jacobian[fuel_row, coolant_row] = transfer / capacity_f
        jacobian[coolant_row, fuel_row] = transfer / capacity_c
        jacobian[coolant_row, coolant_row] = -(transfer + removal) / capacity_c

        # Iodine: dI/dt = gamma_I Sigma_f phi - lambda_I I, phi = flux_per_n * n
        jacobian[offset + i_index, n_row] = gamma_i * fission_xs * flux_per_n
        jacobian[offset + i_index, offset + i_index] = -lambda_i

        # Xenon: dXe/dt = gamma_Xe Sigma_f phi + lambda_I I - (sigma phi + lambda_Xe) Xe
        # Both phi-dependent terms contribute a population derivative.
        jacobian[offset + xe_index, n_row] = (
            gamma_xe * fission_xs * flux_per_n - sigma_xe * flux_per_n * xenon0)
        jacobian[offset + xe_index, offset + i_index] = lambda_i
        jacobian[offset + xe_index, offset + xe_index] = -(
            sigma_xe * flux_per_n + lambda_xe)

        # The coupling term is what allows a tilt; it couples the populations.
        jacobian[n_row, n_row] -= parameters.coupling_per_s
        jacobian[n_row, (1 - region) * block] += parameters.coupling_per_s

    del iodine0  # equilibrium iodine enters only through the fixed point, not J
    return jacobian


def analyse_xenon_spatial(parameters: XenonSpatialParameters
                          ) -> tuple[StabilityResult, tuple[XenonMode, ...]]:
    """Eigenvalues plus symmetric/antisymmetric classification."""
    jacobian = two_region_xenon_jacobian(parameters)
    values, vectors = np.linalg.eig(jacobian)
    block = jacobian.shape[0] // 2
    modes: list[XenonMode] = []
    for index, value in enumerate(values):
        left = vectors[0, index]
        right = vectors[block, index]
        if abs(left) < 1e-300 or abs(right) < 1e-300:
            symmetry, ratio = "degenerate", float("inf")
        else:
            same_sign = (left.real * right.real) > 0.0
            symmetry = "symmetric" if same_sign else "antisymmetric"
            ratio = abs(right) / abs(left)
        modes.append(XenonMode(eigenvalue=complex(value), symmetry=symmetry,
                               region_ratio=float(ratio)))
    result = _analyse(values, "two-region kinetics + thermal + xenon")
    return result, tuple(modes)


def xenon_tilt_mode(parameters: XenonSpatialParameters) -> XenonMode | None:
    """The most unstable antisymmetric mode, which is the tilt.

    Returns ``None`` when no antisymmetric mode exists. A nonzero imaginary part
    means the tilt *oscillates*; a positive real part means it *grows*, which is
    the xenon spatial instability proper.
    """
    _, modes = analyse_xenon_spatial(parameters)
    antisymmetric = [mode for mode in modes if mode.is_antisymmetric]
    if not antisymmetric:
        return None
    return max(antisymmetric, key=lambda mode: mode.eigenvalue.real)


def antidiffusion_threshold_flux(parameters: XenonSpatialParameters,
                                 sample_fluxes: tuple[float, ...] | None = None
                                 ) -> float | None:
    """Lowest flux at which the xenon tilt mode stops decaying.

    Bridges the physical statement "xenon oscillations appear at high flux" to
    the eigenvalue condition "the tilt mode's real part turns positive". Returns
    ``None`` if no sampled flux produces an unstable tilt.
    """
    if sample_fluxes is None:
        # Five decades, geometric; the oscillation is a high-flux phenomenon.
        sample_fluxes = tuple(1.0e11 * 10.0 ** (index / 4.0) for index in range(21))
    unstable: list[float] = []
    for flux in sample_fluxes:
        if not math.isfinite(flux) or flux <= 0.0:
            raise XenonSpatialError("sample fluxes must be finite and positive")
        probe = XenonSpatialParameters(
            base=parameters.base, coupling_per_s=parameters.coupling_per_s,
            flux_per_unit_population_cm2_s=flux,
            macroscopic_fission_xs_cm_inv=parameters.macroscopic_fission_xs_cm_inv,
            xenon_worth_per_absorption_cm=parameters.xenon_worth_per_absorption_cm,
            constants=parameters.constants)
        mode = xenon_tilt_mode(probe)
        if mode is not None and mode.eigenvalue.real > 0.0:
            unstable.append(flux)
    return min(unstable) if unstable else None
