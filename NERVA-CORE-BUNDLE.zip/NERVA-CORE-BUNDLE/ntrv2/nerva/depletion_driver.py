"""Burnup/depletion driver wired to ``openmc.deplete``.

The delivered model had **no depletion at all**: ``openmc.deplete`` appeared
zero times in 278 modules, so there was no fission-product inventory, no xenon,
and no reactivity-versus-time. This module adds that capability.

It is the one component that cannot be executed on a machine without the
compiled ``libopenmc`` shared library, because ``openmc.deplete`` imports
``openmc.lib`` at import time. So it is written to the installed API, checks
first, and fails with a message naming the real cause rather than pretending.

Time units
----------
``openmc.deplete`` integrators conventionally take timesteps in **days**. A
nuclear thermal rocket burns for minutes to hours, not years, so expressing a
NERVA burn in days means numbers like 6e-4. This driver therefore takes
timesteps in **seconds by default** and converts explicitly, and it records the
total burn window so a 90-minute burn cannot silently become a 90-day burn.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

SECONDS_PER_DAY = 86400.0

INTEGRATORS = ("predictor", "cecm", "epc_rk4", "si_qr")


class DepletionError(ValueError):
    """Raised when depletion inputs are inconsistent or unavailable."""


class DepletionPreflightError(RuntimeError):
    """Raised when ``openmc.deplete`` cannot be used in this environment."""


@dataclass(frozen=True)
class DepletionParameters:
    """Power history for a depletion calculation."""

    power_w: float
    timesteps_s: tuple[float, ...]
    integrator: str = "predictor"
    timestep_units: str = "s"

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        if not math.isfinite(self.power_w) or self.power_w <= 0.0:
            raise DepletionError("depletion power must be finite and positive")
        if not self.timesteps_s:
            raise DepletionError("at least one timestep is required")
        for step in self.timesteps_s:
            if not math.isfinite(step) or step <= 0.0:
                raise DepletionError(
                    f"every timestep must be finite and positive, got {step!r}"
                )
        if self.integrator not in INTEGRATORS:
            raise DepletionError(
                f"unknown integrator {self.integrator!r}; expected one of {INTEGRATORS}"
            )
        if self.timestep_units not in ("s", "h", "d"):
            raise DepletionError(
                f"timestep_units must be 's', 'h' or 'd', got {self.timestep_units!r}"
            )

    @property
    def timesteps_days(self) -> tuple[float, ...]:
        """Timesteps expressed in the days that ``openmc.deplete`` expects."""
        divisor = {"s": SECONDS_PER_DAY, "h": 24.0, "d": 1.0}[self.timestep_units]
        return tuple(step / divisor for step in self.timesteps_s)

    @property
    def total_burn_seconds(self) -> float:
        return math.fsum(self.timesteps_s)

    @property
    def total_burn_days(self) -> float:
        return self.total_burn_seconds / SECONDS_PER_DAY


@dataclass(frozen=True)
class DepletionResult:
    """Outcome of a depletion run, with the provenance needed to trust it."""

    k_history: tuple[float, ...]
    burnup_mwd_per_kg: tuple[float, ...]
    timesteps_days: tuple[float, ...]
    total_burn_seconds: float
    power_w: float
    integrator: str
    chain_file: str | None
    nuclear_data: str | None
    isotopes_tracked: int
    provenance: dict

    def __post_init__(self) -> None:
        if not self.k_history:
            raise DepletionError("a depletion result must carry its k history")
        if len(self.k_history) != len(self.timesteps_days):
            raise DepletionError(
                "k history length must match the number of depletion steps"
            )
        for value in self.k_history:
            if not math.isfinite(value):
                raise DepletionError("non-finite k_eff in depletion history")

    @property
    def reactivity_swing(self) -> float:
        """Largest drop in k across the burn, a first-order burnup metric."""
        return max(self.k_history) - min(self.k_history)


# ------------------------------------------------------------------ preflight


def depletion_preflight() -> list[str]:
    """Return blocking problems for depletion; empty means it can run."""
    problems: list[str] = []
    try:
        import openmc.deplete  # noqa: F401, PLC0415 - the import IS the check
    except ModuleNotFoundError as exc:
        if exc.name == "openmc.deplete" or "deplete" in str(exc):
            problems.append(
                "openmc.deplete is unavailable: the installed openmc has no "
                "depletion module"
            )
        else:
            problems.append(f"missing dependency: {exc.name}")
    except OSError as exc:
        text = str(exc)
        if "libopenmc" in text:
            problems.append(
                "the compiled library libopenmc is missing, so openmc.deplete "
                "cannot be imported; build the C++ transport library (cmake) or "
                "install a binary distribution that ships it"
            )
        else:
            problems.append(f"openmc.deplete failed to load: {text[:120]}")
    else:
        try:
            import openmc.lib  # noqa: F401, PLC0415
        except Exception as exc:  # noqa: BLE001
            problems.append(f"openmc.lib unavailable: {str(exc)[:120]}")
    return problems


def require_depletion_ready() -> None:
    problems = depletion_preflight()
    if problems:
        raise DepletionPreflightError(
            "depletion cannot run here:\n  - " + "\n  - ".join(problems)
        )


# ------------------------------------------------------------------ execution


def build_operator(model, *, cross_sections: str, chain_file: str | None = None,
                   materials=None, fission_yields=None):
    """Construct an ``openmc.deplete.Operator`` for a built model.

    ``model`` must be an ``openmc.Model`` whose materials carry depletion
    attributes (``material.depletable = True`` and a ``volume``).
    """
    require_depletion_ready()
    from openmc.deplete import Operator  # noqa: PLC0415

    kwargs = {"cross_sections": cross_sections}
    if chain_file is not None:
        kwargs["chain_file"] = chain_file
    if materials is not None:
        kwargs["materials"] = materials
    if fission_yields is not None:
        kwargs["fission_yields"] = fission_yields
    return Operator(model, **kwargs)


def build_integrator(parameters: DepletionParameters):
    """Construct the requested depletion integrator."""
    require_depletion_ready()
    from openmc.deplete import (CECMIntegrator, EPC_RK4Integrator,  # noqa: PLC0415
                                PredictorIntegrator, SI_QRIntegrator)

    timesteps = list(parameters.timesteps_days)
    power = parameters.power_w
    if parameters.integrator == "predictor":
        return PredictorIntegrator(timesteps, power=power, timestep_units="d")
    if parameters.integrator == "cecm":
        return CECMIntegrator(timesteps, power=power, timestep_units="d")
    if parameters.integrator == "epc_rk4":
        return EPC_RK4Integrator(timesteps, power=power, timestep_units="d")
    return SI_QRIntegrator(timesteps, power=power, timestep_units="d")


def run_depletion(model, parameters: DepletionParameters, *,
                  cross_sections: str, chain_file: str | None = None,
                  output_path: str | Path = "depletion_results.h5",
                  nuclides: tuple[str, ...] | None = None) -> DepletionResult:
    """Run a depletion calculation and extract the k and burnup history.

    Not callable without ``libopenmc``; :func:`depletion_preflight` reports the
    reason and :func:`require_depletion_ready` raises before any work starts.
    """
    parameters.validate()
    require_depletion_ready()
    import openmc.deplete  # noqa: PLC0415

    operator = build_operator(model, cross_sections=cross_sections,
                             chain_file=chain_file)
    integrator = build_integrator(parameters)
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    operator.integrate(integrator)

    k_history = tuple(float(value) for value in operator.eigenvalue_history)
    burnup = tuple(float(value) for value in operator.burnup)

    tracked = 0
    if nuclides:
        try:
            with openmc.deplete.Results(str(output)) as results:  # type: ignore[attr-defined]
                tracked = len(results[0].nuclides) if results else 0
        except Exception:  # noqa: BLE001 - inventory detail is optional
            tracked = 0

    return DepletionResult(
        k_history=k_history,
        burnup_mwd_per_kg=burnup,
        timesteps_days=parameters.timesteps_days,
        total_burn_seconds=parameters.total_burn_seconds,
        power_w=parameters.power_w,
        integrator=parameters.integrator,
        chain_file=chain_file,
        nuclear_data=cross_sections,
        isotopes_tracked=tracked,
        provenance={
            "kind": "openmc-depletion",
            "cross_sections": cross_sections,
            "chain_file": chain_file,
            "integrator": parameters.integrator,
            "power_w": parameters.power_w,
            "timesteps_days": list(parameters.timesteps_days),
            "timestep_units_declared": parameters.timestep_units,
            "caveat": "steady power history; no thermal or reactivity feedback "
                      "is applied during the burn",
        },
    )


def ntr_burn_window(steps: int = 6) -> tuple[float, ...]:
    """Evenly split the cited NERVA maximum single-test burn into ``steps``.

    The window comes from the heritage registry (Emrich p.17: "Maximum burn
    time in one test was 90 min"), so the driver's default burn length is a
    cited quantity rather than a convenient invention.
    """
    if steps < 1:
        raise DepletionError("steps must be at least 1")
    from .heritage.registry import load_registry

    data = Path(__file__).parent / "heritage" / "data" / "emrich2023_nerva.json"
    registry = load_registry(data)
    burn_minutes = registry.value("nerva.max_single_test_burn_time")
    total_seconds = burn_minutes * 60.0
    return tuple(total_seconds / steps for _ in range(steps))
