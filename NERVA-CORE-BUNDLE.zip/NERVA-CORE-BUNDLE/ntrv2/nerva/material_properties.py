"""Temperature-dependent material properties from cited tables.

The model used single scalar properties (one graphite density, one conductivity)
while the reactor operates across a 2500 K span in which those properties change
substantially. Emrich Table 15.2 tabulates reactor-grade graphite at six
temperatures between 1000 and 3500 K, and that data is now in the heritage
registry rather than as an assumed constant.

Interpolation is **linear between tabulated temperatures and never extrapolated**.
For a property that is genuinely nonlinear that is a deliberate limitation, and
asking outside the table raises instead of extending the last slope.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

from .heritage.registry import load_registry

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_materials.json"

GRAPHITE_TEMPERATURES_K = (1000.0, 1500.0, 2000.0, 2500.0, 3000.0, 3500.0)


class MaterialError(ValueError):
    """Raised when a material property request is outside the cited data."""


@dataclass(frozen=True)
class PropertyTable:
    """A tabulated property against temperature, with provenance preserved."""

    name: str
    unit: str
    temperatures_k: tuple[float, ...]
    values: tuple[float, ...]
    citations: tuple[str, ...]

    def __post_init__(self) -> None:
        if len(self.temperatures_k) != len(self.values):
            raise MaterialError(
                f"{self.name}: {len(self.temperatures_k)} temperatures but "
                f"{len(self.values)} values"
            )
        if not self.temperatures_k:
            raise MaterialError(f"{self.name}: an empty property table is useless")
        if any(b <= a for a, b in zip(self.temperatures_k, self.temperatures_k[1:])):
            raise MaterialError(f"{self.name}: temperatures must be strictly increasing")
        for value in self.values:
            if not math.isfinite(value) or value <= 0.0:
                raise MaterialError(
                    f"{self.name}: values must be finite and positive, got {value!r}"
                )

    @property
    def range_k(self) -> tuple[float, float]:
        return (self.temperatures_k[0], self.temperatures_k[-1])

    def at(self, temperature_k: float) -> float:
        """Linear interpolation, refusing to extrapolate."""
        if not math.isfinite(temperature_k):
            raise MaterialError(f"temperature must be finite, got {temperature_k!r}")
        low, high = self.range_k
        if temperature_k < low or temperature_k > high:
            raise MaterialError(
                f"{self.name} is tabulated only over [{low:.0f}, {high:.0f}] K; "
                f"{temperature_k:.1f} K is outside it. Extrapolating a material "
                f"property beyond its table would be an invented number."
            )
        for index in range(len(self.temperatures_k) - 1):
            left_t, right_t = self.temperatures_k[index], self.temperatures_k[index + 1]
            if left_t <= temperature_k <= right_t:
                if right_t == left_t:
                    return self.values[index]
                fraction = (temperature_k - left_t) / (right_t - left_t)
                return (self.values[index]
                        + fraction * (self.values[index + 1] - self.values[index]))
        return self.values[-1]

    def relative_change(self) -> float:
        """Fractional change from the coldest to the hottest entry."""
        return (self.values[-1] - self.values[0]) / self.values[0]

    def citation_at(self, temperature_k: float) -> str:
        index = min(range(len(self.temperatures_k)),
                    key=lambda i: abs(self.temperatures_k[i] - temperature_k))
        return self.citations[index]


def _build_table(registry, prefix: str, unit: str, name: str) -> PropertyTable:
    temperatures: list[float] = []
    values: list[float] = []
    citations: list[str] = []
    for temperature in GRAPHITE_TEMPERATURES_K:
        key = f"{prefix}_at_{int(temperature)}k"
        if key not in registry:
            continue
        entry = registry.get(key)
        temperatures.append(temperature)
        values.append(entry.value)
        citations.append(entry.citation.describe())
    return PropertyTable(name=name, unit=unit,
                         temperatures_k=tuple(temperatures),
                         values=tuple(values), citations=tuple(citations))


@dataclass(frozen=True)
class CitedMaterials:
    """The cited material property tables, loaded from the heritage registry."""

    graphite_density: PropertyTable
    graphite_specific_heat: PropertyTable
    graphite_thermal_expansion: PropertyTable
    graphite_thermal_conductivity: PropertyTable
    graphite_tensile_strength: PropertyTable
    graphite_youngs_modulus: PropertyTable
    zrh_decomposition_temperature_k: float

    @classmethod
    def load(cls, path: str | Path | None = None) -> CitedMaterials:
        registry = load_registry(path or DATA)
        return cls(
            graphite_density=_build_table(registry, "graphite.density",
                                          "g/cm3", "graphite density"),
            graphite_specific_heat=_build_table(registry, "graphite.specific_heat",
                                                "J/g/K", "graphite specific heat"),
            graphite_thermal_expansion=_build_table(
                registry, "graphite.thermal_expansion", "1/K",
                "graphite thermal expansion"),
            graphite_thermal_conductivity=_build_table(
                registry, "graphite.thermal_conductivity", "W/cm/K",
                "graphite thermal conductivity"),
            graphite_tensile_strength=_build_table(
                registry, "graphite.ultimate_tensile_strength", "MPa",
                "graphite ultimate tensile strength"),
            graphite_youngs_modulus=_build_table(
                registry, "graphite.youngs_modulus", "MPa",
                "graphite Young's modulus"),
            zrh_decomposition_temperature_k=registry.value(
                "zrh.decomposition_temperature"),
        )

    def check_zrh(self, temperature_k: float) -> None:
        """Raise if a ZrH moderator would decompose at this temperature.

        Emrich p.298: zirconium hydride "decomposes at about 800 C". The tie-tube
        ZrH sleeve survives only because the cold hydrogen side keeps it below
        this, so exceeding it is a design violation, not a numerical detail.
        """
        if not math.isfinite(temperature_k):
            raise MaterialError("temperature must be finite")
        if temperature_k >= self.zrh_decomposition_temperature_k:
            raise MaterialError(
                f"ZrH decomposes at about "
                f"{self.zrh_decomposition_temperature_k:.1f} K (800 C); "
                f"{temperature_k:.1f} K exceeds it"
            )

    def summary(self) -> str:
        lines = []
        for table in (self.graphite_density, self.graphite_specific_heat,
                      self.graphite_thermal_expansion,
                      self.graphite_thermal_conductivity,
                      self.graphite_tensile_strength, self.graphite_youngs_modulus):
            if not table.values:
                continue
            low, high = table.range_k
            lines.append(f"{table.name:<34} {table.values[0]:>8.4g} .. "
                         f"{table.values[-1]:>8.4g} {table.unit:<7} "
                         f"over {low:.0f}-{high:.0f} K "
                         f"({table.relative_change()*100:+6.1f}%)")
        return "\n".join(lines)
