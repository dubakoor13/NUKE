"""Verify the depletion driver's inputs, units and refusal behaviour.

``openmc.deplete`` cannot be imported here: it pulls in ``openmc.lib``, which
needs the compiled ``libopenmc`` shared library that this machine does not
have. So this suite verifies everything that does not need the library:

* timestep unit conversion (a NERVA burn is minutes, not days);
* that the default burn window comes from the cited heritage value;
* that invalid power/timestep/integrator inputs are rejected;
* that preflight names the real cause, and that execution refuses rather than
  quietly producing nothing.
"""
from __future__ import annotations

from .depletion_driver import (
    SECONDS_PER_DAY,
    DepletionError,
    DepletionParameters,
    DepletionPreflightError,
    DepletionResult,
    depletion_preflight,
    ntr_burn_window,
    require_depletion_ready,
    run_depletion,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- unit handling -------------------------------------------------
    print("timestep units (openmc.deplete wants days; NTR burns want seconds):")
    seconds = DepletionParameters(power_w=1.0e8, timesteps_s=(300.0, 300.0),
                                  timestep_units="s")
    results.append(_report("seconds convert to days correctly",
                           abs(seconds.timesteps_days[0]
                               - 300.0 / SECONDS_PER_DAY) < 1e-15,
                           f"300 s = {seconds.timesteps_days[0]:.8e} d"))
    results.append(_report("total burn sums in seconds",
                           abs(seconds.total_burn_seconds - 600.0) < 1e-12,
                           f"{seconds.total_burn_seconds} s"))
    hours = DepletionParameters(power_w=1.0e8, timesteps_s=(1.5, 1.5),
                                timestep_units="h")
    results.append(_report("hours convert via 24 h/day",
                           abs(hours.timesteps_days[0] - 1.5 / 24.0) < 1e-15,
                           f"1.5 h = {hours.timesteps_days[0]:.8e} d"))
    results.append(_report("days pass through unchanged",
                           DepletionParameters(power_w=1.0, timesteps_s=(2.5,),
                                               timestep_units="d")
                           .timesteps_days == (2.5,), "2.5 d = 2.5 d"))

    # ---- the default burn window is a cited quantity ------------------
    print("\ndefault burn window comes from the heritage registry:")
    window = ntr_burn_window(steps=6)
    results.append(_report("six steps sum to the cited 90 min",
                           abs(sum(window) - 90.0 * 60.0) < 1e-9,
                           f"total={sum(window):.1f} s = {sum(window)/60:.1f} min"))
    results.append(_report("steps are equal",
                           len(set(window)) == 1,
                           f"each {window[0]:.1f} s"))
    single = ntr_burn_window(steps=1)
    results.append(_report("single step equals the full window",
                           abs(single[0] - 5400.0) < 1e-9, f"{single[0]:.1f} s"))
    try:
        ntr_burn_window(steps=0)
    except DepletionError:
        results.append(True)
        print("  [PASS] rejected zero steps")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED zero steps")

    # ---- invalid inputs -----------------------------------------------
    print("\ninvalid inputs are rejected:")
    guards = [
        ("zero power", lambda: DepletionParameters(power_w=0.0,
                                                   timesteps_s=(60.0,))),
        ("negative power", lambda: DepletionParameters(power_w=-1.0e8,
                                                       timesteps_s=(60.0,))),
        ("empty timestep list", lambda: DepletionParameters(power_w=1.0e8,
                                                            timesteps_s=())),
        ("zero timestep", lambda: DepletionParameters(power_w=1.0e8,
                                                      timesteps_s=(0.0,))),
        ("negative timestep", lambda: DepletionParameters(power_w=1.0e8,
                                                          timesteps_s=(60.0, -1.0))),
        ("unknown integrator", lambda: DepletionParameters(
            power_w=1.0e8, timesteps_s=(60.0,), integrator="magic")),
        ("unknown timestep unit", lambda: DepletionParameters(
            power_w=1.0e8, timesteps_s=(60.0,), timestep_units="fortnight")),
    ]
    for label, fn in guards:
        try:
            fn()
        except DepletionError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    # ---- refusal path (the important one on this machine) -------------
    print("\npreflight names the real cause and execution refuses:")
    problems = depletion_preflight()
    results.append(_report("preflight reports a blocking problem",
                           len(problems) >= 1, f"{len(problems)} problem(s)"))
    text = " ".join(problems).lower()
    results.append(_report("names libopenmc or the missing module",
                           "libopenmc" in text or "depletion" in text,
                           problems[0][:64] if problems else ""))
    try:
        require_depletion_ready()
    except DepletionPreflightError as exc:
        results.append(True)
        print(f"  [PASS] require_depletion_ready raises: {str(exc).splitlines()[0]}")
    else:
        results.append(False)
        print("  [FAIL] require_depletion_ready passed without the library")

    try:
        run_depletion(None, DepletionParameters(power_w=1.0e8,
                                                timesteps_s=(60.0,)),
                      cross_sections="nope.xml")
    except DepletionPreflightError:
        results.append(True)
        print("  [PASS] run_depletion refuses instead of returning empty results")
    except DepletionError:
        results.append(True)
        print("  [PASS] run_depletion rejects unusable input first")
    else:
        results.append(False)
        print("  [FAIL] run_depletion returned without the library")

    # ---- result invariants --------------------------------------------
    print("\nresult invariants:")
    good = DepletionResult(
        k_history=(1.02, 1.01, 0.995), burnup_mwd_per_kg=(0.0, 1.0, 2.0),
        timesteps_days=(1e-3, 1e-3, 1e-3), total_burn_seconds=259.2,
        power_w=1.0e8, integrator="predictor", chain_file=None,
        nuclear_data="cross_sections.xml", isotopes_tracked=0, provenance={},
    )
    results.append(_report("reactivity swing computed from the k history",
                           abs(good.reactivity_swing - 0.025) < 1e-12,
                           f"swing={good.reactivity_swing:.5f}"))
    try:
        DepletionResult(k_history=(1.0, 1.1), burnup_mwd_per_kg=(0.0,),
                        timesteps_days=(1e-3,), total_burn_seconds=86.4,
                        power_w=1.0e8, integrator="predictor", chain_file=None,
                        nuclear_data=None, isotopes_tracked=0, provenance={})
    except DepletionError:
        results.append(True)
        print("  [PASS] rejected mismatched k history length")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED mismatched k history length")
    try:
        DepletionResult(k_history=(), burnup_mwd_per_kg=(),
                        timesteps_days=(), total_burn_seconds=0.0,
                        power_w=1.0e8, integrator="predictor", chain_file=None,
                        nuclear_data=None, isotopes_tracked=0, provenance={})
    except DepletionError:
        results.append(True)
        print("  [PASS] rejected empty k history")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED empty k history")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: depletion driver handles units and refuses without libopenmc")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
