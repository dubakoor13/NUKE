"""Verify the coupled core solve and the criticality search.

Everything here runs against the analytic surrogate backend, which is exactly
the point: the coupling logic, its convergence behaviour, its refusal to claim
convergence it did not achieve, and the root-finding are all verified on this
machine. Only the transport backend itself is deferred.

The thermal parameters below are SYNTHETIC test inputs chosen to be physically
plausible order-of-magnitude (a reduced demonstrator core), not heritage data.
"""
from __future__ import annotations

import math

from .coupled_core import (
    ChannelThermalClosure,
    CouplingParameters,
    CriticalPowerParameters,
    ThermalParameters,
    solve_coupled_core,
    solve_critical_power,
)
from .criticality_search import (
    CriticalitySearchError,
    check_monotone,
    critical_control_state,
    drum_worth_curve,
)
from .transport_backend import CoreState, MockCoefficients, MockTransportBackend

COEFFS = MockCoefficients(
    k_reference=1.02,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    hydrogen_temperature_coefficient_per_k=-2.0e-6,
    drum_coefficient_per_deg=2.0e-4,
    enrichment_coefficient_per_wt_percent=2.0e-2,
)

THERMAL = ThermalParameters(
    coolant_inlet_temperature_k=600.0,
    coolant_density_kg_m3=2.0,
    total_mass_flow_kg_s=0.7,
    cp_j_kg_k=14300.0,
    channel_flow_area_m2=9.8e-5,
    channel_heated_perimeter_m=0.1531,
    channel_length_m=1.32,
    coolant_conductivity_w_m_k=0.18,
    coolant_viscosity_pa_s=1.2e-5,
    coolant_prandtl=0.95,
    fuel_conductivity_w_m_k=20.0,
    ligament_thickness_m=0.002,
)

STATE = CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<54} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    backend = MockTransportBackend(coefficients=COEFFS, element_count=7,
                                   radial_peaking=1.30,
                                   shape_temperature_sensitivity_per_k=-2.0e-5)
    closure = ChannelThermalClosure(THERMAL)
    shape = backend.run(STATE).fuel_power_fraction

    # ---- thermal closure conserves energy ------------------------------
    print("thermal closure:")
    power = 1.0e7
    solution = closure.solve(shape, power)
    relative = abs(solution.energy_balance_residual_w) / power
    results.append(_report("energy balance closes on the outlet state",
                           relative < 1e-12,
                           f"residual={solution.energy_balance_residual_w:.3e} W "
                           f"({relative:.1e} relative)"))
    results.append(_report("Re is turbulent as expected for this sizing",
                           solution.reynolds > 1.0e4, f"Re={solution.reynolds:.3g}"))
    results.append(_report("fuel runs hotter than the wall",
                           solution.fuel_temperature_k > solution.wall_temperature_k
                           > solution.hydrogen_temperature_k,
                           f"T_fuel={solution.fuel_temperature_k:.0f} > "
                           f"T_wall={solution.wall_temperature_k:.0f} > "
                           f"T_H2={solution.hydrogen_temperature_k:.0f} K"))
    double = closure.solve(shape, 2.0 * power)
    results.append(_report("doubling power raises coolant temperature when"
                           " mass flow is fixed",
                           double.hydrogen_temperature_k > solution.hydrogen_temperature_k,
                           f"{solution.hydrogen_temperature_k:.0f} -> "
                           f"{double.hydrogen_temperature_k:.0f} K"))
    results.append(_report("peak element is the highest-power element",
                           abs(max(shape) - shape[int(max(range(len(shape)),
                                                          key=lambda i: shape[i]))])
                           < 1e-15,
                           f"peak fraction={max(shape):.4f}"))

    # ---- inner coupling loop converges --------------------------------
    print("\ncoupled temperature loop (fixed power):")
    coupling = CouplingParameters(target_power_w=1.0e7,
                                  temperature_tolerance_k=0.5,
                                  k_tolerance=1e-6,
                                  max_iterations=60, relaxation=0.7)
    coupled = solve_coupled_core(backend, STATE, closure, coupling)
    results.append(_report("converged", coupled.converged,
                           f"iterations={coupled.iterations}: {coupled.reason}"))
    results.append(_report("reports itself as synthetic",
                           coupled.synthetic is True, f"synthetic={coupled.synthetic}"))
    results.append(_report("final temperature is inside a sane range",
                           500.0 < coupled.fuel_temperature_k < 5000.0,
                           f"T_fuel={coupled.fuel_temperature_k:.1f} K"))
    results.append(_report("k change between final iterations is small",
                           coupled.records[-1].k_change <= 1e-6,
                           f"|dk|={coupled.records[-1].k_change:.2e}"))
    coefficient = coupled.temperature_coefficient_per_k
    results.append(_report("emergent temperature coefficient is negative",
                           coefficient is not None and coefficient < 0.0,
                           f"dk/dT={coefficient:.3e} per K"
                           if coefficient is not None else "None"))

    # ---- refusal to claim convergence it did not achieve --------------
    print("\nnon-convergence is reported, not hidden:")
    tight = CouplingParameters(target_power_w=1.0e7,
                               temperature_tolerance_k=1e-9,
                               k_tolerance=1e-12,
                               max_iterations=2, relaxation=0.7)
    starved = solve_coupled_core(backend, STATE, closure, tight)
    results.append(_report("insufficient iterations reports converged=False",
                           starved.converged is False, starved.reason))
    results.append(_report("reason states the iteration limit",
                           "max_iterations" in starved.reason, starved.reason[:60]))

    # ---- critical power solve ----------------------------------------
    print("\ncritical power solve (power becomes a RESULT):")
    critical = solve_critical_power(
        backend, STATE, closure,
        CriticalPowerParameters(power_lower_w=1.0e5, power_upper_w=1.0e9,
                                k_tolerance=1e-6, inner_max_iterations=60),
    )
    results.append(_report("converged on a critical power", critical.converged,
                           f"P={critical.power_w:.4e} W: {critical.reason}"))
    results.append(_report("k at the solved power is unity to tolerance",
                           abs(critical.k_eff - 1.0) <= 1e-6,
                           f"k={critical.k_eff:.8f}"))
    results.append(_report("solved power lies inside the search bracket",
                           1.0e5 < critical.power_w < 1.0e9,
                           f"P={critical.power_w:.4e} W"))
    results.append(_report("solved state is self-consistent (converged)",
                           critical.solution is not None
                           and critical.solution.converged,
                           f"inner iterations={critical.solution.iterations}"
                           if critical.solution else "none"))
    # Independent check: re-evaluate the backend at the solved state.
    verify = backend.run(STATE.with_changes(
        fuel_temperature_k=critical.solution.fuel_temperature_k,
        hydrogen_temperature_k=critical.solution.hydrogen_temperature_k))
    results.append(_report("independent re-evaluation agrees on k",
                           abs(verify.k_eff - critical.k_eff) < 1e-9,
                           f"{verify.k_eff:.8f} vs {critical.k_eff:.8f}"))

    # A bracket that cannot contain criticality must be refused.
    unreachable = solve_critical_power(
        backend, STATE, closure,
        CriticalPowerParameters(power_lower_w=1.0e5, power_upper_w=1.02e5,
                                k_tolerance=1e-6),
    )
    results.append(_report("unbracketed power range is refused",
                           unreachable.converged is False,
                           unreachable.reason[:72]))

    # ---- criticality search on the drums ------------------------------
    print("\ncriticality search (control drums):")
    fixed = STATE.with_changes(fuel_temperature_k=1400.0,
                               hydrogen_temperature_k=1000.0)
    curve = drum_worth_curve(backend, fixed, [-40.0, -20.0, 0.0, 20.0, 40.0])
    results.append(_report("drum worth curve is monotone", check_monotone(curve),
                           " ".join(f"{k:.4f}" for _, k, _ in curve)))

    search = critical_control_state(backend, fixed, "drum_angle_deg",
                                    (-40.0, 40.0), target_k=1.0,
                                    tolerance=1e-8, max_iterations=200)
    results.append(_report("search converged", search.converged, search.reason))
    results.append(_report("achieved k is unity to high precision",
                           abs(search.k_eff - 1.0) < 1e-7, f"k={search.k_eff:.10f}"))
    # Analytic ground truth for this surrogate: k is linear in drum angle.
    k_at_zero = backend.run(fixed.with_changes(drum_angle_deg=0.0)).k_eff
    analytic = (1.0 - k_at_zero) / COEFFS.drum_coefficient_per_deg
    # The angle can only be located as finely as the k tolerance allows, so the
    # correct assertion propagates that tolerance through dk/dtheta instead of
    # demanding a precision the convergence criterion cannot deliver.
    angle_tolerance = 1e-8 / abs(COEFFS.drum_coefficient_per_deg)
    results.append(_report("angle matches analytic within k-tolerance budget",
                           abs(search.parameter_value - analytic) <= angle_tolerance,
                           f"found={search.parameter_value:.8f} "
                           f"analytic={analytic:.8f} "
                           f"|diff|={abs(search.parameter_value - analytic):.2e} "
                           f"<= {angle_tolerance:.2e}"))
    results.append(_report("history records every evaluation",
                           len(search.history) >= 3, f"{len(search.history)} evaluations"))

    print("\nsearch refuses ill-posed problems:")
    guards = [
        ("bracket that never crosses unity",
         lambda: critical_control_state(backend, fixed.with_changes(
             fuel_temperature_k=293.6, hydrogen_temperature_k=293.6),
             "drum_angle_deg", (0.0, 1.0), target_k=1.0)),
        ("unsupported parameter name",
         lambda: critical_control_state(backend, fixed, "control_rod_depth",
                                        (0.0, 1.0))),
        ("enrichment bound above the 20 wt% cap",
         lambda: critical_control_state(backend, fixed, "enrichment_wt_percent",
                                        (1.0, 25.0))),
        ("degenerate bounds",
         lambda: critical_control_state(backend, fixed, "drum_angle_deg",
                                        (5.0, 5.0))),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ValueError, CriticalitySearchError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    # Non-monotone curve detection.
    non_monotone = [(0.0, 1.0, 0.0), (1.0, 1.2, 0.0), (2.0, 1.1, 0.0)]
    results.append(_report("non-monotone curve is detected",
                           check_monotone(non_monotone) is False,
                           "reversal at the third point"))

    # Parameter guards.
    print("\nparameter guards:")
    param_guards = [
        ("relaxation above 1", lambda: CouplingParameters(
            target_power_w=1e7, relaxation=1.5).validate()),
        ("zero target power", lambda: CouplingParameters(
            target_power_w=0.0).validate()),
        ("inverted power bounds", lambda: CriticalPowerParameters(
            power_lower_w=1e8, power_upper_w=1e6).validate()),
        ("non-positive mass flow", lambda: ThermalParameters(
            **{**THERMAL.__dict__, "total_mass_flow_kg_s": 0.0}).validate()),
    ]
    for label, fn in param_guards:
        try:
            fn()
        except (ValueError, TypeError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: coupled core loop and criticality search behave as specified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
