"""Verify the adjoint solve and importance-weighted beta_eff.

Three identities do the work:

1. **Reciprocity** - ``<phi*, A phi>`` must equal ``<A^T phi*, phi>`` for the
   computed forward and adjoint vectors. This is not a property of the code; it
   is a property of the linear algebra, so it validates both solves at once.
2. **Shared eigenvalue** - the forward and adjoint problems must return the same
   ``k``.
3. **One-group degeneracy** - with one group the operator is symmetric, so the
   adjoint equals the forward flux and ``beta_eff`` must equal ``beta`` exactly.
   That is the limit that catches an adjoint implemented as "flux again" in
   disguise.
"""
from __future__ import annotations

import math

from .adjoint import (
    AdjointError,
    importance_weighted_beta,
    solve_slab_adjoint,
)
from .delayed_parameters import (
    BETA_U235_THERMAL,
    BETA_U238_PLACEHOLDER,
    FissionContribution,
    mixture_delayed_fraction,
)
from .diffusion import MultigroupCrossSections, one_group_cross_sections

D1 = 1.30
SA1 = 0.0090
NUSF1 = 0.0165
THICKNESS = 60.0
EXTRAPOLATION = 2.0

ONE_GROUP = one_group_cross_sections(D1, SA1, NUSF1)

TWO_GROUP = MultigroupCrossSections(
    diffusion_coefficient_cm=(1.35, 0.85),
    sigma_absorption_cm=(0.0080, 0.0850),
    nu_sigma_fission_cm=(0.0045, 0.1300),
    chi=(1.0, 0.0),
    scatter_matrix=((0.0, 0.0180), (0.0, 0.0)),
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- the adjoint solve --------------------------------------------
    print("forward and adjoint solves:")
    one, forward, adjoint = solve_slab_adjoint(ONE_GROUP, THICKNESS, EXTRAPOLATION,
                                               mesh_intervals=200)
    print(f"    one-group: k_forward = {one.k_effective:.9f}   "
          f"k_adjoint = {one.adjoint_k_effective:.9f}")
    results.append(_report("both solves converged", one.converged is True,
                           "converged"))
    results.append(_report("the adjoint returns the same eigenvalue",
                           one.k_agreement < 1e-9,
                           f"relative {one.k_agreement:.2e}"))
    results.append(_report("reciprocity holds",
                           one.reciprocity_residual < 1e-12,
                           f"residual {one.reciprocity_residual:.2e}"))

    # A symmetric one-group operator means the adjoint IS the forward flux.
    forward_normalised = forward / max(abs(forward))
    adjoint_normalised = adjoint / max(abs(adjoint))
    difference = float(abs(forward_normalised - adjoint_normalised).max())
    print(f"    one-group |phi - phi*|_inf = {difference:.3e}")
    results.append(_report("one-group adjoint equals the forward flux",
                           difference < 1e-10, f"{difference:.2e}"))
    results.append(_report("one-group flux is positive",
                           bool((forward > 0.0).all()), "all nodes positive"))

    # ---- two-group: the adjoint should differ -------------------------
    print("\ntwo-group: the adjoint is genuinely different:")
    two, forward2, adjoint2 = solve_slab_adjoint(TWO_GROUP, THICKNESS,
                                                 EXTRAPOLATION, mesh_intervals=200)
    print(f"    k_forward = {two.k_effective:.9f}   "
          f"k_adjoint = {two.adjoint_k_effective:.9f}")
    print(f"    forward group peaks {tuple(round(p, 3) for p in two.forward_peaks)}")
    print(f"    adjoint group peaks {tuple(round(p, 3) for p in two.adjoint_peaks)}")
    results.append(_report("two-group eigenvalues agree",
                           two.k_agreement < 1e-9, f"{two.k_agreement:.2e}"))
    results.append(_report("two-group reciprocity holds",
                           two.reciprocity_residual < 1e-12,
                           f"{two.reciprocity_residual:.2e}"))
    results.append(_report("both group fluxes are positive",
                           all(peak > 0.0 for peak in two.forward_peaks),
                           "fundamental mode"))

    # ---- one-group beta_eff must equal beta ---------------------------
    print("\none-group beta_eff collapses to beta:")
    beta = BETA_U235_THERMAL.beta
    one_beta, _ = importance_weighted_beta(
        ONE_GROUP, THICKNESS, EXTRAPOLATION, (beta,), mesh_intervals=200)
    print(f"    {one_beta.describe()}")
    results.append(_report("beta_eff equals the input beta exactly",
                           abs(one_beta.beta_effective - beta) / beta < 1e-12,
                           f"{one_beta.beta_effective:.10f} vs {beta}"))
    results.append(_report("the importance correction is 1.0",
                           abs(one_beta.importance_correction - 1.0) < 1e-12,
                           f"{one_beta.importance_correction:.12f}"))
    results.append(_report("all the fission weight is in the one group",
                           abs(one_beta.group_weights[0] - 1.0) < 1e-12,
                           f"{one_beta.group_weights[0]:.12f}"))

    # ---- two-group beta_eff -------------------------------------------
    print("\ntwo-group beta_eff is weighted across groups:")
    # Fast-group fissions are dominated by 238U in a low-enrichment core, and
    # 238U has a much higher delayed fraction than 235U. (The 238U value is the
    # explicitly-flagged placeholder in delayed_parameters, which is fine here:
    # this test checks the weighting algebra, not the nuclide data.)
    fast_beta = BETA_U238_PLACEHOLDER.beta
    thermal_beta = beta
    two_beta, two_solution = importance_weighted_beta(
        TWO_GROUP, THICKNESS, EXTRAPOLATION, (fast_beta, thermal_beta),
        mesh_intervals=200)
    print(f"    group betas: fast {fast_beta:.6f}, thermal {thermal_beta:.6f}")
    print(f"    {two_beta.describe()}")
    results.append(_report("beta_eff lies between the group betas",
                           min(fast_beta, thermal_beta) - 1e-15
                           <= two_beta.beta_effective
                           <= max(fast_beta, thermal_beta) + 1e-15,
                           f"{two_beta.beta_effective:.6f}"))
    results.append(_report("group weights sum to one",
                           abs(math.fsum(two_beta.group_weights) - 1.0) < 1e-12,
                           "normalised"))
    results.append(_report("the adjoint is recorded as used",
                           two_beta.adjoint_used is True, "adjoint_used=True"))
    results.append(_report("k comes from the same solve",
                           abs(two_beta.k_effective - two.k_effective) < 1e-12,
                           f"{two_beta.k_effective:.9f}"))

    # If both groups carry the same beta, weighting cannot change the answer.
    same_beta, _ = importance_weighted_beta(
        TWO_GROUP, THICKNESS, EXTRAPOLATION, (beta, beta), mesh_intervals=200)
    results.append(_report("equal group betas give beta_eff = beta",
                           abs(same_beta.beta_effective - beta) / beta < 1e-12,
                           f"{same_beta.beta_effective:.10f}"))
    results.append(_report("different group betas DO change the answer",
                           abs(two_beta.beta_effective - beta) / beta > 1e-12,
                           f"beta_eff {two_beta.beta_effective:.6f} vs {beta:.6f}"))
    # With adjoint weighting now differing from forward-only weighting, the
    # correction must be a real number rather than the identically-1.0 value it
    # took when both sides used the same weights.
    results.append(_report("the importance correction is non-trivial",
                           abs(two_beta.importance_correction - 1.0) > 1e-6,
                           f"correction {two_beta.importance_correction:.6f} "
                           f"({two_beta.correction_percent:+.4f}%)"))

    # ---- hand this to the dollars conversion --------------------------
    print("\nfeeds the dollars conversion:")
    mixture = mixture_delayed_fraction([FissionContribution(BETA_U235_THERMAL, 1.0)])
    results.append(_report("the budget can now carry a computed correction",
                           math.isfinite(two_beta.importance_correction)
                           and two_beta.importance_correction > 0.0,
                           f"correction {two_beta.importance_correction:.6f}"))
    results.append(_report("the mixture helper still works independently",
                           abs(mixture.beta_mixture - beta) < 1e-15,
                           "unchanged contract"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid inputs are rejected:")
    guards = [
        ("beta array length mismatch", lambda: importance_weighted_beta(
            TWO_GROUP, THICKNESS, EXTRAPOLATION, (beta,), mesh_intervals=50)),
        ("beta outside [0, 1)", lambda: importance_weighted_beta(
            ONE_GROUP, THICKNESS, EXTRAPOLATION, (1.5,), mesh_intervals=50)),
        ("negative beta", lambda: importance_weighted_beta(
            ONE_GROUP, THICKNESS, EXTRAPOLATION, (-0.01,), mesh_intervals=50)),
        ("too coarse a mesh", lambda: solve_slab_adjoint(
            ONE_GROUP, THICKNESS, EXTRAPOLATION, mesh_intervals=2)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (AdjointError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: adjoint is real and beta_eff is importance-weighted")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
