"""Spatially resolved core feedback.

The delivered model carries one fuel temperature and one coolant temperature
into transport. Its own handoff said so: *"OpenMC material feedback is still
UNIFORM in the fuel and H2 material surrogates... This is not per-voxel
temperature reconstruction in the transport mesh."*

That uniform assumption is the last substantial fidelity gap in the core physics,
because it cannot represent a hot channel. A core with a 1.4 peaking factor has
elements running hundreds of kelvin hotter than the average, and the reactivity
consequence of that distribution is precisely what a thermal margin analysis
depends on.

This module carries a **temperature per element**: the transport solve sees the
whole distribution, the thermal closure updates each element from its own power
fraction, and the loop iterates to a self-consistent map.

Design notes
------------
* ``SpatialCoreState`` reuses ``CoreState`` for every scalar (drum, enrichment,
  reflector) and adds the two per-element vectors. It converts to a ``CoreState``
  carrying the *power-weighted mean* temperatures, so an existing uniform backend
  can still be driven, and the difference between the uniform and spatial
  answers is measurable rather than assumed.
* Backends that can genuinely use the distribution implement
  ``run_spatial``; the OpenMC adapter does so by assigning each element its own
  material temperature. Backends without that capability raise rather than
  silently averaging, so a spatial study can never quietly degrade to a uniform
  one.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace

from .transport_backend import CoreState, TransportBackend, TransportResult


class SpatialCoreError(ValueError):
    """Raised when a spatial core state or solve is not well posed."""


@dataclass(frozen=True)
class SpatialCoreState:
    """A core state with a temperature per fuel element.

    ``fuel_temperatures_k`` and ``hydrogen_temperatures_k`` are per-element
    vectors; ``basis`` is the scalar state they share (drum angle, enrichment,
    reflector temperature, particle counts).
    """

    fuel_temperatures_k: tuple[float, ...]
    hydrogen_temperatures_k: tuple[float, ...]
    basis: CoreState

    def __post_init__(self) -> None:
        if not self.fuel_temperatures_k:
            raise SpatialCoreError("at least one element temperature is required")
        if len(self.fuel_temperatures_k) != len(self.hydrogen_temperatures_k):
            raise SpatialCoreError(
                f"fuel and hydrogen temperature vectors must match in length, got "
                f"{len(self.fuel_temperatures_k)} and "
                f"{len(self.hydrogen_temperatures_k)}"
            )
        for vector, label in ((self.fuel_temperatures_k, "fuel"),
                             (self.hydrogen_temperatures_k, "hydrogen")):
            for value in vector:
                if not math.isfinite(value) or value <= 0.0:
                    raise SpatialCoreError(
                        f"{label} temperature must be finite and positive, got {value!r}"
                    )

    @property
    def element_count(self) -> int:
        return len(self.fuel_temperatures_k)

    def mean_fuel_temperature(self) -> float:
        return math.fsum(self.fuel_temperatures_k) / self.element_count

    def mean_hydrogen_temperature(self) -> float:
        return math.fsum(self.hydrogen_temperatures_k) / self.element_count

    def power_weighted_temperatures(
        self, power_fractions: tuple[float, ...]
    ) -> tuple[float, float]:
        """Heat-capacity-weighted means, which are the right uniform equivalents.

        Weighting by power fraction is the natural choice here: an element that
        produces more heat contributes proportionally more to the effective
        cross-section temperature the lumped model would use.
        """
        if len(power_fractions) != self.element_count:
            raise SpatialCoreError(
                f"power fraction count {len(power_fractions)} does not match "
                f"element count {self.element_count}"
            )
        total = math.fsum(power_fractions)
        if total <= 0.0:
            raise SpatialCoreError("power fractions sum to zero")
        weights = [fraction / total for fraction in power_fractions]
        fuel = math.fsum(w * t for w, t in zip(weights, self.fuel_temperatures_k))
        hydrogen = math.fsum(w * t for w, t in
                             zip(weights, self.hydrogen_temperatures_k))
        return fuel, hydrogen

    def arithmetic_mean_temperatures(self) -> tuple[float, float]:
        """Plain element-wise means.

        This is the mean ``MockTransportBackend.run_spatial`` uses, so a uniform
        comparison built on it isolates the pure *distribution* effect.
        """
        return self.mean_fuel_temperature(), self.mean_hydrogen_temperature()

    def uniform_equivalent(self, power_fractions: tuple[float, ...],
                           weighting: str = "arithmetic") -> CoreState:
        """Collapse to the uniform state a lumped backend would see.

        ``weighting`` selects the averaging:

        * ``"arithmetic"`` (default) - element-wise mean, matching what
          ``run_spatial`` uses internally. The distribution penalty measured
          against this isolates the shape effect with no averaging artifact.
        * ``"power"`` - power-weighted mean, which is arguably the more physical
          single temperature for a lumped model, since a hotter element
          contributes more to the reaction rates.

        The two differ, and that difference is itself a modelling choice worth
        reporting rather than burying: for a 1.4-peaked core it is tens of
        kelvin, which is several pcm of reactivity.
        """
        if weighting == "arithmetic":
            fuel, hydrogen = self.arithmetic_mean_temperatures()
        elif weighting == "power":
            fuel, hydrogen = self.power_weighted_temperatures(power_fractions)
        else:
            raise SpatialCoreError(
                f"weighting must be 'arithmetic' or 'power', got {weighting!r}"
            )
        return self.basis.with_changes(fuel_temperature_k=fuel,
                                       hydrogen_temperature_k=hydrogen)

    def averaging_discrepancy_k(self, power_fractions: tuple[float, ...]) -> float:
        """Difference between the power-weighted and arithmetic mean fuel temperature.

        Reported explicitly because it is the size of the ambiguity in "the"
        uniform equivalent temperature.
        """
        power_mean, _ = self.power_weighted_temperatures(power_fractions)
        arithmetic_mean, _ = self.arithmetic_mean_temperatures()
        return power_mean - arithmetic_mean

    def temperature_spread(self) -> tuple[float, float]:
        """Peak-minus-mean for fuel and coolant, in kelvin."""
        fuel_peak = max(self.fuel_temperatures_k)
        hydrogen_peak = max(self.hydrogen_temperatures_k)
        return (fuel_peak - self.mean_fuel_temperature(),
                hydrogen_peak - self.mean_hydrogen_temperature())

    @classmethod
    def uniform(cls, basis: CoreState, element_count: int) -> SpatialCoreState:
        """Build a spatially flat state from a uniform one."""
        if element_count < 1:
            raise SpatialCoreError("element_count must be at least 1")
        return cls(
            fuel_temperatures_k=tuple([basis.fuel_temperature_k] * element_count),
            hydrogen_temperatures_k=tuple([basis.hydrogen_temperature_k] * element_count),
            basis=basis,
        )


def supports_spatial(backend: TransportBackend) -> bool:
    """True when a backend can accept a per-element temperature distribution."""
    return hasattr(backend, "run_spatial")


# ---------------------------------------------------------------- thermal side


@dataclass(frozen=True)
class ElementThermalParameters:
    """Per-element single-channel thermal closure.

    Deliberately the same physics as ``coupled_core.ChannelThermalClosure`` but
    producing a *vector*, so each element gets its own fuel and coolant state
    from its own power share.
    """

    coolant_inlet_temperature_k: float
    total_mass_flow_kg_s: float
    cp_j_kg_k: float
    channel_heated_perimeter_m: float
    channel_length_m: float
    coolant_conductivity_w_m_k: float
    coolant_viscosity_pa_s: float
    coolant_density_kg_m3: float
    coolant_prandtl: float
    fuel_conductivity_w_m_k: float
    ligament_thickness_m: float
    channel_flow_area_m2: float

    def __post_init__(self) -> None:
        for name in ("coolant_inlet_temperature_k", "total_mass_flow_kg_s",
                     "cp_j_kg_k", "channel_heated_perimeter_m",
                     "channel_length_m", "coolant_conductivity_w_m_k",
                     "coolant_viscosity_pa_s", "coolant_density_kg_m3",
                     "coolant_prandtl", "fuel_conductivity_w_m_k",
                     "ligament_thickness_m", "channel_flow_area_m2"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise SpatialCoreError(f"{name} must be finite and positive, got {value!r}")


@dataclass(frozen=True)
class ElementTemperatures:
    """Per-element thermal result."""

    fuel_temperatures_k: tuple[float, ...]
    hydrogen_temperatures_k: tuple[float, ...]
    wall_temperatures_k: tuple[float, ...]
    heat_fluxes_w_m2: tuple[float, ...]
    reynolds: float
    heat_transfer_coefficient_w_m2_k: float
    energy_balance_residual_w: float


def _nusselt(reynolds: float, prandtl: float) -> float:
    """Dittus-Boelter for turbulent heating; laminar constant-Nu fallback."""
    if reynolds < 2300.0:
        return 3.66
    return 0.023 * reynolds ** 0.8 * prandtl ** 0.4


def element_temperatures(
    power_fractions: tuple[float, ...],
    total_power_w: float,
    parameters: ElementThermalParameters,
) -> ElementTemperatures:
    """Solve each element's coolant and fuel temperature from its power share."""
    if not power_fractions:
        raise SpatialCoreError("at least one element power fraction is required")
    if not math.isfinite(total_power_w) or total_power_w <= 0.0:
        raise SpatialCoreError("total power must be finite and positive")
    total_fraction = math.fsum(power_fractions)
    if abs(total_fraction - 1.0) > 1e-9:
        raise SpatialCoreError(
            f"power fractions must sum to 1, got {total_fraction!r}"
        )
    if any(fraction < 0.0 for fraction in power_fractions):
        raise SpatialCoreError("power fractions cannot be negative")

    p = parameters
    count = len(power_fractions)
    mass_per_element = p.total_mass_flow_kg_s / count
    d_h = 4.0 * p.channel_flow_area_m2 / p.channel_heated_perimeter_m
    velocity = mass_per_element / (p.coolant_density_kg_m3 * p.channel_flow_area_m2)
    reynolds = p.coolant_density_kg_m3 * velocity * d_h / p.coolant_viscosity_pa_s
    if reynolds <= 0.0:
        raise SpatialCoreError("non-positive Reynolds number")
    h_conv = (_nusselt(reynolds, p.coolant_prandtl)
              * p.coolant_conductivity_w_m_k / d_h)

    fuel: list[float] = []
    hydrogen: list[float] = []
    wall: list[float] = []
    fluxes: list[float] = []
    outlets: list[float] = []
    for fraction in power_fractions:
        power = total_power_w * fraction
        outlet = p.coolant_inlet_temperature_k + power / (mass_per_element * p.cp_j_kg_k)
        bulk_mean = 0.5 * (p.coolant_inlet_temperature_k + outlet)
        flux = power / (p.channel_heated_perimeter_m * p.channel_length_m)
        wall_t = bulk_mean + flux / h_conv
        fuel_t = wall_t + flux * p.ligament_thickness_m / p.fuel_conductivity_w_m_k
        outlets.append(outlet)
        hydrogen.append(bulk_mean)
        wall.append(wall_t)
        fuel.append(fuel_t)
        fluxes.append(flux)

    carried = math.fsum(
        mass_per_element * p.cp_j_kg_k * (outlet - p.coolant_inlet_temperature_k)
        for outlet in outlets
    )
    return ElementTemperatures(
        fuel_temperatures_k=tuple(fuel),
        hydrogen_temperatures_k=tuple(hydrogen),
        wall_temperatures_k=tuple(wall),
        heat_fluxes_w_m2=tuple(fluxes),
        reynolds=reynolds,
        heat_transfer_coefficient_w_m2_k=h_conv,
        energy_balance_residual_w=carried - total_power_w,
    )


# ------------------------------------------------------------------- the loop


@dataclass(frozen=True)
class SpatialCouplingParameters:
    """Controls for the spatially resolved Picard iteration."""

    target_power_w: float
    temperature_tolerance_k: float = 0.5
    k_tolerance: float = 1.0e-6
    max_iterations: int = 100
    relaxation: float = 0.6

    def __post_init__(self) -> None:
        if not math.isfinite(self.target_power_w) or self.target_power_w <= 0.0:
            raise SpatialCoreError("target power must be finite and positive")
        if self.temperature_tolerance_k <= 0.0:
            raise SpatialCoreError("temperature tolerance must be positive")
        if self.k_tolerance <= 0.0:
            raise SpatialCoreError("k tolerance must be positive")
        if self.max_iterations < 1:
            raise SpatialCoreError("max_iterations must be at least 1")
        if not 0.0 < self.relaxation <= 1.0:
            raise SpatialCoreError("relaxation must lie in (0, 1]")


@dataclass(frozen=True)
class SpatialIteration:
    index: int
    k_eff: float
    peak_fuel_temperature_k: float
    mean_fuel_temperature_k: float
    peak_to_mean_temperature: float
    temperature_change_k: float


@dataclass(frozen=True)
class SpatialSolution:
    """A self-consistent spatially resolved core state."""

    converged: bool
    reason: str
    iterations: int
    k_eff: float
    k_sigma: float
    state: SpatialCoreState
    power_fractions: tuple[float, ...]
    transport: TransportResult
    thermal: ElementTemperatures
    temperature_coefficient_per_k: float | None
    spatial_reactivity_penalty: float | None
    records: tuple[SpatialIteration, ...] = field(default_factory=tuple)

    @property
    def synthetic(self) -> bool:
        return self.transport.synthetic

    @property
    def peak_fuel_temperature_k(self) -> float:
        return max(self.state.fuel_temperatures_k)

    @property
    def mean_fuel_temperature_k(self) -> float:
        return self.state.mean_fuel_temperature()

    @property
    def peaking_ratio(self) -> float:
        """Peak-to-mean fuel temperature across elements."""
        return self.peak_fuel_temperature_k / self.mean_fuel_temperature_k


def solve_spatial_core(
    backend: TransportBackend,
    initial_state: SpatialCoreState,
    thermal_parameters: ElementThermalParameters,
    parameters: SpatialCouplingParameters,
) -> SpatialSolution:
    """Iterate transport and per-element thermal closures to consistency.

    Requires a backend that accepts a temperature distribution. A uniform-only
    backend raises, because silently averaging would present a lumped answer as
    a spatially resolved one - the exact failure this module exists to remove.
    """
    if not supports_spatial(backend):
        raise SpatialCoreError(
            f"backend {backend.name!r} cannot accept a per-element temperature "
            f"distribution (no run_spatial); use solve_coupled_core for a lumped "
            f"analysis instead of degrading a spatial study to a uniform one"
        )
    backend.require_ready()
    if initial_state.element_count < 2:
        raise SpatialCoreError(
            "a spatial solve needs at least two elements; a single element is a "
            "lumped model and belongs in coupled_core"
        )

    state = initial_state
    fuel = list(state.fuel_temperatures_k)
    hydrogen = list(state.hydrogen_temperatures_k)
    records: list[SpatialIteration] = []
    result = backend.run_spatial(state)
    thermal = element_temperatures(result.fuel_power_fraction,
                                   parameters.target_power_w, thermal_parameters)

    converged = False
    reason = f"reached max_iterations={parameters.max_iterations}"
    previous_k = result.k_eff

    for index in range(1, parameters.max_iterations + 1):
        new_fuel = [old + parameters.relaxation * (target - old)
                    for old, target in zip(fuel, thermal.fuel_temperatures_k)]
        new_hydrogen = [old + parameters.relaxation * (target - old)
                        for old, target in zip(hydrogen, thermal.hydrogen_temperatures_k)]
        if min(new_fuel) <= 0.0 or min(new_hydrogen) <= 0.0:
            return SpatialSolution(
                converged=False,
                reason="iteration produced a non-physical element temperature",
                iterations=index, k_eff=result.k_eff, k_sigma=result.k_sigma,
                state=state, power_fractions=result.fuel_power_fraction,
                transport=result, thermal=thermal,
                temperature_coefficient_per_k=None,
                spatial_reactivity_penalty=None, records=tuple(records),
            )

        state = SpatialCoreState(
            fuel_temperatures_k=tuple(new_fuel),
            hydrogen_temperatures_k=tuple(new_hydrogen),
            basis=state.basis,
        )
        result = backend.run_spatial(state)
        thermal = element_temperatures(result.fuel_power_fraction,
                                       parameters.target_power_w, thermal_parameters)

        fuel_change = max(abs(target - current) for target, current
                          in zip(thermal.fuel_temperatures_k, new_fuel))
        hydrogen_change = max(abs(target - current) for target, current
                              in zip(thermal.hydrogen_temperatures_k, new_hydrogen))
        change = max(fuel_change, hydrogen_change)
        k_change = abs(result.k_eff - previous_k)
        mean_fuel = math.fsum(new_fuel) / len(new_fuel)
        records.append(SpatialIteration(
            index=index, k_eff=result.k_eff,
            peak_fuel_temperature_k=max(new_fuel),
            mean_fuel_temperature_k=mean_fuel,
            peak_to_mean_temperature=max(new_fuel) / mean_fuel,
            temperature_change_k=change,
        ))
        previous_k = result.k_eff
        fuel, hydrogen = new_fuel, new_hydrogen

        if change <= parameters.temperature_tolerance_k and k_change <= parameters.k_tolerance:
            converged = True
            reason = (f"element temperature change {change:.4g} K <= "
                      f"{parameters.temperature_tolerance_k} K and |dk| "
                      f"{k_change:.4g} <= {parameters.k_tolerance}")
            break

    coefficient, penalty = _spatial_diagnostics(
        backend, state, result, parameters, thermal_parameters)

    return SpatialSolution(
        converged=converged, reason=reason, iterations=len(records),
        k_eff=result.k_eff, k_sigma=result.k_sigma, state=state,
        power_fractions=result.fuel_power_fraction, transport=result,
        thermal=thermal, temperature_coefficient_per_k=coefficient,
        spatial_reactivity_penalty=penalty, records=tuple(records),
    )


def _spatial_diagnostics(
    backend: TransportBackend,
    state: SpatialCoreState,
    result: TransportResult,
    parameters: SpatialCouplingParameters,
    thermal_parameters: ElementThermalParameters,
) -> tuple[float | None, float | None]:
    """Emergent dk/dT and the reactivity cost of the spatial distribution.

    The penalty is the difference between ``k`` for the true temperature map and
    ``k`` for the equivalent uniform map at the same power-weighted mean
    temperature. It is the quantity the lumped model structurally cannot see.
    """
    delta = 10.0
    try:
        hotter = backend.run_spatial(SpatialCoreState(
            fuel_temperatures_k=tuple(t + delta for t in state.fuel_temperatures_k),
            hydrogen_temperatures_k=state.hydrogen_temperatures_k,
            basis=state.basis))
        cooler = backend.run_spatial(SpatialCoreState(
            fuel_temperatures_k=tuple(t - delta for t in state.fuel_temperatures_k),
            hydrogen_temperatures_k=state.hydrogen_temperatures_k,
            basis=state.basis))
        slope = (hotter.k_eff - cooler.k_eff) / (2.0 * delta)
    except (ValueError, ArithmeticError):
        slope = None

    try:
        uniform_state = state.uniform_equivalent(result.fuel_power_fraction)
        flat = SpatialCoreState.uniform(uniform_state, state.element_count)
        uniform_result = backend.run_spatial(flat)
        penalty = uniform_result.k_eff - result.k_eff
    except (ValueError, ArithmeticError):
        penalty = None
    del parameters, thermal_parameters
    return slope, penalty
