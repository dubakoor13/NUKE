"""Verify subcritical multiplication and the approach-to-criticality extrapolation.

The multiplication factor has an exact analytic form and a cross-check against
the reactivity formulation, so the numerics are checkable. The extrapolation is
tested by feeding it data generated from a known critical position and requiring
that it recovers it.
"""
from __future__ import annotations

import math

from .startup import (
    StartupError,
    approach_to_criticality,
    extrapolate_critical_parameter,
    multiplication_from_reactivity,
    steady_source_power,
    subcritical_multiplication,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    print("subcritical multiplication M = 1/(1-k):")
    for k, expected in ((0.0, 1.0), (0.5, 2.0), (0.9, 10.0), (0.99, 100.0),
                        (0.999, 1000.0)):
        got = subcritical_multiplication(k)
        print(f"    k={k:<6} M={got:>9.3f}  expected {expected:>9.1f}")
        results.append(_report(f"k={k} gives M={expected:g}",
                               abs(got - expected) / expected < 1e-12,
                               f"rel {abs(got-expected)/expected:.1e}"))

    print("\nreactivity form agrees with the k form:")
    for k in (0.5, 0.9, 0.99):
        reactivity = (k - 1.0) / k
        from_k = subcritical_multiplication(k)
        from_rho = multiplication_from_reactivity(reactivity)
        results.append(_report(f"k={k}: both formulations agree",
                               abs(from_k - from_rho) / from_k < 1e-12,
                               f"{from_k:.6f} vs {from_rho:.6f}"))
    results.append(_report("rho = -0.1 gives M = 11",
                           abs(multiplication_from_reactivity(-0.1) - 11.0) < 1e-12,
                           f"{multiplication_from_reactivity(-0.1):.6f}"))

    print("\ndivergence as criticality is approached:")
    sequence = [subcritical_multiplication(1.0 - 10.0 ** -n) for n in range(1, 6)]
    print("    1-k = 1e-1..1e-5 -> M = " + " ".join(f"{m:.0f}" for m in sequence))
    results.append(_report("multiplication grows monotonically",
                           all(b > a for a, b in zip(sequence, sequence[1:])),
                           "10 -> 100000"))
    results.append(_report("each decade of 1-k adds a decade of M",
                           abs(sequence[1] / sequence[0] - 10.0) < 1e-9,
                           f"ratio {sequence[1]/sequence[0]:.6f}"))

    print("\nsource-driven steady power:")
    source = 1.0e10
    low = steady_source_power(source, 0.9)
    high = steady_source_power(source, 0.99)
    print(f"    k=0.90 -> {low:.4e} W   k=0.99 -> {high:.4e} W")
    results.append(_report("power scales with the multiplication",
                           abs(high / low - 10.0) < 1e-9,
                           f"ratio {high/low:.6f}"))
    results.append(_report("absolute power matches S*M*E_f",
                           abs(low - source * 10.0 * 3.204e-11) / low < 1e-12,
                           f"{low:.4e} W"))

    print("\napproach to criticality extrapolates the critical position:")
    # Spring position 0..1000 with 1.0 pcm per unit: criticality at 1500 units.
    parameters = [500.0, 700.0, 900.0, 1100.0]
    critical_units = 1500.0
    base_k = 1.0 - critical_units * 1.0e-5
    effects = [p * 1.0e-5 for p in parameters]
    points = approach_to_criticality(parameters, effects, base_k=base_k)
    for point in points:
        print(f"    param={point.parameter:7.1f}  k={point.k_eff:.6f}  "
              f"M={point.multiplication:7.3f}  1/CR={point.inverse_count_rate:.5f}")
    predicted = extrapolate_critical_parameter(points)
    print(f"    extrapolated critical position = {predicted:.3f} "
          f"(true {critical_units:.1f})")
    results.append(_report("extrapolation recovers the true critical position",
                           abs(predicted - critical_units) / critical_units < 1e-9,
                           f"{predicted:.4f} vs {critical_units:.1f}"))
    inverses = [point.inverse_count_rate for point in points]
    slopes = {(b - a) for a, b in zip(inverses, inverses[1:])}
    results.append(_report("inverse count rate is linear in the parameter",
                           max(slopes) - min(slopes) < 1e-15,
                           "constant step in 1/CR"))
    results.append(_report("count rate rises monotonically",
                           all(b.count_rate > a.count_rate
                               for a, b in zip(points, points[1:])),
                           f"{points[0].count_rate:.3f} -> "
                           f"{points[-1].count_rate:.3f}"))

    print("\ndivergence and ill-posed cases are refused:")
    guards = [
        ("critical core", lambda: subcritical_multiplication(1.0)),
        ("supercritical core", lambda: subcritical_multiplication(1.05)),
        ("non-positive k", lambda: subcritical_multiplication(-0.1)),
        ("non-negative reactivity", lambda: multiplication_from_reactivity(0.001)),
        ("zero source", lambda: steady_source_power(0.0, 0.9)),
        ("single approach point",
         lambda: extrapolate_critical_parameter(points[:1])),
        ("all points at one parameter",
         lambda: extrapolate_critical_parameter(
             approach_to_criticality([500.0, 500.0], [0.005, 0.005],
                                     base_k=0.9))),
        ("mismatched lists",
         lambda: approach_to_criticality([1.0, 2.0], [0.01], base_k=0.9)),
        ("empty list", lambda: approach_to_criticality([], [], base_k=0.9)),
        ("flat count rate gives no extrapolation",
         lambda: extrapolate_critical_parameter(
             approach_to_criticality([1.0, 2.0], [0.01, 0.01], base_k=0.9))),
    ]
    for label, fn in guards:
        try:
            fn()
        except (StartupError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: subcritical multiplication and 1/M extrapolation are correct")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
