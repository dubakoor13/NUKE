"""Verify hydrogen thermochemistry and the Cantera refusal path.

The reduced two-species model is exercised for real. The Cantera backend cannot
be imported here, so only its refusal is verified - which is the honest claim to
make about code you cannot run.
"""
from __future__ import annotations

import math

from .thermochemistry import (
    NTR_TEMPERATURE_CEILING_K,
    CanteraUnavailableError,
    ThermochemistryError,
    cantera_available,
    compare_providers,
    dissociation_scaling,
    equilibrium_hydrogen_state,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    print("reduced two-species equilibrium (H2 <-> 2H):")
    for temperature in (600.0, 1500.0, 2000.0, 2500.0, 3000.0):
        state = equilibrium_hydrogen_state(temperature, 5.0e6)
        print(f"    T={temperature:6.0f} K  alpha={state.dissociation_fraction:.5f}  "
              f"rho={state.density_kg_m3:7.4f}  cp={state.cp_j_kg_k:8.1f}  "
              f"MW={state.molecular_weight_kg_mol*1000:.4f} g/mol")

    cold = equilibrium_hydrogen_state(600.0, 5.0e6)
    hot = equilibrium_hydrogen_state(3000.0, 5.0e6)
    results.append(_report("dissociation rises with temperature",
                           hot.dissociation_fraction > cold.dissociation_fraction,
                           f"{cold.dissociation_fraction:.5f} -> "
                           f"{hot.dissociation_fraction:.6f}"))
    results.append(_report("dissociation is small at NERVA inlet temperature",
                           cold.dissociation_fraction < 0.01,
                           f"alpha={cold.dissociation_fraction:.6f} at 600 K"))
    results.append(_report("mean molar mass falls as H2 dissociates",
                           hot.molecular_weight_kg_mol < cold.molecular_weight_kg_mol,
                           f"{cold.molecular_weight_kg_mol*1000:.4f} -> "
                           f"{hot.molecular_weight_kg_mol*1000:.4f} g/mol"))
    results.append(_report("undissociated molar mass is hydrogen's 2.0159 g/mol",
                           abs(cold.molecular_weight_kg_mol - 2.01588e-3)
                           / 2.01588e-3 < 0.01,
                           f"{cold.molecular_weight_kg_mol*1000:.4f} g/mol"))
    results.append(_report("provider records its species set",
                           cold.species == ("H2", "H"), str(cold.species)))

    print("\npressure suppresses dissociation (Le Chatelier):")
    low_p = equilibrium_hydrogen_state(2500.0, 1.0e5)
    high_p = equilibrium_hydrogen_state(2500.0, 5.0e6)
    results.append(_report("alpha is larger at lower pressure",
                           low_p.dissociation_fraction > high_p.dissociation_fraction,
                           f"1 bar {low_p.dissociation_fraction:.5f} > "
                           f"50 bar {high_p.dissociation_fraction:.5f}"))

    print("\nsensitivity diagnostic:")
    scaling = dissociation_scaling(2500.0, 5.0e6)
    print(f"    alpha={scaling['alpha']:.5f}  "
          f"d(alpha)/dT(+100K)={scaling['alpha_per_100k']:+.6f}  "
          f"d(alpha)/d(2P)={scaling['alpha_pressure_doubling']:+.6f}")
    results.append(_report("d alpha/dT is positive",
                           scaling["alpha_per_100k"] > 0.0,
                           f"{scaling['alpha_per_100k']:+.2e}"))
    results.append(_report("d alpha/dP is negative",
                           scaling["alpha_pressure_doubling"] < 0.0,
                           f"{scaling['alpha_pressure_doubling']:+.2e}"))

    print("\ndomain limits are enforced:")
    for label, temperature in (("above the NTR ceiling", 5000.0),):
        try:
            equilibrium_hydrogen_state(temperature, 5.0e6)
        except ThermochemistryError:
            results.append(True)
            print(f"  [PASS] rejected {label} ({temperature:.0f} K)")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")
    for label, args in (
        ("zero temperature", (0.0, 5.0e6)),
        ("negative pressure", (600.0, -1.0)),
        ("nan temperature", (float("nan"), 5.0e6)),
        ("unknown provider", (600.0, 5.0e6)),
    ):
        try:
            if label == "unknown provider":
                equilibrium_hydrogen_state(args[0], args[1], provider="magic")
            else:
                equilibrium_hydrogen_state(*args)
        except ThermochemistryError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")
    results.append(_report("ceiling is a stated value",
                           NTR_TEMPERATURE_CEILING_K == 3500.0,
                           f"{NTR_TEMPERATURE_CEILING_K} K"))

    print("\nCantera backend (not installed here):")
    available = cantera_available()
    print(f"    cantera_available() = {available}")
    if available:
        print("  [SKIP] Cantera is present; comparison path not exercised here")
    else:
        try:
            compare_providers(2500.0, 5.0e6)
        except CanteraUnavailableError as exc:
            results.append(True)
            print(f"  [PASS] compare_providers refuses: {str(exc)[:52]}...")
        else:
            results.append(False)
            print("  [FAIL] compare_providers returned without Cantera")
        try:
            equilibrium_hydrogen_state(2500.0, 5.0e6, provider="cantera")
        except CanteraUnavailableError:
            results.append(True)
            print("  [PASS] direct cantera request refuses")
        else:
            results.append(False)
            print("  [FAIL] cantera request returned without Cantera")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: thermochemistry is correct in-domain and refuses outside it")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
