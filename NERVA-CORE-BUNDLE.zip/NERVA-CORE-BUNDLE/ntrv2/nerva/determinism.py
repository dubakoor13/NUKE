"""Determinism: the same inputs must produce bit-identical results.

Acceptance gate 8 requires that a fresh developer can regenerate the results.
A reproducibility claim is only meaningful if a repeated run yields exactly the
same numbers, so this module defines a canonical fingerprint over a spread of
subsystems and lets the validator compare fingerprints computed in separate
processes.

Determinism is claimed only for the parts that genuinely are deterministic:
the heritage registry, the coupled solve on the analytic backend, the pump
operating point, the Inhour root and the axial grid study. A Monte Carlo
transport run is *not* deterministic across seeds by design, and nothing here
claims otherwise.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]


def canonical_results() -> dict:
    """Compute a spread of results that exercise every new subsystem."""
    from .coupled_core import (ChannelThermalClosure, CouplingParameters,
                               ThermalParameters, solve_coupled_core)
    from .cycle_closure import illustrative_characteristics, solve_pump_boundary
    from .heritage import kinetics as kin
    from .heritage.registry import load_registry
    from .numerical_studies import axial_grid_study
    from .transport_backend import CoreState, MockCoefficients, MockTransportBackend

    data_dir = Path(__file__).parent / "heritage" / "data"
    registry_totals = {}
    for path in sorted(data_dir.glob("*.json")):
        registry = load_registry(path)
        registry_totals[path.stem] = len(registry)

    groups = kin.u235_delayed_groups(load_registry(data_dir / "emrich2023_delayed_neutrons.json"))
    omega = kin.solve_period_constant(1.0e-3, 1.0e-3, groups)

    backend = MockTransportBackend(
        coefficients=MockCoefficients(
            k_reference=1.02,
            fuel_temperature_coefficient_per_k=-1.0e-5,
            hydrogen_temperature_coefficient_per_k=-2.0e-6,
            drum_coefficient_per_deg=2.0e-4,
            enrichment_coefficient_per_wt_percent=2.0e-2,
        ),
        element_count=7, radial_peaking=1.30,
        shape_temperature_sensitivity_per_k=-2.0e-5,
    )
    thermal = ChannelThermalClosure(ThermalParameters(
        coolant_inlet_temperature_k=600.0, coolant_density_kg_m3=2.0,
        total_mass_flow_kg_s=0.7, cp_j_kg_k=14300.0,
        channel_flow_area_m2=9.8e-5, channel_heated_perimeter_m=0.1531,
        channel_length_m=1.32, coolant_conductivity_w_m_k=0.18,
        coolant_viscosity_pa_s=1.2e-5, coolant_prandtl=0.95,
        fuel_conductivity_w_m_k=20.0, ligament_thickness_m=0.002,
    ))
    coupled = solve_coupled_core(
        backend,
        CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0),
        thermal,
        CouplingParameters(target_power_w=1.0e7, temperature_tolerance_k=1e-3,
                           k_tolerance=1e-9, max_iterations=400),
    )

    pump, system = illustrative_characteristics()
    boundary = solve_pump_boundary(
        pump, system, available_shaft_power_w=3.0e6, density_kg_m3=71.3,
        suction_pressure_pa=0.45e6, suction_enthalpy_j_kg=2.0e5,
        mechanical_efficiency=0.95, speed_upper_rad_s=2.0 * pump.omega_design_rad_s,
    )

    grid = axial_grid_study(node_counts=(8, 32, 128))

    return {
        "heritage_entry_counts": registry_totals,
        "kinetics_omega_per_s": omega,
        "coupled_k_eff": coupled.k_eff,
        "coupled_fuel_temperature_k": coupled.fuel_temperature_k,
        "coupled_iterations": coupled.iterations,
        "pump_mass_flow_kg_s": boundary.mass_flow_kg_s,
        "pump_head_m": boundary.head_m,
        "pump_shaft_power_w": boundary.shaft_power_required_w,
        "grid_pressure_drop_pa": [point.pressure_drop_pa for point in grid],
    }


def fingerprint(results: dict | None = None) -> str:
    """SHA-256 over the canonical results serialised at full float precision.

    ``json.dumps`` uses ``repr`` for floats in CPython, which round-trips
    exactly, so two runs producing identical doubles hash identically.
    """
    payload = results if results is not None else canonical_results()
    encoded = json.dumps(payload, sort_keys=True, indent=None)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def main() -> int:
    print(fingerprint())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
