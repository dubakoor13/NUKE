"""Verify control worth, excess reactivity and shutdown margin.

The key check is the fundamental theorem of calculus: numerically integrating the
*differential* worth profile must reproduce the *integral* worth measured
directly. Those are two independent measurements of the same quantity, so
agreement is a real consistency test rather than a restatement.

For the linear surrogate the analytic worth is known exactly, which gives a
second, stronger oracle.
"""
from __future__ import annotations

import math

from .control_worth import (
    BETA_U235_THERMAL,
    ControlWorthError,
    assess_operability,
    build_reactivity_balance,
    integrate_differential_worth,
    measure_differential_worth,
    measure_worth_curve,
)
from .reactivity_coefficients import to_pcm
from .transport_backend import CoreState, MockCoefficients, MockTransportBackend

DRUM_PER_DEG = 2.0e-4

COEFFS = MockCoefficients(
    k_reference=1.02,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    hydrogen_temperature_coefficient_per_k=-2.0e-6,
    drum_coefficient_per_deg=DRUM_PER_DEG,
    enrichment_coefficient_per_wt_percent=2.0e-2,
)

STATE = CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0,
                  drum_angle_deg=0.0)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    backend = MockTransportBackend(coefficients=COEFFS, element_count=7,
                                   radial_peaking=1.30, k_uncertainty=1e-4)

    # ---- worth curve ---------------------------------------------------
    angles = (-60.0, -40.0, -20.0, 0.0, 20.0, 40.0, 60.0)
    curve = measure_worth_curve(backend, STATE, angles)
    print("drum worth curve:")
    for point in curve.points:
        print(f"    theta={point.angle_deg:+6.1f} deg  k={point.k_eff:.6f}  "
              f"worth={to_pcm(point.k_eff - curve.k_reference):+8.1f} pcm")
    print(f"    total worth = {curve.total_worth_pcm:.1f} pcm "
          f"({curve.total_worth_dollars:.4f} dollars)")

    expected_total = DRUM_PER_DEG * (max(angles) - min(angles))
    results.append(_report("total worth matches the analytic swing",
                           abs(curve.total_worth - expected_total) / expected_total
                           < 1e-12,
                           f"{curve.total_worth_pcm:.3f} vs "
                           f"{to_pcm(expected_total):.3f} pcm"))
    results.append(_report("total worth is positive",
                           curve.total_worth > 0.0,
                           f"{curve.total_worth_pcm:+.1f} pcm"))
    results.append(_report("k rises monotonically with angle",
                           all(b.k_eff > a.k_eff for a, b in
                               zip(curve.points, curve.points[1:])),
                           "monotone over the sampled range"))

    # ---- fundamental theorem of calculus ------------------------------
    print("\ndifferential worth integrates to the integral worth:")
    differential = measure_differential_worth(
        backend, STATE, (-58.0, -38.0, -18.0, 2.0, 22.0, 42.0, 58.0))
    for point in differential:
        print(f"    theta={point.angle_deg:+6.1f} deg  "
              f"{point.pcm_per_deg:+.4f} pcm/deg")
    integrated = integrate_differential_worth(differential)
    # Compare over the same angular span the differential was sampled.
    span = (differential[-1].angle_deg - differential[0].angle_deg)
    analytic_span = DRUM_PER_DEG * span
    results.append(_report("integral of differential = analytic swing",
                           abs(integrated - analytic_span) / abs(analytic_span)
                           < 1e-12,
                           f"{to_pcm(integrated):.4f} vs "
                           f"{to_pcm(analytic_span):.4f} pcm"))
    results.append(_report("differential worth is constant for a linear core",
                           max(abs(point.dk_per_deg - DRUM_PER_DEG)
                               for point in differential) < 1e-15,
                           f"all {len(differential)} points equal "
                           f"{DRUM_PER_DEG:.1e}"))

    # ---- excess reactivity and shutdown margin ------------------------
    print("\noperability assessment:")
    # The travel must be wide enough to actually shut the core down: with
    # 2e-4 per degree, +-40 deg is only 1600 pcm and leaves k > 1 inserted.
    WITHDRAWN = 40.0
    INSERTED = -60.0
    assessment = assess_operability(
        backend, STATE, withdrawn_angle_deg=WITHDRAWN,
        inserted_angle_deg=INSERTED)
    print(f"    withdrawn {WITHDRAWN:+.0f} deg  k={assessment.k_withdrawn:.6f}  "
          f"excess={assessment.excess_pcm:+.1f} pcm "
          f"({assessment.excess_dollars:+.4f} $)")
    print(f"    inserted  {INSERTED:+.0f} deg  k={assessment.k_inserted:.6f}  "
          f"margin={assessment.shutdown_margin_pcm:+.1f} pcm "
          f"({assessment.shutdown_margin_dollars:+.4f} $)")
    results.append(_report("withdrawn core is supercritical",
                           assessment.is_excess,
                           f"k={assessment.k_withdrawn:.6f} > 1"))
    results.append(_report("inserted core is subcritical",
                           assessment.is_shutdown,
                           f"k={assessment.k_inserted:.6f} < 1"))
    results.append(_report("shutdown is subcritical one sigma high",
                           assessment.is_shutdown_with_sigma,
                           "k + 1 sigma < 1"))
    # The excess at the withdrawn angle is the hot-state offset at zero angle
    # PLUS the drum travel from 0 to the withdrawn angle. Omitting the offset
    # was the first version of this assertion, and it under-predicted by 923 pcm.
    k_at_zero = backend.run(STATE.with_changes(drum_angle_deg=0.0)).k_eff
    expected_excess = (k_at_zero - 1.0) + DRUM_PER_DEG * WITHDRAWN
    results.append(_report("excess reactivity matches the analytic value",
                           abs(assessment.excess_reactivity - expected_excess)
                           / abs(expected_excess) < 1e-12,
                           f"{assessment.excess_pcm:+.3f} vs "
                           f"{to_pcm(expected_excess):+.3f} pcm"))
    travel_worth = DRUM_PER_DEG * (WITHDRAWN - INSERTED)
    results.append(_report("excess + shutdown margin = total travel worth",
                           abs((assessment.excess_reactivity
                                + assessment.shutdown_reactivity)
                               - travel_worth) / travel_worth < 1e-12,
                           f"{to_pcm(assessment.excess_reactivity + assessment.shutdown_reactivity):.3f}"
                           f" vs {to_pcm(travel_worth):.3f} pcm"))
    results.append(_report("drum bank worth exceeds the excess reactivity",
                           curve.total_worth > assessment.excess_reactivity,
                           f"{curve.total_worth_pcm:.0f} > "
                           f"{assessment.excess_pcm:.0f} pcm (can shut down)"))

    # ---- dollars conversion -------------------------------------------
    print("\nreactivity units:")
    results.append(_report("one dollar is beta",
                           abs(1.0 * BETA_U235_THERMAL / BETA_U235_THERMAL - 1.0) < 1e-15,
                           f"beta = {BETA_U235_THERMAL}"))
    dollars = assessment.excess_dollars
    results.append(_report("dollars = pcm / (beta*1e5)",
                           abs(dollars - assessment.excess_pcm / (BETA_U235_THERMAL * 1e5))
                           < 1e-12, f"{dollars:.5f} $"))
    results.append(_report("excess is quoted in dollars for design use",
                           0.0 < dollars,
                           f"{dollars:.4f} $ = {assessment.excess_pcm:.0f} pcm"))

    # ---- reactivity ledger --------------------------------------------
    # Semantics: at COLD, drums withdrawn, the core carries `excess_cold`.
    # Heating removes `defect`, leaving `excess_hot`. Drums must therefore
    # remove exactly `excess_hot` to reach criticality, and the ledger closes.
    print("\nreactivity balance ledger:")
    cold_state = CoreState(fuel_temperature_k=293.6, hydrogen_temperature_k=293.6,
                           reflector_temperature_k=293.6,
                           drum_angle_deg=WITHDRAWN, enrichment_wt_percent=5.0)
    hot_withdrawn = STATE.with_changes(drum_angle_deg=WITHDRAWN)
    k_cold = backend.run(cold_state).k_eff
    k_hot = backend.run(hot_withdrawn).k_eff
    excess_cold = k_cold - 1.0
    defect = k_cold - k_hot
    required_drum_worth = excess_cold - defect
    print(f"    k_cold={k_cold:.6f}  k_hot={k_hot:.6f}  "
          f"excess_cold={to_pcm(excess_cold):+.1f} pcm  "
          f"defect={to_pcm(defect):+.1f} pcm")
    balance = build_reactivity_balance(
        excess=excess_cold, defect=defect, worth_inserted=required_drum_worth)
    print("\n".join("    " + line for line in balance.as_text().splitlines()))
    results.append(_report("ledger closes to zero",
                           abs(balance.total) < 1e-15,
                           f"{balance.total_pcm:+.9f} pcm"))
    results.append(_report("drum worth needed equals the hot excess reactivity",
                           abs(required_drum_worth - (k_hot - 1.0)) < 1e-15,
                           f"{to_pcm(required_drum_worth):.3f} pcm"))
    results.append(_report("ledger has the expected components",
                           len(balance.components) == 3,
                           f"{len(balance.components)} entries"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid analyses are rejected:")
    guards = [
        ("empty angle list", lambda: measure_worth_curve(backend, STATE, ())),
        ("non-finite angle", lambda: measure_worth_curve(backend, STATE,
                                                         (0.0, float("nan")))),
        ("zero angular perturbation",
         lambda: measure_differential_worth(backend, STATE, (0.0,),
                                            perturbation_deg=0.0)),
        ("integration of one point",
         lambda: integrate_differential_worth(differential[:1])),
        ("angle not in the curve", lambda: curve.integral_worth_at(7.5)),
        ("duplicate angle curve",
         lambda: measure_worth_curve(backend, STATE, (0.0, 0.0))),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ControlWorthError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: control worth, excess reactivity and shutdown margin are measured")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
