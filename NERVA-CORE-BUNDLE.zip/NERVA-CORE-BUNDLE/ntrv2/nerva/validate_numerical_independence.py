"""Verify that results are converged under refinement and independent of controls.

This turns acceptance-gate 6 from an assertion into evidence. Three distinct
claims are tested, and each failed at least once while this module was being
written, which is why the metrics look the way they do:

1. **Axial grid** - refining the channel mesh converges the pressure drop with a
   first-order ratio near 2. The *outlet temperature* is deliberately NOT the
   metric: it is an analytically grid-independent energy balance and would
   report machine-precision agreement, proving nothing.
2. **Timestep** - halving dt reduces RK4 error with an observed order near 4,
   measured against a 32x-refined reference. Starting the integrator on the
   eigen-mode instead (the first attempt) made RK4 exact for any dt.
3. **Iteration controls** - the converged coupled solution does not depend on
   the Picard relaxation factor, at a fixed tight tolerance.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import numerical_studies as ns

REPO_ROOT = Path(__file__).resolve().parents[2]
RECORD_PATH = REPO_ROOT / "build" / "nerva_numerics_record.json"


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    record = ns.build_record()

    # ---- 1. axial grid refinement --------------------------------------
    print("axial grid refinement (first-order scheme expected):")
    grid = record["grid"]
    changes = grid["successive_metric_changes"]
    print("    nodes     :", grid["levels"])
    print("    dp [Pa]   :", [round(value, 1) for value in grid["metric_values"]])
    print("    changes   :", [f"{value:.4e}" for value in changes])
    decreasing = all(b < a for a, b in zip(changes, changes[1:]))
    results.append(_report("every refinement reduces the change",
                           decreasing, f"{len(changes)} successive changes"))
    ratio = grid["refinement_ratio"]
    results.append(_report("refinement ratio is near 2 (first order)",
                           1.5 <= ratio <= 2.5, f"ratio={ratio:.2f}"))
    finest = grid["finest_relative_change"]
    results.append(_report("finest mesh change is below 0.5% relative",
                           finest is not None and finest < 5e-3,
                           f"{finest*100:.3f}%"))
    outlet_spread = (max(grid["outlet_temperature_k"])
                     - min(grid["outlet_temperature_k"]))
    results.append(_report("outlet temperature is grid-independent as expected",
                           outlet_spread < 1e-6,
                           f"spread={outlet_spread:.2e} K (energy balance is analytic)"))

    # ---- 2. timestep refinement ----------------------------------------
    print("\ntimestep refinement (RK4 expected order 4):")
    time = record["timestep"]
    errors = time["relative_error"]
    print("    dt [s]    :", time["dt_s"])
    print("    rel error :", [f"{value:.4e}" for value in errors])
    results.append(_report("every halving reduces the error",
                           all(b < a for a, b in zip(errors, errors[1:])),
                           f"{len(errors)} timesteps"))
    order = time["observed_order"]
    results.append(_report("observed order is close to 4",
                           3.5 <= order <= 4.5, f"observed={order:.2f}"))
    results.append(_report("finest timestep error is negligible",
                           errors[-1] < 1e-12, f"{errors[-1]:.2e}"))

    # ---- 3. iteration-control independence ----------------------------
    print("\nconverged answer is independent of Picard controls:")
    controls = record["iteration_controls"]
    for point in controls["points"]:
        print(f"    relax={point['relaxation']} tol={point['tolerance_k']:<8} "
              f"iters={point['iterations']:<3} k={point['k_eff']:.12f}")
    results.append(_report("every control setting converged",
                           all(point["converged"] for point in controls["points"]),
                           f"{len(controls['points'])} settings"))
    results.append(_report("k agrees across relaxations to < 1e-8",
                           controls["k_spread"] < 1e-8,
                           f"spread={controls['k_spread']:.2e}"))
    results.append(_report("fuel temperature agrees to < 1e-3 K",
                           controls["temperature_spread_k"] < 1e-3,
                           f"spread={controls['temperature_spread_k']:.2e} K"))
    iterations = [point["iterations"] for point in controls["points"]]
    aggressor = controls["points"][-2]["iterations"] < controls["points"][0]["iterations"]
    results.append(_report("relaxation changes only the convergence rate",
                           aggressor,
                           f"{min(iterations)}..{max(iterations)} iterations, same answer"))

    # ---- record emission -----------------------------------------------
    print("\nrecord for the acceptance reporter:")
    RECORD_PATH.parent.mkdir(parents=True, exist_ok=True)
    RECORD_PATH.write_text(json.dumps(record, indent=1), encoding="utf-8")
    results.append(_report("record written", RECORD_PATH.exists(),
                           str(RECORD_PATH.relative_to(REPO_ROOT))))
    reloaded = json.loads(RECORD_PATH.read_text(encoding="utf-8"))
    results.append(_report("record round-trips as JSON",
                           reloaded["kind"] == "numerical-independence"
                           and len(reloaded["grid"]["levels"]) == len(grid["levels"]),
                           "structure preserved"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid study parameters are rejected:")
    guards = [
        ("non-positive timestep",
         lambda: ns.kin.integrate_point_kinetics(1.0, [0.0] * 6, 1e-3, 1e-3,
                                                 _groups(), 0.0, 10)),
        ("zero integration steps",
         lambda: ns.kin.integrate_point_kinetics(1.0, [0.0] * 6, 1e-3, 1e-3,
                                                 _groups(), 1e-3, 0)),
        ("unstable timestep drives n negative",
         lambda: ns.kin.integrate_point_kinetics(1.0, [1.0] * 6, -0.02, 1.0e-6,
                                                 _groups(), 1.0e-3, 5)),
    ]
    for label, fn in guards:
        try:
            fn()
        except ValueError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: results are refinement-converged and control-independent")
    return 0


def _groups():
    from .heritage.registry import load_registry
    from .heritage.kinetics import u235_delayed_groups

    data = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"
    return u235_delayed_groups(load_registry(data))


if __name__ == "__main__":
    raise SystemExit(main())
