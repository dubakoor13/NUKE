"""Verify the pump operating point and cycle closure.

These checks establish that the frozen ``mdot_pump_ref`` / ``h_pump_ref`` can be
replaced by a solved boundary, and — just as importantly — that no unsourced
characteristic can enter the model. The pump/system curves used here are
SYNTHETIC and are labelled as such by the code under test; only the algebra is
being verified, not any NERVA hardware number.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

from .cycle_closure import (
    CharacteristicsError,
    PumpCharacteristics,
    SystemResistance,
    illustrative_characteristics,
    operating_volume_flow,
    solve_pump_boundary,
)

REPO_ROOT = Path(__file__).resolve().parents[2]

G = 9.80665
RHO = 71.3          # kg/m3, saturated LH2 near 20 K (Emrich p.178 context)
ETA_MECH = 0.95


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<54} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    pump, system = illustrative_characteristics()

    # ---- the characteristics are honestly labelled ---------------------
    print("provenance discipline:")
    results.append(_report("illustrative curve is not heritage",
                           pump.is_heritage is False, f"source={pump.source[:34]}..."))
    results.append(_report("illustrative system curve is not heritage",
                           system.is_heritage is False, f"source={system.source[:34]}..."))
    cited = PumpCharacteristics(
        shutoff_head_coefficient_m_s2=0.04,
        head_loss_coefficient_s2_m5=1000.0,
        omega_design_rad_s=500.0,
        eta_pump=0.8,
        source="NASA CR-XXXX Table 3, pump map digitised",
    )
    results.append(_report("a cited curve is heritage",
                           cited.is_heritage is True, "is_heritage=True"))

    print("\nunsourced curves are refused:")
    for label, kwargs in [
        ("empty source", dict(shutoff_head_coefficient_m_s2=0.04,
                              head_loss_coefficient_s2_m5=100.0,
                              omega_design_rad_s=500.0, eta_pump=0.8, source="")),
        ("placeholder source", dict(shutoff_head_coefficient_m_s2=0.04,
                                    head_loss_coefficient_s2_m5=100.0,
                                    omega_design_rad_s=500.0, eta_pump=0.8,
                                    source="n/a")),
        ("zero efficiency", dict(shutoff_head_coefficient_m_s2=0.04,
                                 head_loss_coefficient_s2_m5=100.0,
                                 omega_design_rad_s=500.0, eta_pump=0.0,
                                 source="SYNTHETIC test")),
        ("negative shutoff head", dict(shutoff_head_coefficient_m_s2=-0.04,
                                       head_loss_coefficient_s2_m5=100.0,
                                       omega_design_rad_s=500.0, eta_pump=0.8,
                                       source="SYNTHETIC test")),
    ]:
        try:
            PumpCharacteristics(**kwargs)
        except CharacteristicsError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    # ---- operating point is the curve intersection ---------------------
    print("\noperating point:")
    omega_design = pump.omega_design_rad_s
    q_design = operating_volume_flow(pump, system, omega_design)
    pump_head = pump.head_m(omega_design, q_design)
    system_head = system.head_m(q_design)
    results.append(_report("pump head equals system resistance head",
                           abs(pump_head - system_head) < 1e-9,
                           f"pump={pump_head:.6f} m system={system_head:.6f} m"))
    results.append(_report("design point recovers the design flow",
                           abs(q_design - 0.30) < 1e-6, f"Q={q_design:.6f} m3/s"))

    # ---- shaft closure -------------------------------------------------
    print("\nshaft balance (pump demand meets turbine supply):")
    available = 3.0e6
    boundary = solve_pump_boundary(
        pump, system,
        available_shaft_power_w=available,
        density_kg_m3=RHO,
        suction_pressure_pa=0.45e6,
        suction_enthalpy_j_kg=2.0e5,
        mechanical_efficiency=ETA_MECH,
        speed_upper_rad_s=2.0 * omega_design,
    )
    target = ETA_MECH * available
    results.append(_report("shaft power residual is inside tolerance",
                           abs(boundary.shaft_power_residual_w) < 1.0,
                           f"residual={boundary.shaft_power_residual_w:.3e} W "
                           f"(target {target:.4g} W)"))
    results.append(_report("hydraulic power equals mass flow times g*H",
                           abs(boundary.mass_flow_kg_s * boundary.enthalpy_rise_j_kg
                               - RHO * G * boundary.volume_flow_m3_s * boundary.head_m)
                           < 1e-6,
                           f"{boundary.mass_flow_kg_s * boundary.enthalpy_rise_j_kg:.6g} W"))
    results.append(_report("shaft power equals hydraulic power / eta_pump",
                           abs(boundary.shaft_power_required_w
                               - RHO * G * boundary.volume_flow_m3_s
                               * boundary.head_m / pump.eta_pump) < 1e-6,
                           f"{boundary.shaft_power_required_w:.6g} W"))
    results.append(_report("delivered enthalpy = suction + g*H",
                           abs(boundary.delivered_stagnation_enthalpy_j_kg
                               - (2.0e5 + G * boundary.head_m)) < 1e-9,
                           f"h={boundary.delivered_stagnation_enthalpy_j_kg:.4g} J/kg"))
    results.append(_report("discharge pressure uses the same head",
                           abs(boundary.discharge_pressure_pa
                               - (0.45e6 + RHO * G * boundary.head_m)) < 1e-6,
                           f"p={boundary.discharge_pressure_pa:.5g} Pa"))
    results.append(_report("boundary carries a synthetic-data warning",
                           "SYNTHETIC" in boundary.provenance.get("warning", ""),
                           boundary.provenance.get("warning", "")[:46] + "..."))
    results.append(_report("solved speed is finite and positive",
                           boundary.shaft_speed_rad_s > 0.0
                           and math.isfinite(boundary.shaft_speed_rad_s),
                           f"omega={boundary.shaft_speed_rad_s:.2f} rad/s "
                           f"({boundary.shaft_speed_rpm:.0f} rpm)"))
    results.append(_report("speed convert to rpm consistently",
                           abs(boundary.shaft_speed_rpm
                               - boundary.shaft_speed_rad_s * 60.0 / (2.0 * math.pi)) < 1e-9,
                           f"{boundary.shaft_speed_rpm:.2f} rpm"))

    # ---- adapter into the legacy dynamic header -----------------------
    print("\nadapter for the existing dynamic header:")
    from .cycle_closure import header_pump_delivery
    pair = header_pump_delivery(boundary)
    results.append(_report("produces the (mass flow, enthalpy) 2-tuple",
                           isinstance(pair, tuple) and len(pair) == 2,
                           f"type={type(pair).__name__} len={len(pair)}"))
    results.append(_report("mass flow matches the solved boundary",
                           pair[0] == boundary.mass_flow_kg_s,
                           f"{pair[0]:.6f} kg/s"))
    results.append(_report("enthalpy is the delivered stagnation value",
                           pair[1] == boundary.delivered_stagnation_enthalpy_j_kg,
                           f"{pair[1]:.6g} J/kg"))
    results.append(_report("both entries are positive and finite",
                           pair[0] > 0.0 and math.isfinite(pair[0])
                           and math.isfinite(pair[1]),
                           "satisfies the legacy override contract"))

    # ---- monotone response to available power --------------------------
    print("\nresponse to turbine power (the closure must be monotone):")
    sweep = []
    for power in (2.0e6, 3.0e6, 4.0e6, 5.0e6):
        point = solve_pump_boundary(
            pump, system, available_shaft_power_w=power, density_kg_m3=RHO,
            suction_pressure_pa=0.45e6, suction_enthalpy_j_kg=2.0e5,
            mechanical_efficiency=ETA_MECH, speed_upper_rad_s=2.0 * omega_design)
        sweep.append((power, point.shaft_speed_rad_s, point.mass_flow_kg_s))
    print("    " + "  ".join(f"{p/1e6:.0f}MW->{w:.1f}rad/s,{m:.3f}kg/s"
                             for p, w, m in sweep))
    results.append(_report("more turbine power gives higher shaft speed",
                           all(b[1] > a[1] for a, b in zip(sweep, sweep[1:])), ""))
    results.append(_report("more turbine power gives higher mass flow",
                           all(b[2] > a[2] for a, b in zip(sweep, sweep[1:])), ""))

    # ---- operating-limit refusals -------------------------------------
    print("\noperating limits are refused, not extrapolated:")
    steep = SystemResistance(static_head_m=20000.0,
                             resistance_coefficient_s2_m5=system.resistance_coefficient_s2_m5,
                             source="SYNTHETIC steep system")
    try:
        solve_pump_boundary(pump, steep, available_shaft_power_w=3.0e6,
                            density_kg_m3=RHO, suction_pressure_pa=0.45e6,
                            suction_enthalpy_j_kg=2.0e5)
    except CharacteristicsError as exc:
        results.append(True)
        print(f"  [PASS] refused when static head defeats the pump: {str(exc)[:48]}...")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED impossible static head")

    try:
        solve_pump_boundary(pump, system, available_shaft_power_w=1.0e3,
                            density_kg_m3=RHO, suction_pressure_pa=0.45e6,
                            suction_enthalpy_j_kg=2.0e5)
    except CharacteristicsError:
        results.append(True)
        print("  [PASS] refused when the turbine cannot drive the pump")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED under-powered turbine")

    try:
        solve_pump_boundary(pump, system, available_shaft_power_w=5.0e9,
                            density_kg_m3=RHO, suction_pressure_pa=0.45e6,
                            suction_enthalpy_j_kg=2.0e5,
                            speed_upper_rad_s=1.01 * omega_design)
    except CharacteristicsError:
        results.append(True)
        print("  [PASS] refused when the shaft is over-powered beyond the speed limit")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED over-powered shaft")

    # ---- wiring into the legacy dynamic header -------------------------
    print("\nwiring the solved boundary into run_dynamic_header_tie:")
    from .cycle_closure import load_pump_map, resolve_pump_override

    results.append(_report("no map supplied leaves the legacy path untouched",
                           resolve_pump_override(None, None,
                                                 suction_pressure_pa=1.0,
                                                 suction_enthalpy_j_kg=1.0) is None,
                           "returns None, so the frozen reference still applies"))

    class _Shaft:
        turbine_shaft_delivered_power_w = 3.0e6

    map_path = REPO_ROOT / "build" / "nerva_pump_map_test.json"
    map_path.parent.mkdir(parents=True, exist_ok=True)
    map_path.write_text(json.dumps({
        "pump": {
            "shutoff_head_coefficient_m_s2": pump.shutoff_head_coefficient_m_s2,
            "head_loss_coefficient_s2_m5": pump.head_loss_coefficient_s2_m5,
            "omega_design_rad_s": pump.omega_design_rad_s,
            "eta_pump": pump.eta_pump,
            "source": "SYNTHETIC test map",
        },
        "system": {
            "static_head_m": system.static_head_m,
            "resistance_coefficient_s2_m5": system.resistance_coefficient_s2_m5,
            "source": "SYNTHETIC test system",
        },
        "fluid": {"density_kg_m3": RHO, "mechanical_efficiency": ETA_MECH},
    }, indent=1), encoding="utf-8")

    loaded_pump, loaded_system, loaded_density, loaded_eff = load_pump_map(map_path)
    results.append(_report("map round-trips from JSON",
                           loaded_pump.eta_pump == pump.eta_pump
                           and loaded_density == RHO,
                           f"eta={loaded_pump.eta_pump} rho={loaded_density}"))
    override = resolve_pump_override(map_path, _Shaft(),
                                     suction_pressure_pa=0.45e6,
                                     suction_enthalpy_j_kg=2.0e5)
    results.append(_report("a supplied map yields a solvable override",
                           isinstance(override, tuple) and len(override) == 2,
                           f"m={override[0]:.4f} kg/s, h={override[1]:.6g} J/kg"))
    results.append(_report("override flow is positive and finite",
                           override[0] > 0.0 and math.isfinite(override[1]),
                           "satisfies the legacy override contract"))

    print("\nunsourced maps are refused:")
    for label, mutate in [
        ("pump section without a source",
         lambda payload: payload["pump"].__setitem__("source", "")),
        ("system section without a source",
         lambda payload: payload["system"].__setitem__("source", "")),
        ("missing fluid section",
         lambda payload: payload.pop("fluid")),
        ("non-positive density",
         lambda payload: payload["fluid"].__setitem__("density_kg_m3", 0.0)),
    ]:
        payload = json.loads(map_path.read_text(encoding="utf-8"))
        mutate(payload)
        broken = map_path.with_name("nerva_pump_map_broken.json")
        broken.write_text(json.dumps(payload, indent=1), encoding="utf-8")
        try:
            load_pump_map(broken)
        except CharacteristicsError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: pump operating point is solved and provenance is enforced")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
