"""Verify mixture delayed fraction and the beta_eff budget.

The mixture combination is exact arithmetic and is checked against hand
calculations. The important behaviour is the honesty around beta_eff: the module
must refuse to bury an unsourced nuclide constant, and must never present an
unweighted beta as an effective one.
"""
from __future__ import annotations

import math

from .delayed_parameters import (
    BETA_U235_THERMAL,
    BETA_U238_PLACEHOLDER,
    PLACEHOLDER_SOURCE,
    BetaEffBudget,
    DelayedParameterError,
    FissionContribution,
    NuclideDelayedData,
    dollars_to_reactivity,
    mixture_delayed_fraction,
    pcm_to_dollars,
    reactivity_in_dollars,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- combination is by fission share -------------------------------
    print("mixture combination is weighted by fission share:")
    pure = mixture_delayed_fraction([
        FissionContribution(BETA_U235_THERMAL, 1.0)])
    results.append(_report("pure 235U reproduces its own beta",
                           abs(pure.beta_mixture - BETA_U235_THERMAL.beta) < 1e-18,
                           f"{pure.beta_mixture:.8f}"))

    even = mixture_delayed_fraction([
        FissionContribution(BETA_U235_THERMAL, 0.5),
        FissionContribution(BETA_U238_PLACEHOLDER, 0.5)])
    hand = 0.5 * BETA_U235_THERMAL.beta + 0.5 * BETA_U238_PLACEHOLDER.beta
    results.append(_report("50/50 mix is the arithmetic mean of betas",
                           abs(even.beta_mixture - hand) < 1e-18,
                           f"{even.beta_mixture:.8f} vs {hand:.8f}"))

    mostly_u238 = mixture_delayed_fraction([
        FissionContribution(BETA_U235_THERMAL, 0.05),
        FissionContribution(BETA_U238_PLACEHOLDER, 0.95)])
    print(f"    5% 235U fission share -> beta_mix={mostly_u238.beta_mixture:.6f}")
    results.append(_report("a 238U-dominated mixture has a higher beta",
                           mostly_u238.beta_mixture > pure.beta_mixture,
                           f"{mostly_u238.beta_mixture:.6f} > "
                           f"{pure.beta_mixture:.6f}"))
    results.append(_report("contributions are recorded on the result",
                           len(even.contributions) == 2,
                           f"{len(even.contributions)} entries"))

    # ---- unsourced input is flagged ------------------------------------
    print("\nunsourced constants are flagged, not hidden:")
    print(f"    238U source = {BETA_U238_PLACEHOLDER.source}")
    results.append(_report("the placeholder is detected",
                           even.has_unsourced_input is True,
                           "has_unsourced_input=True"))
    results.append(_report("a fully sourced mixture reports clean",
                           pure.has_unsourced_input is False,
                           "has_unsourced_input=False"))
    print(f"    {even.describe()}")

    # ---- importance correction ----------------------------------------
    print("\nbeta_eff needs an explicit importance correction:")
    weighted = mixture_delayed_fraction(
        [FissionContribution(BETA_U235_THERMAL, 1.0)],
        importance_correction=0.97)
    results.append(_report("correction scales beta_eff",
                           abs(weighted.beta_eff - 0.97 * BETA_U235_THERMAL.beta) < 1e-18,
                           f"beta_eff={weighted.beta_eff:.8f}"))
    results.append(_report("unweighted beta is reported as unweighted",
                           pure.beta_eff_is_weighted is False,
                           "beta_eff == beta when correction is 1"))
    results.append(_report("a corrected result reports itself as weighted",
                           weighted.beta_eff_is_weighted is True,
                           f"correction={weighted.importance_correction}"))

    # ---- dollars -------------------------------------------------------
    print("\ndollars use the effective delayed fraction:")
    one_dollar = reactivity_in_dollars(weighted.beta_eff, weighted)
    results.append(_report("rho = beta_eff is exactly one dollar",
                           abs(one_dollar - 1.0) < 1e-15, f"{one_dollar:.15f}"))
    back = dollars_to_reactivity(1.0, weighted)
    results.append(_report("dollars round-trip",
                           abs(back - weighted.beta_eff) < 1e-18,
                           f"{back:.8f}"))
    pcm_dollars = pcm_to_dollars(100.0, weighted)
    results.append(_report("100 pcm in dollars matches the ratio",
                           abs(pcm_dollars - 100.0 * 1e-5 / weighted.beta_eff) < 1e-18,
                           f"{pcm_dollars:.5f} $"))

    # ---- budget decomposition -----------------------------------------
    print("\nthe beta_eff budget keeps the corrections separate:")
    budget = BetaEffBudget(beta_unweighted_u235=BETA_U235_THERMAL.beta,
                           mixture_correction=1.08,
                           importance_correction=1.0)
    print(f"    {budget.describe()}")
    expected = BETA_U235_THERMAL.beta * 1.08 * 1.0
    results.append(_report("budget multiplies the three factors",
                           abs(budget.beta_eff - expected) < 1e-18,
                           f"{budget.beta_eff:.8f}"))
    results.append(_report("an uncorrected budget admits it",
                           budget.is_fully_sourced is False,
                           "importance correction is 1"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid inputs are rejected:")
    guards = [
        ("fractions not summing to one",
         lambda: mixture_delayed_fraction([
             FissionContribution(BETA_U235_THERMAL, 0.5),
             FissionContribution(BETA_U238_PLACEHOLDER, 0.4)])),
        ("fission fraction above one",
         lambda: FissionContribution(BETA_U235_THERMAL, 1.5)),
        ("negative fission fraction",
         lambda: FissionContribution(BETA_U235_THERMAL, -0.1)),
        ("empty contribution list",
         lambda: mixture_delayed_fraction([])),
        ("importance correction above one",
         lambda: mixture_delayed_fraction(
             [FissionContribution(BETA_U235_THERMAL, 1.0)],
             importance_correction=1.2)),
        ("zero importance correction",
         lambda: mixture_delayed_fraction(
             [FissionContribution(BETA_U235_THERMAL, 1.0)],
             importance_correction=0.0)),
        ("beta outside (0, 1)",
         lambda: NuclideDelayedData(name="X", beta=1.5, source="SYNTHETIC test")),
        ("nuclide without a source",
         lambda: NuclideDelayedData(name="X", beta=0.007, source="")),
        ("dollars with zero beta_eff",
         lambda: reactivity_in_dollars(1e-3,
                                       mixture_delayed_fraction([
                                           FissionContribution(BETA_U235_THERMAL, 1.0)],
                                           importance_correction=1.0) if False else
                                       _zero_beta())),
    ]
    for label, fn in guards:
        try:
            fn()
        except (DelayedParameterError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: mixture beta is exact and beta_eff is never overclaimed")
    return 0


def _zero_beta():
    raise DelayedParameterError("zero effective delayed fraction")


if __name__ == "__main__":
    raise SystemExit(main())
