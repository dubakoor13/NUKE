"""Verify spatially resolved core feedback.

The central identity: when the surrogate's distribution sensitivity is zero, the
spatial solve must reproduce the lumped solve **exactly**. That proves the
per-element machinery is wired correctly rather than merely producing plausible
numbers. With a nonzero sensitivity the reactivity penalty must equal
``alpha_dist * (T_peak - T_mean)`` exactly, which is a second analytic check.

Thermal constants are synthetic test inputs.
"""
from __future__ import annotations

import math

from .spatial_core import (
    ElementThermalParameters,
    SpatialCoreError,
    SpatialCoreState,
    SpatialCouplingParameters,
    element_temperatures,
    solve_spatial_core,
    supports_spatial,
)
from .transport_backend import CoreState, MockCoefficients, MockTransportBackend

BASE_COEFFS = dict(
    k_reference=1.02,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    hydrogen_temperature_coefficient_per_k=-2.0e-6,
    drum_coefficient_per_deg=2.0e-4,
    enrichment_coefficient_per_wt_percent=2.0e-2,
)

THERMAL = ElementThermalParameters(
    coolant_inlet_temperature_k=600.0,
    total_mass_flow_kg_s=0.7,
    cp_j_kg_k=14300.0,
    channel_heated_perimeter_m=0.1531,
    channel_length_m=1.32,
    coolant_conductivity_w_m_k=0.18,
    coolant_viscosity_pa_s=1.2e-5,
    coolant_density_kg_m3=2.0,
    coolant_prandtl=0.95,
    fuel_conductivity_w_m_k=20.0,
    ligament_thickness_m=0.002,
    channel_flow_area_m2=9.8e-5,
)

BASIS = CoreState(fuel_temperature_k=1500.0, hydrogen_temperature_k=900.0,
                  coolant_density_kg_m3=2.0)


def _backend(distribution_coefficient: float) -> MockTransportBackend:
    return MockTransportBackend(
        coefficients=MockCoefficients(
            **BASE_COEFFS,
            spatial_distribution_coefficient_per_k=distribution_coefficient),
        element_count=7, radial_peaking=1.40,
        shape_temperature_sensitivity_per_k=-2.0e-5, k_uncertainty=1e-4)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    parameters = SpatialCouplingParameters(target_power_w=1.0e7,
                                          temperature_tolerance_k=0.5,
                                          k_tolerance=1e-7, max_iterations=200)

    # ---- identity: zero sensitivity reproduces the lumped answer -------
    print("zero distribution sensitivity reproduces the lumped solve exactly:")
    flat_backend = _backend(0.0)
    initial = SpatialCoreState.uniform(BASIS, 7)
    flat = solve_spatial_core(flat_backend, initial, THERMAL, parameters)
    results.append(_report("spatial solve converged", flat.converged, flat.reason))
    uniform_state = flat.state.uniform_equivalent(flat.power_fractions)
    lumped = flat_backend.run(uniform_state)
    results.append(_report("spatial k == lumped k exactly",
                           abs(flat.k_eff - lumped.k_eff) < 1e-15,
                           f"{flat.k_eff:.15f} vs {lumped.k_eff:.15f}"))
    results.append(_report("penalty is zero",
                           flat.spatial_reactivity_penalty is not None
                           and abs(flat.spatial_reactivity_penalty) < 1e-15,
                           f"{flat.spatial_reactivity_penalty:.2e}"))
    results.append(_report("temperature spread is resolved (> 0 K)",
                           flat.mean_fuel_temperature_k < flat.peak_fuel_temperature_k,
                           f"peak {flat.peak_fuel_temperature_k:.1f} > "
                           f"mean {flat.mean_fuel_temperature_k:.1f} K"))

    # ---- finite sensitivity produces the analytic penalty --------------
    print("\ndistribution sensitivity produces the analytic reactivity penalty:")
    alpha_dist = -4.0e-7
    hot_backend = _backend(alpha_dist)
    hot = solve_spatial_core(hot_backend, initial, THERMAL, parameters)
    results.append(_report("spatial solve converged", hot.converged, hot.reason))
    peak_above_mean = (hot.state.fuel_temperatures_k
                       and max(hot.state.fuel_temperatures_k)
                       - sum(hot.state.fuel_temperatures_k) / len(hot.state.fuel_temperatures_k))
    expected_penalty = -alpha_dist * peak_above_mean
    print(f"    peak-mean {peak_above_mean:.3f} K  "
          f"alpha_dist {alpha_dist:.1e}  expected penalty {expected_penalty:+.3e}")
    results.append(_report("penalty matches -alpha_dist*(T_peak-T_mean)",
                           hot.spatial_reactivity_penalty is not None
                           and abs(hot.spatial_reactivity_penalty - expected_penalty)
                           / abs(expected_penalty) < 1e-12,
                           f"{hot.spatial_reactivity_penalty:+.6e}"))
    results.append(_report("a hotter peak makes the core less reactive",
                           hot.spatial_reactivity_penalty > 0.0,
                           f"penalty {hot.spatial_reactivity_penalty:+.3e} (dk/k)"))
    results.append(_report("spatial k differs from the lumped k",
                           abs(hot.k_eff - lumped.k_eff) > 1e-9,
                           f"{hot.k_eff:.9f} vs {lumped.k_eff:.9f}"))
    results.append(_report("emergent dk/dT is negative",
                           hot.temperature_coefficient_per_k is not None
                           and hot.temperature_coefficient_per_k < 0.0,
                           f"{hot.temperature_coefficient_per_k:.3e} /K"))

    # ---- peaking is resolved -------------------------------------------
    print("\nper-element peaking is resolved:")
    print(f"    peaking ratio F_r = {hot.peaking_ratio:.4f}")
    results.append(_report("peak-to-mean temperature ratio exceeds 1",
                           hot.peaking_ratio > 1.0, f"{hot.peaking_ratio:.4f}"))
    results.append(_report("each element carries its own temperature",
                           len(set(hot.state.fuel_temperatures_k)) > 1,
                           f"{len(hot.state.fuel_temperatures_k)} distinct values"))
    results.append(_report("iteration history records the peaking trend",
                           len(hot.records) >= 1
                           and hot.records[-1].peak_to_mean_temperature > 1.0,
                           f"{len(hot.records)} iterations"))

    # ---- thermal closure conserves energy ------------------------------
    print("\nper-element thermal closure conserves energy:")
    power = 1.0e7
    shape = hot_backend.run_spatial(hot.state).fuel_power_fraction
    thermal = element_temperatures(shape, power, THERMAL)
    relative = abs(thermal.energy_balance_residual_w) / power
    results.append(_report("energy balance closes",
                           relative < 1e-12,
                           f"residual {thermal.energy_balance_residual_w:.2e} W"))
    results.append(_report("the hottest element has the highest fuel temperature",
                           max(range(len(thermal.fuel_temperatures_k)),
                               key=lambda i: thermal.fuel_temperatures_k[i])
                           == max(range(len(shape)), key=lambda i: shape[i]),
                           "elements ordered by power"))
    results.append(_report("wall temperature lies between coolant and fuel",
                           all(w > h for w, h in zip(thermal.wall_temperatures_k,
                                                     thermal.hydrogen_temperatures_k))
                           and all(f > w for f, w in
                                   zip(thermal.fuel_temperatures_k,
                                       thermal.wall_temperatures_k)),
                           "T_fuel > T_wall > T_H2 for every element"))

    # ---- uniform-only backends are refused -----------------------------
    print("\nuniform-only backends are refused rather than silently averaged:")

    class _UniformOnly:
        name = "uniform-only"
        synthetic = True

        def run(self, state):
            raise AssertionError("should not be called")

        def preflight(self):
            return []

        def require_ready(self):
            return None

    results.append(_report("supports_spatial detects the capability",
                           supports_spatial(hot_backend) is True
                           and supports_spatial(_UniformOnly()) is False,
                           "run_spatial present/absent"))
    try:
        solve_spatial_core(_UniformOnly(), initial, THERMAL, parameters)
    except SpatialCoreError as exc:
        results.append(True)
        print(f"  [PASS] refused: {str(exc)[:58]}...")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED a uniform-only backend for a spatial solve")

    # ---- guards --------------------------------------------------------
    print("\ninvalid spatial states are rejected:")
    guards = [
        ("mismatched vector lengths",
         lambda: SpatialCoreState(fuel_temperatures_k=(900.0, 1000.0),
                                  hydrogen_temperatures_k=(500.0,),
                                  basis=BASIS)),
        ("zero fuel temperature",
         lambda: SpatialCoreState(fuel_temperatures_k=(0.0, 1000.0),
                                  hydrogen_temperatures_k=(500.0, 500.0),
                                  basis=BASIS)),
        ("negative hydrogen temperature",
         lambda: SpatialCoreState(fuel_temperatures_k=(900.0,),
                                  hydrogen_temperatures_k=(-1.0,),
                                  basis=BASIS)),
        ("single element spatial solve",
         lambda: solve_spatial_core(hot_backend,
                                    SpatialCoreState.uniform(BASIS, 1),
                                    THERMAL, parameters)),
        ("power fractions not summing to one",
         lambda: element_temperatures((0.5, 0.4), 1.0e7, THERMAL)),
        ("negative power fraction",
         lambda: element_temperatures((1.2, -0.2), 1.0e7, THERMAL)),
        ("relaxation above one",
         lambda: SpatialCouplingParameters(target_power_w=1e7, relaxation=1.5)),
        ("zero target power",
         lambda: SpatialCouplingParameters(target_power_w=0.0)),
        ("power-weighted mean with wrong count",
         lambda: SpatialCoreState.uniform(BASIS, 7).power_weighted_temperatures((0.5, 0.5))),
    ]
    for label, fn in guards:
        try:
            fn()
        except (SpatialCoreError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: spatial feedback is resolved, exact, and never silently averaged")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
