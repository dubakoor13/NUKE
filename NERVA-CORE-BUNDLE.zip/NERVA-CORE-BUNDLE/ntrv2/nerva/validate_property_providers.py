"""Verify property providers and cross-check them against cited data.

The valuable test here is a genuine cross-source agreement: Emrich (2023) states
saturated liquid hydrogen density is 71.3 kg/m3 at 20 K (p.192), and the
RocketProps data library independently reports 71.07 kg/m3. Those are
independent sources, so their 0.3% agreement is real evidence rather than a
tautology.

The suite also establishes the limits: hot-gas properties have no provider here,
and the module must say so instead of extrapolating a liquid table.
"""
from __future__ import annotations

from pathlib import Path

from .heritage.registry import load_registry
from .property_providers import (
    LH2_MAX_LIQUID_TEMPERATURE_K,
    PropertyUnavailableError,
    describe_providers,
    gas_hydrogen_properties,
    liquid_hydrogen_density,
)

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_hydrogen.json"


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<54} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    registry = load_registry(DATA)
    book_density = registry.value("h2.liquid_density_at_20k")
    book_pressure = registry.value("h2.saturation_pressure_at_20k")
    book_temperature = registry.value("h2.pump_reference_temperature")

    print("cited reference state (Emrich p.192):")
    print(f"    T = {book_temperature} K, Psat = {book_pressure/1e3:.1f} kPa, "
          f"rho_liq = {book_density} kg/m3")

    print("\navailable providers:")
    providers = describe_providers()
    for name, status, coverage in providers:
        print(f"    {name:12} {status:10} {coverage}")
    any_available = any(status == "available" for _, status, _ in providers)
    results.append(_report("at least one property provider is available",
                           any_available,
                           ", ".join(f"{n}={s}" for n, s, _ in providers)))

    if not any_available:
        print("\n  [SKIP] no provider available; cross-check cannot run")
        print("\n0/1 checks passed")
        return 1

    # ---- the cross-source agreement ------------------------------------
    print("\ncross-source density check at the cited reference state:")
    try:
        result = liquid_hydrogen_density(book_temperature)
    except PropertyUnavailableError as exc:
        print(f"  [FAIL] could not evaluate: {exc}")
        return 1
    relative = abs(result.value - book_density) / book_density
    print(f"    provider {result.provider!r} -> {result.value:.4f} kg/m3")
    print(f"    Emrich value                -> {book_density:.4f} kg/m3")
    results.append(_report("independent providers agree within 1%",
                           relative < 0.01,
                           f"relative difference {relative*100:.3f}%"))
    results.append(_report("provider values are physically sensible (60-90 kg/m3)",
                           60.0 < result.value < 90.0, f"{result.value:.2f} kg/m3"))

    # ---- temperature sensitivity ---------------------------------------
    print("\ndensity rises as the liquid is cooled toward its triple point:")
    colder = liquid_hydrogen_density(15.0)
    warmer = liquid_hydrogen_density(28.0)
    print(f"    15 K -> {colder.value:.3f}   20 K -> {result.value:.3f}   "
          f"28 K -> {warmer.value:.3f} kg/m3")
    results.append(_report("density decreases monotonically with temperature",
                           colder.value > result.value > warmer.value,
                           f"{colder.value:.2f} > {result.value:.2f} > {warmer.value:.2f}"))
    results.append(_report("provider is recorded on every result",
                           result.provider != "" and result.temperature_k == book_temperature,
                           result.provider))

    # ---- the honest limit ----------------------------------------------
    print("\nthe hot-gas limit is refused, not extrapolated:")
    for temperature in (40.0, 300.0, 2500.0):
        try:
            liquid_hydrogen_density(temperature)
        except PropertyUnavailableError as exc:
            results.append(True)
            print(f"  [PASS] refused {temperature:>6.0f} K: {str(exc)[:52]}...")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {temperature:.0f} K as a liquid state")

    try:
        liquid_hydrogen_density(0.0)
    except PropertyUnavailableError:
        results.append(True)
        print("  [PASS] rejected zero temperature")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED zero temperature")

    results.append(_report("critical temperature bound is explicit",
                           LH2_MAX_LIQUID_TEMPERATURE_K < 34.0,
                           f"limit = {LH2_MAX_LIQUID_TEMPERATURE_K} K"))

    # ---- hot gaseous hydrogen ------------------------------------------
    print("\nhot gaseous hydrogen (needs CoolProp):")
    try:
        state = gas_hydrogen_properties(600.0, 5.0e6)
    except PropertyUnavailableError as exc:
        print(f"  [SKIP] not available in this interpreter: {str(exc)[:64]}...")
        print("         (verified separately on Python 3.10, which has CoolProp)")
        state = None
    if state is not None:
        for temperature in (600.0, 1000.0, 1500.0, 2500.0):
            pressure = 5.0e6 if temperature < 2000.0 else 3.0e6
            sample = gas_hydrogen_properties(temperature, pressure)
            print(f"    T={temperature:6.0f} K  rho={sample.density_kg_m3:8.4f} kg/m3  "
                  f"cp={sample.cp_j_kg_k:8.1f}  gamma={sample.gamma:.3f}  "
                  f"R={sample.gas_constant_j_kg_k:7.1f}  Pr={sample.prandtl:.3f}")

        # Independent physics identities: these are textbook values for H2 and
        # confirm the provider is wired to the right units, not merely returning
        # numbers.
        results.append(_report("specific gas constant is hydrogen's 4124 J/kg-K",
                               4000.0 < state.gas_constant_j_kg_k < 4300.0,
                               f"R = {state.gas_constant_j_kg_k:.1f} J/kg-K"))
        results.append(_report("gamma is diatomic and below 1.4",
                               1.25 < state.gamma < 1.41, f"gamma = {state.gamma:.4f}"))
        results.append(_report("Prandtl number is near hydrogen's 0.7",
                               0.6 < state.prandtl < 0.75, f"Pr = {state.prandtl:.4f}"))
        results.append(_report("cp exceeds cv", state.cp_j_kg_k > state.cv_j_kg_k,
                               f"cp={state.cp_j_kg_k:.0f} > cv={state.cv_j_kg_k:.0f}"))

        hotter = gas_hydrogen_properties(1500.0, 5.0e6)
        results.append(_report("cp rises with temperature (vibrational modes)",
                               hotter.cp_j_kg_k > state.cp_j_kg_k,
                               f"{state.cp_j_kg_k:.0f} -> {hotter.cp_j_kg_k:.0f} J/kg-K"))
        results.append(_report("gamma falls as temperature rises",
                               hotter.gamma < state.gamma,
                               f"{state.gamma:.4f} -> {hotter.gamma:.4f}"))
        results.append(_report("density falls with temperature at fixed pressure",
                               hotter.density_kg_m3 < state.density_kg_m3,
                               f"{state.density_kg_m3:.4f} -> {hotter.density_kg_m3:.4f}"))
        results.append(_report("viscosity rises with temperature",
                               hotter.viscosity_pa_s > state.viscosity_pa_s,
                               f"{state.viscosity_pa_s:.3e} -> {hotter.viscosity_pa_s:.3e}"))
        results.append(_report("molar mass is hydrogen's 2.016 g/mol",
                               0.0019 < state.molar_mass_kg_mol < 0.0022,
                               f"{state.molar_mass_kg_mol*1000:.4f} g/mol"))

        for bad in ((0.0, 5.0e6), (600.0, 0.0), (-10.0, 5.0e6)):
            try:
                gas_hydrogen_properties(*bad)
            except PropertyUnavailableError:
                results.append(True)
                print(f"  [PASS] rejected T={bad[0]}, P={bad[1]}")
            else:
                results.append(False)
                print(f"  [FAIL] ACCEPTED T={bad[0]}, P={bad[1]}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: property providers are honest about coverage and cross-check "
          "against cited data")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
