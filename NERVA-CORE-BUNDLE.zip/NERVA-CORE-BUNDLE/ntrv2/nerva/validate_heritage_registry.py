"""Verify that the heritage registry enforces provenance and rejects fiction.

The registry's whole value is that it can say *no*. This validates the refusal
behaviour explicitly, then loads the real cited dataset and checks that every
entry is traceable and that the known hardware conflicts are recorded rather
than smoothed over.
"""
from __future__ import annotations

from pathlib import Path

from .heritage import Citation, HeritageRegistry, ProvenanceError, SourcedValue
from .heritage.registry import load_registry

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_nerva.json"

GOOD_CITATION = Citation(
    document="emrich2023",
    section="Ch. 10, Turbomachinery",
    page=178,
    locator="Eq. (10.3)",
    quote="H ¼ Pe Pa gr",
)


def _expect_rejected(label: str, fn) -> bool:
    try:
        fn()
    except (ProvenanceError, ValueError, KeyError) as exc:
        print(f"  [PASS] rejected {label}: {type(exc).__name__}")
        return True
    print(f"  [FAIL] ACCEPTED {label} - provenance hole")
    return False


def main() -> int:
    results: list[bool] = []

    print("unknown document is not citable:")
    results.append(_expect_rejected(
        "unknown document",
        lambda: Citation(document="some-paper-i-remember", section="Ch. 1",
                         page=1, locator="p.1", quote="trust me, the number is 42"),
    ))

    print("\nuncited / degenerate citations are rejected:")
    results.append(_expect_rejected(
        "missing quote",
        lambda: Citation(document="emrich2023", section="Ch. 1", page=1,
                         locator="Table 1", quote=""),
    ))
    results.append(_expect_rejected(
        "quote too short to support a claim",
        lambda: Citation(document="emrich2023", section="Ch. 1", page=1,
                         locator="Table 1", quote="see above"),
    ))
    results.append(_expect_rejected(
        "non-physical page number",
        lambda: Citation(document="emrich2023", section="Ch. 1", page=0,
                         locator="Table 1", quote="a quote of adequate length"),
    ))
    results.append(_expect_rejected(
        "missing locator",
        lambda: Citation(document="emrich2023", section="Ch. 1", page=1,
                         locator="", quote="a quote of adequate length"),
    ))

    print("\ninvented numbers cannot masquerade as heritage data:")
    results.append(_expect_rejected(
        "assumed value without assumed_ prefix",
        lambda: SourcedValue(name="pump.head_curve", value=1.0, unit="m",
                             kind="assumed", citation=GOOD_CITATION),
    ))
    results.append(_expect_rejected(
        "unknown kind label",
        lambda: SourcedValue(name="pump.foo", value=1.0, unit="m",
                             kind="roughly-right", citation=GOOD_CITATION),
    ))
    results.append(_expect_rejected(
        "unitless value",
        lambda: SourcedValue(name="pump.bar", value=1.0, unit="",
                             kind="measured", citation=GOOD_CITATION),
    ))
    results.append(_expect_rejected(
        "negative uncertainty",
        lambda: SourcedValue(name="pump.bar", value=1.0, unit="m",
                             kind="measured", citation=GOOD_CITATION,
                             uncertainty=-1.0),
    ))

    print("\nregistry integrity:")
    results.append(_expect_rejected(
        "duplicate name",
        lambda: _duplicate(),
    ))

    print("\nloading the real cited dataset:")
    if not DATA.exists():
        print(f"  [FAIL] dataset missing: {DATA}")
        return 1
    registry = load_registry(DATA)
    print(f"  [PASS] loaded {len(registry)} cited entries")
    results.append(True)

    kinds: dict[str, int] = {}
    for entry in registry:
        kinds[entry.kind] = kinds.get(entry.kind, 0) + 1
        entry.citation.validate()
    print(f"  [PASS] every entry carries a validated citation "
          f"({', '.join(f'{k}={v}' for k, v in sorted(kinds.items()))})")
    results.append(True)

    required = [
        "nerva.max_thrust",
        "nerva.max_specific_impulse",
        "nerva.fuel_element_coolant_holes",
        "pewee.thermal_power",
        "pewee.exit_coolant_temperature",
    ]
    try:
        registry.require(required)
        print(f"  [PASS] required heritage values present ({len(required)} checked)")
        results.append(True)
    except KeyError as exc:
        print(f"  [FAIL] {exc}")
        results.append(False)

    print("\nknown conflicts must be recorded, and their resolution justified:")
    length = registry.get("nerva.fuel_element_length")
    # The prose "about 55 inches" disagrees with the two precise sources. The
    # requirement is not that a conflict exists forever, nor that it be hidden:
    # it is that the entry says which way the disagreement was decided AND on
    # what evidence. Both readings of the note are therefore accepted only when
    # the note states a verdict.
    resolved = ("RESOLVED" in length.note and "132" in length.note
                and "5.8" in length.note)
    print(f"  [{'PASS' if resolved else 'FAIL'}] "
          f"fuel_element_length records the 132 cm vs 55 in discrepancy and "
          f"states the resolution")
    results.append(resolved)

    core_length = registry.get("nerva.core_length")
    agrees = (core_length.kind == "design-target"
              and abs(core_length.value - 132.0) < 1e-9)
    print(f"  [{'PASS' if agrees else 'FAIL'}] core length 132 cm cited to "
          f"Table III.2 as the superseding value (kind '{core_length.kind}')")
    results.append(agrees)

    i_sp = registry.get("pewee.vacuum_specific_impulse")
    labelled = i_sp.kind == "derived"
    print(f"  [{'PASS' if labelled else 'FAIL'}] Pewee Isp recorded as "
          f"'{i_sp.kind}' (report says 'calculated', not measured)")
    results.append(labelled)

    print("\nmissing values fail loudly and list everything absent:")
    try:
        registry.value("pump.head_flow_curve")
    except KeyError as exc:
        print(f"  [PASS] absent value raises KeyError: {str(exc)[:70]}")
        results.append(True)
    else:
        print("  [FAIL] absent value silently returned")
        results.append(False)

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: heritage registry enforces provenance")
    return 0


def _duplicate() -> None:
    registry = HeritageRegistry()
    entry = SourcedValue(name="dup.value", value=1.0, unit="m",
                         kind="measured", citation=GOOD_CITATION)
    registry.add(entry)
    registry.add(entry)


if __name__ == "__main__":
    raise SystemExit(main())
