"""NASA CEA oracle: compare our thermochemistry against the real thing.

This is the external reference the fidelity matrix flags as "NASA Glenn/CEA
thermochemistry parity - NOT VALIDATED". It drives NASA CEA and reports the
difference, so the claim becomes measurable instead of asserted.

Two execution backends are supported because availability differs per machine:

* ``cea``    - NASA's official pure-Python package (preferred: no binaries)
* ``cea2.exe`` - the Fortran executable, if a working build and its runtime
  libraries are present

Deck generation and output parsing are pure string work and are verified
offline; only the actual CEA invocation needs the backend. When neither backend
is available the module raises with the reason rather than returning a number.

Provenance note: CEA is a chemical-equilibrium code. For a nuclear thermal
rocket the propellant is heated by fission, not by combustion, so CEA is used
here as a **thermochemical property and equilibrium oracle for hydrogen**, not
as a model of the reactor.
"""
from __future__ import annotations

import math
import os
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

_CEA_EXE_CANDIDATES = (
    REPO_ROOT.parent / "ext_lib" / "RocketCEA-master" / "NASA_CEA_Fortran" / "cea2.exe",
    REPO_ROOT.parents[1] / "ext_lib" / "RocketCEA-master" / "NASA_CEA_Fortran" / "cea2.exe",
)


class CeaUnavailableError(RuntimeError):
    """Raised when no CEA backend can be executed, with the reason."""


@dataclass(frozen=True)
class CeaCase:
    """One hydrogen thermochemistry case to run through CEA."""

    temperature_k: float
    pressure_bar: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.temperature_k) or self.temperature_k <= 0.0:
            raise ValueError("CEA case temperature must be finite and positive")
        if not math.isfinite(self.pressure_bar) or self.pressure_bar <= 0.0:
            raise ValueError("CEA case pressure must be finite and positive")

    def describe(self) -> str:
        return f"T={self.temperature_k:.1f} K, p={self.pressure_bar:.4f} bar"


@dataclass(frozen=True)
class CeaResult:
    """What CEA reported for one case."""

    case: CeaCase
    temperature_k: float
    pressure_bar: float
    molecular_weight: float | None = None
    density_kg_m3: float | None = None
    enthalpy_j_kg: float | None = None
    entropy_j_kg_k: float | None = None
    cp_j_kg_k: float | None = None
    gamma: float | None = None
    h_mole_fraction: float | None = None
    h2_mole_fraction: float | None = None
    raw: str = ""
    backend: str = ""

    @property
    def dissociation_fraction(self) -> float | None:
        """Fraction of original H2 molecules that dissociated (alpha).

        With a stoichiometry of pure hydrogen and only H2/H present, if x is the
        H mole fraction then alpha = x/(1+x) for the reaction H2 -> 2H.
        """
        if self.h_mole_fraction is None:
            return None
        return self.h_mole_fraction / (1.0 + self.h_mole_fraction)


def build_deck(case: CeaCase, *, only_hydrogen: bool = True) -> str:
    """Generate a CEA input deck for a tp (temperature-pressure) hydrogen case.

    Kept as a separate pure function so the deck format is unit-testable without
    any CEA installation.
    """
    lines = [
        " problem  tp  new",
        "  fuel  H2  wt=1.0",
    ]
    if only_hydrogen:
        lines.append("  only  H  H2")
    lines.append(f"  p,bar={case.pressure_bar:.6f}  t,k={case.temperature_k:.4f}")
    lines.append("end")
    return "\n".join(lines) + "\n"


def _find_cea_exe() -> str | None:
    explicit = os.environ.get("NUKE_CEA_EXE")
    if explicit and Path(explicit).exists():
        return explicit
    on_path = shutil.which("cea2")
    if on_path:
        return on_path
    for candidate in _CEA_EXE_CANDIDATES:
        if candidate.is_file():
            return str(candidate)
    return None


def _exe_is_launchable(exe: str) -> tuple[bool, str]:
    """Check the executable actually loads, not merely that the file exists.

    A Fortran binary whose runtime DLLs are absent passes every file-existence
    test and then dies at the loader with 0xC0000135. Probing once here means
    the failure is reported as a preflight problem instead of surfacing in the
    middle of a comparison.
    """
    try:
        completed = subprocess.run(
            [exe], input=" problem  tp  new\n  fuel  H2  wt=1.0\nend\n",
            capture_output=True, text=True, timeout=20, errors="replace",
        )
    except OSError as exc:
        return False, (
            f"{Path(exe).name} cannot be launched: {exc}. This is the signature "
            f"of a missing Intel Fortran runtime (libifcoremd.dll / libmmd.dll)."
        )
    except subprocess.TimeoutExpired:
        # It started and waited for input, which means it loaded fine.
        return True, ""
    if completed.returncode == -1073741515 or completed.returncode == 0xC0000135:
        return False, (
            f"{Path(exe).name} failed to load (STATUS_DLL_NOT_FOUND "
            f"0xC0000135): the Intel Fortran runtime DLLs are missing."
        )
    return True, ""


def preflight() -> list[str]:
    """Return blocking problems; empty means a CEA backend is usable."""
    problems: list[str] = []
    python_backend = False
    try:
        import cea  # noqa: F401, PLC0415 - presence check only
        python_backend = True
    except ImportError:
        problems.append(
            "the NASA 'cea' python package is not installed (pip install cea)"
        )

    exe = _find_cea_exe()
    if exe is None:
        if not python_backend:
            problems.append(
                "no cea2 executable found either; set NUKE_CEA_EXE or place a "
                "working build on PATH"
            )
        return problems

    launchable, detail = _exe_is_launchable(exe)
    if not launchable:
        problems.append(detail)
    return problems


def require_backend() -> None:
    problems = preflight()
    if problems:
        raise CeaUnavailableError("CEA is not available here:\n  - "
                                  + "\n  - ".join(problems))


def _parse_cea_output(text: str, case: CeaCase, backend: str) -> CeaResult:
    """Pull the properties block out of CEA's printed output.

    CEA prints a labelled table; this scans for the documented labels rather
    than assuming fixed columns, so it tolerates the usual whitespace variation.
    """
    values: dict[str, float] = {}
    wanted = {
        "MW": "molecular_weight",
        "DENSITY": "density_kg_m3",       # reported in kg/m3 by CEA
        "H,": "enthalpy_j_kg",            # kJ/kg
        "S,": "entropy_j_kg_k",           # kJ/(kg K)
        "CP,": "cp_j_kg_k",               # kJ/(kg K)
        "GAMMAS": "gamma",
        "MOLFRACTION": None,              # handled separately
    }
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        for label, key in wanted.items():
            if key is None:
                continue
            if stripped.upper().startswith(label):
                numbers = _numbers_in(stripped)
                if numbers:
                    values[key] = numbers[0]
    raw = text
    result = CeaResult(
        case=case,
        temperature_k=case.temperature_k,
        pressure_bar=case.pressure_bar,
        molecular_weight=values.get("molecular_weight"),
        density_kg_m3=values.get("density_kg_m3"),
        enthalpy_j_kg=(values["enthalpy_j_kg"] * 1000.0
                       if "enthalpy_j_kg" in values else None),
        entropy_j_kg_k=(values["entropy_j_kg_k"] * 1000.0
                        if "entropy_j_kg_k" in values else None),
        cp_j_kg_k=(values["cp_j_kg_k"] * 1000.0
                   if "cp_j_kg_k" in values else None),
        gamma=values.get("gamma"),
        raw=raw[-4000:],
        backend=backend,
    )
    return result


def _numbers_in(line: str) -> list[float]:
    out: list[float] = []
    for token in line.replace(",", " ").split():
        try:
            out.append(float(token))
        except ValueError:
            continue
    return out


def run_case(case: CeaCase, *, workdir: str | Path | None = None,
             timeout_s: int = 120) -> CeaResult:
    """Run one CEA case through whichever backend is available."""
    require_backend()

    try:
        import cea  # noqa: PLC0415
    except ImportError:
        cea = None

    if cea is not None:
        return _run_with_python_cea(case)

    return _run_with_executable(case, workdir=workdir, timeout_s=timeout_s)


def _run_with_python_cea(case: CeaCase) -> CeaResult:
    """Use NASA's pure-Python CEA package."""
    from cea.thermo.db import ThermoDB  # noqa: PLC0415
    from cea.thermo.solvers import EqSolver  # noqa: PLC0415

    db = ThermoDB()
    thermo = db.get_thermo("H2O")  # placeholder to force DB load ordering
    del thermo
    solver = EqSolver(
        reactants=[(db.get_thermo("H2"), 1.0)],  # kg or mol basis per CEA API
        only=["H", "H2"],
        pressure=[case.pressure_bar],
        temperature=[case.temperature_k],
    )
    solution = solver.solve("TP")[0]
    return CeaResult(
        case=case,
        temperature_k=case.temperature_k,
        pressure_bar=case.pressure_bar,
        molecular_weight=getattr(solution, "MW", None),
        density_kg_m3=getattr(solution, "density", None),
        raw="python-cea",
        backend="cea (python)",
    )


def _run_with_executable(case: CeaCase, *, workdir, timeout_s: int) -> CeaResult:
    """Use a cea2 executable, writing a deck and parsing the printed output."""
    exe = _find_cea_exe()
    if exe is None:  # pragma: no cover - preflight already blocked
        raise CeaUnavailableError("cea2 executable disappeared between checks")
    work = Path(workdir or (REPO_ROOT / "build" / "cea_oracle"))
    work.mkdir(parents=True, exist_ok=True)
    deck = build_deck(case)
    deck_path = work / "nuke_cea_case.inp"
    deck_path.write_text(deck, encoding="ascii")

    try:
        completed = subprocess.run(
            [exe], cwd=str(work), input=deck, capture_output=True,
            text=True, timeout=timeout_s, errors="replace",
        )
    except OSError as exc:
        raise CeaUnavailableError(
            f"could not execute {exe}: {exc}. A missing Intel Fortran runtime "
            f"(libifcoremd.dll / libmmd.dll) presents as a loader error here."
        ) from exc

    if completed.returncode != 0:
        raise CeaUnavailableError(
            f"{exe} failed with exit code {completed.returncode} "
            f"(0xC0000135 means the Fortran runtime DLLs are missing); "
            f"stderr: {(completed.stderr or '').strip()[:160]}"
        )
    output = (completed.stdout or "") + (completed.stderr or "")
    printed = work / "cea2.out"
    if printed.exists():
        output = printed.read_text(encoding="latin-1", errors="replace")
    return _parse_cea_output(output, case, backend=f"cea2 ({Path(exe).name})")


def compare_with_model(cases: list[CeaCase], model_callable
                       ) -> list[tuple[CeaCase, CeaResult, float, float]]:
    """Compare CEA against a model callable returning (cp, gamma).

    ``model_callable(case)`` must return ``(cp_j_kg_k, gamma)``. Returns rows of
    ``(case, cea_result, cp_relative_error, gamma_relative_error)``. A row is
    skipped when CEA did not report the quantity, rather than inventing zero.
    """
    rows = []
    for case in cases:
        result = run_case(case)
        cp_model, gamma_model = model_callable(case)
        cp_error = (abs(result.cp_j_kg_k - cp_model) / cp_model
                    if result.cp_j_kg_k else float("nan"))
        gamma_error = (abs(result.gamma - gamma_model) / gamma_model
                       if result.gamma else float("nan"))
        rows.append((case, result, cp_error, gamma_error))
    return rows
