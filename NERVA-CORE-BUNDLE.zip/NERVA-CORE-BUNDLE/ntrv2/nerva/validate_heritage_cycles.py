"""Verify the cycle methods against the book's own stated properties.

Emrich Ch. 3 gives no numerical worked example, but it does make three
quantitative claims that can be tested directly:

1. Eq. (3.1) defines h5 as the mass-weighted bleed mixture (p.24).
2. The hot bleed cycle's advantage is "the low bleed flow required to drive
   the turbopump" (p.23) - so for equal pump work it must need LESS bleed
   than the cold bleed cycle. That is falsifiable and is tested here.
3. The expander cycle needs no bleed at all but is capped by regenerative
   heat (p.26), which the balance expresses exactly.

The enthalpy values below are SYNTHETIC test inputs, not heritage data. They
exist to exercise algebra and are never presented as NERVA conditions.
"""
from __future__ import annotations

from pathlib import Path

from .heritage import cycles as cy
from .heritage.registry import load_registry

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_cycles.json"

# Synthetic test state points [J/kg]. Illustrative only.
H1_TANK = 1.0e5          # pump inlet
H2_PUMP_OUT = 1.5e5      # pump outlet  (pump rise 5.0e4)
H3_WARM = 4.0e5          # after regenerative cooling
H4_COLD_TURBINE_OUT = 1.5e5   # cold-bleed turbine outlet
H4_HOT_CORE = 6.0e6      # hot bleed tapped from the core exit plenum
H6_HOT_TURBINE_OUT = 3.0e5


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<50} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- heritage constraints ------------------------------------------
    registry = load_registry(DATA)
    print("cycle heritage flags (these constrain what may be labelled NERVA):")
    hot = registry.value("nerva.cycle_is_hot_bleed")
    results.append(_report("NERVA operated the hot bleed cycle (p.23)",
                           hot == 1.0, f"flag={hot}"))
    cold_impl = registry.value("cold_bleed.ever_implemented")
    results.append(_report("cold bleed was never implemented (p.24)",
                           cold_impl == 0.0, f"flag={cold_impl}"))

    # ---- Eq. (3.1) mixing ---------------------------------------------
    print("\nEq. (3.1) bleed mixing is mass-weighted (p.24):")
    h_all_warm = cy.mixed_bleed_enthalpy(1.0, H3_WARM, 0.0, H4_HOT_CORE)
    results.append(_report("all-warm bleed reduces to h3",
                           abs(h_all_warm - H3_WARM) < 1e-12, f"h5={h_all_warm:.6g}"))
    h_all_hot = cy.mixed_bleed_enthalpy(0.0, H3_WARM, 1.0, H4_HOT_CORE)
    results.append(_report("all-hot bleed reduces to h4",
                           abs(h_all_hot - H4_HOT_CORE) < 1e-12, f"h5={h_all_hot:.6g}"))
    h_mixed = cy.mixed_bleed_enthalpy(3.0, H3_WARM, 1.0, H4_HOT_CORE)
    expected = (3.0 * H3_WARM + 1.0 * H4_HOT_CORE) / 4.0
    results.append(_report("3:1 warm:hot mixture matches hand calculation",
                           abs(h_mixed - expected) < 1e-12,
                           f"h5={h_mixed:.6g} expected={expected:.6g}"))
    results.append(_report("mixture enthalpy lies between the branches",
                           min(H3_WARM, H4_HOT_CORE) < h_mixed < max(H3_WARM, H4_HOT_CORE),
                           f"{H3_WARM:.3g} < {h_mixed:.4g} < {H4_HOT_CORE:.3g}"))

    # ---- closure round-trip -------------------------------------------
    print("\nenergy balance closes exactly when solved for the bleed fraction:")
    m_total = 21.4
    hot_fraction = 0.1
    fraction = cy.hot_bleed_fraction(m_total, H1_TANK, H2_PUMP_OUT,
                                     H3_WARM, H4_HOT_CORE, H6_HOT_TURBINE_OUT,
                                     hot_fraction)
    m_bleed = fraction * m_total
    residual = cy.hot_bleed_energy_balance(
        m_total, H1_TANK, H2_PUMP_OUT,
        m_bleed * (1.0 - hot_fraction), H3_WARM,
        m_bleed * hot_fraction, H4_HOT_CORE,
        H6_HOT_TURBINE_OUT)
    scale = m_total * (H2_PUMP_OUT - H1_TANK)
    results.append(_report("hot bleed residual vanishes",
                           abs(residual) / scale < 1e-12,
                           f"fraction={fraction:.6f} rel residual="
                           f"{abs(residual)/scale:.2e}"))

    cold_fraction = cy.cold_bleed_fraction(m_total, H1_TANK, H2_PUMP_OUT,
                                           H3_WARM, H4_COLD_TURBINE_OUT)
    cold_residual = cy.cold_bleed_energy_balance(
        m_total, H1_TANK, H2_PUMP_OUT, cold_fraction * m_total,
        H3_WARM, H4_COLD_TURBINE_OUT)
    results.append(_report("cold bleed residual vanishes",
                           abs(cold_residual) / scale < 1e-12,
                           f"fraction={cold_fraction:.6f} rel residual="
                           f"{abs(cold_residual)/scale:.2e}"))

    # ---- the book's efficiency claim, tested --------------------------
    print("\nbook claim (p.23): hot bleed needs LESS bleed flow than cold bleed")
    print(f"    hot  bleed fraction = {fraction:.4f}")
    print(f"    cold bleed fraction = {cold_fraction:.4f}")
    results.append(_report("hot bleed fraction < cold bleed fraction",
                           fraction < cold_fraction,
                           f"{fraction:.4f} < {cold_fraction:.4f}"))

    sequence = [
        cy.hot_bleed_fraction(m_total, H1_TANK, H2_PUMP_OUT, H3_WARM,
                              H4_HOT_CORE, H6_HOT_TURBINE_OUT, f)
        for f in (0.0, 0.05, 0.10, 0.20, 0.50)
    ]
    decreasing = all(b <= a for a, b in zip(sequence, sequence[1:]))
    results.append(_report("more hot bleed monotonically reduces bleed flow",
                           decreasing,
                           " ".join(f"{v:.4f}" for v in sequence)))

    # ---- expander ------------------------------------------------------
    print("\nexpander cycle (p.26): no bleed, pump work entirely regenerative")
    balanced = cy.expander_energy_balance(H1_TANK, H2_PUMP_OUT,
                                          H3_WARM, H3_WARM - (H2_PUMP_OUT - H1_TANK))
    results.append(_report("expander balance closes when work is matched",
                           abs(balanced) < 1e-12, f"residual={balanced:.2e}"))
    available = cy.expander_available_turbine_work(21.4, H3_WARM, H3_WARM - 5.0e4)
    results.append(_report("expander turbine power = m_dot * drop",
                           abs(available - 21.4 * 5.0e4) < 1e-6,
                           f"{available:.6g} W"))

    # ---- guards --------------------------------------------------------
    print("\nguard checks (each must raise):")
    guards = [
        ("bleed greater than total flow",
         lambda: cy.hot_bleed_energy_balance(1.0, H1_TANK, H2_PUMP_OUT,
                                             2.0, H3_WARM, 1.0, H4_HOT_CORE,
                                             H6_HOT_TURBINE_OUT)),
        ("no bleed flow at all",
         lambda: cy.mixed_bleed_enthalpy(0.0, H3_WARM, 0.0, H4_HOT_CORE)),
        ("negative pump work",
         lambda: cy.cold_bleed_energy_balance(1.0, H2_PUMP_OUT, H1_TANK,
                                              0.1, H3_WARM, H4_COLD_TURBINE_OUT)),
        ("turbine cannot expand upward",
         lambda: cy.cold_bleed_energy_balance(1.0, H1_TANK, H2_PUMP_OUT,
                                              0.5, H4_COLD_TURBINE_OUT, H3_WARM)),
        ("non-closing cycle",
         lambda: cy.cold_bleed_fraction(21.4, H1_TANK, 9.0e5,
                                        H3_WARM, H4_COLD_TURBINE_OUT)),
        ("hot fraction outside [0,1]",
         lambda: cy.hot_bleed_fraction(21.4, H1_TANK, H2_PUMP_OUT, H3_WARM,
                                       H4_HOT_CORE, H6_HOT_TURBINE_OUT, 1.5)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ValueError, ZeroDivisionError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: cycle methods reproduce Emrich (2023) Ch.3 balances and claims")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
