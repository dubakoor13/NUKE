"""Verify the pluggable transport seam.

The OpenMC backend cannot run here (no executable, no cross sections), so this
suite verifies what *can* be verified: that the mock is deterministic and
honestly labelled, that normalisation invariants hold, that the OpenMC backend
refuses cleanly with an actionable message rather than failing obscurely, and
that invalid core states are rejected rather than silently propagated.
"""
from __future__ import annotations

from .transport_backend import (
    CoreState,
    MockCoefficients,
    MockTransportBackend,
    OpenMCTransportBackend,
    PreflightError,
    describe_environment,
)

COEFFS = MockCoefficients(
    k_reference=1.02,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    hydrogen_temperature_coefficient_per_k=-2.0e-6,
    drum_coefficient_per_deg=2.0e-4,
    enrichment_coefficient_per_wt_percent=2.0e-2,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<52} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    backend = MockTransportBackend(coefficients=COEFFS, element_count=7,
                                   radial_peaking=1.30,
                                   shape_temperature_sensitivity_per_k=-2.0e-5)
    state = CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0,
                      drum_angle_deg=0.0, enrichment_wt_percent=5.0)

    # ---- interface contract -------------------------------------------
    print("backend contract:")
    results.append(_report("mock declares itself synthetic",
                           backend.synthetic is True, f"synthetic={backend.synthetic}"))
    result = backend.run(state)
    results.append(_report("synthetic result reports is_physics = False",
                           result.is_physics is False, f"is_physics={result.is_physics}"))
    results.append(_report("openmc backend declares itself non-synthetic",
                           OpenMCTransportBackend.synthetic is False, "synthetic=False"))
    results.append(_report("mock reports ready (nothing to preflight)",
                           backend.preflight() == [], f"{backend.preflight()}"))
    results.append(_report("provenance warns it is not transport",
                           "NOT a neutron-transport result"
                           in str(result.provenance.get("warning", "")),
                           result.provenance.get("kind", "")))

    # ---- determinism and normalisation --------------------------------
    print("\ndeterminism and normalisation:")
    again = backend.run(state)
    results.append(_report("identical state gives identical k",
                           again.k_eff == result.k_eff, f"{result.k_eff!r}"))
    results.append(_report("identical state gives identical shape",
                           again.fuel_power_fraction == result.fuel_power_fraction,
                           f"{len(result.fuel_power_fraction)} elements"))
    total = sum(result.fuel_power_fraction)
    results.append(_report("power fractions sum to exactly 1",
                           abs(total - 1.0) < 1e-12, f"sum={total:.16f}"))
    results.append(_report("all fractions are non-negative",
                           all(f >= 0.0 for f in result.fuel_power_fraction),
                           f"min={min(result.fuel_power_fraction):.6f}"))
    peak = max(result.fuel_power_fraction)
    average = total / len(result.fuel_power_fraction)
    results.append(_report("peak/average <= requested peaking",
                           peak / average <= 1.30 + 1e-9,
                           f"peak/avg={peak/average:.5f}"))

    # ---- physics response directions ----------------------------------
    print("\ndeclared response directions (surrogate coefficients):")
    hotter = backend.run(state.with_changes(fuel_temperature_k=1300.0))
    results.append(_report("k decreases as fuel temperature rises",
                           hotter.k_eff < result.k_eff,
                           f"{result.k_eff:.6f} -> {hotter.k_eff:.6f}"))
    rotated = backend.run(state.with_changes(drum_angle_deg=10.0))
    results.append(_report("k changes with drum angle",
                           rotated.k_eff > result.k_eff,
                           f"{result.k_eff:.6f} -> {rotated.k_eff:.6f}"))
    shape_hot = hotter.fuel_power_fraction
    peaking_cold = max(result.fuel_power_fraction) / (
        sum(result.fuel_power_fraction) / len(result.fuel_power_fraction))
    peaking_hot = max(shape_hot) / (sum(shape_hot) / len(shape_hot))
    results.append(_report("shape flattens as fuel heats",
                           peaking_hot < peaking_cold,
                           f"peak/avg {peaking_cold:.4f} -> {peaking_hot:.4f}"))

    # ---- OpenMC backend must refuse, not improvise --------------------
    print("\nOpenMC backend refusal path (the important one on this machine):")
    openmc_backend = OpenMCTransportBackend(workdir="build/nerva_transport_probe",
                                           cross_sections=None, executable=None)
    problems = openmc_backend.preflight()
    results.append(_report("preflight reports blocking problems",
                           len(problems) >= 1, f"{len(problems)} problem(s)"))
    text = " ".join(problems).lower()
    results.append(_report("mentions the missing executable",
                           "executable" in text, "actionable wording present"))
    results.append(_report("mentions the missing cross sections",
                           "cross section" in text, "actionable wording present"))
    try:
        openmc_backend.run(state)
    except PreflightError as exc:
        results.append(True)
        print(f"  [PASS] run() raises PreflightError, not a fake number")
        print(f"         {str(exc).splitlines()[0]}")
    else:
        results.append(False)
        print("  [FAIL] run() returned without transport data available")

    report = describe_environment(openmc_backend)
    results.append(_report("doctor report says NOT READY",
                           "NOT READY" in report,
                           report.splitlines()[-1] if report else ""))

    # ---- invalid state is rejected ------------------------------------
    print("\ninvalid core states are rejected:")
    guards = [
        ("zero fuel temperature",
         lambda: CoreState(fuel_temperature_k=0.0, hydrogen_temperature_k=900.0)),
        ("negative hydrogen temperature",
         lambda: CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=-5.0)),
        ("enrichment above the 20 wt% cap",
         lambda: CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0,
                           enrichment_wt_percent=25.0)),
        ("zero particles",
         lambda: CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0,
                           particles=0)),
        ("peaking below unity",
         lambda: MockTransportBackend(coefficients=COEFFS, radial_peaking=0.5)),
        ("non-finite coefficient",
         lambda: MockCoefficients(k_reference=1.0,
                                  fuel_temperature_coefficient_per_k=float("nan"),
                                  hydrogen_temperature_coefficient_per_k=0.0,
                                  drum_coefficient_per_deg=0.0,
                                  enrichment_coefficient_per_wt_percent=0.0).validate()),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ValueError, PreflightError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    # Unnormalised heating must be refused.
    from .transport_backend import TransportResult
    try:
        TransportResult(k_eff=1.0, k_sigma=0.0, fuel_power_fraction=(0.5, 0.4),
                        leakage_fraction=0.0, backend="x", synthetic=True,
                        provenance={})
    except ValueError:
        results.append(True)
        print("  [PASS] rejected unnormalised heating fractions")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED unnormalised heating fractions")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: transport seam is pluggable, honest, and refuses to improvise")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
