"""Verify turbomachinery methods against Emrich's own worked example.

Emrich (2023), Chapter 10, "Turbomachinery", pp. 178-179, presents a complete
pump design example and prints its answers. Reproducing those printed answers
is a genuine external verification of this code that needs no OpenMC, no
cross sections and no data files - the book is the oracle.

Book problem: deliver saturated liquid hydrogen at 20 K from 0.45 MPa to
6.9 MPa at 21.4 kg/s, and find the impeller diameter, shaft speed and shaft
work that maximise efficiency.
"""
from __future__ import annotations

from .heritage import cycles as cy
from .heritage import turbomachinery as tm

# Inputs exactly as stated in the worked example (Emrich p.178).
INLET_PRESSURE_PA = 0.45e6      # Pa
OUTLET_PRESSURE_PA = 6.9e6      # Pa
VAPOUR_PRESSURE_PA = 0.091e6    # Pa, saturation at 20 K
LIQUID_DENSITY = 71.3           # kg/m3
MASS_FLOW = 21.4                # kg/s
SPECIFIC_SPEED = 0.5            # from Fig. 10.4 at sigma = 0.0557
SPECIFIC_DIAMETER = 5.2         # from Fig. 10.5 at max efficiency
PUMP_EFFICIENCY = 0.8

# Answers printed in the book (pp. 178-179).
BOOK_NPSH_M = 514.0
BOOK_HEAD_M = 9230.0
BOOK_THOMA = 0.0557
BOOK_VOLUME_FLOW_M3_S = 0.3
BOOK_OMEGA_RAD_S = 4760.0
BOOK_RPM = 45500.0
BOOK_DIAMETER_M = 0.164      # printed as 16.4 cm
BOOK_SHAFT_POWER_W = 2.42e6  # printed as 2.42 MW

# The book rounds intermediate results to 3-4 significant figures, so a
# relative tolerance of 1% compares like with like.
REL_TOL = 1e-2


def _check(label: str, got: float, expected: float, unit: str) -> bool:
    if expected == 0.0:
        ok = abs(got) < 1e-12
        rel = 0.0
    else:
        rel = abs(got - expected) / abs(expected)
        ok = rel <= REL_TOL
    mark = "PASS" if ok else "FAIL"
    print(f"  [{mark}] {label:<28} code={got:>12.5g} {unit:<6} "
          f"book={expected:>12.5g} {unit:<6} rel={rel*100:6.2f}%")
    return ok


def main() -> int:
    print("Emrich (2023) Ch.10 worked pump example reproduced by "
          "ntr.nerva.heritage.turbomachinery\n")

    q = tm.volume_flow(MASS_FLOW, LIQUID_DENSITY)
    head = tm.pump_head(OUTLET_PRESSURE_PA, INLET_PRESSURE_PA, LIQUID_DENSITY)
    hsr = tm.npsh_required(INLET_PRESSURE_PA, VAPOUR_PRESSURE_PA, LIQUID_DENSITY)
    sigma = tm.thoma_parameter(hsr, head)
    omega = tm.omega_from_specific_speed(SPECIFIC_SPEED, q, head)
    rpm = tm.rad_per_s_to_rpm(omega)
    diameter = tm.diameter_from_specific_diameter(SPECIFIC_DIAMETER, q, head)
    power = tm.pump_shaft_power(q, OUTLET_PRESSURE_PA, INLET_PRESSURE_PA,
                               PUMP_EFFICIENCY)

    results = [
        _check("NPSH required", hsr, BOOK_NPSH_M, "m"),
        _check("pump head", head, BOOK_HEAD_M, "m"),
        _check("Thoma parameter", sigma, BOOK_THOMA, "-"),
        _check("volume flow", q, BOOK_VOLUME_FLOW_M3_S, "m3/s"),
        _check("shaft speed", omega, BOOK_OMEGA_RAD_S, "rad/s"),
        _check("shaft speed", rpm, BOOK_RPM, "rpm"),
        _check("impeller diameter", diameter, BOOK_DIAMETER_M, "m"),
        _check("pump shaft power", power, BOOK_SHAFT_POWER_W, "W"),
    ]

    # Internal consistency: Eq. 10.6 must agree with the Q(Pe-Pa)/eta form
    # used by the book, because g*rho*H == Pe - Pa by Eq. 10.3.
    print("\n  internal consistency (Eq. 10.6 vs Q(Pe-Pa)/eta):")
    eta_back = tm.pump_efficiency(LIQUID_DENSITY, q, head, power)
    rel = abs(eta_back - PUMP_EFFICIENCY) / PUMP_EFFICIENCY
    ok = rel <= REL_TOL
    results.append(ok)
    print(f"  [{'PASS' if ok else 'FAIL'}] recovered pump efficiency   "
          f"code={eta_back:.6f}  specified={PUMP_EFFICIENCY}  "
          f"rel={rel*100:.2e}%")

    # Round-trip the similarity inversions.
    print("\n  similarity inversions (round-trip):")
    ns_back = tm.pump_specific_speed(omega, q, head)
    ds_back = tm.pump_specific_diameter(diameter, q, head)
    for label, got, expected in (
        ("specific speed", ns_back, SPECIFIC_SPEED),
        ("specific diameter", ds_back, SPECIFIC_DIAMETER),
    ):
        rel = abs(got - expected) / expected
        ok = rel <= 1e-9
        results.append(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {label:<28} "
              f"code={got:.10f}  target={expected}  rel={rel:.2e}")

    # Physicality guards must actually reject bad input.
    print("\n  guard checks (each must raise):")
    guards = [
        ("cavitating inlet", lambda: tm.npsh_required(1.0e5, 1.0e5, 71.3)),
        ("reversed pump", lambda: tm.pump_head(1.0e5, 6.9e6, 71.3)),
        ("efficiency > 1", lambda: tm.pump_efficiency(71.3, q, head, 1.0)),
        ("pump efficiency = 0", lambda: tm.pump_shaft_power(q, 6.9e6, 4.5e5, 0.0)),
        ("turbine adding enthalpy", lambda: tm.turbine_power(21.4, 100.0, 200.0)),
        ("bleed exceeds total flow",
         lambda: cy.cold_bleed_energy_balance(1.0, 1.0, 2.0, 2.0, 3.0, 1.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ValueError, ZeroDivisionError):
            results.append(True)
            print(f"  [PASS] rejected: {label}")
        else:
            results.append(False)
            print(f"  [FAIL] accepted: {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        print(f"FAILED: {failed}")
        return 1
    print("PASS: turbomachinery methods reproduce Emrich (2023) pp.178-179")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
