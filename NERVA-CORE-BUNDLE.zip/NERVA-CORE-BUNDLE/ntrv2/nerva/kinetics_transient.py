"""Coupled reactor transient: point kinetics with temperature feedback.

This is the capstone of the core model. Everything before it answers "what is k
for this state" or "what power makes the core critical at steady state". This
module answers "what happens next" and, crucially, makes **power a solved
result over time** rather than an input.

The two halves are already verified separately and are reused rather than
reimplemented:

* ``heritage.kinetics`` - the six-group point-kinetics equations, the Inhour
  equation and the temperature-feedback closure.
* The lumped thermal model below - two nodes, fuel and coolant.

Why the quasi-static (prompt-jump) form
---------------------------------------
The prompt mode has eigenvalue ``(rho - beta)/L`` which, for any realistic
prompt lifetime, is thousands of per second. Integrating it explicitly would
force timesteps around a microsecond for a transient lasting seconds. The
standard engineering treatment therefore eliminates the prompt mode
algebraically:

    n = sum(lambda_i * C_i) / (beta - rho)                     (prompt jump)

leaving only the six precursor equations plus the two thermal nodes, whose
timescales are tenths of a second. This is valid while ``rho < beta`` and the
module **refuses** to run above that, because the approximation fails on the
prompt-critical excursion rather than merely losing accuracy.

Sign conventions
----------------
Reactivity coefficients are negative for a self-limiting core. Power is in W;
the neutron population ``n`` is dimensionless and normalised so that ``n = 1``
gives the reference power.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

from .heritage import kinetics as kin


class TransientError(ValueError):
    """Raised when a transient is not well posed or leaves the model's validity."""


def _load_u235_groups() -> kin.DelayedGroups:
    from .heritage.registry import load_registry

    data = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"
    return kin.u235_delayed_groups(load_registry(data))


@dataclass(frozen=True)
class ThermalModel:
    """Two-node lumped thermal model: fuel node and coolant node.

        C_f dT_f/dt = P - h (T_f - T_c)
        C_c dT_c/dt = h (T_f - T_c) - k_c (T_c - T_in)

    ``k_c`` is the coolant heat-removal conductance to the fixed inlet
    temperature. Deliberately simple: this is a stability and equilibrium
    model, not a thermal-hydraulic validation.
    """

    fuel_heat_capacity_j_k: float
    coolant_heat_capacity_j_k: float
    fuel_to_coolant_conductance_w_k: float
    coolant_removal_conductance_w_k: float
    inlet_temperature_k: float

    def __post_init__(self) -> None:
        for name in ("fuel_heat_capacity_j_k", "coolant_heat_capacity_j_k",
                     "fuel_to_coolant_conductance_w_k",
                     "coolant_removal_conductance_w_k"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise TransientError(f"{name} must be finite and positive, got {value!r}")
        if not math.isfinite(self.inlet_temperature_k) or self.inlet_temperature_k <= 0.0:
            raise TransientError("inlet temperature must be finite and positive")

    def equilibrium_temperatures(self, power_w: float) -> tuple[float, float]:
        """Fuel and coolant temperatures at steady power.

        Series resistances: the whole power flows through the fuel-to-coolant
        conductance and then through the coolant removal conductance.
        """
        if power_w < 0.0:
            raise TransientError("steady power cannot be negative")
        coolant = self.inlet_temperature_k + power_w / self.coolant_removal_conductance_w_k
        fuel = coolant + power_w / self.fuel_to_coolant_conductance_w_k
        return fuel, coolant


@dataclass(frozen=True)
class KineticsParameters:
    """Point-kinetics and feedback constants for a transient."""

    reference_power_w: float
    prompt_lifetime_s: float
    fuel_temperature_coefficient_per_k: float
    coolant_temperature_coefficient_per_k: float
    groups: kin.DelayedGroups = field(default_factory=_load_u235_groups)

    def __post_init__(self) -> None:
        if not math.isfinite(self.reference_power_w) or self.reference_power_w <= 0.0:
            raise TransientError("reference power must be finite and positive")
        if not math.isfinite(self.prompt_lifetime_s) or self.prompt_lifetime_s <= 0.0:
            raise TransientError("prompt lifetime must be finite and positive")
        for name in ("fuel_temperature_coefficient_per_k",
                     "coolant_temperature_coefficient_per_k"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise TransientError(f"{name} must be finite")
        if self.prompt_lifetime_s > 1.0e-2:
            raise TransientError(
                "prompt lifetime above 10 ms is not physical for a fast core"
            )


@dataclass(frozen=True)
class TransientStep:
    """One recorded instant of the transient."""

    time_s: float
    neutron_population: float
    power_w: float
    reactivity: float
    fuel_temperature_k: float
    coolant_temperature_k: float

    @property
    def reactivity_dollars(self) -> float:
        return self.reactivity / 0.0065


@dataclass(frozen=True)
class TransientResult:
    """Outcome of a transient simulation."""

    steps: tuple[TransientStep, ...]
    converged_to_steady: bool
    reason: str
    peak_power_w: float
    peak_fuel_temperature_k: float
    final_power_w: float
    final_reactivity: float
    energy_balance_residual_j: float

    @property
    def peak_to_initial_ratio(self) -> float:
        return self.peak_power_w / self.steps[0].power_w

    @property
    def final_power_ratio(self) -> float:
        return self.final_power_w / self.steps[0].power_w


def steady_power_for_reactivity(
    parameters: KineticsParameters, thermal: ThermalModel, reactivity: float
) -> float:
    """Closed-form steady power that exactly cancels an inserted reactivity.

    The transient starts critical at ``reference_power_w``, so feedback is
    measured from *that* temperature, not from cold conditions. At equilibrium

        rho + alpha_f (T_f - T_f0) + alpha_c (T_c - T_c0) = 0

    with temperatures linear in the power *change* from the reference state:

        P = P_ref - rho / (alpha_f (1/k_c + 1/h) + alpha_c / k_c)

    Omitting the ``P_ref`` term is what made an earlier version of this function
    predict 0.1 MW for a core actually running at 10 MW.
    """
    fuel_gain = (1.0 / thermal.coolant_removal_conductance_w_k
                 + 1.0 / thermal.fuel_to_coolant_conductance_w_k)
    coolant_gain = 1.0 / thermal.coolant_removal_conductance_w_k
    slope = (parameters.fuel_temperature_coefficient_per_k * fuel_gain
             + parameters.coolant_temperature_coefficient_per_k * coolant_gain)
    if abs(slope) < 1e-30:
        raise TransientError(
            "no temperature feedback: the steady power is undetermined for a "
            "non-zero insertion"
        )
    power = parameters.reference_power_w - reactivity / slope
    if power < 0.0:
        raise TransientError(
            f"a steady state at reactivity {reactivity:+.3e} would require negative "
            f"power ({power:.3e} W): the inserted reactivity exceeds what the "
            f"negative feedback can absorb"
        )
    return power


def _prompt_jump_population(precursors, groups: kin.DelayedGroups,
                            reactivity: float, lifetime: float) -> float:
    """Quasi-static population: n = L * sum(lambda_i C_i) / (beta - rho).

    Setting dn/dt = 0 in Eq. (11.3) gives

        (rho - beta)/L * n + sum(lambda_i C_i) = 0

    so the population carries a factor of the prompt lifetime. Omitting ``L``
    scales the answer by 1/L - a factor of 10^4 for a 100 us core - which is
    exactly the error this function had before the transient tests caught it.
    """
    if not math.isfinite(lifetime) or lifetime <= 0.0:
        raise TransientError("prompt lifetime must be finite and positive")
    if reactivity >= groups.beta_total:
        raise TransientError(
            f"reactivity {reactivity:.4e} is at or above beta "
            f"({groups.beta_total}); the core is prompt critical and the "
            f"quasi-static approximation this module relies on is invalid"
        )
    source = math.fsum(lam * c for lam, c in zip(groups.lam, precursors))
    return lifetime * source / (groups.beta_total - reactivity)


def simulate_reactivity_insertion(
    parameters: KineticsParameters,
    thermal: ThermalModel,
    *,
    initial_reactivity: float = 0.0,
    insertion_reactivity: float | None = None,
    duration_s: float = 5.0,
    dt_s: float = 1.0e-3,
    sample_every: int = 10,
    record_limit: int = 4000,
) -> TransientResult:
    """Simulate a step reactivity insertion with feedback, from steady state.

    The core starts critical at ``reference_power_w``. At t=0 the external
    reactivity changes to ``insertion_reactivity`` (a step). Precursors are
    integrated with RK4 while the prompt population follows algebraically and
    the two thermal nodes respond to the resulting power.
    """
    if not math.isfinite(duration_s) or duration_s <= 0.0:
        raise TransientError("duration must be finite and positive")
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise TransientError("timestep must be finite and positive")
    if sample_every < 1:
        raise TransientError("sample_every must be at least 1")

    rho_ext = initial_reactivity if insertion_reactivity is None else insertion_reactivity
    groups = parameters.groups
    lifetime = parameters.prompt_lifetime_s

    # Initial state: critical at the reference power.
    n = 1.0
    precursors = [b / (lifetime * lam) * n for b, lam in zip(groups.beta, groups.lam)]
    fuel_t, coolant_t = thermal.equilibrium_temperatures(parameters.reference_power_w)
    fuel0, coolant0 = fuel_t, coolant_t

    def reactivity_of(fuel: float, coolant: float) -> float:
        return kin.reactivity_with_feedback(
            rho_ext,
            (parameters.fuel_temperature_coefficient_per_k,
             parameters.coolant_temperature_coefficient_per_k),
            (fuel, coolant),
            (fuel0, coolant0),
        )

    def derivatives(prec, fuel, coolant):
        rho = reactivity_of(fuel, coolant)
        population = _prompt_jump_population(prec, groups, rho, lifetime)
        power = population * parameters.reference_power_w
        dprec = [b / lifetime * population - lam * c
                 for b, lam, c in zip(groups.beta, groups.lam, prec)]
        transfer = thermal.fuel_to_coolant_conductance_w_k * (fuel - coolant)
        dfuel = (power - transfer) / thermal.fuel_heat_capacity_j_k
        dcool = (transfer
                 - thermal.coolant_removal_conductance_w_k
                 * (coolant - thermal.inlet_temperature_k)
                 ) / thermal.coolant_heat_capacity_j_k
        return dprec, dfuel, dcool, rho

    steps: list[TransientStep] = []
    energy_in = 0.0
    energy_removed = 0.0
    increments = int(round(duration_s / dt_s))
    peak_power = 0.0
    peak_fuel = fuel_t

    for index in range(increments + 1):
        dprec, dfuel, dcool, rho = derivatives(precursors, fuel_t, coolant_t)
        population = _prompt_jump_population(precursors, groups, rho, lifetime)
        power = population * parameters.reference_power_w
        peak_power = max(peak_power, power)
        peak_fuel = max(peak_fuel, fuel_t)
        if index % sample_every == 0 and len(steps) < record_limit:
            steps.append(TransientStep(
                time_s=index * dt_s, neutron_population=population, power_w=power,
                reactivity=rho, fuel_temperature_k=fuel_t,
                coolant_temperature_k=coolant_t,
            ))
        if index == increments:
            break
        coolant_t_old = coolant_t
        # RK4 over precursors and the two thermal nodes.
        p1, f1, c1, _ = dprec, dfuel, dcool, rho
        p2, f2, c2, _ = derivatives(
            [c + 0.5 * dt_s * d for c, d in zip(precursors, p1)],
            fuel_t + 0.5 * dt_s * f1, coolant_t + 0.5 * dt_s * c1)
        p3, f3, c3, _ = derivatives(
            [c + 0.5 * dt_s * d for c, d in zip(precursors, p2)],
            fuel_t + 0.5 * dt_s * f2, coolant_t + 0.5 * dt_s * c2)
        p4, f4, c4, _ = derivatives(
            [c + dt_s * d for c, d in zip(precursors, p3)],
            fuel_t + dt_s * f3, coolant_t + dt_s * c3)
        precursors = [c + dt_s / 6.0 * (a + 2 * b + 2 * d + e)
                      for c, a, b, d, e in zip(precursors, p1, p2, p3, p4)]
        fuel_t += dt_s / 6.0 * (f1 + 2 * f2 + 2 * f3 + f4)
        coolant_t += dt_s / 6.0 * (c1 + 2 * c2 + 2 * c3 + c4)
        # Trapezoidal accumulation of both energy terms, using the post-update
        # state. The identity C_f dT_f + C_c dT_c = P dt - k_c (T_c - T_in) dt
        # holds exactly for the continuous system, so matching quadrature on
        # both sides is what makes the residual a measure of integration error
        # rather than of a left-versus-right endpoint mismatch.
        _, _, _, rho_new = derivatives(precursors, fuel_t, coolant_t)
        power_new = (_prompt_jump_population(precursors, groups, rho_new, lifetime)
                     * parameters.reference_power_w)
        removal_old = (thermal.coolant_removal_conductance_w_k
                       * (coolant_t_old - thermal.inlet_temperature_k))
        removal_new = (thermal.coolant_removal_conductance_w_k
                       * (coolant_t - thermal.inlet_temperature_k))
        energy_in += 0.5 * (power + power_new) * dt_s
        energy_removed += 0.5 * (removal_old + removal_new) * dt_s
        if precursors and min(precursors) < 0.0:
            raise TransientError(
                f"precursor concentration went negative at t={index * dt_s:.3f} s; "
                f"the timestep is too large for this transient"
            )

    final = steps[-1]
    stored = (thermal.fuel_heat_capacity_j_k * (fuel_t - fuel0)
              + thermal.coolant_heat_capacity_j_k * (coolant_t - coolant0))
    residual = energy_in - stored - energy_removed

    fuel_eq, _ = thermal.equilibrium_temperatures(final.power_w)
    # "Settled" is judged relative to the size of the insertion, not against an
    # arbitrary absolute reactivity: 0.17 pcm of residual is fully settled for a
    # 50 pcm insertion, and an absolute threshold would call it unconverged.
    insertion_scale = max(abs(rho_ext), 1.0e-6)
    reactivity_settled = abs(final.reactivity) < 1.0e-2 * insertion_scale
    temperature_settled = abs(final.fuel_temperature_k - fuel_eq) / fuel_eq < 1e-2
    steady = reactivity_settled and temperature_settled
    reason = ("reached a steady state where feedback nulls the insertion"
              if steady else
              f"transient had not settled: residual reactivity "
              f"{final.reactivity:+.2e} against insertion {rho_ext:+.2e}")

    return TransientResult(
        steps=tuple(steps),
        converged_to_steady=steady,
        reason=reason,
        peak_power_w=peak_power,
        peak_fuel_temperature_k=peak_fuel,
        final_power_w=final.power_w,
        final_reactivity=final.reactivity,
        energy_balance_residual_j=residual,
    )
