"""Nozzle closure: match the nozzle to the coupled core's actual mass flow.

Acceptance gate 5 requires that "the nozzle throat is closed against the core
state". The delivered model left that open: the nozzle was solved from an
arbitrary throat area, and the core/nozzle mass demand was never reconciled.

This inverts that relationship. Given the chamber state the coupled core
actually produced (temperature, pressure) and the mass flow the cycle actually
delivers, it solves for the throat area that passes exactly that flow, and
reports thrust, Isp and the residual.

The underlying expansion physics is ``nasa_hydrogen.hydrogen_nozzle``, which is
already in the repository and already covered by its own regressions: an
isentropic reacting/frozen perfect-gas expansion with a maximum-mass-flux sonic
throat. Nothing here re-derives it.

What this is NOT: no axial chemistry rate equation, no shock or viscous losses,
no two-phase flow, no wall heat transfer. ``nozzle_efficiency`` is a single
scalar kinetic-energy loss factor.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .nasa_hydrogen import HydrogenNozzle, hydrogen_nozzle

G0 = 9.80665


class NozzleClosureError(ValueError):
    """Raised when the nozzle cannot be matched to the core state."""


@dataclass(frozen=True)
class NozzleClosureInputs:
    """Chamber state from the coupled core, plus nozzle geometry choices."""

    chamber_temperature_k: float
    chamber_pressure_pa: float
    mass_flow_kg_s: float
    expansion_ratio: float = 100.0
    chemistry_mode: str = "equilibrium"
    nozzle_efficiency: float = 1.0
    ambient_pressure_pa: float = 0.0

    def __post_init__(self) -> None:
        for name in ("chamber_temperature_k", "chamber_pressure_pa",
                     "mass_flow_kg_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise NozzleClosureError(f"{name} must be finite and positive, got {value!r}")
        if not math.isfinite(self.expansion_ratio) or self.expansion_ratio <= 1.0:
            raise NozzleClosureError("expansion ratio must exceed one")
        if self.chemistry_mode not in ("equilibrium", "frozen"):
            raise NozzleClosureError(
                f"chemistry mode must be 'equilibrium' or 'frozen', "
                f"got {self.chemistry_mode!r}"
            )
        if not 0.0 < self.nozzle_efficiency <= 1.0:
            raise NozzleClosureError("nozzle efficiency must lie in (0, 1]")
        if not math.isfinite(self.ambient_pressure_pa) or self.ambient_pressure_pa < 0.0:
            raise NozzleClosureError("ambient pressure cannot be negative")


@dataclass(frozen=True)
class NozzleClosureResult:
    """A nozzle matched to the core: geometry, performance and residual."""

    throat_area_m2: float
    exit_area_m2: float
    mass_flow_kg_s: float
    mass_flow_residual_kg_s: float
    throat_pressure_pa: float
    throat_temperature_k: float
    throat_mass_flux_kg_m2_s: float
    exit_pressure_pa: float
    exit_temperature_k: float
    exit_velocity_m_s: float
    thrust_vacuum_n: float
    thrust_delivered_n: float
    isp_vacuum_s: float
    isp_delivered_s: float
    dissociation_fraction: float
    converged: bool
    iterations: int
    nozzle: HydrogenNozzle

    @property
    def relative_mass_flow_residual(self) -> float:
        return abs(self.mass_flow_residual_kg_s) / self.mass_flow_kg_s


def _evaluate(inputs: NozzleClosureInputs, throat_area_m2: float) -> HydrogenNozzle:
    """Evaluate the nozzle, reporting library failures as closure failures.

    ``hydrogen_nozzle`` raises ``ValueError`` for genuinely impossible states
    (for example a grossly over-expanded nozzle at sea level). Those are
    properties of the *inputs*, not of the throat area being tried, so they are
    converted here and propagate out of the solve with actionable context.
    """
    try:
        return hydrogen_nozzle(
            inputs.chamber_pressure_pa,
            inputs.chamber_temperature_k,
            throat_area_m2,
            inputs.expansion_ratio,
            mode=inputs.chemistry_mode,
            nozzle_efficiency=inputs.nozzle_efficiency,
            ambient_pressure_pa=inputs.ambient_pressure_pa,
        )
    except ValueError as exc:
        raise NozzleClosureError(
            f"nozzle evaluation failed for chamber {inputs.chamber_temperature_k:.0f} K, "
            f"{inputs.chamber_pressure_pa/1e6:.2f} MPa, area ratio "
            f"{inputs.expansion_ratio:.1f}, ambient {inputs.ambient_pressure_pa:.0f} Pa: "
            f"{exc}"
        ) from exc


def solve_nozzle_closure(
    inputs: NozzleClosureInputs,
    *,
    relative_tolerance: float = 1.0e-10,
    max_iterations: int = 200,
    initial_throat_area_m2: float | None = None,
) -> NozzleClosureResult:
    """Solve the throat area that passes exactly the delivered mass flow.

    Nozzle mass flow rises monotonically with throat area, so the residual is
    monotone in ``A_t`` and bisection in ``log A_t`` is safe and unique. Working
    in the log domain keeps the large geometric range of a 100:1 nozzle well
    conditioned.
    """
    if not math.isfinite(relative_tolerance) or relative_tolerance <= 0.0:
        raise NozzleClosureError("relative tolerance must be positive")

    target = inputs.mass_flow_kg_s
    # A first guess from choked-flow scaling lets the bracket start close.
    guess = initial_throat_area_m2 or (target / 2500.0)
    if not math.isfinite(guess) or guess <= 0.0:
        raise NozzleClosureError("initial throat area must be positive")

    def residual(area: float) -> float:
        return _evaluate(inputs, area).mass_flow_kg_s - target

    lo = hi = guess
    # Expand geometrically until the residual brackets zero.
    for _ in range(80):
        if residual(lo) <= 0.0:
            break
        lo *= 0.5
    else:
        raise NozzleClosureError(
            "could not bracket the throat area from below; the nozzle cannot "
            "pass the required mass flow at any physically small throat"
        )
    for _ in range(80):
        if residual(hi) >= 0.0:
            break
        hi *= 2.0
    else:
        raise NozzleClosureError(
            "could not bracket the throat area from above; the chamber state "
            "cannot support the required mass flow"
        )

    log_lo, log_hi = math.log(lo), math.log(hi)
    area = guess
    nozzle = _evaluate(inputs, area)
    converged = False
    iterations = 0
    for iterations in range(1, max_iterations + 1):
        log_mid = 0.5 * (log_lo + log_hi)
        area = math.exp(log_mid)
        nozzle = _evaluate(inputs, area)
        error = (nozzle.mass_flow_kg_s - target) / target
        if abs(error) <= relative_tolerance:
            converged = True
            break
        if error < 0.0:
            log_lo = log_mid
        else:
            log_hi = log_mid

    vacuum_thrust = nozzle.thrust_n
    if inputs.ambient_pressure_pa > 0.0:
        delivered_thrust = vacuum_thrust - inputs.ambient_pressure_pa * nozzle.exit_area_m2
    else:
        delivered_thrust = vacuum_thrust
    if delivered_thrust <= 0.0:
        raise NozzleClosureError(
            f"the nozzle is grossly over-expanded for an ambient pressure of "
            f"{inputs.ambient_pressure_pa:.0f} Pa: the ambient pressure force on "
            f"the {nozzle.exit_area_m2:.3f} m2 exit ({inputs.ambient_pressure_pa * nozzle.exit_area_m2/1e3:.1f} kN) "
            f"exceeds the vacuum thrust ({vacuum_thrust/1e3:.1f} kN), giving "
            f"{delivered_thrust/1e3:.1f} kN net. Reduce the expansion ratio or "
            f"specify a vacuum ambient."
        )

    mass_flow = nozzle.mass_flow_kg_s
    return NozzleClosureResult(
        throat_area_m2=nozzle.throat_area_m2,
        exit_area_m2=nozzle.exit_area_m2,
        mass_flow_kg_s=mass_flow,
        mass_flow_residual_kg_s=mass_flow - target,
        throat_pressure_pa=nozzle.throat.pressure_pa,
        throat_temperature_k=nozzle.throat.temperature_k,
        throat_mass_flux_kg_m2_s=nozzle.mass_flux_kg_m2_s,
        exit_pressure_pa=nozzle.exit.pressure_pa,
        exit_temperature_k=nozzle.exit.temperature_k,
        exit_velocity_m_s=nozzle.exit_velocity_m_s,
        thrust_vacuum_n=vacuum_thrust,
        thrust_delivered_n=delivered_thrust,
        isp_vacuum_s=vacuum_thrust / (target * G0),
        isp_delivered_s=delivered_thrust / (target * G0),
        dissociation_fraction=nozzle.chamber.dissociation_fraction,
        converged=converged,
        iterations=iterations,
        nozzle=nozzle,
    )


def closure_from_coupled_solution(solution, *, expansion_ratio: float = 100.0,
                                  chemistry_mode: str = "equilibrium",
                                  nozzle_efficiency: float = 1.0,
                                  ambient_pressure_pa: float = 0.0,
                                  chamber_pressure_pa: float | None = None,
                                  mass_flow_kg_s: float | None = None
                                  ) -> NozzleClosureResult:
    """Close the nozzle against a ``CoupledSolution``.

    The chamber temperature comes from the coupled solve. Chamber pressure and
    mass flow are *not* predicted by the neutronics-plus-thermal closure, so
    they must be supplied; passing them explicitly keeps the distinction
    between what the core model determines and what the cycle determines.
    Raising when they are absent is deliberate.
    """
    if chamber_pressure_pa is None:
        raise NozzleClosureError(
            "chamber pressure is not a coupled-core output; supply it from the "
            "engine cycle (see cycle_closure / turbine_bleed_cycle)"
        )
    if mass_flow_kg_s is None:
        raise NozzleClosureError(
            "mass flow is not a coupled-core output; supply the cycle value or "
            "the solved pump delivery from cycle_closure.PumpBoundary"
        )
    return solve_nozzle_closure(NozzleClosureInputs(
        chamber_temperature_k=solution.fuel_temperature_k
        if hasattr(solution, "fuel_temperature_k") else solution,
        chamber_pressure_pa=chamber_pressure_pa,
        mass_flow_kg_s=mass_flow_kg_s,
        expansion_ratio=expansion_ratio,
        chemistry_mode=chemistry_mode,
        nozzle_efficiency=nozzle_efficiency,
        ambient_pressure_pa=ambient_pressure_pa,
    ))
