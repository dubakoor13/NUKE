"""Verify the deterministic diffusion backend.

The decisive checks:

* it agrees with the closed-form criticality equation of Ch. 8 for one group;
* its power fractions integrate to one and follow the chopped-sine shape;
* it is a genuine physics backend, not a surrogate - ``synthetic`` is False and
  it carries no Monte Carlo statistical error;
* the coupled core and the reactivity-coefficient machinery run on it unchanged,
  which is the whole point of the seam.
"""
from __future__ import annotations

import math

from .coupled_core import (
    ChannelThermalClosure,
    CouplingParameters,
    ThermalParameters,
    solve_coupled_core,
)
from .diffusion import DiffusionError
from .diffusion_backend import (
    DiffusionBackendError,
    DiffusionTransportBackend,
    one_group_temperature_cross_sections,
)
from .reactivity_coefficients import fuel_temperature_coefficient
from .transport_backend import CoreState

# A core sized so the one-group result is close to critical.
D0 = 1.30
SA0 = 0.0090
NUSF0 = 0.0165
LENGTH = 132.0
RADIUS = 40.0

XS = one_group_temperature_cross_sections(
    d0_cm=D0, d_slope_per_k=1.0e-5,
    sa0_cm=SA0, sa_slope_per_k=2.0e-6,
    nusf0_cm=NUSF0, nusf_slope_per_k=-1.6e-6,
)

BACKEND = DiffusionTransportBackend(
    cross_sections=XS, core_length_cm=LENGTH, radius_cm=RADIUS,
    element_count=7, extrapolation_cm=2.0, mesh_intervals=120)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- contract ------------------------------------------------------
    print("backend contract:")
    results.append(_report("declares itself non-synthetic physics",
                           BACKEND.synthetic is False, "synthetic=False"))
    results.append(_report("preflight is trivially clean",
                           BACKEND.preflight() == [], "no environment needed"))

    state = CoreState(fuel_temperature_k=293.6, hydrogen_temperature_k=600.0)
    result = BACKEND.run(state)
    print(f"    k_eff = {result.k_eff:.6f}   leakage = {result.leakage_fraction:.4f}")
    results.append(_report("a transport result is produced",
                           math.isfinite(result.k_eff), f"{result.k_eff:.6f}"))
    results.append(_report("k_eff is finite and positive", result.k_eff > 0.0,
                           f"{result.k_eff:.6f}"))
    results.append(_report("k_sigma is zero because the solve is deterministic",
                           result.k_sigma == 0.0, "not a sampling error"))
    results.append(_report("provenance records the approximation",
                           "NOT a 3-D solution" in str(result.provenance),
                           "labelled as reduced"))

    # ---- power fractions ----------------------------------------------
    print("\naxial power distribution:")
    fractions = result.fuel_power_fraction
    print("    fractions " + " ".join(f"{value:.4f}" for value in fractions))
    results.append(_report("fractions sum to one",
                           abs(math.fsum(fractions) - 1.0) < 1e-12,
                           f"{math.fsum(fractions):.15f}"))
    results.append(_report("every fraction is positive",
                           all(value > 0.0 for value in fractions), "all positive"))
    centre = len(fractions) // 2
    results.append(_report("the peak is at the axial centre",
                           fractions[centre] == max(fractions),
                           f"index {centre}"))
    results.append(_report("the ends are the coldest zones",
                           fractions[0] == min(fractions)
                           and fractions[-1] == min(fractions),
                           "chopped-sine profile"))

    # ---- against the closed form --------------------------------------
    print("\nagreement with the Ch. 8 criticality equation:")
    # Recompute the same physics independently: k_inf with leakage added as an
    # effective absorption, using the radial buckling from Table 8.2.
    from .diffusion import geometric_buckling

    axial_b2 = geometric_buckling("slab", {"L": LENGTH}, 2.0)
    total_b2 = geometric_buckling("cylinder", {"R": RADIUS, "H": LENGTH}, 2.0)
    radial_b2 = total_b2 - axial_b2
    effective_sa = SA0 + D0 * radial_b2
    closed_form = NUSF0 / (D0 * axial_b2 + effective_sa)
    relative = abs(result.k_eff - closed_form) / closed_form
    print(f"    backend     k = {result.k_eff:.9f}")
    print(f"    closed form k = {closed_form:.9f}   (rel {relative:.2e})")
    results.append(_report("the discrete solve matches Eq. 8.21",
                           relative < 1e-3, f"rel {relative:.2e}"))
    results.append(_report("leakage fraction equals 1 - k/k_inf",
                           abs(result.leakage_fraction
                               - (1.0 - result.k_eff / (NUSF0 / SA0))) < 1e-9,
                           f"{result.leakage_fraction:.6f}"))

    # ---- temperature response -----------------------------------------
    print("\ntemperature response:")
    hot = BACKEND.run(CoreState(fuel_temperature_k=1200.0,
                                hydrogen_temperature_k=900.0))
    print(f"    k(293.6 K) = {result.k_eff:.6f}   k(1200 K) = {hot.k_eff:.6f}")
    results.append(_report("k falls as the fuel heats",
                           hot.k_eff < result.k_eff,
                           f"{result.k_eff:.6f} -> {hot.k_eff:.6f}"))
    coefficient = fuel_temperature_coefficient(
        BACKEND, CoreState(fuel_temperature_k=600.0,
                           hydrogen_temperature_k=600.0), perturbation_k=50.0)
    print(f"    Doppler coefficient = {coefficient.pcm_per_unit:+.4f} pcm/K")
    results.append(_report("a Doppler coefficient can be measured on it",
                           math.isfinite(coefficient.value_per_unit),
                           "coefficient machinery works unchanged"))
    results.append(_report("the coefficient is negative",
                           coefficient.value_per_unit < 0.0,
                           f"{coefficient.pcm_per_unit:+.4f} pcm/K"))

    # ---- the coupled core runs on it -----------------------------------
    print("\nthe coupled core runs on deterministic diffusion:")
    thermal = ChannelThermalClosure(ThermalParameters(
        coolant_inlet_temperature_k=600.0, coolant_density_kg_m3=2.0,
        total_mass_flow_kg_s=0.7, cp_j_kg_k=14300.0,
        channel_flow_area_m2=9.8e-5, channel_heated_perimeter_m=0.1531,
        channel_length_m=1.32, coolant_conductivity_w_m_k=0.18,
        coolant_viscosity_pa_s=1.2e-5, coolant_prandtl=0.95,
        fuel_conductivity_w_m_k=20.0, ligament_thickness_m=0.002,
    ))
    coupled = solve_coupled_core(
        BACKEND, CoreState(fuel_temperature_k=800.0, hydrogen_temperature_k=700.0),
        thermal,
        CouplingParameters(target_power_w=1.0e7, temperature_tolerance_k=1.0,
                           k_tolerance=1e-7, max_iterations=60))
    print(f"    converged={coupled.converged}  k={coupled.k_eff:.6f}  "
          f"T_fuel={coupled.fuel_temperature_k:.1f} K  "
          f"({coupled.iterations} iterations)")
    results.append(_report("the coupled loop converges on real physics",
                           coupled.converged is True, coupled.reason[:52]))
    results.append(_report("the coupled solve reports itself non-synthetic",
                           coupled.synthetic is False, "synthetic=False"))
    results.append(_report("emergent temperature coefficient is negative",
                           coupled.temperature_coefficient_per_k is not None
                           and coupled.temperature_coefficient_per_k < 0.0,
                           f"{coupled.temperature_coefficient_per_k:.3e} /K"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid inputs are rejected:")
    guards = [
        ("zero core length", lambda: DiffusionTransportBackend(
            cross_sections=XS, core_length_cm=0.0, radius_cm=RADIUS)),
        ("zero radius", lambda: DiffusionTransportBackend(
            cross_sections=XS, core_length_cm=LENGTH, radius_cm=0.0)),
        ("too few mesh intervals", lambda: DiffusionTransportBackend(
            cross_sections=XS, core_length_cm=LENGTH, radius_cm=RADIUS,
            mesh_intervals=2)),
        ("zero reference diffusion", lambda: one_group_temperature_cross_sections(
            d0_cm=0.0, d_slope_per_k=0.0, sa0_cm=SA0, sa_slope_per_k=0.0,
            nusf0_cm=NUSF0, nusf_slope_per_k=0.0)),
        ("non-finite slope", lambda: one_group_temperature_cross_sections(
            d0_cm=D0, d_slope_per_k=float("nan"), sa0_cm=SA0,
            sa_slope_per_k=0.0, nusf0_cm=NUSF0, nusf_slope_per_k=0.0)),
        ("zero fuel temperature", lambda: BACKEND.run(
            CoreState(fuel_temperature_k=0.0, hydrogen_temperature_k=600.0))),
    ]
    for label, fn in guards:
        try:
            fn()
        except (DiffusionBackendError, DiffusionError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: deterministic diffusion backend drives the coupled core")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
