"""Verify the coupled kinetics-plus-feedback transient.

Two oracles make this a real verification rather than a plausibility check:

1. **Prompt jump.** Immediately after a step insertion the population must jump
   by exactly ``1/(1 - rho/beta)``, an algebraic consequence of the point
   kinetics equations.
2. **Steady power.** With linear feedback the settled power has a closed form,
   ``-rho / (alpha_f (1/k_c + 1/h) + alpha_c / k_c)``. The simulation must
   land on it.

Thermal and kinetic constants below are synthetic but physically scaled test
inputs, not heritage values.
"""
from __future__ import annotations

import math

from .kinetics_transient import (
    KineticsParameters,
    ThermalModel,
    TransientError,
    simulate_reactivity_insertion,
    steady_power_for_reactivity,
)

BETA = 0.0065

THERMAL = ThermalModel(
    fuel_heat_capacity_j_k=2.0e5,          # J/K, a few hundred kg of graphite
    coolant_heat_capacity_j_k=5.0e4,
    fuel_to_coolant_conductance_w_k=2.0e4,
    coolant_removal_conductance_w_k=8.0e3,
    inlet_temperature_k=600.0,
)

PARAMS = KineticsParameters(
    reference_power_w=1.0e7,
    prompt_lifetime_s=1.0e-4,
    fuel_temperature_coefficient_per_k=-1.0e-5,
    coolant_temperature_coefficient_per_k=-2.0e-6,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- steady state at zero reactivity -------------------------------
    print("critical steady state is preserved:")
    steady = simulate_reactivity_insertion(PARAMS, THERMAL, initial_reactivity=0.0,
                                           duration_s=1.0, dt_s=1e-3)
    first, last = steady.steps[0], steady.steps[-1]
    print(f"    P: {first.power_w:.6f} -> {last.power_w:.6f} W over "
          f"{last.time_s:.1f} s")
    results.append(_report("power stays at the reference value",
                           abs(last.power_w - PARAMS.reference_power_w)
                           / PARAMS.reference_power_w < 1e-9,
                           f"{last.power_w:.3f} W"))
    results.append(_report("reactivity stays zero",
                           abs(last.reactivity) < 1e-15, f"{last.reactivity:.2e}"))
    results.append(_report("fuel temperature holds steady",
                           abs(last.fuel_temperature_k - first.fuel_temperature_k)
                           < 1e-6,
                           f"{last.fuel_temperature_k:.6f} K"))

    # ---- prompt jump (exact algebra) -----------------------------------
    print("\nprompt jump matches the analytic factor:")
    for rho in (5.0e-4, 1.0e-3, 2.0e-3):
        run = simulate_reactivity_insertion(
            PARAMS, THERMAL, initial_reactivity=0.0, insertion_reactivity=rho,
            duration_s=1.0e-3, dt_s=1.0e-6, sample_every=1)
        early = run.steps[0]
        predicted = 1.0 / (1.0 - rho / BETA)
        relative = abs(early.neutron_population - predicted) / predicted
        results.append(_report(f"rho={rho:.1e} jump = 1/(1-rho/beta)",
                               relative < 2e-3,
                               f"{early.neutron_population:.5f} vs "
                               f"{predicted:.5f} (rel {relative*100:.2f}%)"))

    # ---- settling onto the analytic steady power ----------------------
    print("\ntransient settles on the analytic steady power:")
    for rho in (2.0e-4, 5.0e-4):
        predicted_power = steady_power_for_reactivity(PARAMS, THERMAL, rho)
        run = simulate_reactivity_insertion(
            PARAMS, THERMAL, initial_reactivity=0.0, insertion_reactivity=rho,
            duration_s=60.0, dt_s=5e-3, sample_every=100)
        final = run.steps[-1]
        relative = abs(final.power_w - predicted_power) / predicted_power
        print(f"    rho={rho:.1e}: predicted {predicted_power/1e6:.4f} MW  "
              f"simulated {final.power_w/1e6:.4f} MW  "
              f"(x{run.final_power_ratio:.3f})")
        results.append(_report(f"rho={rho:.1e} final power matches closed form",
                               relative < 5e-3,
                               f"rel {relative*100:.3f}%"))
        results.append(_report(f"rho={rho:.1e} feedback nulls the insertion",
                               abs(final.reactivity) < 1e-5,
                               f"rho_final={final.reactivity:.2e}"))
        results.append(_report(f"rho={rho:.1e} reported as settled",
                               run.converged_to_steady, run.reason[:48]))

    # ---- energy conservation ------------------------------------------
    print("\nenergy is conserved through the transient:")
    run = simulate_reactivity_insertion(PARAMS, THERMAL, initial_reactivity=0.0,
                                        insertion_reactivity=5.0e-4,
                                        duration_s=20.0, dt_s=5e-3,
                                        sample_every=100)
    scale = PARAMS.reference_power_w * 20.0
    relative = abs(run.energy_balance_residual_j) / scale
    results.append(_report("deposited = stored + removed",
                           relative < 1e-6,
                           f"residual {run.energy_balance_residual_j:.3e} J "
                           f"({relative:.1e} of {scale:.3e} J)"))

    # ---- peak behaviour and shutdown -----------------------------------
    print("\npeak response and shutdown:")
    print(f"    peak power ratio x{run.peak_to_initial_ratio:.3f}, "
          f"peak fuel {run.peak_fuel_temperature_k:.1f} K")
    results.append(_report("an insertion raises power above the reference",
                           run.peak_power_w > PARAMS.reference_power_w,
                           f"x{run.peak_to_initial_ratio:.3f}"))
    results.append(_report("fuel temperature rises with power",
                           run.peak_fuel_temperature_k
                           > THERMAL.equilibrium_temperatures(
                               PARAMS.reference_power_w)[0],
                           f"{run.peak_fuel_temperature_k:.1f} K"))

    scram = simulate_reactivity_insertion(PARAMS, THERMAL, initial_reactivity=0.0,
                                          insertion_reactivity=-2.0e-3,
                                          duration_s=30.0, dt_s=5e-3,
                                          sample_every=100)
    immediate = scram.steps[0]
    print(f"    scram: immediate x{immediate.power_w/PARAMS.reference_power_w:.4f}, "
          f"final x{scram.final_power_ratio:.4f}, "
          f"rho {immediate.reactivity:+.3e} -> {scram.final_reactivity:+.3e}")
    results.append(_report("prompt drop on insertion",
                           immediate.power_w < PARAMS.reference_power_w,
                           f"x{immediate.power_w/PARAMS.reference_power_w:.4f}"))
    results.append(_report("reactivity is strongly negative at insertion",
                           immediate.reactivity < 0.0,
                           f"rho={immediate.reactivity:.3e}"))
    # Cooling below the reference state returns reactivity, because the
    # feedback is measured from the reference operating point. This is a real
    # property of the model and is asserted rather than hidden: a shallow scram
    # can therefore partially recover.
    results.append(_report("cooling below reference returns reactivity",
                           scram.final_reactivity > immediate.reactivity,
                           f"{immediate.reactivity:+.3e} -> "
                           f"{scram.final_reactivity:+.3e}"))

    # ---- timestep independence ----------------------------------------
    print("\nresult is timestep-independent:")
    coarse = simulate_reactivity_insertion(PARAMS, THERMAL, insertion_reactivity=5e-4,
                                           duration_s=40.0, dt_s=1e-2,
                                           sample_every=1000)
    fine = simulate_reactivity_insertion(PARAMS, THERMAL, insertion_reactivity=5e-4,
                                         duration_s=40.0, dt_s=2.5e-3,
                                         sample_every=4000)
    relative = abs(coarse.final_power_w - fine.final_power_w) / fine.final_power_w
    results.append(_report("dt=10 ms and dt=2.5 ms agree",
                           relative < 1e-3,
                           f"rel {relative*100:.4f}% after 40 s"))

    # ---- guards --------------------------------------------------------
    print("\nmodel validity limits are enforced:")
    guards = [
        ("prompt-critical insertion refused",
         lambda: simulate_reactivity_insertion(
             PARAMS, THERMAL, insertion_reactivity=BETA,
             duration_s=0.1, dt_s=1e-4)),
        # A shallow negative insertion still has a positive steady power (the
        # core just runs cooler), so the closed form legitimately succeeds.
        # Only a deep scram drives the equilibrium power negative.
        ("deep scram has no positive steady power",
         lambda: steady_power_for_reactivity(PARAMS, THERMAL, -0.05)),
        ("zero timestep refused",
         lambda: simulate_reactivity_insertion(PARAMS, THERMAL, dt_s=0.0)),
        ("zero duration refused",
         lambda: simulate_reactivity_insertion(PARAMS, THERMAL, duration_s=0.0)),
        ("no feedback refused",
         lambda: steady_power_for_reactivity(
             KineticsParameters(reference_power_w=1e7, prompt_lifetime_s=1e-4,
                                fuel_temperature_coefficient_per_k=0.0,
                                coolant_temperature_coefficient_per_k=0.0),
             THERMAL, 1e-3)),
        ("unphysical heat capacity refused",
         lambda: ThermalModel(fuel_heat_capacity_j_k=0.0,
                              coolant_heat_capacity_j_k=1.0,
                              fuel_to_coolant_conductance_w_k=1.0,
                              coolant_removal_conductance_w_k=1.0,
                              inlet_temperature_k=600.0)),
        ("absurd prompt lifetime refused",
         lambda: KineticsParameters(reference_power_w=1e7,
                                    prompt_lifetime_s=1.0,
                                    fuel_temperature_coefficient_per_k=-1e-5,
                                    coolant_temperature_coefficient_per_k=-1e-6)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (TransientError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: coupled transient reproduces prompt jump and closed-form steady power")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
