"""Hydrogen property providers, with an explicit capability table.

No single property library on hand covers the whole NERVA operating envelope, and
pretending otherwise is how property-reference bugs get into a model. This
module exposes narrow, honest functions that name their source and refuse to
extrapolate outside a provider's valid range.

Provider status on this machine, established by probe rather than assumption:

===========================  ===================================  ==============
Envelope                     Best available provider               Status
===========================  ===================================  ==============
Liquid H2 near 20 K          RocketProps (embedded data tables)    works
Liquid H2 near 20 K          CoolProp on Python 3.10               works
Hot gaseous H2 (600-3000 K)  none of the above                     **gap**
Equilibrium H2 <-> 2H        ``nasa_hydrogen`` (GRI-Mech NASA-7)   works, NASA-7
===========================  ===================================  ==============

The gap is real: RocketProps is a *liquid* property table and returns unphysical
values above saturation (it reported a "liquid" density of 31 kg/m3 at 300 K).
CoolProp covers the gas but is not importable in the interpreter where the rest
of this package's dependencies live. Hot-gas properties therefore remain with
``nasa_hydrogen`` and its documented NASA-7 caveat.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# RocketProps is vendored under ext_lib rather than installed, so it needs an
# explicit path. The workspace layout puts ext_lib one level above the OpenMC
# snapshot, so both the repo root and its grandparents are searched. Any real
# install is found without any of this.
_ROCKETPROPS_CANDIDATES = (
    REPO_ROOT / "ext_lib" / "RocketProps-master",
    REPO_ROOT.parent / "ext_lib" / "RocketProps-master",
    REPO_ROOT.parents[1] / "ext_lib" / "RocketProps-master",
)


class PropertyUnavailableError(RuntimeError):
    """Raised when no provider covers the requested state."""


@dataclass(frozen=True)
class PropertyResult:
    """A property value together with the provider that produced it."""

    value: float
    unit: str
    provider: str
    temperature_k: float
    note: str = ""

    def __post_init__(self) -> None:
        if not math.isfinite(self.value) or self.value <= 0.0:
            raise PropertyUnavailableError(
                f"provider {self.provider!r} returned an unusable value "
                f"{self.value!r} for {self.unit}"
            )
        if not math.isfinite(self.temperature_k) or self.temperature_k <= 0.0:
            raise PropertyUnavailableError(
                f"temperature must be finite and positive, got {self.temperature_k!r}"
            )


def _import_rocketprops():
    """Import the vendored RocketProps, or return None."""
    try:
        from rocketprops.rocket_prop import get_prop  # noqa: PLC0415
        return get_prop
    except ImportError:
        pass
    import sys  # noqa: PLC0415

    for candidate in _ROCKETPROPS_CANDIDATES:
        if candidate.is_dir() and str(candidate) not in sys.path:
            sys.path.insert(0, str(candidate))
            try:
                from rocketprops.rocket_prop import get_prop  # noqa: PLC0415
                return get_prop
            except ImportError:
                continue
    return None


def _import_coolprop():
    try:
        from CoolProp.CoolProp import PropsSI  # noqa: PLC0415
        return PropsSI
    except ImportError:
        return None


# Saturated liquid hydrogen is only meaningful below the critical point; the
# RocketProps tables silently return liquid values far above it, so the range is
# enforced here rather than trusted to the provider.
LH2_MAX_LIQUID_TEMPERATURE_K = 33.0   # critical temperature is 33.14 K


def liquid_hydrogen_density(temperature_k: float) -> PropertyResult:
    """Saturated liquid parahydrogen density [kg/m3].

    Refuses liquid lookups above the critical temperature, because both
    available providers will happily return a number there and it would be
    meaningless.
    """
    if not math.isfinite(temperature_k) or temperature_k <= 0.0:
        raise PropertyUnavailableError(
            f"temperature must be finite and positive, got {temperature_k!r}"
        )
    if temperature_k > LH2_MAX_LIQUID_TEMPERATURE_K:
        raise PropertyUnavailableError(
            f"{temperature_k} K is above the hydrogen critical temperature "
            f"({LH2_MAX_LIQUID_TEMPERATURE_K} K); there is no saturated liquid. "
            f"Hot-gas properties are not covered by any available provider."
        )

    props = _import_coolprop()
    if props is not None:
        try:
            dens = float(props("D", "T", temperature_k, "Q", 0.0, "Hydrogen"))
        except Exception:  # noqa: BLE001 - fall through to the next provider
            dens = None
        if dens is not None and math.isfinite(dens) and dens > 0.0:
            return PropertyResult(dens, "kg/m3", "CoolProp", temperature_k)

    get_prop = _import_rocketprops()
    if get_prop is not None:
        prop = get_prop("HYDROGEN")
        temperature_r = temperature_k * 1.8
        specific_gravity = prop.SGLiqAtTdegR(temperature_r)
        # RocketProps reports specific gravity relative to water at 999.016 kg/m3.
        return PropertyResult(
            float(specific_gravity) * 999.016, "kg/m3",
            "RocketProps (Ph2 data tables)", temperature_k,
            note="liquid table only; not valid above the critical temperature",
        )

    raise PropertyUnavailableError(
        "no liquid-hydrogen property provider is available: neither CoolProp nor "
        "the vendored RocketProps could be imported"
    )


def describe_providers() -> list[tuple[str, str, str]]:
    """Report which providers exist and what they cover."""
    rows = []
    rows.append((
        "CoolProp", "available" if _import_coolprop() else "missing",
        "liquid and gas hydrogen, full envelope",
    ))
    rows.append((
        "RocketProps", "available" if _import_rocketprops() else "missing",
        "liquid hydrogen below the critical temperature only",
    ))
    return rows


# ------------------------------------------------------ hot gaseous hydrogen


@dataclass(frozen=True)
class GasState:
    """Thermodynamic and transport state of gaseous hydrogen."""

    temperature_k: float
    pressure_pa: float
    density_kg_m3: float
    cp_j_kg_k: float
    cv_j_kg_k: float
    enthalpy_j_kg: float
    viscosity_pa_s: float
    conductivity_w_m_k: float
    molar_mass_kg_mol: float
    provider: str

    @property
    def gamma(self) -> float:
        """Ratio of specific heats, cp/cv."""
        return self.cp_j_kg_k / self.cv_j_kg_k

    @property
    def gas_constant_j_kg_k(self) -> float:
        """Specific gas constant R = cp - cv."""
        return self.cp_j_kg_k - self.cv_j_kg_k

    @property
    def prandtl(self) -> float:
        """Prandtl number, mu*cp/k."""
        return (self.viscosity_pa_s * self.cp_j_kg_k) / self.conductivity_w_m_k

    def __post_init__(self) -> None:
        for name in ("density_kg_m3", "cp_j_kg_k", "cv_j_kg_k",
                     "viscosity_pa_s", "conductivity_w_m_k", "molar_mass_kg_mol"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise PropertyUnavailableError(
                    f"{name} from {self.provider!r} is not physical: {value!r}"
                )
        if not math.isfinite(self.enthalpy_j_kg):
            raise PropertyUnavailableError(
                f"enthalpy from {self.provider!r} is not finite"
            )
        if self.cp_j_kg_k <= self.cv_j_kg_k:
            raise PropertyUnavailableError(
                f"cp ({self.cp_j_kg_k}) must exceed cv ({self.cv_j_kg_k})"
            )


# CoolProp is only tabulated to modest temperatures for hydrogen; above this the
# equilibrium dissociation of H2 into H makes a pure-H2 property call wrong.
H2_DISSOCIATION_ONSET_K = 1500.0


def gas_hydrogen_properties(temperature_k: float, pressure_pa: float) -> GasState:
    """Gaseous hydrogen properties from CoolProp.

    This is the provider that makes ``ChannelThermalClosure`` able to use real
    state-dependent properties instead of its constant-cp surrogate.

    Above :data:`H2_DISSOCIATION_ONSET_K` a warning-level caveat is attached
    via the caller's own logic: CoolProp treats hydrogen as a fixed H2 species,
    so it does not capture the H2 -> 2H dissociation that matters for a nuclear
    thermal rocket's hot leg. ``thermochemistry`` covers that.
    """
    for name, value in (("temperature", temperature_k), ("pressure", pressure_pa)):
        if not math.isfinite(value) or value <= 0.0:
            raise PropertyUnavailableError(
                f"{name} must be finite and positive, got {value!r}"
            )

    props = _import_coolprop()
    if props is None:
        raise PropertyUnavailableError(
            "no hot-gas hydrogen provider is available: CoolProp is not "
            "importable in this interpreter. RocketProps cannot substitute, "
            "because it is a liquid property table that returns unphysical "
            "values above the critical temperature."
        )
    fluid = "Hydrogen"
    try:
        return GasState(
            temperature_k=temperature_k,
            pressure_pa=pressure_pa,
            density_kg_m3=float(props("D", "T", temperature_k, "P", pressure_pa, fluid)),
            cp_j_kg_k=float(props("C", "T", temperature_k, "P", pressure_pa, fluid)),
            cv_j_kg_k=float(props("O", "T", temperature_k, "P", pressure_pa, fluid)),
            enthalpy_j_kg=float(props("H", "T", temperature_k, "P", pressure_pa, fluid)),
            viscosity_pa_s=float(props("V", "T", temperature_k, "P", pressure_pa, fluid)),
            conductivity_w_m_k=float(props("L", "T", temperature_k, "P", pressure_pa, fluid)),
            molar_mass_kg_mol=float(props("M", "T", temperature_k, "P", pressure_pa, fluid)),
            provider="CoolProp",
        )
    except (ValueError, OverflowError) as exc:
        raise PropertyUnavailableError(
            f"CoolProp hydrogen property failure at T={temperature_k} K, "
            f"P={pressure_pa} Pa: {exc}"
        ) from exc
