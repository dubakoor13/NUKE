"""Verify the nozzle is closed against the core state.

This establishes the gate-5 condition "nozzle throat is closed with the
core/channel state": given the chamber temperature from a coupled solve and the
mass flow the cycle actually delivers, the throat area is solved such that the
nozzle passes exactly that flow.

Chamber conditions here are synthetic NERVA-scale test inputs, not heritage
operating points.
"""
from __future__ import annotations

import math

from .nozzle_closure import (
    NozzleClosureError,
    NozzleClosureInputs,
    closure_from_coupled_solution,
    solve_nozzle_closure,
)

CHAMBER_T = 2500.0
CHAMBER_P = 4.5e6
MASS_FLOW = 30.0


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    inputs = NozzleClosureInputs(
        chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
        mass_flow_kg_s=MASS_FLOW, expansion_ratio=100.0,
        chemistry_mode="equilibrium",
    )
    result = solve_nozzle_closure(inputs)
    print(f"chamber: {CHAMBER_T:.0f} K, {CHAMBER_P/1e6:.1f} MPa, "
          f"{MASS_FLOW:.0f} kg/s, eps=100")
    print(f"  throat   A={result.throat_area_m2*1e4:.4f} cm2  "
          f"T={result.throat_temperature_k:.0f} K  P={result.throat_pressure_pa/1e6:.3f} MPa")
    print(f"  exit     A={result.exit_area_m2*1e4:.3f} cm2  "
          f"T={result.exit_temperature_k:.0f} K  P={result.exit_pressure_pa:.1f} Pa")
    print(f"  thrust   {result.thrust_vacuum_n/1e3:.2f} kN   "
          f"Isp={result.isp_vacuum_s:.1f} s   v_exit={result.exit_velocity_m_s:.0f} m/s")

    print("\nclosure and geometry:")
    results.append(_report("solver converged", result.converged,
                           f"{result.iterations} iterations"))
    results.append(_report("mass flow residual is negligible",
                           result.relative_mass_flow_residual < 1e-9,
                           f"{result.relative_mass_flow_residual:.2e} relative"))
    ratio = result.exit_area_m2 / result.throat_area_m2
    results.append(_report("area ratio equals the requested expansion ratio",
                           abs(ratio - 100.0) < 1e-6, f"Ae/At = {ratio:.6f}"))
    results.append(_report("throat area is physically sane (1-1000 cm2)",
                           1e-4 < result.throat_area_m2 < 0.1,
                           f"{result.throat_area_m2*1e4:.3f} cm2"))

    print("\nphysics plausibility (not heritage validation):")
    results.append(_report("Isp is in the nuclear-thermal range 700-950 s",
                           700.0 < result.isp_vacuum_s < 950.0,
                           f"{result.isp_vacuum_s:.1f} s"))
    results.append(_report("exit velocity is supersonic",
                           result.exit_velocity_m_s > 3000.0,
                           f"{result.exit_velocity_m_s:.0f} m/s"))
    results.append(_report("throat is hotter than the exit",
                           result.throat_temperature_k > result.exit_temperature_k,
                           f"{result.throat_temperature_k:.0f} > "
                           f"{result.exit_temperature_k:.0f} K"))
    results.append(_report("throat pressure exceeds exit pressure",
                           result.throat_pressure_pa > result.exit_pressure_pa,
                           f"{result.throat_pressure_pa/1e6:.3f} MPa > "
                           f"{result.exit_pressure_pa:.0f} Pa"))
    results.append(_report("some H2 dissociation occurs at 2500 K",
                           result.dissociation_fraction > 0.0,
                           f"alpha = {result.dissociation_fraction:.4f}"))
    results.append(_report("vacuum thrust equals mass flow times Isp times g0",
                           abs(result.thrust_vacuum_n
                               - MASS_FLOW * result.isp_vacuum_s * 9.80665)
                           / max(result.thrust_vacuum_n, 1.0) < 1e-12,
                           f"{result.thrust_vacuum_n/1e3:.3f} kN"))

    print("\nresponse directions:")
    bigger = solve_nozzle_closure(NozzleClosureInputs(
        chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
        mass_flow_kg_s=2.0 * MASS_FLOW, expansion_ratio=100.0))
    results.append(_report("doubling mass flow increases the throat area",
                           bigger.throat_area_m2 > result.throat_area_m2,
                           f"{result.throat_area_m2*1e4:.2f} -> "
                           f"{bigger.throat_area_m2*1e4:.2f} cm2"))
    results.append(_report("doubling mass flow doubles thrust roughly",
                           1.8 < bigger.thrust_vacuum_n / result.thrust_vacuum_n < 2.2,
                           f"ratio = {bigger.thrust_vacuum_n/result.thrust_vacuum_n:.3f}"))
    hotter = solve_nozzle_closure(NozzleClosureInputs(
        chamber_temperature_k=2800.0, chamber_pressure_pa=CHAMBER_P,
        mass_flow_kg_s=MASS_FLOW, expansion_ratio=100.0))
    results.append(_report("a hotter chamber raises Isp",
                           hotter.isp_vacuum_s > result.isp_vacuum_s,
                           f"{result.isp_vacuum_s:.1f} -> {hotter.isp_vacuum_s:.1f} s"))
    frozen = solve_nozzle_closure(NozzleClosureInputs(
        chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
        mass_flow_kg_s=MASS_FLOW, expansion_ratio=100.0,
        chemistry_mode="frozen"))
    results.append(_report("frozen chemistry differs from equilibrium",
                           abs(frozen.isp_vacuum_s - result.isp_vacuum_s) > 0.1,
                           f"equilibrium {result.isp_vacuum_s:.1f} s vs "
                           f"frozen {frozen.isp_vacuum_s:.1f} s"))
    # A 100:1 nozzle is grossly over-expanded at sea level - the ambient force on
    # the exit exceeds the vacuum thrust, so a sea-level case must use a modest
    # area ratio. That refusal is itself verified below.
    sea_level = solve_nozzle_closure(NozzleClosureInputs(
        chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
        mass_flow_kg_s=MASS_FLOW, expansion_ratio=8.0,
        ambient_pressure_pa=101325.0))
    results.append(_report("sea-level thrust is below vacuum thrust",
                           sea_level.thrust_delivered_n < sea_level.thrust_vacuum_n,
                           f"{sea_level.thrust_delivered_n/1e3:.2f} kN < "
                           f"{sea_level.thrust_vacuum_n/1e3:.2f} kN at eps=8"))
    try:
        solve_nozzle_closure(NozzleClosureInputs(
            chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
            mass_flow_kg_s=MASS_FLOW, expansion_ratio=100.0,
            ambient_pressure_pa=101325.0))
    except NozzleClosureError as exc:
        results.append(True)
        print(f"  [PASS] refused a 100:1 nozzle at sea level: {str(exc)[:44]}...")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED a grossly over-expanded sea-level nozzle")

    print("\ninputs the core does NOT determine are refused:")
    class _Solution:
        fuel_temperature_k = CHAMBER_T

    for label, kwargs in (
        ("no chamber pressure",
         dict(mass_flow_kg_s=MASS_FLOW)),
        ("no mass flow",
         dict(chamber_pressure_pa=CHAMBER_P)),
    ):
        try:
            closure_from_coupled_solution(_Solution(), **kwargs)
        except NozzleClosureError as exc:
            results.append(True)
            print(f"  [PASS] refused {label}: {str(exc)[:46]}...")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    ok = closure_from_coupled_solution(_Solution(), chamber_pressure_pa=CHAMBER_P,
                                       mass_flow_kg_s=MASS_FLOW)
    results.append(_report("closes when the cycle supplies both values",
                           ok.converged, f"Isp={ok.isp_vacuum_s:.1f} s"))

    print("\ninvalid inputs are rejected:")
    guards = [
        ("zero chamber temperature", lambda: NozzleClosureInputs(
            chamber_temperature_k=0.0, chamber_pressure_pa=CHAMBER_P,
            mass_flow_kg_s=MASS_FLOW)),
        ("zero mass flow", lambda: NozzleClosureInputs(
            chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
            mass_flow_kg_s=0.0)),
        ("expansion ratio of one", lambda: NozzleClosureInputs(
            chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
            mass_flow_kg_s=MASS_FLOW, expansion_ratio=1.0)),
        ("unknown chemistry mode", lambda: NozzleClosureInputs(
            chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
            mass_flow_kg_s=MASS_FLOW, chemistry_mode="plasma")),
        ("nozzle efficiency above one", lambda: NozzleClosureInputs(
            chamber_temperature_k=CHAMBER_T, chamber_pressure_pa=CHAMBER_P,
            mass_flow_kg_s=MASS_FLOW, nozzle_efficiency=1.5)),
        ("negative throat area guess", lambda: solve_nozzle_closure(
            inputs, initial_throat_area_m2=-1.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (NozzleClosureError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: nozzle throat is closed against the chamber state and mass flow")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
