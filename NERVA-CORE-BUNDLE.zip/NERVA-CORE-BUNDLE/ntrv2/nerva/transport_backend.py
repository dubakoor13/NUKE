"""Pluggable neutron-transport backends.

The delivered model never called transport: `openmc.run(` appeared zero times
in 278 modules, so every "coupling" was tested only against injected
snapshots. This module makes the transport a first-class, swappable component
so the coupled reactor loop can be written once, exercised today against an
analytic :class:`MockTransportBackend`, and pointed at the real C++ solver on
a machine that has one.

Two hard rules:

* A backend must declare :attr:`TransportBackend.synthetic`. Nothing that
  consumed a synthetic result may report it as a reactor prediction.
* The OpenMC backend refuses to run without an executable and evaluated cross
  sections, and says exactly what is missing. Silence here is what let the
  delivered repo's CI look like physics when it was algebra.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass, replace
from pathlib import Path


class PreflightError(RuntimeError):
    """Raised when a backend cannot run in this environment, with the reason."""


@dataclass(frozen=True)
class CoreState:
    """Everything a transport solve is allowed to depend on.

    Making this explicit is the point: a transport run whose inputs are not
    captured here cannot be reproduced, and a feedback loop that mutates state
    outside this object cannot be audited.
    """

    fuel_temperature_k: float
    hydrogen_temperature_k: float
    reflector_temperature_k: float = 293.6
    # Coolant density. Optional because not every analysis needs it, but a void
    # coefficient cannot be measured without it, so the coefficient refuses
    # rather than returning a fabricated zero.
    coolant_density_kg_m3: float | None = None
    # Fission-product poison loading, as a macroscopic absorption cross-section
    # [1/cm]. Optional; the poison worth cannot be measured without it.
    poison_absorption_cm_inv: float | None = None
    drum_angle_deg: float = 0.0
    enrichment_wt_percent: float = 5.0
    particles: int = 4000
    batches: int = 80
    inactive: int = 20
    seed: int = 1
    # Photon transport. OpenMC supports coupled neutron-photon transport natively
    # (``src/photon.cpp``, bremsstrahlung and secondary-photon handling); the
    # NERVA config already carries a ``photon_transport`` flag that defaulted to
    # False and was never reachable from this layer. Exposing it here is what
    # makes gamma heating and gamma dose reachable at all.
    photon_transport: bool = False

    def __post_init__(self) -> None:
        for name in ("fuel_temperature_k", "hydrogen_temperature_k",
                     "reflector_temperature_k"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive, got {value!r}")
        if self.coolant_density_kg_m3 is not None:
            density = self.coolant_density_kg_m3
            if not math.isfinite(density) or density <= 0.0:
                raise ValueError(
                    f"coolant_density_kg_m3 must be finite and positive when "
                    f"given, got {density!r}"
                )
        if self.poison_absorption_cm_inv is not None:
            poison = self.poison_absorption_cm_inv
            if not math.isfinite(poison) or poison < 0.0:
                raise ValueError(
                    f"poison_absorption_cm_inv must be finite and non-negative "
                    f"when given, got {poison!r}"
                )
        if not 0.0 <= self.enrichment_wt_percent < 20.0:
            raise ValueError(
                "demonstration enrichment must remain between 0 and 20 wt% U-235; "
                "a higher value is a different reactor and needs its own evidence"
            )
        for name in ("particles", "batches", "inactive"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")

    def with_changes(self, **changes) -> CoreState:
        """Return a copy with fields replaced, re-validated."""
        return replace(self, **changes)


@dataclass(frozen=True)
class TransportResult:
    """Outcome of one transport solve, with provenance attached."""

    k_eff: float
    k_sigma: float
    fuel_power_fraction: tuple[float, ...]
    leakage_fraction: float
    backend: str
    synthetic: bool
    provenance: dict

    def __post_init__(self) -> None:
        if not math.isfinite(self.k_eff):
            raise ValueError("k_eff must be finite")
        if self.k_sigma < 0.0 or not math.isfinite(self.k_sigma):
            raise ValueError("k_eff uncertainty must be finite and non-negative")
        if not self.fuel_power_fraction:
            raise ValueError("a transport result must carry the heating distribution")
        total = math.fsum(self.fuel_power_fraction)
        if abs(total - 1.0) > 1e-9:
            raise ValueError(
                f"fuel power fractions must sum to 1, got {total!r}; an "
                f"unnormalised distribution silently rescales the reactor power"
            )
        if not 0.0 <= self.leakage_fraction <= 1.0:
            raise ValueError("leakage fraction must lie in [0, 1]")

    @property
    def is_physics(self) -> bool:
        """True only for a real transport solve, never for a mock."""
        return not self.synthetic


class TransportBackend(ABC):
    """A neutron-transport solver behind a stable interface."""

    name: str = "abstract"
    synthetic: bool = True

    @abstractmethod
    def run(self, state: CoreState) -> TransportResult:
        """Solve transport for ``state`` and return heating plus eigenvalue."""

    def preflight(self) -> list[str]:
        """Return a list of blocking problems; empty means ready to run."""
        return []

    def require_ready(self) -> None:
        problems = self.preflight()
        if problems:
            raise PreflightError(
                f"{self.name} cannot run here:\n  - " + "\n  - ".join(problems)
            )


# --------------------------------------------------------------- mock backend


@dataclass(frozen=True)
class MockCoefficients:
    """Coefficients of the analytic surrogate reactor.

    These are **not heritage data** and carry no citation. They exist so the
    coupling loop can be exercised and its convergence proved. Every one must
    be supplied explicitly by the caller - there are no defaults - so no
    invented number can hide inside the backend.
    """

    k_reference: float
    fuel_temperature_coefficient_per_k: float
    hydrogen_temperature_coefficient_per_k: float
    drum_coefficient_per_deg: float
    enrichment_coefficient_per_wt_percent: float
    # Reflector feedback. Defaults to zero, which means "this surrogate has no
    # reflector feedback" - an explicit and honest statement rather than a
    # silently invented coefficient.
    reflector_temperature_coefficient_per_k: float = 0.0
    # Coal density feedback (the void coefficient). Also defaults to zero.
    coolant_density_coefficient_per_kg_m3: float = 0.0
    # Fission-product poison worth: dk per unit poison absorption [1/cm]. Also
    # defaults to zero, meaning "no poison feedback in this surrogate".
    poison_absorption_coefficient_per_cm_inv: float = 0.0
    reference_fuel_temperature_k: float = 293.6
    reference_hydrogen_temperature_k: float = 293.6
    reference_reflector_temperature_k: float = 293.6
    reference_coolant_density_kg_m3: float = 2.0
    reference_drum_angle_deg: float = 0.0
    reference_enrichment_wt_percent: float = 5.0
    # Spatial distribution sensitivity: reactivity per kelvin of peak-above-mean
    # fuel temperature. Zero means "this surrogate treats a distribution exactly
    # like its mean", which makes the spatial machinery verifiable against the
    # lumped one.
    spatial_distribution_coefficient_per_k: float = 0.0

    def validate(self) -> None:
        if not math.isfinite(self.k_reference) or self.k_reference <= 0.0:
            raise ValueError("k_reference must be finite and positive")
        for name in ("fuel_temperature_coefficient_per_k",
                     "hydrogen_temperature_coefficient_per_k",
                     "drum_coefficient_per_deg",
                     "enrichment_coefficient_per_wt_percent",
                     "reflector_temperature_coefficient_per_k",
                     "coolant_density_coefficient_per_kg_m3",
                     "poison_absorption_coefficient_per_cm_inv",
                     "spatial_distribution_coefficient_per_k"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
        if (not math.isfinite(self.reference_coolant_density_kg_m3)
                or self.reference_coolant_density_kg_m3 <= 0.0):
            raise ValueError("reference coolant density must be finite and positive")

    def k_eff(self, state: CoreState) -> float:
        self.validate()
        density_term = 0.0
        if state.coolant_density_kg_m3 is not None:
            density_term = (self.coolant_density_coefficient_per_kg_m3
                            * (state.coolant_density_kg_m3
                               - self.reference_coolant_density_kg_m3))
        poison_term = 0.0
        if state.poison_absorption_cm_inv is not None:
            poison_term = (self.poison_absorption_coefficient_per_cm_inv
                           * state.poison_absorption_cm_inv)
        return (
            self.k_reference
            + self.fuel_temperature_coefficient_per_k
            * (state.fuel_temperature_k - self.reference_fuel_temperature_k)
            + self.hydrogen_temperature_coefficient_per_k
            * (state.hydrogen_temperature_k - self.reference_hydrogen_temperature_k)
            + self.reflector_temperature_coefficient_per_k
            * (state.reflector_temperature_k - self.reference_reflector_temperature_k)
            + density_term
            + poison_term
            + self.drum_coefficient_per_deg
            * (state.drum_angle_deg - self.reference_drum_angle_deg)
            + self.enrichment_coefficient_per_wt_percent
            * (state.enrichment_wt_percent - self.reference_enrichment_wt_percent)
        )


@dataclass(frozen=True)
class MockTransportBackend(TransportBackend):
    """Analytic surrogate reactor: deterministic, monotone, and openly synthetic.

    The heating profile is a smooth dimensionless shape so that the coupling
    loop has something spatially non-uniform to transport through the thermal
    closure. It is not a power shape from any reactor.
    """

    coefficients: MockCoefficients
    element_count: int = 7
    radial_peaking: float = 1.30
    # How strongly the power shape flattens as the fuel heats. Real transport
    # produces this because cross sections shift with temperature; here it is a
    # declared surrogate coefficient with no default, so the feedback loop has
    # a shape response to iterate on rather than converging in one pass.
    shape_temperature_sensitivity_per_k: float = 0.0
    reference_fuel_temperature_k: float = 293.6
    k_uncertainty: float = 1e-4
    name: str = "mock-analytic"
    synthetic: bool = True

    def __post_init__(self) -> None:
        if self.element_count < 1:
            raise ValueError("element_count must be positive")
        if self.radial_peaking < 1.0:
            raise ValueError(
                "radial_peaking must be >= 1; a value below 1 would put the "
                "hottest element outside the core"
            )
        if self.k_uncertainty < 0.0:
            raise ValueError("k_uncertainty cannot be negative")
        if not math.isfinite(self.shape_temperature_sensitivity_per_k):
            raise ValueError("shape_temperature_sensitivity_per_k must be finite")

    def _peaking(self, state: CoreState) -> float:
        """Peak-to-average ratio after the declared temperature response."""
        peaking = (self.radial_peaking
                   + self.shape_temperature_sensitivity_per_k
                   * (state.fuel_temperature_k - self.reference_fuel_temperature_k))
        return max(1.0, peaking)

    def _shape(self, state: CoreState) -> tuple[float, ...]:
        """Cosine radial shape scaled to the requested peak-to-average ratio."""
        n = self.element_count
        peaking = self._peaking(state)
        centre = (n - 1) / 2.0
        half = max(centre, 1.0)
        raw = [
            1.0 + (peaking - 1.0) * math.cos(
                0.5 * math.pi * ((i - centre) / half) ** 2
            )
            for i in range(n)
        ]
        total = math.fsum(raw)
        return tuple(value / total for value in raw)

    def run(self, state: CoreState) -> TransportResult:
        return TransportResult(
            k_eff=self.coefficients.k_eff(state),
            k_sigma=self.k_uncertainty,
            fuel_power_fraction=self._shape(state),
            leakage_fraction=0.0,
            backend=self.name,
            synthetic=True,
            provenance={
                "kind": "analytic-surrogate",
                "warning": "NOT a neutron-transport result",
                "state": {
                    "fuel_temperature_k": state.fuel_temperature_k,
                    "hydrogen_temperature_k": state.hydrogen_temperature_k,
                    "drum_angle_deg": state.drum_angle_deg,
                    "enrichment_wt_percent": state.enrichment_wt_percent,
                },
                "coefficients": {
                    "k_reference": self.coefficients.k_reference,
                    "fuel_temperature_coefficient_per_k":
                        self.coefficients.fuel_temperature_coefficient_per_k,
                    "drum_coefficient_per_deg":
                        self.coefficients.drum_coefficient_per_deg,
                    "shape_temperature_sensitivity_per_k":
                        self.shape_temperature_sensitivity_per_k,
                },
            },
        )

    # -- spatially resolved solve -----------------------------------------
    def run_spatial(self, spatial_state) -> TransportResult:
        """Solve with a per-element temperature distribution.

        The eigenvalue uses the power-weighted mean temperatures, exactly as a
        lumped backend would, **plus** a declared distribution term

            k = k_uniform(mean) + alpha_dist * (T_peak - T_mean)

        because cross sections are not linear in temperature: a 1.4-peaked core
        is not reactivity-equivalent to a flat core at the same mean. With
        ``spatial_distribution_coefficient_per_k = 0`` the spatial and lumped
        answers coincide *exactly*, which is what makes the machinery verifiable
        against the lumped one.
        """
        temperatures = spatial_state.fuel_temperatures_k
        mean_fuel = math.fsum(temperatures) / len(temperatures)
        mean_hydrogen = (math.fsum(spatial_state.hydrogen_temperatures_k)
                         / len(spatial_state.hydrogen_temperatures_k))
        uniform_state = spatial_state.basis.with_changes(
            fuel_temperature_k=mean_fuel, hydrogen_temperature_k=mean_hydrogen)
        base_k = self.coefficients.k_eff(uniform_state)
        peak_fuel = max(temperatures)
        distribution = peak_fuel - mean_fuel
        k_eff = (base_k
                 + self.coefficients.spatial_distribution_coefficient_per_k
                 * distribution)
        shape = self._shape(uniform_state)
        return TransportResult(
            k_eff=k_eff,
            k_sigma=self.k_uncertainty,
            fuel_power_fraction=shape,
            leakage_fraction=0.0,
            backend=self.name,
            synthetic=True,
            provenance={
                "kind": "analytic-surrogate",
                "mode": "spatial",
                "warning": "NOT a neutron-transport result",
                "elements": len(temperatures),
                "mean_fuel_temperature_k": mean_fuel,
                "peak_fuel_temperature_k": peak_fuel,
                "peak_above_mean_k": distribution,
                "spatial_distribution_coefficient_per_k":
                    self.coefficients.spatial_distribution_coefficient_per_k,
            },
        )


# ------------------------------------------------------------- OpenMC backend


FUEL_HEATING_TALLY = "nerva_3d_fuel_heating"
NEUTRONICS_TALLY = "nerva_3d_neutronics"


class OpenMCTransportBackend(TransportBackend):
    """Real Monte Carlo transport, run only when the environment can support it.

    This is the one component that cannot be exercised on a machine without a
    built OpenMC executable and evaluated cross sections. It therefore checks
    first and fails loudly rather than producing a plausible-looking number.
    """

    name = "openmc"
    synthetic = False

    def __init__(self, workdir: str | Path, *, assembly: str = "reactor",
                 rings: int = 8, executable: str | None = None,
                 cross_sections: str | None = None,
                 threads: int | None = None) -> None:
        self.workdir = Path(workdir)
        self.assembly = assembly
        self.rings = rings
        self.executable = executable
        self.cross_sections = cross_sections
        self.threads = threads

    # -- environment checks ------------------------------------------------
    def _resolve_executable(self) -> str | None:
        if self.executable:
            return self.executable if Path(self.executable).exists() else None
        return shutil.which("openmc")

    def _resolve_cross_sections(self) -> str | None:
        if self.cross_sections:
            return self.cross_sections if Path(self.cross_sections).exists() else None
        env = os.environ.get("OPENMC_CROSS_SECTIONS")
        if env and Path(env).exists():
            return env
        try:  # openmc.config may hold it in newer versions
            import openmc  # noqa: PLC0415 - optional dependency
            configured = openmc.config.get("cross_sections")
            if configured and Path(configured).exists():
                return str(configured)
        except Exception:  # noqa: BLE001 - absence is the answer we need
            return None
        return None

    def preflight(self) -> list[str]:
        problems: list[str] = []
        if self._resolve_executable() is None:
            problems.append(
                "no OpenMC executable found: build the C++ transport code or "
                "pass executable=..., or set the 'openmc' entry on PATH"
            )
        if self._resolve_cross_sections() is None:
            problems.append(
                "no evaluated cross sections found: set OPENMC_CROSS_SECTIONS to "
                "a cross_sections.xml (NNDC HDF5 library)"
            )
        try:
            import openmc  # noqa: F401, PLC0415 - presence check only
        except Exception as exc:  # noqa: BLE001
            problems.append(f"the openmc python package is not importable: {exc}")
        return problems

    # -- solve -------------------------------------------------------------
    def _config(self, state: CoreState):
        from .config import NervaConfig  # noqa: PLC0415 - avoid import cost

        return NervaConfig(
            core_rings=self.rings,
            fuel_temperature_k=state.fuel_temperature_k,
            hydrogen_temperature_k=state.hydrogen_temperature_k,
            uranium_enrichment_wt_percent=state.enrichment_wt_percent,
            control_drum_angle_deg=state.drum_angle_deg,
            batches=state.batches,
            inactive=state.inactive,
            particles=state.particles,
            photon_transport=state.photon_transport,
        )

    def run(self, state: CoreState) -> TransportResult:
        self.require_ready()
        import openmc  # noqa: PLC0415

        from .model import build_model  # noqa: PLC0415

        config = self._config(state)
        model = build_model(config, self.assembly)
        model.settings.seed = state.seed
        self.workdir.mkdir(parents=True, exist_ok=True)
        model.export_to_xml(str(self.workdir))

        executable = self._resolve_executable()
        if executable is None:  # pragma: no cover - preflight already blocks
            raise PreflightError("OpenMC executable disappeared between checks")
        openmc.run(cwd=str(self.workdir), openmc_exec=executable,
                   threads=self.threads, output=False)

        statepoints = sorted(self.workdir.glob("statepoint.*.h5"))
        if not statepoints:
            raise RuntimeError(
                f"OpenMC produced no statepoint in {self.workdir}; the transport "
                f"run did not complete"
            )
        statepoint_path = statepoints[-1]
        with openmc.StatePoint(statepoint_path) as statepoint:
            k_eff = float(statepoint.k_combined.nominal_value)
            k_sigma = float(statepoint.k_combined.std_dev)
            fractions = self._extract_heating(statepoint)
            leakage = self._extract_leakage(statepoint)

        digest = hashlib.sha256()
        with statepoint_path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                digest.update(chunk)

        return TransportResult(
            k_eff=k_eff,
            k_sigma=k_sigma,
            fuel_power_fraction=fractions,
            leakage_fraction=leakage,
            backend=self.name,
            synthetic=False,
            provenance={
                "kind": "openmc-transport",
                "statepoint": str(statepoint_path),
                "statepoint_sha256": digest.hexdigest(),
                "cross_sections": self._resolve_cross_sections(),
                "openmc_version": openmc.__version__,
                "seed": state.seed,
                "particles": state.particles,
                "batches": state.batches,
                "inactive": state.inactive,
                "assembly": self.assembly,
                "rings": self.rings,
            },
        )

    @staticmethod
    def _extract_heating(statepoint) -> tuple[float, ...]:
        """Element-wise fuel heating fractions from the fuel-heating tally."""
        tally = statepoint.get_tally(name=FUEL_HEATING_TALLY)
        values = tally.mean.ravel()
        total = float(values.sum())
        if not math.isfinite(total) or total <= 0.0:
            raise RuntimeError(
                f"tally {FUEL_HEATING_TALLY!r} carries no usable heating; the "
                f"tally may be empty or mis-defined"
            )
        return tuple(float(value / total) for value in values)

    @staticmethod
    def _extract_leakage(statepoint) -> float:
        try:
            balance = statepoint.get_tally(name="nerva_global_neutron_balance")
            values = dict(zip(balance.scores, balance.mean.ravel()))
        except Exception:  # noqa: BLE001 - leakage is diagnostic, not essential
            return 0.0
        net = float(values.get("absorption", 0.0) + values.get("leakage", 0.0))
        if net <= 0.0:
            return 0.0
        return min(1.0, float(values.get("leakage", 0.0)) / net)


def describe_environment(backend: TransportBackend) -> str:
    """Human-readable readiness report for a backend (used by the doctor)."""
    problems = backend.preflight()
    lines = [f"backend: {backend.name}", f"synthetic: {backend.synthetic}"]
    if backend.synthetic:
        lines.append("NOTE: this backend is an analytic surrogate, not physics.")
    if problems:
        lines.append("status: NOT READY")
        lines.extend(f"  - {problem}" for problem in problems)
    else:
        lines.append("status: ready")
    return "\n".join(lines)
