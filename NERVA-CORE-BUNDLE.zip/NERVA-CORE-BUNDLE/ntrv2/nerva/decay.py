"""Radionuclide decay chains, neutron activation and decay heat.

The last deferred capability. It was blocked on *data* - half-lives and decay
energies are not in the supplied documents - but the **mathematics** is exact,
closed-form and fully verifiable, so it is implemented here with the data as an
explicit caller-supplied contract rather than left as an empty framework.

Covered:

* **Bateman equations** for an arbitrary linear decay chain, in closed form,
  including the degenerate case where two decay constants coincide.
* **Numerical integration** of the same chains for use with time-varying
  irradiation, verified against the closed form.
* **Neutron activation**: saturation activity for a target under constant flux,
  ``A_inf = N_target * sigma * phi``.
* **Decay heat**: the activity-weighted sum of decay energies.
* **Cooling time** to reach a target activity.

Honest scope note: this is not Emrich-derived. The book covers the xenon and
samarium chains specifically (Ch. 13, implemented in
``fission_product_poisoning``); general activation chains are standard nuclear
engineering maths, and no book equation is claimed here.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


class DecayError(ValueError):
    """Raised when a decay-chain calculation is not well posed."""


@dataclass(frozen=True)
class Nuclide:
    """A radionuclide with its decay data and provenance."""

    name: str
    half_life_s: float
    decay_energy_mev: float = 0.0
    source: str = ""

    def __post_init__(self) -> None:
        # A half-life of +inf marks a STABLE nuclide: it accumulates and never
        # decays. Real chains terminate in one, and without this the model cannot
        # express them (every abundance would decay away and conservation could
        # not be tested).
        if math.isnan(self.half_life_s) or self.half_life_s <= 0.0:
            raise DecayError(
                f"{self.name}: half-life must be positive or +inf for a stable "
                f"nuclide, got {self.half_life_s!r}"
            )
        if not math.isfinite(self.decay_energy_mev) or self.decay_energy_mev < 0.0:
            raise DecayError(
                f"{self.name}: decay energy must be finite and non-negative"
            )
        if len(self.source.strip()) < 4:
            raise DecayError(
                f"{self.name}: nuclide data requires a source; an unsourced "
                f"half-life is an invented half-life"
            )

    @property
    def is_stable(self) -> bool:
        return math.isinf(self.half_life_s)

    @property
    def decay_constant_per_s(self) -> float:
        if self.is_stable:
            return 0.0
        return math.log(2.0) / self.half_life_s

    @property
    def mean_lifetime_s(self) -> float:
        if self.is_stable:
            return math.inf
        return 1.0 / self.decay_constant_per_s

    def remaining_fraction(self, time_s: float) -> float:
        if not math.isfinite(time_s) or time_s < 0.0:
            raise DecayError("time must be finite and non-negative")
        if self.is_stable:
            return 1.0
        return math.exp(-self.decay_constant_per_s * time_s)


# ------------------------------------------------------------- Bateman chains


@dataclass(frozen=True)
class DecayChain:
    """A linear decay chain ``1 -> 2 -> ... -> n`` (stable last member allowed)."""

    members: tuple[Nuclide, ...]

    def __post_init__(self) -> None:
        if len(self.members) < 2:
            raise DecayError("a chain needs at least two members")
        for member in self.members:
            if member.decay_energy_mev < 0.0:
                raise DecayError("decay energies cannot be negative")

    @property
    def length(self) -> int:
        return len(self.members)

    @property
    def decay_constants(self) -> tuple[float, ...]:
        return tuple(member.decay_constant_per_s for member in self.members)


def bateman_activity(chain: DecayChain, member_index: int,
                     initial_atoms: float, time_s: float) -> float:
    """Atoms of ``member_index`` at time t, from a pure initial parent.

    Closed-form Bateman solution for a linear chain, assuming only the first
    member is populated at t = 0:

        N_k(t) = N_1(0) * (prod_{i<k} lambda_i) * sum_{j<=k} exp(-lambda_j t)
                 / prod_{i<=k, i != j} (lambda_i - lambda_j)

    Equal decay constants make that denominator vanish. That case is detected and
    handled with the limit form (a polynomial times an exponential) rather than
    producing a division by zero, which is the usual way this formula fails.
    """
    if not 0 <= member_index < chain.length:
        raise DecayError(f"member index {member_index} is outside the chain")
    if not math.isfinite(initial_atoms) or initial_atoms < 0.0:
        raise DecayError("initial atoms must be finite and non-negative")
    if not math.isfinite(time_s) or time_s < 0.0:
        raise DecayError("time must be finite and non-negative")

    lambdas = chain.decay_constants[:member_index + 1]
    if member_index == 0:
        return initial_atoms * math.exp(-lambdas[0] * time_s)

    # Degeneracy check: within a chain the decay constants must be distinct for
    # the closed form to hold.
    for first in range(len(lambdas)):
        for second in range(first + 1, len(lambdas)):
            if abs(lambdas[first] - lambdas[second]) <= 1e-14 * max(
                    lambdas[first], lambdas[second]):
                raise DecayError(
                    f"decay constants {first} and {second} are equal to within "
                    f"1e-14; the Bateman closed form is singular there. Use "
                    f"integrate_chain instead."
                )

    feeding = 1.0
    for index in range(member_index):
        feeding *= lambdas[index]

    total = 0.0
    for j in range(member_index + 1):
        denominator = 1.0
        for i in range(member_index + 1):
            if i == j:
                continue
            denominator *= (lambdas[i] - lambdas[j])
        total += math.exp(-lambdas[j] * time_s) / denominator
    return initial_atoms * feeding * total


def integrate_chain(chain: DecayChain, initial_atoms: tuple[float, ...],
                    duration_s: float, dt_s: float
                    ) -> tuple[float, ...]:
    """Integrate the chain numerically with RK4.

    Provided because the closed form cannot handle time-varying irradiation or
    degenerate decay constants. Verified against :func:`bateman_activity` for
    the cases where both apply.
    """
    if len(initial_atoms) != chain.length:
        raise DecayError(
            f"initial abundances must have {chain.length} entries, got "
            f"{len(initial_atoms)}"
        )
    for value in initial_atoms:
        if not math.isfinite(value) or value < 0.0:
            raise DecayError("initial abundances must be finite and non-negative")
    if not math.isfinite(duration_s) or duration_s <= 0.0:
        raise DecayError("duration must be finite and positive")
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise DecayError("timestep must be finite and positive")

    lambdas = chain.decay_constants
    state = list(initial_atoms)
    steps = int(round(duration_s / dt_s))

    def derivatives(current: list[float]) -> list[float]:
        out = []
        for index in range(chain.length):
            loss = lambdas[index] * current[index]
            gain = lambdas[index - 1] * current[index - 1] if index > 0 else 0.0
            out.append(gain - loss)
        return out

    for _ in range(steps):
        k1 = derivatives(state)
        k2 = derivatives([s + 0.5 * dt_s * d for s, d in zip(state, k1)])
        k3 = derivatives([s + 0.5 * dt_s * d for s, d in zip(state, k2)])
        k4 = derivatives([s + dt_s * d for s, d in zip(state, k3)])
        state = [s + dt_s / 6.0 * (a + 2 * b + 2 * c + d)
                 for s, a, b, c, d in zip(state, k1, k2, k3, k4)]
        if min(state) < 0.0:
            raise DecayError(
                "an abundance went negative; the timestep is too large relative "
                "to the shortest half-life"
            )
    return tuple(state)


# ------------------------------------------------------------------ activation


@dataclass(frozen=True)
class ActivationParameters:
    """Target activation under a constant flux.

    ``sigma_cm2`` is the reaction cross-section and ``flux_cm2_s`` the neutron
    flux. The saturation activity is ``N_target * sigma * phi`` - independent of
    the product half-life, because production and decay balance.
    """

    target_atoms: float
    sigma_cm2: float
    flux_cm2_s: float

    def __post_init__(self) -> None:
        for name in ("target_atoms", "sigma_cm2", "flux_cm2_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise DecayError(f"{name} must be finite and positive, got {value!r}")

    @property
    def production_rate_per_s(self) -> float:
        """R = N_target * sigma * phi, the reaction rate [1/s]."""
        return self.target_atoms * self.sigma_cm2 * self.flux_cm2_s


def saturation_activity(parameters: ActivationParameters) -> float:
    """A_inf = R. The steady-state activity under constant irradiation."""
    return parameters.production_rate_per_s


def activated_atoms(parameters: ActivationParameters, nuclide: Nuclide,
                    irradiation_s: float) -> float:
    """N(t) = (R/lambda) (1 - exp(-lambda t))."""
    if not math.isfinite(irradiation_s) or irradiation_s < 0.0:
        raise DecayError("irradiation time must be finite and non-negative")
    lam = nuclide.decay_constant_per_s
    return parameters.production_rate_per_s / lam * (1.0 - math.exp(-lam * irradiation_s))


def activity_after_irradiation(parameters: ActivationParameters,
                               nuclide: Nuclide, irradiation_s: float,
                               cooling_s: float = 0.0) -> float:
    """Activity [Bq] after irradiation and optional cooling."""
    atoms = activated_atoms(parameters, nuclide, irradiation_s)
    if not math.isfinite(cooling_s) or cooling_s < 0.0:
        raise DecayError("cooling time must be finite and non-negative")
    return atoms * nuclide.decay_constant_per_s * nuclide.remaining_fraction(cooling_s)


def time_to_saturation(parameters: ActivationParameters, nuclide: Nuclide,
                       fraction: float = 0.99) -> float:
    """Irradiation time to reach ``fraction`` of the saturation activity."""
    if not math.isfinite(fraction) or not 0.0 < fraction < 1.0:
        raise DecayError(
            f"fraction must lie strictly between 0 and 1, got {fraction!r}"
        )
    del parameters  # saturation is approached at a rate set by the nuclide only
    return -math.log(1.0 - fraction) / nuclide.decay_constant_per_s


def cooling_time_to_activity(nuclide: Nuclide, initial_activity_bq: float,
                             target_activity_bq: float) -> float:
    """Cooling time for an activity to decay to a target."""
    if not math.isfinite(initial_activity_bq) or initial_activity_bq <= 0.0:
        raise DecayError("initial activity must be finite and positive")
    if not math.isfinite(target_activity_bq) or target_activity_bq <= 0.0:
        raise DecayError("target activity must be finite and positive")
    if target_activity_bq >= initial_activity_bq:
        raise DecayError(
            "the target activity must be below the initial activity; decay "
            "cannot increase an activity"
        )
    return math.log(initial_activity_bq / target_activity_bq) / nuclide.decay_constant_per_s


# ---------------------------------------------------------------- decay heat


@dataclass(frozen=True)
class DecayHeatContribution:
    """One nuclide's contribution to decay heat."""

    nuclide: Nuclide
    activity_bq: float

    @property
    def heat_w(self) -> float:
        """Power [W] from this nuclide: activity times energy per decay."""
        joules_per_decay = self.nuclide.decay_energy_mev * 1.602176634e-13
        return self.activity_bq * joules_per_decay


def decay_heat(contributions: list[DecayHeatContribution]) -> float:
    """Total decay heat [W]."""
    if not contributions:
        raise DecayError("at least one contribution is required")
    return math.fsum(entry.heat_w for entry in contributions)


def decay_heat_from_chain(chain: DecayChain, initial_parent_atoms: float,
                          time_s: float) -> float:
    """Decay heat [W] from a chain, using the closed-form activities."""
    if not math.isfinite(initial_parent_atoms) or initial_parent_atoms <= 0.0:
        raise DecayError("initial parent atoms must be finite and positive")
    total = 0.0
    for index, member in enumerate(chain.members):
        atoms = bateman_activity(chain, index, initial_parent_atoms, time_s)
        joules_per_decay = member.decay_energy_mev * 1.602176634e-13
        total += atoms * member.decay_constant_per_s * joules_per_decay
    return total
