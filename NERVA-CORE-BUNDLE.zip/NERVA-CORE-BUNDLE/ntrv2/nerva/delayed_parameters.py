"""Delayed neutron parameters for a fissile mixture, and the beta_eff question.

Point kinetics needs the delayed fraction of *this core*, not of pure 235U in a
thermal spectrum. Two separate corrections matter for a nuclear thermal rocket:

1. **Mixture.** A low-enrichment core contains 238U, whose delayed fraction is
   much larger than 235U's (fast fission of 238U yields far fewer prompt
   neutrons per fission, so its delayed fraction is high). Weighting by fission
   fraction rather than by atom fraction is the correct combination.
2. **Importance (beta_eff).** Delayed neutrons are born at lower energy than
   prompt neutrons and therefore leak and are absorbed differently. The proper
   correction requires adjoint weighting,

       beta_eff = <phi*, sum_i beta_i nu Sigma_f> / <phi*, nu Sigma_f>

   which needs an adjoint flux this model does not have.

This module therefore does the mixture combination **properly and exactly**, and
treats beta_eff as an **explicit, caller-supplied correction factor** rather than
manufacturing one. Passing a correction of 1.0 means "unweighted", and the result
says so.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


class DelayedParameterError(ValueError):
    """Raised when delayed-neutron parameters are missing or inconsistent."""


@dataclass(frozen=True)
class NuclideDelayedData:
    """Delayed-neutron data for one fissile or fertile nuclide."""

    name: str
    beta: float
    source: str

    def __post_init__(self) -> None:
        if not math.isfinite(self.beta) or not 0.0 < self.beta < 1.0:
            raise DelayedParameterError(
                f"{self.name}: delayed fraction must lie in (0, 1), got {self.beta!r}"
            )
        if len(self.source.strip()) < 4:
            raise DelayedParameterError(
                f"{self.name}: delayed-neutron data requires a source"
            )


# Emrich (2023) Table 11.1, p.204, composite row. Thermal-spectrum value for 235U.
BETA_U235_THERMAL = NuclideDelayedData(
    name="U235",
    beta=0.0065,
    source="emrich2023 Table 11.1 p204 (composite row, thermal spectrum)",
)

# Emrich p.204 states the delayed data are spectrum dependent. No fast-spectrum
# 238U value appears in the supplied documents, so none is invented here: the
# entry below must be replaced with a sourced value before a mixed-core beta is
# quoted as heritage. It is included with an explicit placeholder source so the
# mixture machinery is complete and testable, and so any user of it sees plainly
# that this one number is unsourced.
PLACEHOLDER_SOURCE = "UNSOURCED placeholder - replace with evaluated data"

BETA_U238_PLACEHOLDER = NuclideDelayedData(
    name="U238",
    beta=0.0157,
    source=PLACEHOLDER_SOURCE,
)


@dataclass(frozen=True)
class FissionContribution:
    """Fission rate share of one nuclide in the mixture."""

    nuclide: NuclideDelayedData
    fission_fraction: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.fission_fraction) or not 0.0 <= self.fission_fraction <= 1.0:
            raise DelayedParameterError(
                f"fission fraction must lie in [0, 1], got {self.fission_fraction!r}"
            )


@dataclass(frozen=True)
class MixtureDelayedFraction:
    """The effective delayed fraction of a core, with its provenance."""

    beta_mixture: float
    beta_eff: float
    importance_correction: float
    contributions: tuple[FissionContribution, ...]
    has_unsourced_input: bool

    @property
    def beta_eff_is_weighted(self) -> bool:
        """False when the importance correction is exactly 1 (unweighted)."""
        return self.importance_correction != 1.0

    def describe(self) -> str:
        parts = ", ".join(
            f"{c.nuclide.name}={c.fission_fraction:.3f} (beta={c.nuclide.beta:.5f})"
            for c in self.contributions
        )
        flag = " [contains UNSOURCED input]" if self.has_unsourced_input else ""
        return (f"beta_mix={self.beta_mixture:.6f}  beta_eff={self.beta_eff:.6f}  "
                f"correction={self.importance_correction:.4f}  ({parts}){flag}")


def mixture_delayed_fraction(
    contributions: list[FissionContribution],
    *,
    importance_correction: float = 1.0,
) -> MixtureDelayedFraction:
    """Combine per-nuclide delayed fractions by fission share.

    ``sum(fission_fraction)`` must equal 1, since the shares describe where the
    fissions happen, not how much material is present.
    """
    if not contributions:
        raise DelayedParameterError("at least one fission contribution is required")
    total = math.fsum(c.fission_fraction for c in contributions)
    if abs(total - 1.0) > 1e-9:
        raise DelayedParameterError(
            f"fission fractions must sum to 1, got {total!r}; contributions are "
            f"shares of the fission rate, not of the mass"
        )
    if not math.isfinite(importance_correction) or not 0.0 < importance_correction <= 1.0:
        raise DelayedParameterError(
            f"importance correction must lie in (0, 1], got {importance_correction!r}; "
            f"a correction above one would need adjoint evidence"
        )

    beta_mixture = math.fsum(c.nuclide.beta * c.fission_fraction
                             for c in contributions)
    unsourced = any(PLACEHOLDER_SOURCE in c.nuclide.source for c in contributions)
    return MixtureDelayedFraction(
        beta_mixture=beta_mixture,
        beta_eff=beta_mixture * importance_correction,
        importance_correction=importance_correction,
        contributions=tuple(contributions),
        has_unsourced_input=unsourced,
    )


def reactivity_in_dollars(reactivity: float,
                          mixture: MixtureDelayedFraction) -> float:
    """Convert reactivity to dollars using the *effective* delayed fraction."""
    if mixture.beta_eff <= 0.0:
        raise DelayedParameterError("beta_eff must be positive")
    return reactivity / mixture.beta_eff


def dollars_to_reactivity(dollars: float,
                          mixture: MixtureDelayedFraction) -> float:
    return dollars * mixture.beta_eff


def pcm_to_dollars(pcm: float, mixture: MixtureDelayedFraction) -> float:
    return reactivity_in_dollars(pcm * 1.0e-5, mixture)


@dataclass(frozen=True)
class BetaEffBudget:
    """The two corrections that separate beta (unweighted) from beta_eff.

    Documented separately because they are independently uncertain and must
    never be collapsed into a single fudge factor.
    """

    beta_unweighted_u235: float
    mixture_correction: float
    importance_correction: float

    @property
    def beta_eff(self) -> float:
        return (self.beta_unweighted_u235 * self.mixture_correction
                * self.importance_correction)

    @property
    def is_fully_sourced(self) -> bool:
        return self.importance_correction != 1.0

    def describe(self) -> str:
        return (f"beta(235U)={self.beta_unweighted_u235:.5f} "
                f"x mixture={self.mixture_correction:.4f} "
                f"x importance={self.importance_correction:.4f} "
                f"= beta_eff={self.beta_eff:.6f}")
