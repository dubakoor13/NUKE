"""Hydrogen thermochemistry with an optional Cantera backend.

The reduced two-species model (H2 <-> 2H, NASA-7 polynomials) already exists in
``nasa_hydrogen`` and is covered by its own regressions. This module does two
things it does not:

1. Exposes a single, explicit entry point for equilibrium thermochemistry with
   the species set and provenance stated, so callers cannot accidentally treat
   a reduced model as a general one.
2. Provides a **Cantera** backend for an independent, full-mechanism
   comparison. Cantera is not installed on this machine, so that path is
   written, guarded, and verified only for its refusal behaviour.

The honest state of the art here:

============================  ==========================================
Question                      Answer
============================  ==========================================
H2 <-> 2H equilibrium         reduced two-species model, NASA-7 (works)
Full mechanism equilibrium    requires Cantera (not available)
CEA parity                    requires the ``cea`` package (see cea_oracle)
============================  ==========================================
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .nasa_hydrogen import hydrogen_state

# Emrich (2023) p.17 gives 2750 K as the highest NERVA core temperature, so
# anything much above that is outside the machine's demonstrated envelope.
NTR_TEMPERATURE_CEILING_K = 3500.0


class ThermochemistryError(ValueError):
    """Raised when a thermochemical request is outside the model's validity."""


class CanteraUnavailableError(RuntimeError):
    """Raised when the Cantera backend is requested and cannot be imported."""


@dataclass(frozen=True)
class EquilibriumState:
    """Equilibrium hydrogen composition and bulk properties."""

    temperature_k: float
    pressure_pa: float
    dissociation_fraction: float
    density_kg_m3: float
    enthalpy_j_kg: float
    entropy_j_kg_k: float
    cp_j_kg_k: float
    provider: str
    species: tuple[str, ...] = ("H2", "H")

    def __post_init__(self) -> None:
        for name in ("temperature_k", "pressure_pa", "density_kg_m3",
                     "cp_j_kg_k"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise ThermochemistryError(
                    f"{name} is not physical: {value!r}"
                )
        if not 0.0 <= self.dissociation_fraction < 1.0:
            raise ThermochemistryError(
                f"dissociation fraction must lie in [0, 1), got "
                f"{self.dissociation_fraction!r}"
            )

    @property
    def molecular_weight_kg_mol(self) -> float:
        """Mean molar mass including dissociation.

        One mole of original H2 either stays H2 (2 g/mol) or splits into two H
        atoms, so the mixture mole count is ``1 + alpha`` and the mean molar
        mass is ``2.01588 / (1 + alpha)`` grams per mole.
        """
        return 2.01588e-3 / (1.0 + self.dissociation_fraction)


def _validate(temperature_k: float, pressure_pa: float) -> None:
    for name, value in (("temperature", temperature_k), ("pressure", pressure_pa)):
        if not math.isfinite(value) or value <= 0.0:
            raise ThermochemistryError(
                f"{name} must be finite and positive, got {value!r}"
            )
    if temperature_k > NTR_TEMPERATURE_CEILING_K:
        raise ThermochemistryError(
            f"{temperature_k} K exceeds the {NTR_TEMPERATURE_CEILING_K} K ceiling "
            f"for this model; above it the two-species reduction and the "
            f"underlying polynomials are not trustworthy"
        )


def equilibrium_hydrogen_state(temperature_k: float, pressure_pa: float,
                               provider: str = "reduced") -> EquilibriumState:
    """Equilibrium H2 <-> 2H state.

    ``provider="reduced"`` uses the in-repository two-species NASA-7 model.
    ``provider="cantera"`` uses a full Cantera mechanism, which is not
    available on this machine.
    """
    _validate(temperature_k, pressure_pa)
    if provider == "reduced":
        state = hydrogen_state(temperature_k, pressure_pa, "equilibrium")
        return EquilibriumState(
            temperature_k=temperature_k,
            pressure_pa=pressure_pa,
            dissociation_fraction=float(state.dissociation_fraction),
            density_kg_m3=float(state.density_kg_m3),
            enthalpy_j_kg=float(state.enthalpy_j_kg),
            entropy_j_kg_k=float(state.entropy_j_kg_k),
            cp_j_kg_k=float(state.frozen_cp_j_kg_k),
            provider="nasa_hydrogen (2 species, GRI-Mech NASA-7)",
        )
    if provider == "cantera":
        return _cantera_equilibrium(temperature_k, pressure_pa)
    raise ThermochemistryError(
        f"unknown provider {provider!r}; expected 'reduced' or 'cantera'"
    )


def cantera_available() -> bool:
    try:
        import cantera  # noqa: F401, PLC0415
        return True
    except ImportError:
        return False


def _cantera_equilibrium(temperature_k: float, pressure_pa: float) -> EquilibriumState:
    """Full-mechanism equilibrium via Cantera.

    The mechanism is the pure-hydrogen subset: a mixture of H2 and H, so the
    species basis matches the reduced model and the comparison is like-for-like
    rather than "reduced model versus air".
    """
    if not cantera_available():
        raise CanteraUnavailableError(
            "Cantera is not importable in this interpreter. Install the cantera "
            "wheel for this Python version (cp310/cp312 win_amd64 is more likely "
            "available than cp314). Building from the cantera source tree "
            "requires SCons, Boost and a full C++ toolchain."
        )
    import cantera as ct  # noqa: PLC0415

    gas = ct.Solution("h2o2.yaml", "ohmech")
    gas.TPX = temperature_k, pressure_pa, {"H2": 1.0, "H": 1e-10}
    gas.equilibrate("TP")
    h_mole = float(gas.X[gas.species_index("H")])
    h2_mole = float(gas.X[gas.species_index("H2")])
    total = h_mole + h2_mole
    if total <= 0.0:
        raise ThermochemistryError("Cantera returned an empty H2/H mixture")
    alpha = (h_mole / total) / (1.0 + h_mole / total)
    return EquilibriumState(
        temperature_k=temperature_k,
        pressure_pa=pressure_pa,
        dissociation_fraction=alpha,
        density_kg_m3=float(gas.density),
        enthalpy_j_kg=float(gas.enthalpy_mass),
        entropy_j_kg_k=float(gas.entropy_mass),
        cp_j_kg_k=float(gas.cp_mass),
        provider="Cantera (full mechanism)",
    )


def compare_providers(temperature_k: float, pressure_pa: float
                      ) -> tuple[EquilibriumState, EquilibriumState]:
    """Return (reduced, cantera) states for the same condition."""
    return (equilibrium_hydrogen_state(temperature_k, pressure_pa, "reduced"),
            equilibrium_hydrogen_state(temperature_k, pressure_pa, "cantera"))


def dissociation_scaling(temperature_k: float, pressure_pa: float) -> dict[str, float]:
    """Diagnostic: how much alpha changes with T and with P.

    Included because the reduced model's dissociation is the single most
    model-sensitive quantity in the hot leg, and having its sensitivity visible
    is more useful than a single number.
    """
    base = equilibrium_hydrogen_state(temperature_k, pressure_pa)
    hotter = equilibrium_hydrogen_state(temperature_k + 100.0, pressure_pa)
    denser = equilibrium_hydrogen_state(temperature_k, pressure_pa * 2.0)
    return {
        "alpha": base.dissociation_fraction,
        "alpha_per_100k": hotter.dissociation_fraction - base.dissociation_fraction,
        "alpha_pressure_doubling": denser.dissociation_fraction - base.dissociation_fraction,
    }
