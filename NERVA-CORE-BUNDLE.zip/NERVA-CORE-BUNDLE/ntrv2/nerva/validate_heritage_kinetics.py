"""Verify point-kinetics methods against the book's own tabulated identities.

Emrich Ch. 11 gives no numerical worked example for the Inhour equation, but it
gives two things that are just as strong as oracles:

* Table 11.1 (p.204) prints six delayed groups AND the composite row. The
  composite row is over-determined by the six groups, so it can be used as a
  consistency target (p.191 defines the identity).
* Eqs. (11.7) and (11.9) together define an exact eigen-solution. Substituting
  it into the implemented RHS must return omega exactly. That checks the
  reaction-rate equations and the root solver against each other with no
  integration error at all.

A short RK4 integration then confirms the eigen-solution is the one the ODEs
actually converge to.
"""
from __future__ import annotations

import math
from pathlib import Path

from .heritage import kinetics as kin
from .heritage.registry import load_registry

DATA = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"

BOOK_BETA_COMPOSITE = 0.0065
BOOK_LAMBDA_COMPOSITE = 0.0764


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<44} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    registry = load_registry(DATA)
    groups = kin.u235_delayed_groups(registry)
    print(f"loaded {len(registry)} cited delayed-neutron entries "
          f"({groups.n_groups} groups)\n")

    # ---- 1. Table 11.1 is internally consistent -------------------------
    print("Table 11.1 consistency (p.204):")
    beta_sum = groups.beta_total
    beta_book = registry.value("u235.delayed.beta.composite")
    rel = abs(beta_sum - beta_book) / beta_book
    results.append(_report("sum(beta_i) reproduces composite beta",
                           rel < 1e-12,
                           f"sum={beta_sum:.6f} book={beta_book} rel={rel:.1e}"))
    results.append(_report("sum(beta_i) equals printed 0.0065",
                           abs(beta_sum - BOOK_BETA_COMPOSITE) < 1e-12,
                           f"code={beta_sum:.6f} book={BOOK_BETA_COMPOSITE}"))

    lam_one = groups.composite_decay_constant()
    rel = abs(lam_one - BOOK_LAMBDA_COMPOSITE) / BOOK_LAMBDA_COMPOSITE
    results.append(_report("composite lambda from Eq. (p.191) identity",
                           rel < 1e-3,
                           f"code={lam_one:.6f} book={BOOK_LAMBDA_COMPOSITE} "
                           f"rel={rel*100:.3f}%"))

    # ---- 2. Criticality is exact --------------------------------------
    print("\nInhour behaviour:")
    for lifetime in (0.0, 1e-4, 1e-3):
        omega = kin.solve_period_constant(0.0, lifetime, groups)
        results.append(_report(f"rho=0 gives omega=0 exactly (L={lifetime})",
                               omega == 0.0, f"omega={omega!r}"))

    # ---- 3. One-group closed form as an independent oracle -------------
    # NOTE: a six-group reactor and a one-group reactor with the composite
    # lambda are NOT the same system, so comparing them is not a valid test.
    # The honest oracle is to solve the ONE-group system by the numerical
    # solver and by the analytic quadratic, which must agree exactly.
    print("\none-group: numerical solver vs analytic quadratic (true oracle):")
    for rho in (0.0001, 0.0005, 0.001, 0.003, -0.0005, -0.002):
        for lifetime in (0.0, 1e-4):
            solver = kin.solve_period_constant(rho, lifetime, groups.one_group())
            analytic = kin.one_group_omega_exact(rho, lifetime, groups)
            rel = abs(solver - analytic) / abs(analytic)
            results.append(_report(f"rho={rho:+.4f} L={lifetime:g}", rel < 1e-9,
                                   f"solver={solver:+.8f} quadratic={analytic:+.8f} "
                                   f"rel={rel:.1e}"))

    # Six-group asymptotic: for rho -> 0, omega/rho -> 1/sum(beta_i/lambda_i).
    print("\nsix-group asymptotic limit (p.191 identity):")
    weighted = math.fsum(b / l for b, l in zip(groups.beta, groups.lam))
    previous_error = None
    converging = True
    for rho in (1e-4, 1e-5, 1e-6, 1e-7):
        omega = kin.solve_period_constant(rho, 0.0, groups)
        ratio = omega / rho
        error = abs(ratio - 1.0 / weighted)
        converging = converging and (previous_error is None or error < previous_error)
        previous_error = error
        print(f"    rho={rho:.0e}  omega/rho={ratio:.8f}  "
              f"target={1.0/weighted:.8f}  |error|={error:.2e}")
    results.append(_report("omega/rho -> 1/sum(beta_i/lambda_i) as rho -> 0",
                           converging, f"target={1.0/weighted:.8f}"))

    # ---- 4. Exact eigen-solution residual -----------------------------
    print("\neigen-solution must satisfy the implemented RHS exactly (Eqs 11.7+11.9):")
    for rho, lifetime in ((0.001, 1e-4), (-0.001, 1e-4), (0.0065, 1e-4)):
        omega = kin.solve_period_constant(rho, lifetime, groups)
        n0 = 1.0
        precursors = [b / (lifetime * (omega + lam)) * n0
                      for b, lam in zip(groups.beta, groups.lam)]
        dn, dc = kin.point_kinetics_rhs(n0, precursors, rho, lifetime, groups)
        residual = abs(dn - omega * n0) / max(abs(omega), 1e-30)
        for value, expected in zip(dc, precursors):
            residual = max(residual, abs(value - omega * expected) / max(abs(omega), 1e-30))
        results.append(_report(f"rho={rho:+.4f} L={lifetime:g}",
                               residual < 1e-9,
                               f"omega={omega:+.6f} max rel residual={residual:.1e}"))

    # ---- 5. Inhour residual at the solved root ------------------------
    print("\nInhour residual at the solved root (must vanish):")
    for rho in (0.002, -0.003):
        omega = kin.solve_period_constant(rho, 1e-4, groups)
        back = kin.inhour_reactivity(omega, 1e-4, groups)
        results.append(_report(f"rho={rho:+.4f}", abs(back - rho) < 1e-12,
                               f"recovered rho={back:+.12f}"))

    # ---- 6. Sign and monotonicity -------------------------------------
    print("\nphysical sign and monotonicity:")
    negative = kin.solve_period_constant(-0.001, 1e-4, groups)
    lam_min = min(groups.lam)
    results.append(_report("subcritical gives omega in (-lambda_min, 0)",
                           -lam_min < negative < 0.0,
                           f"omega={negative:+.6f} lambda_min={lam_min}"))
    sequence = [kin.solve_period_constant(r, 1e-4, groups)
                for r in (0.0005, 0.001, 0.002, 0.004)]
    increasing = all(b > a for a, b in zip(sequence, sequence[1:]))
    results.append(_report("omega increases monotonically with rho", increasing,
                           " ".join(f"{v:+.4f}" for v in sequence)))

    # ---- 7. Dollars and prompt criticality ----------------------------
    print("\nreactivity units:")
    one_dollar = kin.dollars(groups.beta_total, groups)
    results.append(_report("rho = beta is exactly 1 dollar",
                           abs(one_dollar - 1.0) < 1e-15, f"{one_dollar}"))
    omega_at = kin.solve_period_constant(groups.beta_total, 1e-4, groups)
    omega_above = kin.solve_period_constant(2.0 * groups.beta_total, 1e-4, groups)
    results.append(_report("above prompt critical the response steepens",
                           omega_above > 3.0 * omega_at,
                           f"omega(beta)={omega_at:.2f} omega(2beta)={omega_above:.2f}"))
    # For rho >> beta and omega >> lambda_max the Inhour equation reduces to
    # rho ~ omega*L + beta, so omega -> (rho - beta)/L. That limit is only
    # approached asymptotically: the residual is sum(beta_i*lambda_i)/omega,
    # so the right test is that the error SHRINKS as rho grows, not that it is
    # already tiny at rho = 2*beta.
    print("\nasymptotic approach to omega -> (rho-beta)/L:")
    errors = {}
    for multiple in (2.0, 10.0):
        omega_m = kin.solve_period_constant(multiple * groups.beta_total, 1e-4, groups)
        predicted_m = (multiple * groups.beta_total - groups.beta_total) / 1e-4
        errors[multiple] = abs(omega_m - predicted_m) / predicted_m
        print(f"    rho={multiple:.0f}*beta  omega={omega_m:8.2f}  "
              f"(rho-beta)/L={predicted_m:8.2f}  rel={errors[multiple]*100:.4f}%")
    results.append(_report("error shrinks as reactivity grows",
                           errors[10.0] < errors[2.0],
                           f"{errors[2.0]*100:.4f}% -> {errors[10.0]*100:.4f}%"))
    results.append(_report("limit accurate to 0.1% at 10*beta",
                           errors[10.0] < 1e-3,
                           f"rel={errors[10.0]*100:.4f}%"))

    # ---- 8. RK4 integration converges to the eigen-period -------------
    # A step insertion starts with a prompt jump, so measuring the growth rate
    # from t=0 would include that transient and overstate omega. The rate is
    # measured between two late times instead, where only the fundamental
    # (slowest) mode survives.
    print("\nRK4 integration of Eqs (11.3)+(11.4) reaches the predicted period:")
    lifetime = 1e-3
    rho = 0.003
    omega = kin.solve_period_constant(rho, lifetime, groups)
    n = 1.0
    c = kin.equilibrium_precursors(n, lifetime, groups)
    dt = 1e-3
    step_window_start = 20_000     # t = 20 s
    steps = 40_000                 # t = 40 s
    n_at_window = None
    for step in range(steps):
        if step == step_window_start:
            n_at_window = n
        k1n, k1c = kin.point_kinetics_rhs(n, c, rho, lifetime, groups)
        k2n, k2c = kin.point_kinetics_rhs(n + 0.5*dt*k1n,
                                          [ci + 0.5*dt*ki for ci, ki in zip(c, k1c)],
                                          rho, lifetime, groups)
        k3n, k3c = kin.point_kinetics_rhs(n + 0.5*dt*k2n,
                                          [ci + 0.5*dt*ki for ci, ki in zip(c, k2c)],
                                          rho, lifetime, groups)
        k4n, k4c = kin.point_kinetics_rhs(n + dt*k3n,
                                          [ci + dt*ki for ci, ki in zip(c, k3c)],
                                          rho, lifetime, groups)
        n += dt / 6.0 * (k1n + 2*k2n + 2*k3n + k4n)
        c = [ci + dt / 6.0 * (a + 2*b + 2*d + e)
             for ci, a, b, d, e in zip(c, k1c, k2c, k3c, k4c)]
    window = (steps - step_window_start) * dt
    measured = math.log(n / n_at_window) / window
    rel = abs(measured - omega) / omega
    results.append(_report("integrated growth rate matches solver",
                           rel < 2e-2,
                           f"integrated={measured:.6f} inhour={omega:.6f} "
                           f"rel={rel*100:.3f}%"))

    # ---- 9. Feedback closure ------------------------------------------
    print("\ntemperature feedback closure:")
    rho_fb = kin.reactivity_with_feedback(
        1e-3, alphas=(-3e-5, -1e-6), temperatures=(2500.0, 900.0),
        reference_temperatures=(293.6, 600.0),
    )
    lower = rho_fb < 1e-3
    results.append(_report("negative Doppler reduces inserted reactivity",
                           lower, f"rho_ext=1.0e-3 -> rho_total={rho_fb:.6e}"))
    zero = kin.reactivity_with_feedback(
        1e-3, alphas=(-3e-5, -1e-6), temperatures=(293.6, 600.0),
        reference_temperatures=(293.6, 600.0),
    )
    results.append(_report("at reference temperature feedback vanishes",
                           abs(zero - 1e-3) < 1e-18, f"{zero!r}"))

    # ---- 10. Guards ----------------------------------------------------
    print("\nperiod sign convention (negative omega is a legitimate decay):")
    decaying = kin.stable_period(kin.solve_period_constant(-0.002, 1e-4, groups))
    results.append(_report("subcritical reactor has a negative period",
                           decaying < 0.0, f"period={decaying:.3f} s"))
    # The delayed neutrons exist to make the period controlable: show that a
    # one-dollar insertion still yields a period far longer than the prompt
    # lifetime, which is the whole point of the book's opening paragraph.
    prompt_period = kin.stable_period(
        kin.solve_period_constant(groups.beta_total, 1e-4, groups))
    results.append(_report("period at rho=beta greatly exceeds prompt lifetime",
                           prompt_period > 100 * 1e-4,
                           f"period={prompt_period:.3f} s vs L=1.0e-04 s"))

    print("\nguard checks (each must raise):")
    guards = [
        ("negative lifetime", lambda: kin.solve_period_constant(1e-3, -1.0, groups)),
        ("omega on an Inhour pole", lambda: kin.inhour_reactivity(-0.0305, 1e-4, groups)),
        ("critical reactor has no period", lambda: kin.stable_period(0.0)),
        ("wrong precursor count",
         lambda: kin.point_kinetics_rhs(1.0, [0.0], 1e-3, 1e-4, groups)),
        ("mismatched feedback arrays",
         lambda: kin.reactivity_with_feedback(0.0, [-1e-5], [1.0, 2.0], [0.0])),
        ("non-positive delayed group",
         lambda: kin.DelayedGroups(beta=(0.001, 0.0), lam=(0.1, 0.2))),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ValueError, ZeroDivisionError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: point-kinetics methods reproduce Emrich (2023) Ch.11 identities")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
