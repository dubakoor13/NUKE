"""Verify the CEA oracle's deck generation, parsing and refusal path.

The CEA executable cannot run on this machine (missing Intel Fortran runtimes)
and the ``cea`` python package is not installed, so this suite verifies
everything that does not require them: the input deck format, the output
parser, input validation, and that execution refuses with the real reason
rather than returning a fabricated comparison.
"""
from __future__ import annotations

import math

from .cea_oracle import (
    CeaCase,
    CeaResult,
    CeaUnavailableError,
    _parse_cea_output,
    build_deck,
    preflight,
    require_backend,
    run_case,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    case = CeaCase(temperature_k=2500.0, pressure_bar=45.0)

    # ---- deck generation (pure, always testable) ----------------------
    print("CEA input deck generation:")
    deck = build_deck(case)
    print("    " + deck.replace("\n", "\n    ").rstrip())
    lines = [line for line in deck.splitlines() if line.strip()]
    results.append(_report("deck opens a tp problem",
                           lines[0].split()[:3] == ["problem", "tp", "new"],
                           lines[0].strip()))
    results.append(_report("deck declares a pure H2 fuel",
                           any("fuel" in line and "H2" in line for line in lines),
                           "fuel H2 wt=1.0"))
    results.append(_report("deck restricts products to H and H2",
                           any(line.strip().startswith("only") and "H2" in line
                               for line in lines),
                           "only H H2"))
    results.append(_report("deck carries the pressure in bar",
                           any("p,bar=45.000000" in line for line in lines),
                           "p,bar=45.000000"))
    results.append(_report("deck carries the temperature in kelvin",
                           any("t,k=2500.0000" in line for line in lines),
                           "t,k=2500.0000"))
    results.append(_report("deck terminates with 'end'",
                           lines[-1].strip() == "end", lines[-1].strip()))
    restricted = build_deck(case, only_hydrogen=False)
    results.append(_report("'only' line can be suppressed",
                           "only" not in restricted, "full CEA species set"))

    # ---- output parsing (pure, always testable) ----------------------
    print("\nCEA output parsing against the printed table format:")
    synthetic_output = (
        "      THEORETICAL ROCKET PERFORMANCE ASSUMING EQUILIBRIUM\n"
        "         P, BAR              45.0000\n"
        "         T, K                2500.0000\n"
        "         DENSITY, KG/CU M      0.8735\n"
        "         H, KJ/KG            -1400.2000\n"
        "         S, KJ/(KG)(K)        75.4100\n"
        "         CP, KJ/(KG)(K)       17.8200\n"
        "         GAMMAS               1.3010\n"
        "         M, (1/n)              2.0159\n"
    )
    parsed = _parse_cea_output(synthetic_output, case, backend="synthetic-test")
    print(f"    parsed: cp={parsed.cp_j_kg_k} J/kg-K  gamma={parsed.gamma}  "
          f"rho={parsed.density_kg_m3} kg/m3  H={parsed.enthalpy_j_kg} J/kg")
    results.append(_report("cp parsed and converted kJ -> J",
                           parsed.cp_j_kg_k is not None
                           and abs(parsed.cp_j_kg_k - 17820.0) < 1e-6,
                           f"{parsed.cp_j_kg_k} J/kg-K"))
    results.append(_report("gamma parsed",
                           parsed.gamma is not None
                           and abs(parsed.gamma - 1.301) < 1e-9, f"{parsed.gamma}"))
    results.append(_report("density parsed",
                           parsed.density_kg_m3 is not None
                           and abs(parsed.density_kg_m3 - 0.8735) < 1e-9,
                           f"{parsed.density_kg_m3} kg/m3"))
    results.append(_report("enthalpy converted kJ -> J",
                           parsed.enthalpy_j_kg is not None
                           and abs(parsed.enthalpy_j_kg + 1_400_200.0) < 1e-6,
                           f"{parsed.enthalpy_j_kg} J/kg"))
    missing = _parse_cea_output("no property table here", case, backend="x")
    results.append(_report("absent properties stay None, never invented",
                           missing.cp_j_kg_k is None and missing.gamma is None,
                           "None rather than a fabricated zero"))

    # ---- dissociation algebra ----------------------------------------
    print("\ndissociation fraction from the H mole fraction:")
    for x_h, expected in ((0.0, 0.0), (0.1, 0.1 / 1.1), (1.0, 0.5)):
        probe = CeaResult(case=case, temperature_k=2500.0, pressure_bar=45.0,
                          h_mole_fraction=x_h)
        got = probe.dissociation_fraction
        results.append(_report(f"x_H={x_h} -> alpha={expected:.5f}",
                               abs(got - expected) < 1e-12, f"{got:.6f}"))

    # ---- refusal path -------------------------------------------------
    print("\nbackend availability and refusal:")
    problems = preflight()
    results.append(_report("preflight reports what is missing",
                           len(problems) >= 1, f"{len(problems)} problem(s)"))
    text = " ".join(problems).lower()
    results.append(_report("mentions the cea package or the executable",
                           "cea" in text, problems[0][:56] if problems else ""))
    results.append(_report("mentions the missing Fortran runtime",
                           "libifcoremd" in text or "intel fortran" in text,
                           "actionable diagnosis present"))
    try:
        require_backend()
    except CeaUnavailableError as exc:
        results.append(True)
        print(f"  [PASS] require_backend raises: {str(exc).splitlines()[0]}")
    else:
        results.append(False)
        print("  [FAIL] require_backend passed without a working CEA")
    try:
        run_case(case)
    except CeaUnavailableError:
        results.append(True)
        print("  [PASS] run_case refuses instead of fabricating a comparison")
    else:
        results.append(False)
        print("  [FAIL] run_case returned without a CEA backend")

    # ---- input validation ---------------------------------------------
    print("\ninvalid cases are rejected:")
    guards = [
        ("zero temperature", lambda: CeaCase(temperature_k=0.0, pressure_bar=1.0)),
        ("negative pressure", lambda: CeaCase(temperature_k=2500.0,
                                              pressure_bar=-1.0)),
        ("nan temperature", lambda: CeaCase(temperature_k=float("nan"),
                                            pressure_bar=1.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except ValueError:
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: CEA oracle builds decks, parses output and refuses without a backend")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
