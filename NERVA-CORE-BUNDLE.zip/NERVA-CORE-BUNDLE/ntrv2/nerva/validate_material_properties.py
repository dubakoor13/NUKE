"""Verify the cited material property tables.

Every value is checked against Emrich Table 15.2 as transcribed, and the
interpolation is checked for the properties that matter: endpoints must reproduce
the table exactly, interpolation must be monotone where the table is, and
extrapolation must be refused rather than invented.
"""
from __future__ import annotations

import math

from .material_properties import (
    GRAPHITE_TEMPERATURES_K,
    CitedMaterials,
    MaterialError,
    PropertyTable,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    materials = CitedMaterials.load()

    # ---- transcription -------------------------------------------------
    print("Table 15.2 transcription (Emrich p.297):")
    print("\n".join("    " + line for line in materials.summary().splitlines()))
    density = materials.graphite_density
    results.append(_report("density spans all six temperatures",
                           density.temperatures_k == GRAPHITE_TEMPERATURES_K,
                           f"{len(density.temperatures_k)} points"))
    results.append(_report("density at 1000 K is 1.605 g/cm3",
                           abs(density.values[0] - 1.605) < 1e-12, "1.605"))
    results.append(_report("density at 3500 K is 1.540 g/cm3",
                           abs(density.values[-1] - 1.540) < 1e-12, "1.540"))
    results.append(_report("density falls with temperature (thermal expansion)",
                           density.relative_change() < 0.0,
                           f"{density.relative_change()*100:+.2f}%"))
    heat = materials.graphite_specific_heat
    results.append(_report("specific heat rises 1.80 -> 2.30 J/g/K",
                           abs(heat.values[0] - 1.80) < 1e-12
                           and abs(heat.values[-1] - 2.30) < 1e-12,
                           f"{heat.values[0]} -> {heat.values[-1]}"))
    results.append(_report("specific heat increases with temperature",
                           heat.relative_change() > 0.0,
                           f"{heat.relative_change()*100:+.1f}%"))
    conductivity = materials.graphite_thermal_conductivity
    results.append(_report("conductivity falls 0.57 -> 0.30 W/cm/K",
                           abs(conductivity.values[0] - 0.57) < 1e-12
                           and abs(conductivity.values[-1] - 0.30) < 1e-12,
                           f"{conductivity.values[0]} -> {conductivity.values[-1]}"))
    results.append(_report("conductivity table stops at 2500 K as tabulated",
                           conductivity.range_k == (1000.0, 2500.0),
                           f"{conductivity.range_k}"))
    results.append(_report("every table value carries a citation",
                           all(len(table.citations) == len(table.values)
                               for table in (density, heat,
                                             materials.graphite_thermal_conductivity)),
                           "page + locator on each"))

    # ---- interpolation -------------------------------------------------
    print("\ninterpolation:")
    for temperature in GRAPHITE_TEMPERATURES_K:
        interpolated = density.at(temperature)
        index = density.temperatures_k.index(temperature)
        results.append(_report(f"reproduces the table exactly at {temperature:.0f} K",
                               abs(interpolated - density.values[index]) < 1e-12,
                               f"{interpolated:.4f} g/cm3"))
    midpoint = density.at(1250.0)
    expected = 0.5 * (1.605 + 1.595)
    results.append(_report("midpoint is the arithmetic mean (linear)",
                           abs(midpoint - expected) < 1e-12, f"{midpoint:.4f}"))
    results.append(_report("interpolation is monotone between points",
                           density.at(1100.0) > density.at(1400.0),
                           f"{density.at(1100.0):.4f} > {density.at(1400.0):.4f}"))
    results.append(_report("a value stays inside its bracketing entries",
                           density.values[0] >= midpoint >= density.values[1],
                           "bounded by neighbours"))

    # ---- refusal -------------------------------------------------------
    print("\nextrapolation is refused:")
    for temperature in (900.0, 3600.0):
        try:
            density.at(temperature)
        except MaterialError:
            results.append(True)
            print(f"  [PASS] refused {temperature:.0f} K (outside 1000-3500 K)")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {temperature:.0f} K outside the table")
    try:
        conductivity.at(3000.0)
    except MaterialError:
        results.append(True)
        print("  [PASS] refused 3000 K for conductivity (table ends at 2500 K)")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED 3000 K for a table that ends at 2500 K")

    # ---- the ZrH design limit ------------------------------------------
    print("\nZrH decomposition limit (Emrich p.298):")
    limit = materials.zrh_decomposition_temperature_k
    print(f"    limit = {limit:.2f} K ({limit - 273.15:.1f} C)")
    results.append(_report("limit is 800 C in kelvin",
                           abs(limit - 1073.15) < 0.01, f"{limit:.2f} K"))
    materials.check_zrh(700.0)
    results.append(_report("700 K is acceptable for ZrH", True, "no exception"))
    try:
        materials.check_zrh(1200.0)
    except MaterialError:
        results.append(True)
        print("  [PASS] rejected ZrH at 1200 K")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED ZrH above its decomposition temperature")

    # ---- table validation ----------------------------------------------
    print("\ninvalid tables are rejected:")
    guards = [
        ("length mismatch", lambda: PropertyTable(
            name="x", unit="m", temperatures_k=(1.0, 2.0), values=(1.0,),
            citations=("c",))),
        ("non-increasing temperatures", lambda: PropertyTable(
            name="x", unit="m", temperatures_k=(2.0, 1.0), values=(1.0, 2.0),
            citations=("c", "c"))),
        ("negative property", lambda: PropertyTable(
            name="x", unit="m", temperatures_k=(1.0,), values=(-1.0,),
            citations=("c",))),
        ("empty table", lambda: PropertyTable(
            name="x", unit="m", temperatures_k=(), values=(), citations=())),
    ]
    for label, fn in guards:
        try:
            fn()
        except (MaterialError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: material properties are cited, interpolated and never extrapolated")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
