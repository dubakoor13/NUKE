"""The doctor entry point: ``python -m ntr.nerva.doctor``."""
from __future__ import annotations

from .preflight import main

if __name__ == "__main__":
    raise SystemExit(main())
