"""Verify shielding and the reactor control system.

Shielding checks: the Taylor coefficients are verified against Table 14.1, the
buildup factor must be exactly 1 at zero optical thickness, and the slab
attenuation must be exactly 1 at zero thickness (the geometric integrals are
normalised). Controls checks: rate limiting, anti-windup, setpoint tracking and
independent latching protection.
"""
from __future__ import annotations

import math

from .control_system import (
    ControlSystemError,
    ControllerState,
    DrumDrive,
    PidGains,
    ProtectionSystem,
    TripChannel,
    simulate_controlled_operation,
    update_controller,
)
from .shielding import (
    TABLE_ENERGIES_MEV,
    TAYLOR_TABLE,
    AttenuationCoefficients,
    ShieldingError,
    exponential_integral_e1,
    exponential_integral_e2,
    narrow_beam_transmission,
    point_kernel,
    slab_dose_rate,
    slab_transmission,
    taylor_buildup,
    thickness_for_attenuation,
)

# Iron at 3 MeV, Table 14.1. mu is an illustrative value: Emrich gives no
# tabulated attenuation coefficients (Fig. 14.5 is a plot).
MU_IRON_3MEV = AttenuationCoefficients(
    material="iron", energy_mev=3.0, mu_per_cm=0.32,
    source="SYNTHETIC test value for unit checks")


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- Table 14.1 provenance ----------------------------------------
    print("Table 14.1 buildup coefficients:")
    results.append(_report("eight materials are tabulated",
                           len(TAYLOR_TABLE) == 8, f"{sorted(TAYLOR_TABLE)}"))
    iron = taylor_buildup("iron", 3.0)
    print(f"    iron @ 3 MeV: A={iron.a} alpha={iron.alpha} beta={iron.beta}")
    results.append(_report("iron coefficients match the book (4.4, -0.077, 0.075)",
                           iron.a == 4.4 and iron.alpha == -0.077
                           and iron.beta == 0.075, "exact transcription"))
    water = taylor_buildup("Water", 1.0)
    results.append(_report("water coefficients match (11, -0.104, 0.030)",
                           water.a == 11.0 and water.alpha == -0.104
                           and water.beta == 0.030, "exact transcription"))
    hydro = taylor_buildup("liquid hydrogen", 6.0)
    results.append(_report("liquid hydrogen (LCH4-like) row matches",
                           hydro.a == 6.82, "A=6.82 at 6 MeV"))
    results.append(_report("liquid hydrogen has no 10 MeV entry (as tabulated)",
                           max(TAYLOR_TABLE["liquid_hydrogen"]) == 6.0,
                           "table genuinely ends at 6 MeV"))

    # ---- buildup factor behaviour -------------------------------------
    print("\nbuildup factor:")
    for material in ("water", "iron", "lead", "uranium"):
        sample = taylor_buildup(material, 3.0)
        at_zero = sample.factor(0.0)
        at_one = sample.factor(1.0)
        print(f"    {material:8} B(0)={at_zero:.6f}  B(1)={at_one:.4f}")
        results.append(_report(f"{material}: B(0) is exactly 1",
                               abs(at_zero - 1.0) < 1e-12, f"{at_zero:.12f}"))
        results.append(_report(f"{material}: B grows with optical thickness",
                               at_one > at_zero, f"{at_one:.4f} > {at_zero:.4f}"))

    # ---- exponential integrals ----------------------------------------
    print("\nexponential integrals:")
    results.append(_report("E2(0) = 1 exactly", exponential_integral_e2(0.0) == 1.0,
                           "boundary value"))
    results.append(_report("E1 and E2 decrease monotonically",
                           all(exponential_integral_e2(z) > exponential_integral_e2(z + 0.5)
                               for z in (0.1, 1.0, 5.0, 20.0)),
                           "monotone"))
    # Numerical quadrature as an independent check. NOTE the convention: the
    # book's E_n(x) integrates exp(-x t)/t^n from t = 1, so that E_n(0) = 1.
    # An earlier version of this test integrated exp(-t)/t^2 from z, which is the
    # mathematical-physics E2 and not the shielding one - the two disagree by a
    # factor of ~3 at x = 0.3.
    def quadrature_e1(z: float) -> float:
        steps = 400000
        h = 60.0 / steps
        total = 0.0
        for index in range(steps):
            t = 1.0 + (index + 0.5) * h
            total += math.exp(-z * t) / t
        return total * h

    def quadrature_e2(z: float) -> float:
        steps = 400000
        h = 60.0 / steps
        total = 0.0
        for index in range(steps):
            t = 1.0 + (index + 0.5) * h
            total += math.exp(-z * t) / (t * t)
        return total * h

    for z in (0.3, 2.0):
        analytic = exponential_integral_e1(z)
        numeric = quadrature_e1(z)
        results.append(_report(f"E1({z}) matches quadrature",
                               abs(analytic - numeric) / max(abs(numeric), 1e-30) < 1e-5,
                               f"{analytic:.8f} vs {numeric:.8f}"))
        analytic2 = exponential_integral_e2(z)
        numeric2 = quadrature_e2(z)
        results.append(_report(f"E2({z}) matches quadrature",
                               abs(analytic2 - numeric2) / max(abs(numeric2), 1e-30) < 1e-5,
                               f"{analytic2:.8f} vs {numeric2:.8f}"))

    # ---- slab attenuation ---------------------------------------------
    print("\nslab attenuation (Eq. 14.21):")
    results.append(_report("zero thickness gives exactly unit transmission",
                           abs(slab_transmission(iron, MU_IRON_3MEV.mu_per_cm, 0.0)
                               - 1.0) < 1e-12,
                           f"{slab_transmission(iron, 0.32, 0.0):.12f}"))
    for thickness in (5.0, 20.0, 50.0, 100.0):
        ratio = slab_transmission(iron, MU_IRON_3MEV.mu_per_cm, thickness)
        narrow = narrow_beam_transmission(MU_IRON_3MEV.mu_per_cm, thickness)
        print(f"    {thickness:5.0f} cm: slab {ratio:.6e}   narrow-beam {narrow:.6e}")
        results.append(_report(f"{thickness:.0f} cm: attenuation ratio below 1",
                               0.0 < ratio < 1.0, f"{ratio:.4e}"))
    monotone = all(slab_transmission(iron, 0.32, z) >
                   slab_transmission(iron, 0.32, z + 5.0) for z in (1.0, 10.0, 40.0))
    results.append(_report("transmission decreases monotonically with thickness",
                           monotone, "monotone"))

    # ---- half-value layer and sizing -----------------------------------
    print("\nhalf-value layer and shield sizing:")
    hvl = MU_IRON_3MEV.half_value_layer_cm()
    narrow_at_hvl = narrow_beam_transmission(MU_IRON_3MEV.mu_per_cm, hvl)
    print(f"    narrow-beam HVL = {hvl:.4f} cm -> transmission {narrow_at_hvl:.6f}")
    results.append(_report("a narrow beam halves in one HVL",
                           abs(narrow_at_hvl - 0.5) < 1e-12, f"{narrow_at_hvl:.12f}"))
    target = 1.0e-4
    needed = thickness_for_attenuation(iron, 0.32, target)
    achieved = slab_transmission(iron, 0.32, needed)
    print(f"    to reach {target:.0e}: {needed:.3f} cm -> {achieved:.3e}")
    results.append(_report("solved thickness hits the target ratio",
                           abs(achieved - target) / target < 1e-6,
                           f"{achieved:.4e} vs {target:.0e}"))
    results.append(_report("solved thickness is physically plausible",
                           1.0 < needed < 1000.0, f"{needed:.2f} cm"))

    # ---- point kernel and dose ----------------------------------------
    print("\npoint kernel and dose rate:")
    kernel = point_kernel(0.1, 10.0, 0.32, 50.0, iron, 200.0)
    print(f"    kernel = {kernel:.6e} /cm2")
    results.append(_report("kernel is finite and positive",
                           math.isfinite(kernel) and kernel > 0.0, f"{kernel:.3e}"))
    results.append(_report("inverse-square falloff holds at zero attenuation",
                           abs(point_kernel(0.0, 0.0, 0.0, 0.0,
                                            taylor_buildup("water", 3.0), 100.0)
                               / point_kernel(0.0, 0.0, 0.0, 0.0,
                                              taylor_buildup("water", 3.0), 200.0)
                               - 4.0) < 1e-9,
                           "ratio 4 for doubled distance"))
    dose = slab_dose_rate(1.0e10, iron, 0.32, 50.0, 1.0e-12)
    results.append(_report("dose rate scales with surface intensity",
                           abs(slab_dose_rate(2.0e10, iron, 0.32, 50.0, 1.0e-12)
                               / dose - 2.0) < 1e-9,
                           "linear in intensity"))

    # ---- control system: actuator -------------------------------------
    print("\ncontrol actuator:")
    drive = DrumDrive(rate_deg_per_s=0.5, travel_deg=180.0)
    moved = drive.step(0.0, 100.0, 1.0)
    print(f"    demand 100 deg in 1 s at 0.5 deg/s -> {moved:.4f} deg")
    results.append(_report("rate limit caps the movement",
                           abs(moved - 0.5) < 1e-12, f"{moved:.6f} deg"))
    results.append(_report("travel limit clamps at the stop",
                           drive.step(179.9, 500.0, 100.0) == 180.0, "180 deg"))
    results.append(_report("settling time matches change / rate",
                           abs(drive.settling_time_s(10.0) - 20.0) < 1e-12,
                           f"{drive.settling_time_s(10.0):.3f} s"))

    # ---- control system: regulator ------------------------------------
    print("\nregulator:")
    gains = PidGains(kp=1.0, ki=0.1, kd=0.0)
    output = update_controller(measurement=0.0, setpoint=10.0, gains=gains,
                               state=ControllerState(), dt_s=1.0)
    results.append(_report("proportional term responds to the error",
                           abs(output.raw_deg - 10.0) < 1e-12,
                           f"raw {output.raw_deg:.4f} deg"))
    results.append(_report("integrator accumulates when not saturated",
                           output.state.integral > 0.0,
                           f"integral {output.state.integral:.4f}"))
    saturated = update_controller(measurement=0.0, setpoint=1.0e6, gains=gains,
                                  state=ControllerState(), dt_s=1.0,
                                  angle_bounds=(-180.0, 180.0))
    results.append(_report("output is clamped to the angle bounds",
                           saturated.demanded_deg == 180.0, "180 deg"))
    results.append(_report("anti-windup freezes the integrator when saturated",
                           saturated.state.integral == 0.0,
                           f"integral {saturated.state.integral}"))
    inside = update_controller(measurement=10.0, setpoint=10.0, gains=gains,
                               state=ControllerState(), dt_s=1.0, deadband=0.5)
    results.append(_report("deadband zeroes a small error",
                           inside.error == 0.0, "error suppressed"))

    # ---- control system: closed loop ----------------------------------
    print("\nclosed-loop regulation against an analytic plant:")
    # Plant: measurement responds to drum angle with a linear coefficient.
    def plant(angle_deg: float) -> float:
        return 1.0 + 0.01 * angle_deg

    closed = simulate_controlled_operation(
        plant, initial_measurement=1.0, setpoint=2.0,
        gains=PidGains(kp=100.0, ki=20.0), drive=DrumDrive(rate_deg_per_s=5.0),
        duration_s=400.0, dt_s=0.1, settle_tolerance=1e-3)
    print(f"    final {closed.final_measurement:.6f} vs setpoint 2.0 "
          f"(settled={closed.settled})")
    results.append(_report("the loop reaches the setpoint",
                           closed.settled is True,
                           f"error {closed.setpoint_band:.2e}"))
    results.append(_report("no scram occurred in normal operation",
                           closed.scrammed is False, "scrammed=False"))
    results.append(_report("drum motion respects the drive rate",
                           all(abs(b.actual_deg - a.actual_deg)
                               <= 5.0 * 0.1 + 1e-9
                               for a, b in zip(closed.steps, closed.steps[1:])),
                           "rate limit honoured"))

    # ---- protection ----------------------------------------------------
    print("\nprotection system:")
    protection = ProtectionSystem(channels=(
        TripChannel("power", threshold=3.0, trips_high=True),
        TripChannel("fuel_temperature", threshold=3000.0, trips_high=True),
    ), scram_angle_deg=-90.0)
    results.append(_report("no trip below threshold",
                           protection.evaluate({"power": 2.0,
                                                "fuel_temperature": 2000.0}) == []
                           and protection.demanding_scram is False,
                           "quiet"))
    newly = protection.evaluate({"power": 3.5, "fuel_temperature": 2000.0})
    results.append(_report("trips above threshold",
                           newly == ["power"] and protection.demanding_scram is True,
                           f"{newly}"))
    results.append(_report("trip latches", protection.latched_channels == ("power",),
                           f"{protection.latched_channels}"))
    results.append(_report("the latch holds after the signal recovers",
                           protection.evaluate({"power": 2.0,
                                                "fuel_temperature": 2000.0}) == []
                           and protection.demanding_scram is True,
                           "still demanding scram"))
    protection.reset()
    results.append(_report("reset clears the latch",
                           protection.demanding_scram is False
                           and protection.latched_channels == (), "cleared"))

    missing = ProtectionSystem(channels=(TripChannel("power", threshold=3.0),))
    results.append(_report("a missing measurement trips",
                           missing.evaluate({}) == ["power"],
                           "fail-safe on absent data"))
    nan_channel = ProtectionSystem(channels=(TripChannel("power", threshold=3.0),))
    results.append(_report("a NaN measurement trips",
                           nan_channel.evaluate({"power": float("nan")}) == ["power"],
                           "fail-safe on bad data"))

    # ---- scram in the loop --------------------------------------------
    print("\nscram through the closed loop:")
    trip = ProtectionSystem(channels=(TripChannel("power", threshold=1.5),),
                            scram_angle_deg=-90.0)
    scrammed = simulate_controlled_operation(
        lambda angle: 1.0 + 0.01 * angle, initial_measurement=1.9, setpoint=2.0,
        gains=PidGains(kp=100.0, ki=20.0), drive=DrumDrive(rate_deg_per_s=5.0),
        duration_s=30.0, dt_s=0.1, protection=trip)
    print(f"    scrammed={scrammed.scrammed}, trips={scrammed.trips}, "
          f"final angle {scrammed.steps[-1].actual_deg:.2f} deg")
    results.append(_report("an out-of-band start scrammed immediately",
                           scrammed.scrammed is True, f"trips {scrammed.trips}"))
    results.append(_report("the drum drives toward the scram angle",
                           scrammed.steps[-1].actual_deg
                           < scrammed.steps[0].actual_deg,
                           f"{scrammed.steps[0].actual_deg:.2f} -> "
                           f"{scrammed.steps[-1].actual_deg:.2f} deg"))
    results.append(_report("a scrammed run is not reported as settled",
                           scrammed.settled is False, "settled=False"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid configurations are rejected:")
    guards = [
        ("zero drive rate", lambda: DrumDrive(rate_deg_per_s=0.0)),
        ("zero travel", lambda: DrumDrive(rate_deg_per_s=1.0, travel_deg=0.0)),
        ("zero gains", lambda: PidGains(kp=0.0, ki=0.0, kd=0.0)),
        ("negative gain", lambda: PidGains(kp=-1.0)),
        ("no trip channels", lambda: ProtectionSystem(channels=())),
        ("zero timestep", lambda: simulate_controlled_operation(
            lambda a: a, 1.0, 2.0, PidGains(kp=1.0),
            DrumDrive(rate_deg_per_s=1.0), duration_s=1.0, dt_s=0.0)),
        ("non-positive mu", lambda: AttenuationCoefficients(
            material="iron", energy_mev=3.0, mu_per_cm=0.0, source="SYNTHETIC")),
        ("untabulated energy", lambda: taylor_buildup("iron", 5.0)),
        ("unknown material", lambda: taylor_buildup("unobtainium", 3.0)),
        ("negative E1 argument", lambda: exponential_integral_e1(0.0)),
        ("transmission target above one",
         lambda: thickness_for_attenuation(iron, 0.32, 2.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (ControlSystemError, ShieldingError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: shielding follows Ch.14 and the control loop regulates and trips")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
