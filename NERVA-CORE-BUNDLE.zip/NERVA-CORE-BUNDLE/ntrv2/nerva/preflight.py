"""Preflight doctor: report exactly what this machine can and cannot do.

Run as a module:

    python -m ntr.nerva.doctor

The purpose is that the *first* thing a fresh developer or CI job sees on a new
machine is a checklist naming what is missing, rather than a traceback from
somewhere inside a transport run. Every check reports one of three states:

* ``READY``    - available and usable
* ``MISSING``  - required for a capability that is not reachable here
* ``OPTIONAL`` - improves fidelity but is not required

Exit status is 0 when everything required for the *offline* verification suite
is present, and 1 when something required is absent. Missing transport assets
do not fail the offline suite, because they gate only the real physics run.
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

READY = "READY"
MISSING = "MISSING"
OPTIONAL = "OPTIONAL"


@dataclass
class Check:
    name: str
    state: str
    detail: str
    gates: str

    @property
    def ok(self) -> bool:
        return self.state in (READY, OPTIONAL)


def _module_status(module: str) -> tuple[str, str]:
    try:
        found = importlib.util.find_spec(module)
    except (ImportError, ValueError):
        return MISSING, "not importable"
    if found is None:
        return MISSING, "not installed"
    return READY, "installed"


def _python_checks() -> list[Check]:
    checks: list[Check] = []
    version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    supported = sys.version_info >= (3, 11)
    checks.append(Check(
        "python >= 3.11", READY if supported else MISSING,
        f"running {version}", "offline suite",
    ))
    for module, gates in (("numpy", "offline suite"),
                          ("openmc", "model building"),
                          ("h5py", "statepoint access"),
                          ("pandas", "model export"),
                          ("CoolProp", "real hydrogen properties")):
        state, detail = _module_status(module)
        if module == "numpy" and state == MISSING:
            state = MISSING
        checks.append(Check(module, state, detail, gates))
    return checks


def _transport_checks() -> list[Check]:
    from .transport_backend import OpenMCTransportBackend

    backend = OpenMCTransportBackend(workdir="build/doctor")
    problems = backend.preflight()
    executable = shutil.which("openmc")
    checks = [Check(
        "openmc executable",
        READY if executable else MISSING,
        executable or "not on PATH; build the C++ transport code",
        "REAL neutron transport",
    )]
    cross_sections = os.environ.get("OPENMC_CROSS_SECTIONS")
    xs_path = Path(cross_sections) if cross_sections else None
    xs_present = bool(xs_path and xs_path.exists())
    checks.append(Check(
        "evaluated cross sections",
        READY if xs_present else MISSING,
        (str(xs_path) if xs_present else
         "OPENMC_CROSS_SECTIONS unset or unreadable; needs an NNDC HDF5 library"),
        "REAL neutron transport",
    ))
    checks.append(Check(
        "transport backend",
        READY if not problems else MISSING,
        "ready" if not problems else f"{len(problems)} blocking problem(s)",
        "REAL neutron transport",
    ))
    return checks


def _depletion_checks() -> list[Check]:
    """openmc.deplete needs libopenmc; report the real cause when it fails."""
    try:
        import openmc.deplete  # noqa: F401, PLC0415
    except Exception as exc:  # noqa: BLE001 - the message is the payload
        text = str(exc)
        reason = ("shared library libopenmc not found" if "libopenmc" in text
                  else type(exc).__name__)
        return [Check("openmc.deplete", MISSING, reason, "burnup / depletion")]
    return [Check("openmc.deplete", READY, "importable", "burnup / depletion")]


def _heritage_checks() -> list[Check]:
    from .heritage.registry import load_registry

    data_dir = Path(__file__).parent / "heritage" / "data"
    files = sorted(data_dir.glob("*.json"))
    checks: list[Check] = []
    if not files:
        return [Check("heritage datasets", MISSING,
                      f"no JSON datasets under {data_dir}", "offline suite")]
    total = 0
    problems: list[str] = []
    for path in files:
        try:
            registry = load_registry(path)
        except Exception as exc:  # noqa: BLE001
            problems.append(f"{path.name}: {exc}")
            continue
        total += len(registry)
        for entry in registry:
            if entry.kind == "assumed":
                problems.append(f"{path.name}: uncited assumed value {entry.name}")
    checks.append(Check(
        "heritage datasets", READY if not problems else MISSING,
        f"{len(files)} file(s), {total} cited entries"
        + ("" if not problems else f"; {len(problems)} problem(s)"),
        "offline suite",
    ))
    return checks


def _theoretical_checks() -> list[Check]:
    """Textbook-oracle suites must be importable, since they are the backbone."""
    suites = [
        "validate_heritage_turbomachinery",
        "validate_heritage_kinetics",
        "validate_heritage_cycles",
        "validate_coupled_core",
    ]
    missing = [name for name in suites
               if _module_status(f"ntr.nerva.{name}")[0] == MISSING]
    return [Check(
        "theory verification suites", READY if not missing else MISSING,
        f"{len(suites) - len(missing)}/{len(suites)} importable"
        + ("" if not missing else f"; missing {missing}"),
        "offline suite",
    )]


def collect() -> list[Check]:
    checks: list[Check] = []
    for group in (_python_checks, _transport_checks, _depletion_checks,
                  _heritage_checks, _theoretical_checks):
        try:
            checks.extend(group())
        except Exception as exc:  # noqa: BLE001 - a broken check must not hide others
            checks.append(Check(group.__name__, MISSING, f"check crashed: {exc}", "?"))
    return checks


def report(checks: list[Check]) -> str:
    width = max(len(c.name) for c in checks) + 2
    lines = ["NERVA preflight", "=" * 72]
    for check in checks:
        mark = {READY: "[ok]", MISSING: "[--]", OPTIONAL: "[~~]"}[check.state]
        lines.append(f"{mark} {check.name:<{width}} {check.state:<8} "
                     f"gates: {check.gates}")
        lines.append(f"    {check.detail}")
    blocked = [c for c in checks if c.state == MISSING]
    lines.append("=" * 72)
    if blocked:
        gates: dict[str, int] = {}
        for check in blocked:
            gates[check.gates] = gates.get(check.gates, 0) + 1
        lines.append(f"{len(blocked)} missing item(s), by capability:")
        for gate, count in sorted(gates.items()):
            lines.append(f"  - {gate}: {count}")
        lines.append("")
        lines.append("The offline verification suite can still run; the items "
                     "above gate only the capabilities named next to them.")
    else:
        lines.append("everything required is present")
    return "\n".join(lines)


def offline_suite_ready(checks: list[Check]) -> bool:
    return all(c.state != MISSING for c in checks if c.gates == "offline suite")


def main() -> int:
    checks = collect()
    print(report(checks))
    return 0 if offline_suite_ready(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
