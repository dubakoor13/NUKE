"""Reactivity coefficients — the core's self-regulating properties.

A reactor core is characterised by how its multiplication changes with the state
it is in. Until this module existed the model could report ``k`` at one state;
it could not say how ``k`` responds, which is the difference between a
description and a design.

Coefficients are measured the way a real reactor physics calculation measures
them: by **transport perturbation**, not by an assumed formula. Each one is a
central difference of ``k`` under a small, symmetric change of one state
variable:

    alpha_X = (k(X + dX) - k(X - dX)) / (2 dX)

Central differencing cancels the leading truncation term, so for a linear
response the result is exact and for a smooth nonlinear one it is second-order
accurate. The uncertainty is propagated from the two eigenvalue uncertainties:

    sigma_alpha = sqrt(sigma_+^2 + sigma_-^2) / (2 dX)

Units are reported in both per-kelvin and pcm/K (1 pcm = 1e-5 dk/k), because
core design is done in pcm.

What is deliberately absent: a void coefficient obtained by inventing a density
knob. ``CoreState`` carries temperatures, not densities, so the coolant
temperature coefficient is reported instead and the void coefficient is left as
an explicit gap rather than a fabricated number.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, replace

from .transport_backend import CoreState, TransportBackend

PCM = 1.0e-5


def to_pcm(reactivity: float) -> float:
    """Convert a reactivity (dk/k) to pcm."""
    return reactivity / PCM


def from_pcm(pcm: float) -> float:
    """Convert pcm to reactivity (dk/k)."""
    return pcm * PCM


class CoefficientError(ValueError):
    """Raised when a coefficient cannot be measured meaningfully."""


@dataclass(frozen=True)
class CoefficientResult:
    """A measured reactivity coefficient with its uncertainty and evidence."""

    name: str
    parameter: str
    value_per_unit: float
    unit: str
    uncertainty_per_unit: float | None
    perturbation: float
    k_plus: float
    k_minus: float
    k_sigma_plus: float
    k_sigma_minus: float
    backend: str
    synthetic: bool

    @property
    def pcm_per_unit(self) -> float:
        return to_pcm(self.value_per_unit)

    @property
    def pcm_uncertainty(self) -> float | None:
        if self.uncertainty_per_unit is None:
            return None
        return to_pcm(self.uncertainty_per_unit)

    @property
    def is_negative(self) -> bool:
        """Negative coefficients are the ones that make a core self-limiting."""
        return self.value_per_unit < 0.0

    def describe(self) -> str:
        sigma = (f" +/- {self.pcm_uncertainty:.2f}" if self.pcm_uncertainty is not None
                 else "")
        return (f"{self.name}: {self.pcm_per_unit:+.3f}{sigma} pcm per {self.unit}"
                f"  (perturbation {self.perturbation:g} {self.unit})")


def _central_difference(
    backend: TransportBackend,
    state: CoreState,
    parameter: str,
    perturbation: float,
    name: str,
    unit: str,
) -> CoefficientResult:
    """Measure dk/d(parameter) by symmetric transport perturbation."""
    if not math.isfinite(perturbation) or perturbation <= 0.0:
        raise CoefficientError(
            f"perturbation must be finite and positive, got {perturbation!r}"
        )
    base = getattr(state, parameter)
    if not math.isfinite(base):
        raise CoefficientError(f"{parameter} of the base state is not finite")

    plus_value = base + perturbation
    minus_value = base - perturbation
    if parameter.endswith("_temperature_k") and minus_value <= 0.0:
        raise CoefficientError(
            f"perturbing {parameter} by {perturbation:g} from {base:g} would give "
            f"a non-physical temperature {minus_value:g} K; reduce the perturbation"
        )

    plus = backend.run(replace(state, **{parameter: plus_value}))
    minus = backend.run(replace(state, **{parameter: minus_value}))

    slope = (plus.k_eff - minus.k_eff) / (2.0 * perturbation)
    # Independent marginal uncertainties; treat the two runs as uncorrelated,
    # which is conservative for a shared source bank.
    sigma = math.hypot(plus.k_sigma, minus.k_sigma) / (2.0 * perturbation)

    return CoefficientResult(
        name=name,
        parameter=parameter,
        value_per_unit=slope,
        unit=unit,
        uncertainty_per_unit=sigma,
        perturbation=perturbation,
        k_plus=plus.k_eff,
        k_minus=minus.k_eff,
        k_sigma_plus=plus.k_sigma,
        k_sigma_minus=minus.k_sigma,
        backend=plus.backend,
        synthetic=plus.synthetic,
    )


def fuel_temperature_coefficient(
    backend: TransportBackend, state: CoreState, perturbation_k: float = 25.0
) -> CoefficientResult:
    """Doppler (fuel temperature) coefficient, dk/dT_fuel.

    Expected sign for a real core: **negative**. A positive Doppler coefficient
    is a serious safety finding, not a modelling quirk.
    """
    return _central_difference(backend, state, "fuel_temperature_k",
                               perturbation_k, "fuel temperature (Doppler)", "K")


def coolant_temperature_coefficient(
    backend: TransportBackend, state: CoreState, perturbation_k: float = 25.0
) -> CoefficientResult:
    """Coolant/moderator temperature coefficient, dk/dT_H2.

    In a hydrogen-cooled core this carries both a spectrum effect (hydrogen is
    the moderator) and a density effect, since the gas density falls sharply
    with temperature at fixed pressure.
    """
    return _central_difference(backend, state, "hydrogen_temperature_k",
                               perturbation_k, "coolant temperature", "K")


def reflector_temperature_coefficient(
    backend: TransportBackend, state: CoreState, perturbation_k: float = 25.0
) -> CoefficientResult:
    """Radial reflector temperature coefficient, dk/dT_reflector."""
    return _central_difference(backend, state, "reflector_temperature_k",
                               perturbation_k, "reflector temperature", "K")


def enrichment_worth(
    backend: TransportBackend, state: CoreState,
    perturbation_wt_percent: float = 0.1,
) -> CoefficientResult:
    """Enrichment worth, dk/d(wt% U-235).

    The 20 wt% demonstration cap is enforced by ``CoreState`` itself, so an
    out-of-range perturbation fails there rather than being silently clipped.
    """
    return _central_difference(backend, state, "enrichment_wt_percent",
                               perturbation_wt_percent, "enrichment", "wt%")


def drum_worth_gradient(
    backend: TransportBackend, state: CoreState, perturbation_deg: float = 2.0
) -> CoefficientResult:
    """Differential control-drum worth at the current angle, dk/dtheta.

    Local gradient only. Integral worth over the full travel is in
    ``control_worth``; for a nonlinear worth curve this local slope is not the
    average.
    """
    return _central_difference(backend, state, "drum_angle_deg",
                               perturbation_deg, "control drum angle", "deg")


def poison_worth(
    backend: TransportBackend, state: CoreState,
    perturbation_cm_inv: float | None = None,
) -> CoefficientResult:
    """Worth of fission-product poison loading, dk/d(Sigma_a,poison).

    Measured by the same transport perturbation as every other coefficient, so
    ``fission_product_poisoning`` no longer needs a caller-supplied worth: the
    core model supplies it. Units are dk per 1/cm of extra macroscopic absorber.

    Expect a **negative** value: poison absorbs neutrons and lowers reactivity.
    """
    base = state.poison_absorption_cm_inv
    if base is None:
        raise CoefficientError(
            "the base state carries no poison_absorption_cm_inv, so the poison "
            "worth cannot be measured; supply the equilibrium poison loading "
            "from fission_product_poisoning"
        )
    if perturbation_cm_inv is None:
        # Scale the step to the loading, with an absolute floor so a lightly
        # poisoned state is still measured meaningfully.
        perturbation_cm_inv = max(1.0e-6, 0.1 * base)
    if base - perturbation_cm_inv < 0.0:
        raise CoefficientError(
            f"perturbing the poison loading by {perturbation_cm_inv:g} from "
            f"{base:g} /cm would give a negative absorption; reduce the step"
        )
    return _central_difference(backend, state, "poison_absorption_cm_inv",
                               perturbation_cm_inv,
                               "fission-product poison", "1/cm")

def void_coefficient(    backend: TransportBackend, state: CoreState,
    perturbation_kg_m3: float | None = None,
) -> CoefficientResult:
    """Coolant density coefficient, dk/d(rho_coolant), in dk per kg/m3.

    This is the void coefficient in the form a nuclear thermal rocket needs it.
    The hydrogen passes from liquid (about 71 kg/m3) to hot gas (well under
    1 kg/m3) through the core, so the density swing is far larger than any
    temperature swing and this coefficient drives most of the coolant feedback.

    Refuses when the state carries no density: an absent density would otherwise
    produce a confident zero.
    """
    if state.coolant_density_kg_m3 is None:
        raise CoefficientError(
            "the base state carries no coolant_density_kg_m3, so the void "
            "coefficient cannot be measured; supply a density (see "
            "property_providers for liquid and gaseous hydrogen values)"
        )
    if perturbation_kg_m3 is None:
        # A default of 10% of the base density keeps the perturbation
        # proportionate across the enormous liquid-to-gas range.
        perturbation_kg_m3 = max(1.0e-3, 0.1 * state.coolant_density_kg_m3)
    if state.coolant_density_kg_m3 - perturbation_kg_m3 <= 0.0:
        raise CoefficientError(
            f"perturbing the coolant density by {perturbation_kg_m3:g} from "
            f"{state.coolant_density_kg_m3:g} kg/m3 would give a non-physical "
            f"density; reduce the perturbation"
        )
    return _central_difference(backend, state, "coolant_density_kg_m3",
                               perturbation_kg_m3,
                               "coolant density (void)", "kg/m3")


@dataclass(frozen=True)
class PowerCoefficient:
    """Power coefficient assembled from temperature coefficients.

    A reactor's power coefficient is not measured directly here; it is built
    from the measured temperature coefficients and the *thermal* response, how
    many kelvin each component gains per unit power. Keeping those separate is
    what lets the thermal side be replaced without re-measuring the nuclear
    side.
    """

    value_per_watt: float
    doppler_per_watt: float
    coolant_per_watt: float
    dT_fuel_per_watt: float
    dT_coolant_per_watt: float

    @property
    def pcm_per_watt(self) -> float:
        return to_pcm(self.value_per_watt)

    @property
    def pcm_per_mw(self) -> float:
        return to_pcm(self.value_per_watt) * 1.0e6

    @property
    def is_negative(self) -> bool:
        return self.value_per_watt < 0.0


def power_coefficient(
    doppler: CoefficientResult,
    coolant: CoefficientResult,
    *,
    dT_fuel_per_watt: float,
    dT_coolant_per_watt: float,
) -> PowerCoefficient:
    """Assemble the power coefficient from measured parts.

        alpha_P = alpha_fuel * dT_fuel/dP + alpha_coolant * dT_coolant/dP
    """
    for name, value in (("dT_fuel_per_watt", dT_fuel_per_watt),
                        ("dT_coolant_per_watt", dT_coolant_per_watt)):
        if not math.isfinite(value):
            raise CoefficientError(f"{name} must be finite, got {value!r}")
    doppler_part = doppler.value_per_unit * dT_fuel_per_watt
    coolant_part = coolant.value_per_unit * dT_coolant_per_watt
    return PowerCoefficient(
        value_per_watt=doppler_part + coolant_part,
        doppler_per_watt=doppler_part,
        coolant_per_watt=coolant_part,
        dT_fuel_per_watt=dT_fuel_per_watt,
        dT_coolant_per_watt=dT_coolant_per_watt,
    )


@dataclass(frozen=True)
class TemperatureDefect:
    """The reactivity held down by heating the core from cold to hot."""

    k_cold: float
    k_hot: float
    defect: float
    k_sigma: float

    @property
    def pcm(self) -> float:
        return to_pcm(self.defect)

    @property
    def pcm_uncertainty(self) -> float:
        return to_pcm(self.k_sigma)


def temperature_defect(
    backend: TransportBackend, cold_state: CoreState, hot_state: CoreState
) -> TemperatureDefect:
    """Reactivity lost between a cold and a hot state, k_cold - k_hot.

    This is the quantity that has to be built back in as excess reactivity, so
    it belongs with the coefficients rather than with the operability model.
    """
    cold = backend.run(cold_state)
    hot = backend.run(hot_state)
    return TemperatureDefect(
        k_cold=cold.k_eff,
        k_hot=hot.k_eff,
        defect=cold.k_eff - hot.k_eff,
        k_sigma=math.hypot(cold.k_sigma, hot.k_sigma),
    )
