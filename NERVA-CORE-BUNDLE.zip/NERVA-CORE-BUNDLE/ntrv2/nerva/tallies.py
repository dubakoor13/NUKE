"""Tallies for the NERVA-derived OpenMC model."""

from __future__ import annotations

import numpy as np
import openmc

from .config import NervaConfig
from .neutron_energy_groups import diagnostic_energy_edges


_TIE_SOLID_CELL_NAMES = {
    "tie-tube inner Inconel tube",
    "tie-tube ZrH moderator",
    "tie-tube outer Inconel tube",
    "tie-tube ZrC sleeve",
    "tie-tube graphite filler",
    "tie-tube outer ZrC coating",
}

_MATERIAL_ORDER = (
    "fuel",
    "hydrogen",
    "zrc",
    "reflector",
    "graphite",
    "zrh",
    "inconel",
    "b4c",
    "aluminum",
)

def _safe_slug(value: str) -> str:
    return (
        value.lower()
        .replace("-", "_")
        .replace(" ", "_")
        .replace("/", "_")
        .replace("(", "")
        .replace(")", "")
    )


def _cells_named(
    geometry: openmc.Geometry,
    name: str,
) -> list[openmc.Cell]:
    return [
        cell
        for cell in geometry.get_all_cells().values()
        if cell.name == name
    ]


def _cells_named_prefix(
    geometry: openmc.Geometry,
    prefix: str,
) -> list[openmc.Cell]:
    return sorted(
        [
            cell
            for cell in geometry.get_all_cells().values()
            if cell.name.startswith(prefix)
        ],
        key=lambda cell: cell.name,
    )


def _attach_heating_trigger(
    tally: openmc.Tally,
    config: NervaConfig,
) -> None:
    if config.tally_rel_err_trigger is None:
        return
    trigger = openmc.Trigger(
        "rel_err",
        config.tally_rel_err_trigger,
        ignore_zeros=True,
    )
    trigger.scores = ["heating" if config.photon_transport else "heating-local"]
    tally.triggers = [trigger]


def _energy_edges(config: NervaConfig) -> np.ndarray:
    """EnergyFilter bins with exact 0.625-eV and 100-keV boundaries.

    Uniform logspace bins cross the diagnostic spectrum class cutoffs
    and would misclassify an entire straddling flux tally bin.
    """
    return diagnostic_energy_edges(config.diagnostic_energy_groups)


def _vacuum_surfaces(
    geometry: openmc.Geometry,
) -> list[openmc.Surface]:
    return [
        surface
        for surface in geometry.get_all_surfaces().values()
        if surface.boundary_type == "vacuum"
    ]


def build_tallies(
    config: NervaConfig,
    radial_extent_cm: float | None = None,
    fuel_material: openmc.Material | None = None,
    geometry: openmc.Geometry | None = None,
    materials: dict[str, openmc.Material] | None = None,
) -> openmc.Tallies:
    """Create engineering and diagnostics tallies.

    The original mesh/fuel/tie tally names are preserved for backward
    compatibility. Additional tallies expose reaction rates, material-wise
    energy deposition, spectra, axial profiles, and vacuum-boundary currents.
    """
    half_length = 0.5 * config.active_length_cm
    r = (
        config.reflector_outer_radius_cm
        if radial_extent_cm is None
        else radial_extent_cm
    )

    mesh = openmc.RegularMesh(name="nerva_core_mesh")
    mesh.dimension = tuple(config.heating_mesh_dimension)
    mesh.lower_left = (-r, -r, -half_length)
    mesh.upper_right = (r, r, half_length)

    mesh_filter = openmc.MeshFilter(mesh)

    neutronics = openmc.Tally(name="nerva_3d_neutronics")
    neutronics.filters = [mesh_filter]
    neutronics.scores = [
        "flux",
        "absorption",
        "fission",
        "nu-fission",
        "kappa-fission",  # gross recoverable fission energy, not deposited heat
        "heating",
        "heating-local",
    ]

    _attach_heating_trigger(neutronics, config)
    tallies: list[openmc.Tally] = [neutronics]

    # Fundamental eigenvalue-generation neutron accounting. These scores
    # integrate the ENTIRE physical geometry (unlike the finite diagnostic
    # mesh, which may clip reflector/vessel volumes). Fission neutrons are
    # banked for the next generation; scatter multiplicity, however, adds
    # live neutrons to this generation. The closure is therefore:
    #
    #   absorption + global_vacuum_leakage
    #   - (nu-scatter - scatter) ~= one source neutron.
    #
    # Compare against OpenMC's GLOBAL leakage estimator, which already has
    # the correct outward orientation at every exterior vacuum boundary.
    global_balance = openmc.Tally(name="nerva_global_neutron_balance")
    if config.photon_transport:
        global_balance.filters = [openmc.ParticleFilter(["neutron"])]
    global_balance.scores = [
        "absorption", "scatter", "nu-scatter", "nu-fission",
    ]
    tallies.append(global_balance)

    # Independent cross-filter reaction bookkeeping MUST use a like-for-like
    # estimator. The global conservation tally above includes continuous-
    # energy nu-scatter, which forces OpenMC's ANALOG estimator, whereas
    # material/incident-energy reaction tallies use TRACKLENGTH. Analog and
    # tracklength sample means differ statistically even for identical
    # physical reaction rates: do not demand machine-level bin closure
    # between different estimators or weaken neutron accounting tolerances.
    global_tracklength = openmc.Tally(
        name="nerva_global_reaction_tracklength"
    )
    global_tracklength.estimator = "tracklength"
    if config.photon_transport:
        global_tracklength.filters = [openmc.ParticleFilter(["neutron"])]
    global_tracklength.scores = ["absorption", "nu-fission"]
    tallies.append(global_tracklength)

    # Evaluated fission-emission physics: TOTAL = PROMPT + DELAYED
    # neutron production at the actual incident-neutron energy.
    # The native unfiltered tracklength tally is an independent whole-core
    # reference; this is not adjoint-weighted effective delayed fraction.
    global_emission = openmc.Tally(
        name="nerva_global_fission_emission"
    )
    global_emission.estimator = "tracklength"
    if config.photon_transport:
        global_emission.filters = [openmc.ParticleFilter(["neutron"])]
    global_emission.scores = [
        "nu-fission", "prompt-nu-fission", "delayed-nu-fission"
    ]
    tallies.append(global_emission)

    if fuel_material is None and materials is not None:
        fuel_material = materials.get("fuel")

    if fuel_material is not None:
        fuel_heating = openmc.Tally(name="nerva_3d_fuel_heating")
        fuel_heating.filters = [
            mesh_filter,
            openmc.MaterialFilter([fuel_material]),
        ]
        fuel_heating.scores = [
            "heating-local",
            "fission",
            "nu-fission",
        ]
        tallies.append(fuel_heating)

    if geometry is not None:
        tie_cells = [
            cell
            for cell in geometry.get_all_cells().values()
            if cell.name in _TIE_SOLID_CELL_NAMES
        ]
        if tie_cells:
            tie_heating = openmc.Tally(name="nerva_3d_tie_heating")
            tie_heating.filters = [
                mesh_filter,
                openmc.CellFilter(tie_cells),
            ]
            tie_heating.scores = [
                "heating-local",
                "absorption",
            ]
            tallies.append(tie_heating)



    if geometry is not None:
        fuel_hydrogen_cells = [
            cell
            for cell in geometry.get_all_cells().values()
            if cell.name.startswith("hydrogen channel ")
        ]
        if fuel_hydrogen_cells:
            fuel_h2_heating = openmc.Tally(
                name="nerva_3d_fuel_hydrogen_heating"
            )
            fuel_h2_heating.filters = [
                mesh_filter,
                openmc.CellFilter(fuel_hydrogen_cells),
            ]
            fuel_h2_heating.scores = [
                "heating-local",
                "absorption",
            ]
            tallies.append(fuel_h2_heating)

        tie_supply_hydrogen_cells = [
            cell
            for cell in geometry.get_all_cells().values()
            if cell.name == "tie-tube hydrogen supply"
        ]
        tie_return_hydrogen_cells = [
            cell
            for cell in geometry.get_all_cells().values()
            if cell.name == "tie-tube hydrogen return"
        ]
        tie_hydrogen_cells = (
            tie_supply_hydrogen_cells
            + tie_return_hydrogen_cells
        )
        if tie_supply_hydrogen_cells:
            tie_supply_h2 = openmc.Tally(
                name="nerva_3d_tie_supply_hydrogen_heating"
            )
            tie_supply_h2.filters = [
                mesh_filter,
                openmc.CellFilter(tie_supply_hydrogen_cells),
            ]
            tie_supply_h2.scores = [
                "heating-local",
                "absorption",
            ]
            tallies.append(tie_supply_h2)

        if tie_return_hydrogen_cells:
            tie_return_h2 = openmc.Tally(
                name="nerva_3d_tie_return_hydrogen_heating"
            )
            tie_return_h2.filters = [
                mesh_filter,
                openmc.CellFilter(tie_return_hydrogen_cells),
            ]
            tie_return_h2.scores = [
                "heating-local",
                "absorption",
            ]
            tallies.append(tie_return_h2)

        if tie_hydrogen_cells:
            tie_h2_heating = openmc.Tally(
                name="nerva_3d_tie_hydrogen_heating"
            )
            tie_h2_heating.filters = [
                mesh_filter,
                openmc.CellFilter(tie_hydrogen_cells),
            ]
            tie_h2_heating.scores = [
                "heating-local",
                "absorption",
            ]
            tallies.append(tie_h2_heating)

    instance_axial_filter = None
    if config.instance_axial_tallies:
        instance_axial_mesh = openmc.RegularMesh(
            name="nerva_instance_axial_mesh"
        )
        instance_axial_mesh.dimension = (
            1,
            1,
            config.axial_mesh_bins,
        )
        instance_axial_mesh.lower_left = (
            -r,
            -r,
            -half_length,
        )
        instance_axial_mesh.upper_right = (
            r,
            r,
            half_length,
        )
        instance_axial_filter = openmc.MeshFilter(
            instance_axial_mesh
        )

    # Repeated-cell instance diagnostics. These preserve the actual Monte Carlo
    # power distribution instead of averaging all repeated lattice placements.
    if geometry is not None and config.element_instance_tallies:
        fuel_cells = _cells_named(geometry, "fuel matrix")
        if fuel_cells:
            fuel_instance = openmc.Tally(
                name="nerva_fuel_element_instances"
            )
            fuel_instance.filters = [
                openmc.DistribcellFilter(fuel_cells[0])
            ]
            fuel_instance.scores = [
                "flux",
                "fission",
                "nu-fission",
                "heating-local",
            ]
            tallies.append(fuel_instance)

            if instance_axial_filter is not None:
                fuel_axial_instance = openmc.Tally(
                    name="nerva_fuel_element_axial_instances"
                )
                fuel_axial_instance.filters = [
                    openmc.DistribcellFilter(fuel_cells[0]),
                    instance_axial_filter,
                ]
                fuel_axial_instance.scores = [
                    "fission",
                    "heating-local",
                ]
                tallies.append(fuel_axial_instance)


        fuel_sector_cells = _cells_named_prefix(
            geometry,
            "fuel matrix channel sector ",
        )
        for sector_index, sector_cell in enumerate(
            fuel_sector_cells,
            start=1,
        ):
            sector_tally = openmc.Tally(
                name=(
                    f"nerva_fuel_sector_"
                    f"{sector_index:02d}_instances"
                )
            )
            sector_tally.filters = [
                openmc.DistribcellFilter(sector_cell)
            ]
            sector_tally.scores = [
                "flux",
                "fission",
                "nu-fission",
                "heating-local",
            ]
            tallies.append(sector_tally)

            if instance_axial_filter is not None:
                sector_axial = openmc.Tally(
                    name=(
                        f"nerva_fuel_sector_"
                        f"{sector_index:02d}_axial_instances"
                    )
                )
                sector_axial.filters = [
                    openmc.DistribcellFilter(sector_cell),
                    instance_axial_filter,
                ]
                sector_axial.scores = [
                    "fission",
                    "heating-local",
                ]
                tallies.append(sector_axial)

        for tie_name in sorted(_TIE_SOLID_CELL_NAMES):
            cells = _cells_named(geometry, tie_name)
            if not cells:
                continue
            tie_instance = openmc.Tally(
                name=(
                    "nerva_tie_instance_"
                    + _safe_slug(tie_name)
                )
            )
            tie_instance.filters = [
                openmc.DistribcellFilter(cells[0])
            ]
            tie_instance.scores = [
                "absorption",
                "heating-local",
            ]
            tallies.append(tie_instance)

            if instance_axial_filter is not None:
                tie_axial_instance = openmc.Tally(
                    name=(
                        "nerva_tie_axial_instance_"
                        + _safe_slug(tie_name)
                    )
                )
                tie_axial_instance.filters = [
                    openmc.DistribcellFilter(cells[0]),
                    instance_axial_filter,
                ]
                tie_axial_instance.scores = [
                    "absorption",
                    "heating-local",
                ]
                tallies.append(tie_axial_instance)

    if geometry is not None and config.channel_instance_tallies:
        for channel_index in range(1, 20):
            channel_name = f"hydrogen channel {channel_index}"
            channel_cells = _cells_named(geometry, channel_name)
            if not channel_cells:
                continue
            channel_tally = openmc.Tally(
                name=(
                    f"nerva_hydrogen_channel_"
                    f"{channel_index:02d}_instances"
                )
            )
            channel_tally.filters = [
                openmc.DistribcellFilter(channel_cells[0])
            ]
            channel_tally.scores = [
                "flux",
                "absorption",
                "heating-local",
            ]
            tallies.append(channel_tally)

            if instance_axial_filter is not None:
                channel_axial_tally = openmc.Tally(
                    name=(
                        f"nerva_hydrogen_channel_"
                        f"{channel_index:02d}_axial_instances"
                    )
                )
                channel_axial_tally.filters = [
                    openmc.DistribcellFilter(channel_cells[0]),
                    instance_axial_filter,
                ]
                channel_axial_tally.scores = [
                    "absorption",
                    "heating-local",
                ]
                tallies.append(channel_axial_tally)


    if (
        geometry is not None
        and config.instance_axial_tallies
        and instance_axial_filter is not None
    ):
        tie_supply_cells = _cells_named(
            geometry,
            "tie-tube hydrogen supply",
        )
        if tie_supply_cells:
            tie_supply_instance_axial = openmc.Tally(
                name="nerva_tie_supply_hydrogen_axial_instances"
            )
            tie_supply_instance_axial.filters = [
                openmc.DistribcellFilter(tie_supply_cells[0]),
                instance_axial_filter,
            ]
            tie_supply_instance_axial.scores = [
                "absorption",
                "heating-local",
            ]
            tallies.append(tie_supply_instance_axial)

        tie_return_cells = _cells_named(
            geometry,
            "tie-tube hydrogen return",
        )
        if tie_return_cells:
            tie_return_instance_axial = openmc.Tally(
                name="nerva_tie_return_hydrogen_axial_instances"
            )
            tie_return_instance_axial.filters = [
                openmc.DistribcellFilter(tie_return_cells[0]),
                instance_axial_filter,
            ]
            tie_return_instance_axial.scores = [
                "absorption",
                "heating-local",
            ]
            tallies.append(tie_return_instance_axial)

    # Material-resolved transport and energy deposition.
    if materials is not None:
        material_list = [
            materials[key]
            for key in _MATERIAL_ORDER
            if key in materials
        ]
        if material_list:
            material_transport = openmc.Tally(
                name="nerva_material_transport"
            )
            material_transport.filters = [
                openmc.MaterialFilter(material_list)
            ]
            material_transport.scores = [
                "flux",
                "absorption",
                "fission",
                "nu-fission",
                "heating",
                "heating-local",
            ]
            tallies.append(material_transport)

            # Delayed and prompt neutron yields from evaluated microscopic
            # fission product data in every declared material, including
            # materials that are not instantiated in the root geometry.
            material_emission = openmc.Tally(
                name="nerva_material_fission_emission"
            )
            material_emission.estimator = "tracklength"
            material_emission.filters = [
                openmc.MaterialFilter(material_list)
            ]
            material_emission.scores = [
                "nu-fission", "prompt-nu-fission", "delayed-nu-fission"
            ]
            tallies.append(material_emission)

        energy_filter = openmc.EnergyFilter(_energy_edges(config))

        if material_list:
            material_energy = openmc.Tally(
                name="nerva_material_energy_transport"
            )
            material_energy.filters = [
                openmc.MaterialFilter(material_list),
                energy_filter,
            ]
            material_energy.scores = [
                "flux",
                "absorption",
                "fission",
                "nu-fission",
                "heating-local",
            ]
            tallies.append(material_energy)

        if config.photon_transport:
            particle_heating = openmc.Tally(
                name="nerva_particle_heating"
            )
            particle_heating.filters = [
                openmc.ParticleFilter(["neutron", "photon"])
            ]
            particle_heating.scores = ["heating"]
            tallies.append(particle_heating)

        fuel = materials.get("fuel")
        if fuel is not None:
            fuel_spectrum = openmc.Tally(name="nerva_fuel_spectrum")
            fuel_spectrum.filters = [
                openmc.MaterialFilter([fuel]),
                energy_filter,
            ]
            fuel_spectrum.scores = [
                "flux",
                "absorption",
                "fission",
                "nu-fission",
            ]
            tallies.append(fuel_spectrum)

        hydrogen = materials.get("hydrogen")
        if hydrogen is not None:
            hydrogen_spectrum = openmc.Tally(
                name="nerva_hydrogen_spectrum"
            )
            hydrogen_spectrum.filters = [
                openmc.MaterialFilter([hydrogen]),
                energy_filter,
            ]
            hydrogen_spectrum.scores = [
                "flux",
                "absorption",
                "heating-local",
            ]
            tallies.append(hydrogen_spectrum)

    # Axial profile with much finer z resolution than the 3-D mesh.
    axial_mesh = openmc.RegularMesh(name="nerva_axial_mesh")
    axial_mesh.dimension = (1, 1, config.axial_mesh_bins)
    axial_mesh.lower_left = (-r, -r, -half_length)
    axial_mesh.upper_right = (r, r, half_length)

    axial = openmc.Tally(name="nerva_axial_transport")
    axial.filters = [openmc.MeshFilter(axial_mesh)]
    axial.scores = [
        "flux",
        "fission",
        "nu-fission",
        "heating-local",
    ]
    tallies.append(axial)

    # Current across all vacuum boundaries provides a leakage diagnostic.
    if geometry is not None:
        vacuum_surfaces = _vacuum_surfaces(geometry)
        if vacuum_surfaces:
            leakage = openmc.Tally(name="nerva_vacuum_boundary_current")
            leakage.filters = [
                openmc.SurfaceFilter(vacuum_surfaces)
            ]
            leakage.scores = ["current"]
            tallies.append(leakage)

    # Both heating scores remain available for diagnostics. When photons
    # are transported, the thermal coupling must use 'heating' (physical
    # photon deposition locations), not 'heating-local' (on-site gamma
    # deposition approximation). Preserve neutron-only tally definitions.
    if config.photon_transport:
        for tally in tallies:
            if "heating-local" in tally.scores and "heating" not in tally.scores:
                tally.scores = [*tally.scores, "heating"]

    return openmc.Tallies(tallies)
