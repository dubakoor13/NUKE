"""Verify determinism, including across separate processes.

A reproducibility claim is worthless if the numbers drift between runs, so this
compares fingerprints computed in independent interpreter processes. It also
records the fingerprint so the acceptance reporter can cite it.

Monte Carlo transport is deliberately *not* claimed to be deterministic here;
only the deterministic subsystems are fingerprinted.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from . import determinism

REPO_ROOT = Path(__file__).resolve().parents[2]
RECORD_PATH = REPO_ROOT / "build" / "nerva_determinism_record.json"


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def _fingerprint_in_subprocess() -> str:
    """Run the fingerprint in a fresh interpreter and return its hash."""
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        [sys.executable, "-m", "ntr.nerva.determinism"],
        cwd=str(REPO_ROOT), env=env, capture_output=True, text=True,
        timeout=900, errors="replace",
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"subprocess fingerprint failed: "
            f"{(completed.stderr or '').strip().splitlines()[-1:] }"
        )
    return completed.stdout.strip().splitlines()[-1]


def main() -> int:
    results: list[bool] = []

    print("in-process repeatability:")
    first = determinism.canonical_results()
    second = determinism.canonical_results()
    hash_first = determinism.fingerprint(first)
    hash_second = determinism.fingerprint(second)
    results.append(_report("two calls in one process agree",
                           hash_first == hash_second, hash_first[:24] + "..."))
    results.append(_report("every canonical quantity is identical",
                           first == second,
                           f"{len(first)} quantities compared"))
    results.append(_report("fingerprint is a 64-hex SHA-256",
                           len(hash_first) == 64
                           and all(c in "0123456789abcdef" for c in hash_first),
                           hash_first[:16] + "..."))

    print("\ncross-process determinism (the claim that matters):")
    try:
        sub_hash = _fingerprint_in_subprocess()
    except (RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f"  [FAIL] subprocess fingerprint could not be computed: {exc}")
        results.append(False)
        sub_hash = None
    if sub_hash is not None:
        results.append(_report("two separate processes agree",
                               sub_hash == hash_first,
                               f"sub={sub_hash[:24]}..."))
        results.append(_report("a third process also agrees",
                               _fingerprint_in_subprocess() == hash_first,
                               "three-way match"))

    print("\nfingerprint covers every subsystem:")
    expected_keys = {
        "heritage_entry_counts", "kinetics_omega_per_s", "coupled_k_eff",
        "coupled_fuel_temperature_k", "coupled_iterations",
        "pump_mass_flow_kg_s", "pump_head_m", "pump_shaft_power_w",
        "grid_pressure_drop_pa",
    }
    results.append(_report("all subsystems contribute to the hash",
                           expected_keys <= set(first),
                           f"{len(expected_keys)} keys present"))
    perturbed = dict(first)
    perturbed["coupled_k_eff"] = first["coupled_k_eff"] + 1e-15
    results.append(_report("hash is sensitive to a 1e-15 change",
                           determinism.fingerprint(perturbed) != hash_first,
                           "perturbation detected"))

    print("\nrecord for the acceptance reporter:")
    RECORD_PATH.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "kind": "determinism",
        "fingerprint": hash_first,
        "in_process_agreement": hash_first == hash_second,
        "cross_process_agreement": sub_hash == hash_first if sub_hash else False,
        "independent_processes": 3 if sub_hash else 1,
        "quantities": sorted(first),
        "note": "covers the analytic-backend coupled solve, pump operating "
                "point, Inhour root, heritage registry and axial grid study; "
                "Monte Carlo transport is NOT deterministic by design and is "
                "not claimed here",
    }
    RECORD_PATH.write_text(json.dumps(record, indent=1), encoding="utf-8")
    results.append(_report("record written", RECORD_PATH.exists(),
                           str(RECORD_PATH.relative_to(REPO_ROOT))))
    reloaded = json.loads(RECORD_PATH.read_text(encoding="utf-8"))
    results.append(_report("record round-trips with the same fingerprint",
                           reloaded["fingerprint"] == hash_first,
                           reloaded["fingerprint"][:16] + "..."))

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print(f"PASS: results are deterministic across processes "
          f"({hash_first[:16]}...)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
