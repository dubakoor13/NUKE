"""Gamma shielding: point kernels, slab attenuation and Taylor buildup.

Radiation shielding was entirely absent from the model. This module implements
the theory of Emrich (2023) Ch. 14, pp.267-270, and - importantly - the Taylor
buildup coefficients from **Table 14.1**, which the book tabulates for eight
materials at seven gamma energies. That makes the bulk of this module cited data
rather than a framework waiting for input.

Equations (numbering preserved):

* Eq. (14.7)  narrow-beam exponential attenuation
* Eq. (14.8)  uncollided point kernel with geometric spreading
* Eq. (14.9)  collapse-corrected kernel with a buildup factor
* Eq. (14.10) Taylor buildup factor ``B = A exp(-alpha*mu) + (1-A) exp(-beta*mu)``
* Eq. (14.12) gamma point attenuation kernel
* Eq. (14.19) semi-infinite slab attenuation, in exponential-integral form
* Eq. (14.21) slab attenuation in terms of the shield-surface intensity

What the book does *not* provide is the mass attenuation coefficients themselves:
Fig. 14.5 is a plot, and the text says only that the data came from NIST XCOM.
Those are therefore supplied by the caller through
:class:`AttenuationCoefficients` and flagged as external.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

# Taylor buildup coefficients from Emrich (2023) Table 14.1, p.269.
# Energies in MeV; each entry is (A, alpha, beta).
TAYLOR_TABLE: dict[str, dict[float, tuple[float, float, float]]] = {
    "water": {
        1.0: (11.0, -0.104, 0.030), 2.0: (6.4, -0.076, 0.092),
        3.0: (5.2, -0.062, 0.110), 4.0: (4.5, -0.055, 0.117),
        6.0: (3.55, -0.050, 0.124), 8.0: (3.05, -0.045, 0.128),
        10.0: (2.7, -0.042, 0.130),
    },
    "liquid_hydrogen": {
        1.0: (3.22, -0.165, 0.078), 2.0: (34.8, 0.021, 0.042),
        3.0: (22.9, 0.031, 0.058), 4.0: (20.2, 0.025, 0.050),
        6.0: (6.82, -0.016, 0.043),
    },
    "beryllium": {
        1.0: (204.0, -0.0579, -0.441), 2.0: (40.3, -0.0309, 0.0027),
        3.0: (42.7, -0.0151, 0.006), 4.0: (13.1, -0.022, 0.037),
        6.0: (10.8, -0.0146, 0.037), 8.0: (6.30, -0.018, 0.059),
        10.0: (4.73, -0.019, 0.082),
    },
    "graphite": {
        1.0: (127.0, -0.0466, -0.032), 2.0: (41.2, -0.026, 0.0001),
        3.0: (23.9, -0.0193, 0.015), 4.0: (12.1, -0.022, 0.037),
        6.0: (7.32, -0.0225, 0.055), 8.0: (4.99, -0.024, 0.084),
        10.0: (4.48, -0.0226, 0.067),
    },
    "iron": {
        1.0: (8.0, -0.089, 0.040), 2.0: (5.5, -0.079, 0.070),
        3.0: (4.4, -0.077, 0.075), 4.0: (3.75, -0.075, 0.082),
        6.0: (2.9, -0.082, 0.075), 8.0: (2.35, -0.083, 0.055),
        10.0: (2.0, -0.095, 0.012),
    },
    "lead": {
        1.0: (6.0, -0.009, 0.053), 2.0: (11.6, -0.021, 0.015),
        3.0: (10.9, -0.036, 0.001), 4.0: (6.29, -0.060, -0.007),
        6.0: (3.5, -0.108, -0.030), 8.0: (3.5, -0.157, -0.100),
        10.0: (2.39, -0.214, -0.092),
    },
    "tungsten": {
        1.0: (3.3, -0.043, 0.148), 2.0: (2.9, -0.069, 0.188),
        3.0: (2.7, -0.086, 0.134), 4.0: (2.05, -0.118, 0.070),
        6.0: (1.2, -0.171, 0.000), 8.0: (0.7, -0.205, 0.052),
        10.0: (0.6, -0.212, 0.144),
    },
    "uranium": {
        1.0: (2.081, -0.0386, 0.2264), 2.0: (3.550, -0.0344, 0.0881),
        3.0: (4.883, -0.0495, 0.0098), 4.0: (2.800, -0.0824, 0.0037),
        6.0: (0.975, -0.1589, 0.2110), 8.0: (0.602, -0.1919, 0.0277),
        10.0: (0.399, -0.2131, 0.0208),
    },
}

TABLE_ENERGIES_MEV = (1.0, 2.0, 3.0, 4.0, 6.0, 8.0, 10.0)


class ShieldingError(ValueError):
    """Raised when a shielding calculation is not well posed."""


@dataclass(frozen=True)
class TaylorBuildup:
    """Taylor two-exponential buildup factor, Eq. (14.10).

    ``B(mu_gamma) = A exp(-alpha mu_gamma) + (1 - A) exp(-beta mu_gamma)``
    """

    material: str
    energy_mev: float
    a: float
    alpha: float
    beta: float

    def __post_init__(self) -> None:
        for name in ("a", "alpha", "beta"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise ShieldingError(f"{name} must be finite, got {value!r}")
        if self.a < 0.0:
            raise ShieldingError("Taylor coefficient A must be non-negative")

    def factor(self, mu_gamma: float) -> float:
        """B(mu gamma). At mu gamma = 0 this is exactly 1."""
        if not math.isfinite(mu_gamma) or mu_gamma < 0.0:
            raise ShieldingError(
                f"optical thickness must be finite and non-negative, got {mu_gamma!r}"
            )
        return (self.a * math.exp(-self.alpha * mu_gamma)
                + (1.0 - self.a) * math.exp(-self.beta * mu_gamma))


def taylor_buildup(material: str, energy_mev: float) -> TaylorBuildup:
    """Look up Table 14.1 coefficients for a material and gamma energy.

    The table is tabulated at seven discrete energies. Interpolating between them
    would be an invented interpolation law, so a request that does not match a
    tabulated energy is refused, and the caller is told which energies exist.
    """
    key = material.strip().lower().replace(" ", "_").replace("-", "_")
    if key not in TAYLOR_TABLE:
        raise ShieldingError(
            f"no Taylor buildup coefficients for {material!r}; "
            f"Table 14.1 covers {sorted(TAYLOR_TABLE)}"
        )
    table = TAYLOR_TABLE[key]
    if energy_mev not in table:
        raise ShieldingError(
            f"{material!r} has no Table 14.1 entry at {energy_mev} MeV; "
            f"tabulated energies are {sorted(table)}"
        )
    a, alpha, beta = table[energy_mev]
    return TaylorBuildup(material=key, energy_mev=energy_mev,
                         a=a, alpha=alpha, beta=beta)


# ------------------------------------------------------- exponential integrals


def exponential_integral_e1(z: float) -> float:
    """E1(z) = integral from z to infinity of exp(-t)/t dt, for z > 0.

    Evaluated from the convergent series

        E1(z) = -gamma - ln z - sum_{n>=1} (-z)^n / (n * n!)

    which is accurate to machine precision for z up to about 40, where the
    asymptotic form ``E1 ~ exp(-z)/z (1 - 1/z + 2/z^2)`` takes over.
    """
    if not math.isfinite(z):
        raise ShieldingError(f"argument must be finite, got {z!r}")
    if z <= 0.0:
        raise ShieldingError(
            f"E1 is singular at z <= 0; got {z!r}"
        )
    euler_gamma = 0.5772156649015329
    if z > 40.0:
        inverse = 1.0 / z
        return math.exp(-z) * inverse * (1.0 - inverse * (1.0 - 2.0 * inverse))
    total = 0.0
    term = 1.0
    for n in range(1, 200):
        term *= -z / n
        total += term / n
        if abs(term / n) < 1e-18 * max(abs(total), 1.0):
            break
    return -euler_gamma - math.log(z) - total


def exponential_integral_e2(z: float) -> float:
    """E2(z) = integral from 1 to infinity of exp(-z t)/t^2 dt.

    This is the convention Emrich uses in Eq. (14.19): the integration variable
    runs from 1, not from z. It satisfies ``E2(0) = 1`` and
    ``E2(z) = exp(-z) - z E1(z)``, with ``E1`` the standard
    ``int_z^inf exp(-u)/u du``.

    For large ``z`` that difference cancels catastrophically (both terms are
    about e^-z), so the asymptotic form ``E2 ~ exp(-z)/z`` is used instead.
    """
    if not math.isfinite(z):
        raise ShieldingError(f"argument must be finite, got {z!r}")
    if z < 0.0:
        raise ShieldingError(f"E2 requires a non-negative argument, got {z!r}")
    if z == 0.0:
        return 1.0
    if z > 15.0:
        inverse = 1.0 / z
        return math.exp(-z) * inverse * (1.0 - 2.0 * inverse)
    return math.exp(-z) - z * exponential_integral_e1(z)


# ------------------------------------------------------------- attenuation


@dataclass(frozen=True)
class AttenuationCoefficients:
    """Linear attenuation coefficient for one material at one energy.

    Supplied by the caller: Emrich references NIST XCOM but plots rather than
    tabulates the values, so none are transcribed here.
    """

    material: str
    energy_mev: float
    mu_per_cm: float
    source: str

    def __post_init__(self) -> None:
        if not math.isfinite(self.mu_per_cm) or self.mu_per_cm <= 0.0:
            raise ShieldingError(
                f"mu must be finite and positive, got {self.mu_per_cm!r}"
            )
        if len(self.source.strip()) < 4:
            raise ShieldingError("attenuation coefficients require a source")
        if not math.isfinite(self.energy_mev) or self.energy_mev <= 0.0:
            raise ShieldingError("energy must be finite and positive")

    def mean_free_path_cm(self) -> float:
        return 1.0 / self.mu_per_cm

    def half_value_layer_cm(self) -> float:
        """Thickness that halves a narrow-beam intensity."""
        return math.log(2.0) / self.mu_per_cm

    def tenth_value_layer_cm(self) -> float:
        return math.log(10.0) / self.mu_per_cm


def narrow_beam_transmission(mu_per_cm: float, thickness_cm: float) -> float:
    """Eq. (14.7) with no buildup: transmission = exp(-mu * thickness)."""
    if not math.isfinite(mu_per_cm) or mu_per_cm < 0.0:
        raise ShieldingError("mu must be finite and non-negative")
    if not math.isfinite(thickness_cm) or thickness_cm < 0.0:
        raise ShieldingError("thickness must be finite and non-negative")
    return math.exp(-mu_per_cm * thickness_cm)


def point_kernel(mu_source_per_cm: float, source_path_cm: float,
                 mu_shield_per_cm: float, shield_path_cm: float,
                 buildup: TaylorBuildup, distance_cm: float) -> float:
    """Gamma point attenuation kernel, Eq. (14.12) with the source term of (14.11).

    Returns the kernel value per unit source strength, including the unshielded
    source-region attenuation ``exp(-mu_r T)``:

        kernel = exp(-mu_r T) * B(mu_s Q) * exp(-mu_s Q) / (4 pi R^2)
    """
    for name, value in (("mu_source_per_cm", mu_source_per_cm),
                        ("source_path_cm", source_path_cm),
                        ("mu_shield_per_cm", mu_shield_per_cm),
                        ("shield_path_cm", shield_path_cm)):
        if not math.isfinite(value) or value < 0.0:
            raise ShieldingError(f"{name} must be finite and non-negative, got {value!r}")
    if not math.isfinite(distance_cm) or distance_cm <= 0.0:
        raise ShieldingError("distance must be finite and positive")
    optical = mu_shield_per_cm * shield_path_cm
    return (math.exp(-mu_source_per_cm * source_path_cm)
            * buildup.factor(optical)
            * math.exp(-optical)
            / (4.0 * math.pi * distance_cm ** 2))


def slab_transmission(buildup: TaylorBuildup, mu_per_cm: float,
                      thickness_cm: float) -> float:
    """Semi-infinite slab attenuation, Eq. (14.21).

    The surface intensity ``S_a`` normalises out, so this returns the ratio
    ``phi(z) / phi(0)``:

        phi(z)/phi(0) = A E2[mu(1+alpha) z] + (1-A) E2[mu(1+beta) z]

    Note this is *not* an exponential: the exponential-integral form carries the
    geometric spreading of an infinite plane source. At z = 0 both integrals are
    1, so the ratio is exactly ``A + (1-A) = 1``.
    """
    if not math.isfinite(mu_per_cm) or mu_per_cm < 0.0:
        raise ShieldingError("mu must be finite and non-negative")
    if not math.isfinite(thickness_cm) or thickness_cm < 0.0:
        raise ShieldingError("thickness must be finite and non-negative")
    first = exponential_integral_e2(mu_per_cm * (1.0 + buildup.alpha) * thickness_cm)
    second = exponential_integral_e2(mu_per_cm * (1.0 + buildup.beta) * thickness_cm)
    return buildup.a * first + (1.0 - buildup.a) * second


def slab_dose_rate(surface_intensity_per_cm2_s: float, buildup: TaylorBuildup,
                   mu_per_cm: float, thickness_cm: float,
                   dose_conversion_sv_cm2: float) -> float:
    """Dose rate behind a slab [Sv/s].

    ``dose_conversion_sv_cm2`` converts fluence to dose and is caller-supplied:
    it depends on the energy spectrum and the ICRP convention in use, neither of
    which the book tabulates.
    """
    if not math.isfinite(surface_intensity_per_cm2_s) or surface_intensity_per_cm2_s < 0.0:
        raise ShieldingError("surface intensity must be finite and non-negative")
    if not math.isfinite(dose_conversion_sv_cm2) or dose_conversion_sv_cm2 <= 0.0:
        raise ShieldingError("dose conversion factor must be finite and positive")
    return (surface_intensity_per_cm2_s
            * slab_transmission(buildup, mu_per_cm, thickness_cm)
            * dose_conversion_sv_cm2)


def thickness_for_attenuation(buildup: TaylorBuildup, mu_per_cm: float,
                              target_ratio: float,
                              thickness_bounds_cm: tuple[float, float] = (1e-6, 1e4),
                              iterations: int = 200) -> float:
    """Shield thickness that attenuates the slab intensity to ``target_ratio``.

    Monotone in thickness, so bisection is safe. Being an exponential-integral
    form rather than a pure exponential, there is no closed-form inverse - which
    is exactly why this is solved numerically.
    """
    if not math.isfinite(target_ratio) or not 0.0 < target_ratio < 1.0:
        raise ShieldingError(
            f"target ratio must lie strictly between 0 and 1, got {target_ratio!r}"
        )
    if not math.isfinite(mu_per_cm) or mu_per_cm <= 0.0:
        raise ShieldingError("mu must be finite and positive")
    lo, hi = thickness_bounds_cm
    if not (lo < hi):
        raise ShieldingError("thickness bounds must be increasing")
    if slab_transmission(buildup, mu_per_cm, hi) > target_ratio:
        raise ShieldingError(
            f"even {hi:.4g} cm does not reach the target ratio; widen the bounds"
        )
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if slab_transmission(buildup, mu_per_cm, mid) > target_ratio:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-12:
            break
    return 0.5 * (lo + hi)
