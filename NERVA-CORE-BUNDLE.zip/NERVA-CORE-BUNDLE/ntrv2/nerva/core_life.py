"""Core life: fissile depletion, poison buildup, and reactivity versus time.

Every previous module answered a single-state question. This one answers the
question a mission actually asks: **how long can this core run, and what does its
reactivity do while it does?**

The reactivity ledger over life has three terms, each now measured rather than
assumed:

* **burnup** - fissile atoms consumed, from the fission rate;
* **poison** - xenon and samarium buildup, integrated from Ch. 13;
* **control** - whatever margin the drum bank can recover.

All three are expressed in the same currency (dk/k) so they can be summed, and
the end of core life is where the initial excess reactivity is exactly consumed.

Stated plainly: this is a **point-depletion** model. It tracks total fissile
inventory and total poison loading; it does not track individual nuclide chains
beyond I/Xe/Pm/Sm, and it does not redistribute power as the fissile content
changes. Formal nuclide-chain depletion is ``openmc.deplete``'s job and is gated
on ``libopenmc``; this module is the offline core-life estimate.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .core_metrics import AVOGADRO, U235_MOLAR_MASS_KG_MOL
from .fission_product_poisoning import (
    CorePoisoningInputs,
    PoisonInventory,
    PoisoningConstants,
    equilibrium_xenon,
    integrate_poisoning,
)

ENERGY_PER_FISSION_J = 3.204e-11
SECONDS_PER_DAY = 86400.0


class CoreLifeError(ValueError):
    """Raised when a core-life calculation is not well posed."""


@dataclass(frozen=True)
class CoreLifeParameters:
    """Inputs for a core-life march.

    ``poison_worth_per_cm`` is the *measured* dk/d(Sigma_a) from
    ``reactivity_coefficients.poison_worth`` - not an invented coefficient.
    ``burnup_worth_per_kg`` is dk/d(fissile mass consumed); it is supplied
    because it depends on the core's importance function, exactly like the poison
    worth did before that was measured.
    """

    initial_fissile_mass_kg: float
    thermal_power_w: float
    macroscopic_fission_xs_cm_inv: float
    neutron_flux_cm2_s: float
    initial_excess_reactivity: float
    poison_worth_per_cm: float
    burnup_worth_per_kg: float
    controllable_reactivity: float = 0.0

    def __post_init__(self) -> None:
        for name in ("initial_fissile_mass_kg", "thermal_power_w",
                     "macroscopic_fission_xs_cm_inv", "neutron_flux_cm2_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise CoreLifeError(f"{name} must be finite and positive, got {value!r}")
        for name in ("initial_excess_reactivity", "poison_worth_per_cm",
                     "burnup_worth_per_kg", "controllable_reactivity"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise CoreLifeError(f"{name} must be finite")
        if self.poison_worth_per_cm > 0.0:
            raise CoreLifeError(
                "poison worth must be negative (poison absorbs neutrons); "
                f"got {self.poison_worth_per_cm!r}"
            )

    @property
    def fission_rate_per_s(self) -> float:
        return self.thermal_power_w / ENERGY_PER_FISSION_J

    @property
    def fissile_atoms(self) -> float:
        return self.initial_fissile_mass_kg / U235_MOLAR_MASS_KG_MOL * AVOGADRO

    @property
    def fission_rate_fraction_per_s(self) -> float:
        """Fraction of the fissile inventory consumed per second."""
        return self.fission_rate_per_s / self.fissile_atoms

    def poisoning_inputs(self) -> CorePoisoningInputs:
        return CorePoisoningInputs(
            macroscopic_fission_xs_cm_inv=self.macroscopic_fission_xs_cm_inv,
            neutron_flux_cm2_s=self.neutron_flux_cm2_s)


@dataclass(frozen=True)
class LifePoint:
    """State of the core at one instant of the life march."""

    time_s: float
    effective_full_power_days: float
    fissile_mass_kg: float
    burnup_fraction: float
    poison: PoisonInventory
    poison_reactivity: float
    burnup_reactivity: float
    net_reactivity: float

    @property
    def available_reactivity(self) -> float:
        """Net reactivity still in hand once control margin is accounted for."""
        return self.net_reactivity


@dataclass(frozen=True)
class CoreLifeResult:
    """Outcome of a core-life march."""

    points: tuple[LifePoint, ...]
    end_of_life_days: float | None
    reason: str
    peak_poison_reactivity: float
    converged_to_poison_equilibrium: bool

    @property
    def has_finite_life(self) -> bool:
        return self.end_of_life_days is not None


def march_core_life(
    parameters: CoreLifeParameters,
    constants: PoisoningConstants,
    *,
    duration_days: float = 500.0,
    dt_s: float = 3600.0,
    reactivity_floor: float = 0.0,
) -> CoreLifeResult:
    """March fissile depletion and poison buildup, tracking reactivity.

    The core is considered to have reached end of life when the net reactivity
    falls to ``reactivity_floor``.
    """
    if not math.isfinite(duration_days) or duration_days <= 0.0:
        raise CoreLifeError("duration must be finite and positive")
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise CoreLifeError("timestep must be finite and positive")
    if not math.isfinite(reactivity_floor):
        raise CoreLifeError("reactivity floor must be finite")

    inputs = parameters.poisoning_inputs()
    total_seconds = duration_days * SECONDS_PER_DAY
    steps = max(1, int(round(total_seconds / dt_s)))
    # Keep the sample count bounded for long marches.
    sample_every = max(1, steps // 400)

    poison = PoisonInventory(0.0, 0.0, 0.0, 0.0)
    consumed_fraction = 0.0
    points: list[LifePoint] = []
    end_of_life_days: float | None = None
    peak_poison_reactivity = 0.0

    # Record the loading state at t = 0 before anything is burned. Recording
    # after the first integration step (the original ordering) mislabelled a
    # state one timestep old as the start of life.
    points.append(LifePoint(
        time_s=0.0, effective_full_power_days=0.0,
        fissile_mass_kg=parameters.initial_fissile_mass_kg,
        burnup_fraction=0.0, poison=poison, poison_reactivity=0.0,
        burnup_reactivity=0.0,
        net_reactivity=parameters.initial_excess_reactivity
        + parameters.controllable_reactivity,
    ))

    for index in range(steps):
        poison, _ = integrate_poisoning(
            inputs, constants, poison, duration_s=dt_s, dt_s=min(dt_s, 3600.0))
        # Fissile depletion over this step (fixed power, so fixed fission rate).
        consumed_fraction += parameters.fission_rate_fraction_per_s * dt_s
        if consumed_fraction >= 1.0:
            consumed_fraction = 1.0
        fissile_mass = parameters.initial_fissile_mass_kg * (1.0 - consumed_fraction)
        # The step just completed, so the state is at (index + 1) * dt.
        time_s = (index + 1) * dt_s

        absorption = poison.absorption_cm_inv(constants)
        poison_rho = parameters.poison_worth_per_cm * absorption
        burnup_rho = parameters.burnup_worth_per_kg * (
            parameters.initial_fissile_mass_kg - fissile_mass)
        net = (parameters.initial_excess_reactivity
               + poison_rho + burnup_rho
               + parameters.controllable_reactivity)
        peak_poison_reactivity = min(peak_poison_reactivity, poison_rho)

        exhausted = cooked = consumed_fraction >= 1.0
        reached_floor = end_of_life_days is None and net <= reactivity_floor
        # Record on the sample cadence, at the end of the window, and always at
        # the moment of end of life - otherwise an early break leaves the history
        # containing only the initial point.
        record = (index % sample_every == 0) or (index == steps - 1) \
            or reached_floor or exhausted
        if record:
            points.append(LifePoint(
                time_s=time_s,
                effective_full_power_days=time_s / SECONDS_PER_DAY,
                fissile_mass_kg=fissile_mass,
                burnup_fraction=consumed_fraction,
                poison=poison,
                poison_reactivity=poison_rho,
                burnup_reactivity=burnup_rho,
                net_reactivity=net,
            ))
        if reached_floor:
            end_of_life_days = time_s / SECONDS_PER_DAY
            break
        if exhausted:
            end_of_life_days = time_s / SECONDS_PER_DAY
            break

    # Poison equilibrium test: is the xenon inventory within a few percent of
    # its closed-form equilibrium value at the end of the march?
    final = points[-1]
    target = equilibrium_xenon(inputs, constants)
    converged = (target > 0.0
                 and abs(final.poison.xenon - target) / target < 0.05)

    reason = ("end of life reached: net reactivity fell to the floor"
              if end_of_life_days is not None else
              f"reactivity remained above the floor for the whole "
              f"{duration_days:.0f} day window; core life exceeds the window")

    return CoreLifeResult(
        points=tuple(points),
        end_of_life_days=end_of_life_days,
        reason=reason,
        peak_poison_reactivity=peak_poison_reactivity,
        converged_to_poison_equilibrium=converged,
    )


@dataclass(frozen=True)
class ReactivityLedgerEntry:
    """One line of a life-cycle reactivity ledger."""

    name: str
    reactivity: float
    evidence: str

    @property
    def pcm(self) -> float:
        return self.reactivity / 1.0e-5


def life_reactivity_ledger(point: LifePoint, initial_excess: float,
                           controllable: float = 0.0) -> tuple[ReactivityLedgerEntry, ...]:
    """Assemble the reactivity ledger at one point in the core's life.

    Signs: excess is positive (loaded), poison and burnup are losses, control is
    whatever the drums can still add back.
    """
    entries = [
        ReactivityLedgerEntry("initial excess reactivity", initial_excess,
                              f"{initial_excess/1e-5:+.1f} pcm loaded"),
        ReactivityLedgerEntry("fission-product poison", point.poison_reactivity,
                              f"Xe+Sm at {point.poison.xenon:.3e} /cm3"),
        ReactivityLedgerEntry("fissile burnup", point.burnup_reactivity,
                              f"{point.burnup_fraction*100:.2f}% of inventory consumed"),
    ]
    if controllable:
        entries.append(ReactivityLedgerEntry(
            "control drum recovery", controllable,
            f"{controllable/1e-5:+.1f} pcm available"))
    return tuple(entries)


def ledger_total(entries: tuple[ReactivityLedgerEntry, ...]) -> float:
    return math.fsum(entry.reactivity for entry in entries)
