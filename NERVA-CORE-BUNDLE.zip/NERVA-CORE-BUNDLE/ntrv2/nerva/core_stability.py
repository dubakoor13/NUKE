"""Core stability and two-region spatial kinetics.

Two capabilities were missing, and they are the same problem seen twice: the
model could integrate a transient but could not say whether an equilibrium is
*stable*, and it modelled the core as one point rather than as regions that can
drift out of phase. Xenon oscillations and regional power tilts are real
phenomena that a point model cannot represent at all.

Approach
--------
Linear stability analysis. The coupled system is linearised about an equilibrium
and its Jacobian eigenvalues are examined:

* a positive real part means the equilibrium is unstable;
* the imaginary part gives the oscillation frequency;
* the eigenvalue structure identifies the physical mode.

Two systems are analysed:

1. **Lumped** - full point kinetics (including the prompt mode, so the neutron
   lifetime is retained) coupled to the two-node thermal model.
2. **Two-region nodal** - the lumped system duplicated for two halves of the
   core, joined by a neutron exchange term. This is the smallest system that can
   show an *antisymmetric* (tilt) mode, which is the spatial instability a point
   model structurally cannot have.

The verification leans on an exact oracle: with the feedback coefficients set to
zero, the neutron block decouples from the thermal block and its eigenvalues must
be the **seven Inhour roots** of Ch. 11 - one positive root equal to the Inhour
omega plus six negative ones between the poles. Those roots are computed
independently by ``heritage.kinetics``.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .heritage import kinetics as kin


class StabilityError(ValueError):
    """Raised when a stability analysis is not well posed."""


def _u235_groups() -> kin.DelayedGroups:
    from .heritage.registry import load_registry

    data = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"
    return kin.u235_delayed_groups(load_registry(data))


@dataclass(frozen=True)
class StabilityParameters:
    """Linearisation point and coefficients for a stability analysis."""

    prompt_lifetime_s: float
    reference_power_w: float
    fuel_heat_capacity_j_k: float
    coolant_heat_capacity_j_k: float
    fuel_to_coolant_conductance_w_k: float
    coolant_removal_conductance_w_k: float
    fuel_temperature_coefficient_per_k: float
    coolant_temperature_coefficient_per_k: float
    groups: kin.DelayedGroups = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.groups is None:
            object.__setattr__(self, "groups", _u235_groups())
        for name in ("prompt_lifetime_s", "reference_power_w",
                     "fuel_heat_capacity_j_k", "coolant_heat_capacity_j_k",
                     "fuel_to_coolant_conductance_w_k",
                     "coolant_removal_conductance_w_k"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise StabilityError(f"{name} must be finite and positive, got {value!r}")
        for name in ("fuel_temperature_coefficient_per_k",
                     "coolant_temperature_coefficient_per_k"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise StabilityError(f"{name} must be finite")

    @property
    def n_precursors(self) -> int:
        return self.groups.n_groups


@dataclass(frozen=True)
class StabilityResult:
    """Eigenvalue structure of a linearised core."""

    eigenvalues: tuple[complex, ...]
    dominant_real: float
    dominant_imag: float
    stable: bool
    growth_rate_per_s: float
    oscillation_period_s: float | None
    description: str

    @property
    def doubling_time_s(self) -> float | None:
        if self.dominant_real <= 0.0:
            return None
        return math.log(2.0) / self.dominant_real


def _analyse(eigenvalues: np.ndarray, description: str) -> StabilityResult:
    ordered = sorted(eigenvalues, key=lambda value: -value.real)
    dominant = ordered[0]
    oscillatory = [value for value in ordered if abs(value.imag) > 1e-9]
    period = None
    if oscillatory and abs(dominant.imag) > 1e-9:
        period = 2.0 * math.pi / abs(dominant.imag)
    return StabilityResult(
        eigenvalues=tuple(complex(value) for value in ordered),
        dominant_real=float(dominant.real),
        dominant_imag=float(dominant.imag),
        stable=bool(dominant.real < 0.0),
        growth_rate_per_s=float(dominant.real),
        oscillation_period_s=period,
        description=description,
    )


# ------------------------------------------------------------- lumped system


def lumped_jacobian(parameters: StabilityParameters) -> np.ndarray:
    """Jacobian of the lumped core at a critical equilibrium.

    State vector: ``[n, C_1..C_m, T_fuel, T_coolant]`` where ``n`` is the neutron
    population normalised to the reference power. The equilibrium assumed is
    critical (``rho = 0``) with the temperatures at their power-equilibrium
    values, so the linearisation point is a genuine steady state.
    """
    p = parameters
    groups = p.groups
    m = p.n_precursors
    size = 1 + m + 2
    jacobian = np.zeros((size, size))
    lifetime = p.prompt_lifetime_s
    n0 = 1.0

    # Neutron population row: dn/dt = ((rho - beta)/L) n + sum(lambda_i C_i)
    #   rho = rho_ext + alpha_f (T_f - T_f0) + alpha_c (T_c - T_c0)
    jacobian[0, 0] = -groups.beta_total / lifetime       # rho0 = 0 at equilibrium
    for index, lam in enumerate(groups.lam):
        jacobian[0, 1 + index] = lam
    jacobian[0, 1 + m] = p.fuel_temperature_coefficient_per_k * n0 / lifetime
    jacobian[0, 1 + m + 1] = p.coolant_temperature_coefficient_per_k * n0 / lifetime

    # Precursor rows: dC_i/dt = (beta_i / L) n - lambda_i C_i
    for index, (beta, lam) in enumerate(zip(groups.beta, groups.lam)):
        jacobian[1 + index, 0] = beta / lifetime
        jacobian[1 + index, 1 + index] = -lam

    # Fuel node: C_f dT_f/dt = P_ref n - h (T_f - T_c)
    fuel_row = 1 + m
    jacobian[fuel_row, 0] = p.reference_power_w / p.fuel_heat_capacity_j_k
    jacobian[fuel_row, fuel_row] = -p.fuel_to_coolant_conductance_w_k / p.fuel_heat_capacity_j_k
    jacobian[fuel_row, fuel_row + 1] = p.fuel_to_coolant_conductance_w_k / p.fuel_heat_capacity_j_k

    # Coolant node: C_c dT_c/dt = h (T_f - T_c) - k_c (T_c - T_in)
    coolant_row = fuel_row + 1
    jacobian[coolant_row, fuel_row] = p.fuel_to_coolant_conductance_w_k / p.coolant_heat_capacity_j_k
    jacobian[coolant_row, coolant_row] = (
        -(p.fuel_to_coolant_conductance_w_k + p.coolant_removal_conductance_w_k)
        / p.coolant_heat_capacity_j_k)
    return jacobian


def analyse_lumped_stability(parameters: StabilityParameters) -> StabilityResult:
    """Eigenvalues of the lumped coupled core."""
    return _analyse(np.linalg.eigvals(lumped_jacobian(parameters)),
                    "lumped point kinetics + two-node thermal")


def neutron_block_eigenvalues(parameters: StabilityParameters) -> np.ndarray:
    """Eigenvalues of the neutron block alone (feedback coefficients zeroed).

    These must reproduce the Inhour roots, which is the oracle used in
    ``validate_core_stability``.
    """
    p = parameters
    groups = p.groups
    m = p.n_precursors
    lifetime = p.prompt_lifetime_s
    block = np.zeros((1 + m, 1 + m))
    block[0, 0] = -groups.beta_total / lifetime
    for index, lam in enumerate(groups.lam):
        block[0, 1 + index] = lam
    for index, beta in enumerate(groups.beta):
        block[1 + index, 0] = beta / lifetime
        block[1 + index, 1 + index] = -groups.lam[index]
    return np.linalg.eigvals(block)


# ------------------------------------------------------- two-region kinetics


@dataclass(frozen=True)
class TwoRegionParameters:
    """Two halves of a core coupled by neutron exchange."""

    base: StabilityParameters
    coupling_per_s: float
    """Neutron exchange coefficient between the regions [1/s].

    Large values force the two halves to move together; small values let them
    drift, which is the condition for a spatial power tilt.
    """

    def __post_init__(self) -> None:
        if not math.isfinite(self.coupling_per_s) or self.coupling_per_s < 0.0:
            raise StabilityError("coupling coefficient must be finite and non-negative")


def two_region_jacobian(parameters: TwoRegionParameters) -> np.ndarray:
    """Jacobian of the two-region nodal system.

    Each region is a full point-kinetics + thermal block; the neutron populations
    exchange ``c (n_j - n_i)``. State ordering is region 1 block then region 2
    block, so an eigenvector with opposite signs between the halves is an
    antisymmetric (tilt) mode.
    """
    single = lumped_jacobian(parameters.base)
    size = single.shape[0]
    jacobian = np.zeros((2 * size, 2 * size))
    jacobian[:size, :size] = single
    jacobian[size:, size:] = single
    coupling = parameters.coupling_per_s
    jacobian[0, 0] -= coupling
    jacobian[0, size] += coupling
    jacobian[size, size] -= coupling
    jacobian[size, 0] += coupling
    return jacobian


@dataclass(frozen=True)
class RegionMode:
    """One identified mode of the two-region system."""

    eigenvalue: complex
    symmetry: str
    region_amplitude_ratio: float

    @property
    def is_antisymmetric(self) -> bool:
        return self.symmetry == "antisymmetric"


def analyse_two_region_stability(
    parameters: TwoRegionParameters,
) -> tuple[StabilityResult, tuple[RegionMode, ...]]:
    """Eigenvalues plus a symmetric/antisymmetric classification.

    The classification uses the eigenvector: if the two halves' neutron
    components have the same sign the mode is symmetric (whole-core), if
    opposite it is antisymmetric (a spatial tilt).
    """
    jacobian = two_region_jacobian(parameters)
    values, vectors = np.linalg.eig(jacobian)
    size = jacobian.shape[0] // 2
    modes: list[RegionMode] = []
    for index, value in enumerate(values):
        vector = vectors[:, index]
        left = vector[0]
        right = vector[size]
        if abs(left) < 1e-300 or abs(right) < 1e-300:
            symmetry = "degenerate"
            ratio = float("inf")
        else:
            same_sign = (left.real * right.real) > 0.0
            symmetry = "symmetric" if same_sign else "antisymmetric"
            ratio = abs(right) / abs(left)
        modes.append(RegionMode(eigenvalue=complex(value), symmetry=symmetry,
                                region_amplitude_ratio=float(ratio)))
    result = _analyse(values, "two-region nodal kinetics")
    return result, tuple(modes)


def antisymmetric_growth_rate(parameters: TwoRegionParameters) -> float | None:
    """Growth rate of the most unstable antisymmetric mode, if any.

    This is the quantity that decides whether a spatial power tilt grows. A
    point-kinetics model cannot produce it at all.
    """
    _, modes = analyse_two_region_stability(parameters)
    antisymmetric = [mode for mode in modes if mode.is_antisymmetric]
    if not antisymmetric:
        return None
    return max(mode.eigenvalue.real for mode in antisymmetric)


# --------------------------------------------------------- xenon oscillations


def iodine_xenon_discriminant(lambda_i_s: float, lambda_xe_s: float,
                              sigma_xe_cm2: float, flux_cm2_s: float) -> float:
    """Discriminant of the single-region iodine/xenon linear system.

    The two-state loop has trace ``-(l_i + l_xe + sigma phi)`` and determinant
    ``l_i (l_xe + sigma phi)``, so

        disc = trace^2 - 4 det = (l_i - l_xe - sigma phi)^2

    which is a perfect square and therefore **never negative**. A single-region
    iodine/xenon model is always overdamped: it relaxes monotonically and cannot
    oscillate, at any flux. This function exists so that fact is explicit and
    testable instead of being assumed away.
    """
    for name, value in (("lambda_i_s", lambda_i_s), ("lambda_xe_s", lambda_xe_s),
                        ("sigma_xe_cm2", sigma_xe_cm2), ("flux", flux_cm2_s)):
        if not math.isfinite(value) or value <= 0.0:
            raise StabilityError(f"{name} must be finite and positive, got {value!r}")
    return (lambda_i_s - lambda_xe_s - sigma_xe_cm2 * flux_cm2_s) ** 2


def single_region_xenon_can_oscillate(lambda_i_s: float, lambda_xe_s: float,
                                      sigma_xe_cm2: float,
                                      flux_cm2_s: float) -> bool:
    """Always ``False``, and provably so (see :func:`iodine_xenon_discriminant`).

    Xenon oscillations are a **spatial** phenomenon: Emrich (2023) p.257
    describes xenon building up in a high-flux region, suppressing the flux
    there, decaying, and letting it recover. Capturing that needs at least two
    coupled regions with flux redistribution - which is what
    :func:`analyse_two_region_stability` provides - not a bigger single-node
    iodine/xenon loop.

    Returning ``False`` here rather than a fabricated period is the point: an
    earlier version of this module computed a `period` from the two-state loop
    and would have reported a number for something that cannot happen.
    """
    discriminant = iodine_xenon_discriminant(lambda_i_s, lambda_xe_s,
                                             sigma_xe_cm2, flux_cm2_s)
    return discriminant < 0.0
