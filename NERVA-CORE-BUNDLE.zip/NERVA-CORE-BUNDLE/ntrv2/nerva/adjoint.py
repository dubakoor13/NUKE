"""Adjoint flux and importance-weighted delayed fraction (beta_eff).

``delayed_parameters`` could combine per-nuclide delayed fractions but had to
take the adjoint (importance) correction as an unfilled caller input, because
nothing in the model could produce an adjoint. The diffusion solver can: the
adjoint of the k-eigenvalue problem is just the transpose system, so a genuine
adjoint flux is now available for a slab.

With it, ``beta_eff`` becomes a computed quantity rather than a supplied factor:

    beta_eff = <phi*, beta nu Sigma_f phi> / <phi*, nu Sigma_f phi>

summed over groups, where ``beta_g`` is the delayed fraction of the fissions
occurring in group ``g``. The distinction from plain ``beta`` is the whole point:
delayed neutrons are born at lower energy than prompt neutrons and are therefore
weighted differently by leakage and absorption.

What this is and is not
-----------------------
* It **is** an adjoint-weighted, group-resolved beta_eff from a deterministic
  diffusion solve.
* It is **not** adjoint-weighted against continuous-energy Monte Carlo data, and
  it inherits the diffusion approximation (1-D slab plus transverse buckling).
* In the one-group limit the adjoint is proportional to the flux, so
  ``beta_eff = beta`` exactly - which is the identity used to validate it.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .diffusion import (
    DiffusionError,
    MultigroupCrossSections,
    slab_system_matrices,
    solve_slab_eigenvalue,
)


class AdjointError(ValueError):
    """Raised when an adjoint calculation is not well posed."""


@dataclass(frozen=True)
class AdjointSolution:
    """Forward and adjoint flux shapes from the same discretisation."""

    k_effective: float
    adjoint_k_effective: float
    mesh_intervals: int
    groups: int
    forward_peaks: tuple[float, ...]
    adjoint_peaks: tuple[float, ...]
    reciprocity_residual: float
    converged: bool

    @property
    def k_agreement(self) -> float:
        """Relative difference between the forward and adjoint eigenvalues."""
        return abs(self.k_effective - self.adjoint_k_effective) / self.k_effective


def solve_slab_adjoint(cross_sections: MultigroupCrossSections,
                       thickness_cm: float, extrapolation_cm: float,
                       *, mesh_intervals: int = 120,
                       tolerance: float = 1e-10,
                       max_iterations: int = 5000) -> tuple[AdjointSolution, np.ndarray, np.ndarray]:
    """Solve the forward and adjoint k-eigenvalue problems for a bare slab.

    The adjoint problem is the transpose system,

        A^T phi* = (1/k) F^T phi*

    which has the same eigenvalue. Returns the solution plus both flux vectors
    so the caller can form importance-weighted integrals.
    """
    a_matrix, f_matrix = slab_system_matrices(
        cross_sections, thickness_cm, extrapolation_cm, mesh_intervals)
    a_adjoint = a_matrix.T
    f_adjoint = f_matrix.T

    def power_iterate(left: np.ndarray, right: np.ndarray
                      ) -> tuple[float, np.ndarray, bool, float]:
        size = left.shape[0]
        vector = np.ones(size)
        k = 1.0
        residual = float("inf")
        converged = False
        for _ in range(max_iterations):
            source = right @ vector
            new = np.linalg.solve(left, source)
            norm = float(np.max(np.abs(new)))
            if not math.isfinite(norm) or norm <= 0.0:
                raise AdjointError("the solve produced a non-physical flux")
            new = new / norm
            k = norm
            residual = float(np.max(np.abs(new - vector)))
            vector = new
            if residual < tolerance:
                converged = True
                break
        return float(k), vector, converged, residual

    forward_k, forward_flux, forward_converged, _ = power_iterate(a_matrix, f_matrix)
    adjoint_k, adjoint_flux, adjoint_converged, _ = power_iterate(a_adjoint, f_adjoint)

    # Reciprocity: <phi*, A phi> must equal <A^T phi*, phi>.
    lhs = float(adjoint_flux @ (a_matrix @ forward_flux))
    rhs = float((a_adjoint @ adjoint_flux) @ forward_flux)
    scale = max(abs(lhs), abs(rhs), 1e-30)
    reciprocity = abs(lhs - rhs) / scale

    nodes = mesh_intervals - 1
    groups = cross_sections.groups

    def peaks(vector: np.ndarray) -> tuple[float, ...]:
        return tuple(float(np.max(np.abs(vector[group * nodes:(group + 1) * nodes])))
                     for group in range(groups))

    solution = AdjointSolution(
        k_effective=forward_k,
        adjoint_k_effective=adjoint_k,
        mesh_intervals=mesh_intervals,
        groups=groups,
        forward_peaks=peaks(forward_flux),
        adjoint_peaks=peaks(adjoint_flux),
        reciprocity_residual=reciprocity,
        converged=forward_converged and adjoint_converged,
    )
    return solution, forward_flux, adjoint_flux


@dataclass(frozen=True)
class BetaEffResult:
    """Importance-weighted delayed fraction, with the parts that formed it."""

    beta_effective: float
    beta_unweighted: float
    importance_correction: float
    group_weights: tuple[float, ...]
    k_effective: float
    adjoint_used: bool

    @property
    def correction_percent(self) -> float:
        return (self.importance_correction - 1.0) * 100.0

    def describe(self) -> str:
        weight_text = " ".join(f"{weight:.4f}" for weight in self.group_weights)
        return (f"beta={self.beta_unweighted:.6f} -> beta_eff={self.beta_effective:.6f} "
                f"({self.correction_percent:+.3f}%)  group weights [{weight_text}]")


def importance_weighted_beta(
    cross_sections: MultigroupCrossSections,
    thickness_cm: float,
    extrapolation_cm: float,
    group_beta: tuple[float, ...],
    *,
    mesh_intervals: int = 120,
    tolerance: float = 1e-10,
) -> tuple[BetaEffResult, AdjointSolution]:
    """Compute ``beta_eff`` from forward and adjoint group fluxes.

    ``group_beta[g]`` is the delayed fraction appropriate to the fissions
    occurring in group ``g``. The weighted average is

        beta_eff = sum_g bbar_g phi*_g nuSf_g phi_g / sum_g phi*_g nuSf_g phi_g

    where ``bbar_g`` is the fission-rate-weighted mean beta within group ``g``.
    Group fluxes are taken as the peak of each group's shape, which for the
    fundamental mode is the group's amplitude.
    """
    if len(group_beta) != cross_sections.groups:
        raise AdjointError(
            f"group_beta has {len(group_beta)} entries but the cross-sections "
            f"have {cross_sections.groups} groups"
        )
    for index, value in enumerate(group_beta):
        if not math.isfinite(value) or not 0.0 <= value < 1.0:
            raise AdjointError(
                f"group_beta[{index}] must lie in [0, 1), got {value!r}"
            )

    solution, forward_flux, adjoint_flux = solve_slab_adjoint(
        cross_sections, thickness_cm, extrapolation_cm,
        mesh_intervals=mesh_intervals, tolerance=tolerance)
    if not solution.converged:
        raise AdjointError("the adjoint power iteration did not converge")

    nodes = mesh_intervals - 1
    numerator_adjoint = 0.0
    numerator_forward = 0.0
    denominator_adjoint = 0.0
    denominator_forward = 0.0
    weights: list[float] = []
    for group in range(cross_sections.groups):
        block = slice(group * nodes, (group + 1) * nodes)
        forward = float(np.max(np.abs(forward_flux[block])))
        adjoint = float(np.max(np.abs(adjoint_flux[block])))
        fission = cross_sections.nu_sigma_fission_cm[group]
        fission_density = fission * forward
        # Two DIFFERENT weights on purpose: the adjoint-weighted fission density
        # for beta_eff, and the forward-only density for the comparison. Using
        # the same weight for both made the "correction" identically 1.0 and
        # therefore meaningless.
        weight_adjoint = adjoint * fission_density
        weight_forward = fission_density
        weights.append(weight_adjoint)
        numerator_adjoint += group_beta[group] * weight_adjoint
        numerator_forward += group_beta[group] * weight_forward
        denominator_adjoint += weight_adjoint
        denominator_forward += weight_forward
    if denominator_adjoint <= 0.0 or denominator_forward <= 0.0:
        raise AdjointError(
            "the importance-weighted fission density is zero: no group produces "
            "fissions, so beta_eff is undefined"
        )
    beta_effective = numerator_adjoint / denominator_adjoint
    beta_forward_only = numerator_forward / denominator_forward
    total_weight = math.fsum(weights)
    if total_weight <= 0.0:
        raise AdjointError("adjoint fission weights sum to zero")
    normalised = tuple(weight / total_weight for weight in weights)
    correction = (beta_effective / beta_forward_only
                  if beta_forward_only > 0.0 else float("nan"))
    return (BetaEffResult(
        beta_effective=beta_effective,
        beta_unweighted=beta_forward_only,
        importance_correction=correction,
        group_weights=normalised,
        k_effective=solution.k_effective,
        adjoint_used=True,
    ), solution)
