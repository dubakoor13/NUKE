"""Numerical-independence studies: grid and timestep refinement.

Acceptance gate 6 requires that results are not artefacts of the discretisation.
That means demonstrating convergence under refinement, and ideally observing the
expected order of accuracy, rather than merely showing that a conservation
residual is small.

Two genuinely discretised solvers exist in this system, so two studies:

* **Axial grid** - ``thermal.solve_fuel_channel`` discretises the channel with
  ``z_edges_m``. Refining the axial mesh must converge the outlet temperature
  and the absorbed power.
* **Timestep** - the point-kinetics RK4 integrator. Halving ``dt`` must reduce
  the error against the analytic eigen-solution by ~2^4 = 16, giving an
  observed order near 4.

A third study covers the coupled core, which has **no spatial discretisation of
its own** (each fuel element is a lumped channel and elements do not couple).
Reporting a "grid study" there would be theatre. What *can* be shown is that
the converged answer does not depend on the iteration controls (relaxation and
tolerance), which is the relevant independence claim for a Picard loop.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .heritage import kinetics as kin
from .thermal import HydrogenProperties, solve_fuel_channel

SECONDS_PER_DAY = 86400.0


# ------------------------------------------------------------------ axial grid


@dataclass(frozen=True)
class GridPoint:
    nodes: int
    outlet_temperature_k: float
    peak_wall_temperature_k: float
    absorbed_power_w: float
    pressure_drop_pa: float


# Measured quantity chosen for the refinement test. The outlet temperature is
# an *analytically* grid-independent energy balance (T_out = T_in + P/(m cp)),
# so refining the mesh leaves it unchanged to machine precision - a useless
# convergence metric. The pressure drop is genuinely discretisation-sensitive
# because density and viscosity vary on every node, so it is the honest scalar
# to test.
GRID_METRIC = "pressure_drop_pa"


def axial_grid_study(*, length_m: float = 1.32, total_power_w: float = 5.9e4,
                     channel_count: int = 1, mass_flow_per_channel_kg_s: float = 2.0e-3,
                     inlet_temperature_k: float = 600.0,
                     inlet_pressure_pa: float = 5.0e6,
                     channel_diameter_m: float = 2.565e-3,
                     peak_to_average: float = 1.4,
                     node_counts: tuple[int, ...] = (8, 16, 32, 64, 128)) -> list[GridPoint]:
    """Refine the axial mesh and record the converged-when-refined quantities.

    Defaults describe one NERVA-like coolant channel (0.2565 cm bore, 1.32 m
    long, ~2 g/s of hydrogen, ~59 kW) so the outlet lands near 2660 K and
    Re ~ 8e4 - the regime the correlations are meant for. These are synthetic
    test conditions, not a heritage operating point.
    """
    properties = HydrogenProperties()
    points: list[GridPoint] = []
    for nodes in node_counts:
        edges = np.linspace(0.0, length_m, nodes + 1)
        centres = 0.5 * (edges[:-1] + edges[1:])
        # Cosine axial power shape normalised to the requested total power.
        raw = np.cos(0.5 * math.pi * (2.0 * centres / length_m - 1.0)
                     ** 2 * peak_to_average)
        raw = np.clip(raw, 1e-6, None)
        power = raw / raw.sum() * total_power_w
        solution = solve_fuel_channel(
            axial_total_fuel_power_w=power,
            z_edges_m=edges,
            fuel_channel_count=channel_count,
            mass_flow_per_channel_kg_s=mass_flow_per_channel_kg_s,
            inlet_temperature_k=inlet_temperature_k,
            inlet_pressure_pa=inlet_pressure_pa,
            channel_diameter_m=channel_diameter_m,
            properties=properties,
        )
        points.append(GridPoint(
            nodes=nodes,
            outlet_temperature_k=float(solution.outlet_temperature_k),
            peak_wall_temperature_k=float(np.max(solution.wall_temperature_k)),
            absorbed_power_w=float(solution.absorbed_power_w),
            pressure_drop_pa=float(inlet_pressure_pa - solution.outlet_pressure_pa),
        ))
    return points


def successive_changes(values: list[float]) -> list[float]:
    """Absolute change between consecutive refinement levels."""
    return [abs(b - a) for a, b in zip(values, values[1:])]


def _refinement_ratio(changes: list[float]) -> float:
    """Ratio of successive changes; >1 means the sequence is converging."""
    ratios = []
    for earlier, later in zip(changes, changes[1:]):
        if later <= 0.0:
            continue
        if earlier <= 0.0:
            continue
        ratios.append(earlier / later)
    return min(ratios) if ratios else 0.0


# ------------------------------------------------------------------- timestep


@dataclass(frozen=True)
class TimestepPoint:
    dt_s: float
    steps: int
    final_population: float
    relative_error: float


def _step_insertion_run(reactivity: float, lifetime: float, groups, dt: float,
                        horizon_s: float) -> tuple[float, int]:
    """Integrate a physical step insertion and return the final population.

    The initial state is the *critical equilibrium* at rho = 0, not the
    eigen-mode of the perturbed system. Starting on the eigen-vector would make
    RK4 exact for any timestep and turn the study into a tautology - the first
    version of this function did exactly that and reported 5e-16 errors.
    """
    n0 = 1.0
    precursors = [b / (lifetime * lam) * n0 for b, lam in zip(groups.beta, groups.lam)]
    steps = int(round(horizon_s / dt))
    history, _ = kin.integrate_point_kinetics(
        n0, precursors, reactivity, lifetime, groups, dt, steps)
    return history[-1], steps


def timestep_study(*, reactivity: float = 1.0e-3, lifetime: float = 1.0e-3,
                   dt_values: tuple[float, ...] = (2.0e-2, 1.0e-2, 5.0e-3,
                                                   2.5e-3, 1.25e-3),
                   horizon_s: float = 2.0,
                   reference_subdivisions: int = 32) -> list[TimestepPoint]:
    """Halve ``dt`` and measure the error against a strongly refined reference.

    A six-group transient has no single closed-form exponent, so the reference
    is a run at ``dt_min / reference_subdivisions`` on the same horizon. Errors
    are relative to that reference, which is standard refinement practice.
    """
    from .heritage.registry import load_registry

    data = Path(__file__).parent / "heritage" / "data" / "emrich2023_delayed_neutrons.json"
    groups = kin.u235_delayed_groups(load_registry(data))

    reference_dt = min(dt_values) / reference_subdivisions
    reference, reference_steps = _step_insertion_run(
        reactivity, lifetime, groups, reference_dt, horizon_s)

    points: list[TimestepPoint] = []
    for dt in dt_values:
        final, steps = _step_insertion_run(reactivity, lifetime, groups, dt, horizon_s)
        points.append(TimestepPoint(
            dt_s=dt, steps=steps, final_population=final,
            relative_error=abs(final - reference) / reference,
        ))
    return points


def observed_order(points: list[TimestepPoint]) -> float:
    """Estimate the order of accuracy from successive halvings of dt."""
    orders = []
    for coarse, fine in zip(points, points[1:]):
        if fine.relative_error <= 0.0 or coarse.relative_error <= 0.0:
            continue
        ratio = coarse.relative_error / fine.relative_error
        step_ratio = coarse.dt_s / fine.dt_s
        if ratio > 0.0 and step_ratio > 0.0:
            orders.append(math.log(ratio) / math.log(step_ratio))
    return float(np.median(orders)) if orders else float("nan")


# ------------------------------------------------- iteration-control sensitivity


@dataclass(frozen=True)
class ControlPoint:
    relaxation: float
    tolerance_k: float
    converged: bool
    iterations: int
    k_eff: float
    fuel_temperature_k: float


def iteration_control_study(*, target_power_w: float = 1.0e7) -> list[ControlPoint]:
    """Show the converged answer is independent of the Picard controls.

    A coupled solve is only trustworthy if the fixed point it reports does not
    depend on how aggressively it was damped or how tightly it was asked to
    converge.
    """
    from .coupled_core import (ChannelThermalClosure, CouplingParameters,
                               ThermalParameters, solve_coupled_core)
    from .transport_backend import CoreState, MockCoefficients, MockTransportBackend

    backend = MockTransportBackend(
        coefficients=MockCoefficients(
            k_reference=1.02,
            fuel_temperature_coefficient_per_k=-1.0e-5,
            hydrogen_temperature_coefficient_per_k=-2.0e-6,
            drum_coefficient_per_deg=2.0e-4,
            enrichment_coefficient_per_wt_percent=2.0e-2,
        ),
        element_count=7, radial_peaking=1.30,
        shape_temperature_sensitivity_per_k=-2.0e-5,
    )
    thermal = ChannelThermalClosure(ThermalParameters(
        coolant_inlet_temperature_k=600.0, coolant_density_kg_m3=2.0,
        total_mass_flow_kg_s=0.7, cp_j_kg_k=14300.0,
        channel_flow_area_m2=9.8e-5, channel_heated_perimeter_m=0.1531,
        channel_length_m=1.32, coolant_conductivity_w_m_k=0.18,
        coolant_viscosity_pa_s=1.2e-5, coolant_prandtl=0.95,
        fuel_conductivity_w_m_k=20.0, ligament_thickness_m=0.002,
    ))
    state = CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0)

    points: list[ControlPoint] = []
    # Tolerance is held tight so the comparison is about the *fixed point*, not
    # about how early each run stopped. A loose tolerance lets k differ in the
    # sixth digit purely because of when the loop was cut off.
    for relaxation, tolerance in ((0.3, 1.0e-3), (0.5, 1.0e-3), (0.7, 1.0e-3),
                                  (0.9, 1.0e-3), (0.7, 1.0e-4)):
        solution = solve_coupled_core(
            backend, state, thermal,
            CouplingParameters(target_power_w=target_power_w,
                               temperature_tolerance_k=tolerance,
                               k_tolerance=1e-9, max_iterations=400,
                               relaxation=relaxation),
        )
        points.append(ControlPoint(
            relaxation=relaxation, tolerance_k=tolerance,
            converged=solution.converged, iterations=solution.iterations,
            k_eff=solution.k_eff,
            fuel_temperature_k=solution.fuel_temperature_k,
        ))
    return points


# ------------------------------------------------------------------- recording


def build_record() -> dict:
    """Run every study and package the evidence for the acceptance reporter."""
    grid = axial_grid_study()
    time = timestep_study()
    controls = iteration_control_study()

    metric_values = [getattr(point, GRID_METRIC) for point in grid]
    metric_changes = successive_changes(metric_values)
    order = observed_order(time)

    return {
        "kind": "numerical-independence",
        "grid": {
            "study": "axial fuel-channel mesh refinement (thermal.solve_fuel_channel)",
            "sensitive_metric": GRID_METRIC,
            "metric_rationale": (
                "outlet temperature is an analytically grid-independent energy "
                "balance, so the discretisation-sensitive pressure drop is used"
            ),
            "levels": [point.nodes for point in grid],
            "metric_values": metric_values,
            "outlet_temperature_k": [point.outlet_temperature_k for point in grid],
            "peak_wall_temperature_k": [point.peak_wall_temperature_k for point in grid],
            "successive_metric_changes": metric_changes,
            "refinement_ratio": _refinement_ratio(metric_changes),
            "finest_change": metric_changes[-1] if metric_changes else None,
            "finest_relative_change": (
                metric_changes[-1] / abs(metric_values[-1])
                if metric_changes and metric_values[-1] else None
            ),
        },
        "timestep": {
            "study": "point-kinetics RK4 step insertion against a "
                     "32x-refined reference run",
            "dt_s": [point.dt_s for point in time],
            "relative_error": [point.relative_error for point in time],
            "observed_order": order,
        },
        "iteration_controls": {
            "study": "Picard relaxation sweep at fixed tight tolerance (the "
                     "lumped coupled core has no spatial grid to refine)",
            "k_spread": (max(p.k_eff for p in controls)
                         - min(p.k_eff for p in controls)),
            "temperature_spread_k": (max(p.fuel_temperature_k for p in controls)
                                     - min(p.fuel_temperature_k for p in controls)),
            "points": [
                {"relaxation": point.relaxation, "tolerance_k": point.tolerance_k,
                 "converged": point.converged, "iterations": point.iterations,
                 "k_eff": point.k_eff,
                 "fuel_temperature_k": point.fuel_temperature_k}
                for point in controls
            ],
        },
    }


def write_record(path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(build_record(), indent=1), encoding="utf-8")
    return target
