"""Reactor control system: sensing, actuation, regulation and protection.

The model could compute drum *worth* but had no control system - nothing that
decides how far to move a drum, how fast it may move, or when to scram. Worth is
the physics of a control device; a control system is the loop around it. This
module supplies the loop.

Structure
---------
* :class:`DrumDrive` - actuator: rate limit, total-travel limit, backlash-free
  setpoint following. A reactor drum cannot teleport; the rate limit is the
  dominant dynamic in most transients.
* :class:`ReactorController` - a PID regulator on a measured signal (power or
  temperature) producing a drum setpoint, with anti-windup and a deadband.
* :class:`ProtectionSystem` - independent trip logic with latching. Deliberately
  kept separate from the regulator: a protection system that shares the
  regulator's state is not independent, which is the whole point of one.
* :func:`simulate_controlled_startup` - closed-loop march using a plant callable.

The separation matters and is deliberate: the regulator may be saturated,
windup-limited or even failed, and the protection channel must still trip.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field


class ControlSystemError(ValueError):
    """Raised when a control-system configuration is invalid."""


# ------------------------------------------------------------------- actuator


@dataclass(frozen=True)
class DrumDrive:
    """Rate- and travel-limited drum actuator.

    ``rate_deg_per_s`` is the drive speed; ``travel_deg`` is the half-range so
    the drum cannot be driven past its mechanical stops.
    """

    rate_deg_per_s: float
    travel_deg: float = 180.0

    def __post_init__(self) -> None:
        if not math.isfinite(self.rate_deg_per_s) or self.rate_deg_per_s <= 0.0:
            raise ControlSystemError("drive rate must be finite and positive")
        if not math.isfinite(self.travel_deg) or self.travel_deg <= 0.0:
            raise ControlSystemError("drum travel must be finite and positive")

    def step(self, current_deg: float, demanded_deg: float, dt_s: float) -> float:
        """Move toward the demand, limited by rate and travel."""
        if not math.isfinite(dt_s) or dt_s <= 0.0:
            raise ControlSystemError("timestep must be finite and positive")
        for name, value in (("current angle", current_deg),
                            ("demanded angle", demanded_deg)):
            if not math.isfinite(value):
                raise ControlSystemError(f"{name} must be finite, got {value!r}")
        maximum_move = self.rate_deg_per_s * dt_s
        delta = demanded_deg - current_deg
        limited = max(-maximum_move, min(maximum_move, delta))
        target = current_deg + limited
        return max(-self.travel_deg, min(self.travel_deg, target))

    def settling_time_s(self, angle_change_deg: float) -> float:
        """Minimum time to move a given number of degrees."""
        if not math.isfinite(angle_change_deg):
            raise ControlSystemError("angle change must be finite")
        return abs(angle_change_deg) / self.rate_deg_per_s


# ------------------------------------------------------------------ regulator


@dataclass(frozen=True)
class PidGains:
    """Proportional, integral and derivative gains on the error signal."""

    kp: float
    ki: float = 0.0
    kd: float = 0.0
    integral_limit: float = 1.0e6

    def __post_init__(self) -> None:
        for name in ("kp", "ki", "kd"):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 0.0:
                raise ControlSystemError(f"{name} must be finite and non-negative")
        if self.kp == 0.0 and self.ki == 0.0 and self.kd == 0.0:
            raise ControlSystemError("at least one gain must be non-zero")
        if not math.isfinite(self.integral_limit) or self.integral_limit <= 0.0:
            raise ControlSystemError("integral limit must be finite and positive")


@dataclass(frozen=True)
class ControllerState:
    """Integrator and derivative memory, carried between steps."""

    integral: float = 0.0
    previous_error: float | None = None
    setpoint_deg: float = 0.0


@dataclass(frozen=True)
class ControllerOutput:
    """Result of one regulator update."""

    state: ControllerState
    demanded_deg: float
    raw_deg: float
    error: float
    saturated: bool


def update_controller(measurement: float, setpoint: float, gains: PidGains,
                      state: ControllerState, dt_s: float,
                      angle_bounds: tuple[float, float] = (-180.0, 180.0),
                      deadband: float = 0.0) -> ControllerOutput:
    """One PID update, with anti-windup and output clamping.

    The integrator is only advanced when the output is not saturated, which is
    the standard anti-windup remedy: without it a controller held against a stop
    will accumulate error and then overshoot badly once the plant responds.
    """
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise ControlSystemError("timestep must be finite and positive")
    for name, value in (("measurement", measurement), ("setpoint", setpoint)):
        if not math.isfinite(value):
            raise ControlSystemError(f"{name} must be finite, got {value!r}")
    if not math.isfinite(deadband) or deadband < 0.0:
        raise ControlSystemError("deadband must be finite and non-negative")
    low, high = angle_bounds
    if not low < high:
        raise ControlSystemError("angle bounds must be increasing")

    error = setpoint - measurement
    if abs(error) <= deadband:
        error = 0.0

    derivative = 0.0
    if gains.kd and state.previous_error is not None:
        derivative = (error - state.previous_error) / dt_s

    raw = (gains.kp * error + gains.ki * state.integral + gains.kd * derivative)
    clamped = max(low, min(high, raw))
    saturated = clamped != raw

    integral = state.integral
    if not saturated:
        integral = max(-gains.integral_limit,
                       min(gains.integral_limit, integral + error * dt_s))

    return ControllerOutput(
        state=ControllerState(integral=integral, previous_error=error,
                              setpoint_deg=clamped),
        demanded_deg=clamped, raw_deg=raw, error=error, saturated=saturated)


# ------------------------------------------------------------------ protection


@dataclass(frozen=True)
class TripChannel:
    """One protection trip: a signal, a threshold and a direction."""

    name: str
    threshold: float
    trips_high: bool = True
    latching: bool = True

    def is_tripped(self, value: float) -> bool:
        if not math.isfinite(value):
            # A non-finite measurement is itself a trip condition: a protection
            # channel must never be lulled by a NaN.
            return True
        return value >= self.threshold if self.trips_high else value <= self.threshold


@dataclass
class ProtectionSystem:
    """Independent, latching protection logic with a scram demand."""

    channels: tuple[TripChannel, ...]
    scram_angle_deg: float = -180.0
    _latched: dict[str, bool] = field(default_factory=dict)
    _demanding: bool = False

    def __post_init__(self) -> None:
        if not self.channels:
            raise ControlSystemError("at least one trip channel is required")
        if not math.isfinite(self.scram_angle_deg):
            raise ControlSystemError("scram angle must be finite")
        self._latched = {channel.name: False for channel in self.channels}
        self._demanding = False

    def evaluate(self, measurements: dict[str, float]) -> list[str]:
        """Evaluate all channels; return newly latched trip names."""
        newly: list[str] = []
        for channel in self.channels:
            if channel.name not in measurements:
                # A missing measurement cannot be ignored by a protection system.
                tripped = True
            else:
                tripped = channel.is_tripped(measurements[channel.name])
            if tripped and not self._latched[channel.name]:
                newly.append(channel.name)
                if channel.latching:
                    self._latched[channel.name] = True
            if tripped:
                self._demanding = True
        return newly

    @property
    def demanding_scram(self) -> bool:
        return self._demanding

    @property
    def latched_channels(self) -> tuple[str, ...]:
        return tuple(name for name, state in self._latched.items() if state)

    def reset(self) -> None:
        """Clear latches. Requires an explicit operator action by design."""
        self._latched = {name: False for name in self._latched}
        self._demanding = False


# ----------------------------------------------------------------- closed loop


@dataclass(frozen=True)
class ControlStep:
    """One instant of a controlled operation."""

    time_s: float
    measurement: float
    setpoint: float
    demanded_deg: float
    actual_deg: float
    scram: bool
    trips: tuple[str, ...]


@dataclass(frozen=True)
class ControlResult:
    """Outcome of a controlled operation."""

    steps: tuple[ControlStep, ...]
    final_measurement: float
    settled: bool
    demand_saturated_fraction: float
    scrammed: bool
    trips: tuple[str, ...]

    @property
    def setpoint_band(self) -> float:
        if not self.steps:
            return float("nan")
        return abs(self.final_measurement - self.steps[-1].setpoint)


def simulate_controlled_operation(
    plant, initial_measurement: float, setpoint: float, gains: PidGains,
    drive: DrumDrive, *, initial_angle_deg: float = 0.0,
    duration_s: float, dt_s: float, deadband: float = 0.0,
    protection: ProtectionSystem | None = None,
    measurement_name: str = "power",
    settle_tolerance: float = 1.0e-3,
) -> ControlResult:
    """Close the loop around a plant callable.

    ``plant(angle_deg) -> measured signal`` is supplied by the caller, so the
    controller can be exercised against the coupled core, a transient, or a
    simple analytic plant. Nothing about the plant is assumed here.
    """
    if not math.isfinite(duration_s) or duration_s <= 0.0:
        raise ControlSystemError("duration must be finite and positive")
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise ControlSystemError("timestep must be finite and positive")

    angle = initial_angle_deg
    measurement = initial_measurement
    state = ControllerState()
    steps: list[ControlStep] = []
    saturated_count = 0
    trips: list[str] = []
    scrammed = False

    increments = int(round(duration_s / dt_s))
    for index in range(increments + 1):
        time_s = index * dt_s
        if protection is not None:
            newly = protection.evaluate({measurement_name: measurement})
            trips.extend(name for name in newly if name not in trips)
            if protection.demanding_scram:
                scrammed = True

        if scrammed:
            demanded = drive.travel_deg * (-1.0 if protection else 1.0)
            demanded = protection.scram_angle_deg if protection else demanded
            output = None
            saturated = True
        else:
            output = update_controller(measurement, setpoint, gains, state,
                                       dt_s, deadband=deadband)
            state = output.state
            demanded = output.demanded_deg
            saturated = output.saturated
            if saturated:
                saturated_count += 1

        angle = drive.step(angle, demanded, dt_s)
        steps.append(ControlStep(
            time_s=time_s, measurement=measurement, setpoint=setpoint,
            demanded_deg=demanded, actual_deg=angle, scram=scrammed,
            trips=tuple(trips)))
        if index == increments:
            break
        measurement = plant(angle)

    final = steps[-1]
    settled = (not scrammed
               and abs(final.measurement - setpoint)
               <= settle_tolerance * max(abs(setpoint), 1e-30))
    return ControlResult(
        steps=tuple(steps),
        final_measurement=final.measurement,
        settled=settled,
        demand_saturated_fraction=saturated_count / max(len(steps), 1),
        scrammed=scrammed,
        trips=tuple(trips),
    )
