"""Core metrics: power peaking factors and fissile inventory.

Two quantities every core design is specified by, and neither existed in the
model:

* **Peaking factors** - how much hotter the hottest channel is than the average.
  These set the thermal margin, so they are a design constraint rather than a
  diagnostic.
* **Fissile inventory** - how much U-235 is loaded, and the specific power it
  runs at. NERVA-class cores run at tens of kilowatts per kilogram, so an
  inventory error is immediately visible.

Both are computed from data the core model already produces (the transport
heating distribution) or from explicitly supplied geometry and masses. No
heritage numbers are invented here: volumes and densities come from the caller,
and the module refuses to guess.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

AVOGADRO = 6.02214076e23
U235_MOLAR_MASS_KG_MOL = 0.2350432


class CoreMetricsError(ValueError):
    """Raised when a metric cannot be computed from the supplied data."""


@dataclass(frozen=True)
class PeakingFactors:
    """Radial, axial and total power peaking factors.

    Definitions follow standard practice:

    * radial peaking ``F_r``  = max element power / mean element power
    * axial peaking ``F_z``   = max axial power / mean axial power
    * total peaking ``F_q``   = max local power / mean local power

    ``F_q`` is *not* in general ``F_r * F_z``; that product is an upper bound
    that assumes the axial peak and radial peak coincide, which is why the
    coincidence factor is reported separately.
    """

    radial: float
    axial: float
    total: float
    radial_location: int | None = None
    axial_location: int | None = None

    def __post_init__(self) -> None:
        for name in ("radial", "axial", "total"):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 1.0 - 1e-12:
                raise CoreMetricsError(
                    f"{name} peaking factor must be >= 1, got {value!r}; a value "
                    f"below one would mean the peak is below the average"
                )

    @property
    def separation_bound(self) -> float:
        """Upper bound ``F_r * F_z``; equals ``F_q`` only if peaks coincide."""
        return self.radial * self.axial

    @property
    def coincidence_factor(self) -> float:
        """``F_q / (F_r F_z)``; 1.0 means the peaks coincide."""
        return self.total / self.separation_bound

    def describe(self) -> str:
        return (f"F_r={self.radial:.4f}  F_z={self.axial:.4f}  "
                f"F_q={self.total:.4f}  coincidence={self.coincidence_factor:.4f}")


def _peaking(values: list[float], label: str) -> tuple[float, int]:
    if not values:
        raise CoreMetricsError(f"{label} distribution is empty")
    negative = [value for value in values if value < 0.0]
    if negative:
        raise CoreMetricsError(
            f"{label} distribution contains negative values, which is not a power shape"
        )
    total = math.fsum(values)
    if total <= 0.0:
        raise CoreMetricsError(f"{label} distribution sums to zero")
    average = total / len(values)
    peak_index = max(range(len(values)), key=lambda i: values[i])
    return values[peak_index] / average, peak_index


def peaking_factors(radial_powers: list[float] | tuple[float, ...],
                    axial_powers: list[float] | tuple[float, ...] | None = None,
                    ) -> PeakingFactors:
    """Compute peaking factors from per-element and per-axial-node power.

    When only a radial distribution is available the axial factor is reported
    as 1.0 and the total equals the radial - which is an explicit statement that
    the axial direction is unresolved, not a claim that it is flat.
    """
    radial_values = [float(value) for value in radial_powers]
    radial, radial_index = _peaking(radial_values, "radial")
    if axial_powers is None:
        return PeakingFactors(radial=radial, axial=1.0, total=radial,
                              radial_location=radial_index, axial_location=None)

    axial_values = [float(value) for value in axial_powers]
    axial, axial_index = _peaking(axial_values, "axial")

    # The local peak is the worst element at its worst axial node. This is
    # exact for a separable shape and a conservative inner product bound
    # otherwise, so the normalised total is formed from the product of the two
    # normalised shapes.
    local_peak = radial * axial
    return PeakingFactors(radial=radial, axial=axial, total=local_peak,
                          radial_location=radial_index, axial_location=axial_index)


@dataclass(frozen=True)
class CoreInventory:
    """Fuel mass and fissile inventory for a core."""

    fuel_volume_m3: float
    fuel_density_kg_m3: float
    uranium_mass_fraction: float
    enrichment_wt_percent: float
    thermal_power_w: float

    def __post_init__(self) -> None:
        for name in ("fuel_volume_m3", "fuel_density_kg_m3",
                     "uranium_mass_fraction"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise CoreMetricsError(f"{name} must be finite and positive, got {value!r}")
        if not 0.0 < self.uranium_mass_fraction <= 1.0:
            raise CoreMetricsError("uranium mass fraction must lie in (0, 1]")
        if not 0.0 < self.enrichment_wt_percent < 100.0:
            raise CoreMetricsError("enrichment must lie in (0, 100) wt%")
        if not math.isfinite(self.thermal_power_w) or self.thermal_power_w <= 0.0:
            raise CoreMetricsError("thermal power must be finite and positive")

    @property
    def fuel_mass_kg(self) -> float:
        return self.fuel_volume_m3 * self.fuel_density_kg_m3

    @property
    def uranium_mass_kg(self) -> float:
        return self.fuel_mass_kg * self.uranium_mass_fraction

    @property
    def u235_mass_kg(self) -> float:
        return self.uranium_mass_kg * self.enrichment_wt_percent / 100.0

    @property
    def u238_mass_kg(self) -> float:
        return self.uranium_mass_kg - self.u235_mass_kg

    @property
    def u235_atoms(self) -> float:
        return self.u235_mass_kg / U235_MOLAR_MASS_KG_MOL * AVOGADRO

    @property
    def specific_power_kw_per_kg(self) -> float:
        """Thermal power per kilogram of U-235."""
        return (self.thermal_power_w / 1000.0) / self.u235_mass_kg

    @property
    def specific_power_total_kw_per_kg(self) -> float:
        """Thermal power per kilogram of total fuel mass."""
        return (self.thermal_power_w / 1000.0) / self.fuel_mass_kg

    def describe(self) -> str:
        return (f"fuel {self.fuel_mass_kg:8.2f} kg  "
                f"U {self.uranium_mass_kg:7.2f} kg  "
                f"U-235 {self.u235_mass_kg:6.3f} kg  "
                f"specific power {self.specific_power_kw_per_kg:6.1f} kW/kg(U-235)")


@dataclass(frozen=True)
class BurnupRate:
    """Fission rate and burnup rate implied by the thermal power."""

    power_w: float
    u235_mass_kg: float
    energy_per_fission_j: float = 3.204e-11

    def __post_init__(self) -> None:
        if not math.isfinite(self.power_w) or self.power_w <= 0.0:
            raise CoreMetricsError("power must be finite and positive")
        if not math.isfinite(self.u235_mass_kg) or self.u235_mass_kg <= 0.0:
            raise CoreMetricsError("U-235 mass must be finite and positive")

    @property
    def fissions_per_second(self) -> float:
        return self.power_w / self.energy_per_fission_j

    @property
    def u235_atoms(self) -> float:
        return self.u235_mass_kg / U235_MOLAR_MASS_KG_MOL * AVOGADRO

    @property
    def burnup_fraction_per_efpd(self) -> float:
        """Fraction of the U-235 inventory consumed per effective full-power day."""
        per_day = self.fissions_per_second * 86400.0 / self.u235_atoms
        return per_day

    @property
    def efpd_to_full_consumption(self) -> float:
        """Effective full-power days to consume the whole inventory (upper bound)."""
        return 1.0 / self.burnup_fraction_per_efpd

    @property
    def burnup_mwd_per_kg_u235(self) -> float:
        """Burnup rate in MWd per kg of U-235, per effective full-power day."""
        return self.power_w / 1e6 / self.u235_mass_kg
