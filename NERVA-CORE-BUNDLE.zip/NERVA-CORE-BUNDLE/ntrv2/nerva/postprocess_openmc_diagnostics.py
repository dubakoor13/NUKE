"""Advanced OpenMC diagnostics postprocessor for the NERVA-derived model."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import numpy as np
import openmc

from .power import EV_TO_J, heating_score_for_transport
from .neutron_energy_groups import spectral_fractions, ENERGY_LIMITS_EV
from .source_history_statistics import (
    analyze_correlated_history,
    batch_average_generation_k,
)


_MATERIAL_ORDER = (
    "fuel",
    "hydrogen",
    "zrc",
    "reflector",
    "graphite",
    "zrh",
    "inconel",
    "b4c",
    "aluminum",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract advanced OpenMC diagnostics from a NERVA-derived "
            "statepoint using the source-rate normalization from metadata.json."
        )
    )
    parser.add_argument("statepoint", type=Path)
    parser.add_argument(
        "--power-metadata",
        type=Path,
        required=True,
        help="metadata.json produced by postprocess_statepoint.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("build/nerva_diagnostics"),
    )
    return parser.parse_args()


def _tally_values(
    tally: openmc.Tally,
    score: str,
    value: str = "mean",
) -> np.ndarray:
    sliced = tally.get_slice(scores=[score])
    data = np.asarray(
        sliced.get_reshaped_data(value=value, expand_dims=True),
        dtype=float,
    )
    if data.shape[-2:] != (1, 1):
        raise ValueError(
            f"unexpected trailing tally dimensions {data.shape[-2:]}"
        )
    return np.asarray(data[..., 0, 0], dtype=float)


def _mesh_score(
    tally: openmc.Tally,
    score: str,
    value: str = "mean",
) -> tuple[np.ndarray, openmc.RegularMesh]:
    mesh_filter = tally.find_filter(openmc.MeshFilter)
    mesh = mesh_filter.mesh
    if not isinstance(mesh, openmc.RegularMesh):
        raise TypeError(f"{tally.name} must use RegularMesh")

    mesh_shape = tuple(int(v) for v in mesh.dimension)
    data = _tally_values(tally, score, value=value)

    if data.shape[: len(mesh_shape)] != mesh_shape:
        raise ValueError(
            f"{tally.name} mesh prefix {data.shape} does not begin "
            f"with {mesh_shape}"
        )

    if data.ndim > len(mesh_shape):
        data = np.sum(
            data,
            axis=tuple(range(len(mesh_shape), data.ndim)),
        )

    return data, mesh


def _uncertain_pair(obj: Any) -> tuple[float | None, float | None]:
    if obj is None:
        return None, None

    for mean_name, std_name in (
        ("nominal_value", "std_dev"),
        ("n", "s"),
        ("mean", "std_dev"),
    ):
        if hasattr(obj, mean_name):
            mean = float(getattr(obj, mean_name))
            std_attr = getattr(obj, std_name, None)
            std = None if std_attr is None else float(std_attr)
            return mean, std

    if isinstance(obj, (tuple, list)) and len(obj) >= 2:
        return float(obj[0]), float(obj[1])

    try:
        return float(obj), None
    except (TypeError, ValueError):
        return None, None


def _keff_pair(statepoint: openmc.StatePoint) -> tuple[float | None, float | None]:
    value = getattr(statepoint, "keff", None)
    if value is None:
        value = getattr(statepoint, "k_combined", None)
    return _uncertain_pair(value)


def _trend_metrics(
    values: np.ndarray,
    window: int = 20,
) -> dict[str, float | int | None]:
    array = np.asarray(values, dtype=float).reshape(-1)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return {
            "count": 0,
            "window_count": 0,
            "window_mean": None,
            "window_std": None,
            "window_range": None,
            "window_relative_range": None,
            "window_slope_per_index": None,
        }

    use = array[-min(window, array.size):]
    x = np.arange(use.size, dtype=float)
    slope = (
        float(np.polyfit(x, use, 1)[0])
        if use.size >= 2
        else 0.0
    )
    mean = float(np.mean(use))
    spread = float(np.max(use) - np.min(use))
    return {
        "count": int(array.size),
        "window_count": int(use.size),
        "window_mean": mean,
        "window_std": float(np.std(use, ddof=1)) if use.size > 1 else 0.0,
        "window_range": spread,
        "window_relative_range": (
            spread / abs(mean) if mean != 0.0 else None
        ),
        "window_slope_per_index": slope,
    }


def _entropy_history(statepoint: openmc.StatePoint) -> list[float]:
    entropy = getattr(statepoint, "entropy", None)
    if entropy is None:
        return []
    array = np.asarray(entropy, dtype=float).reshape(-1)
    return [float(v) for v in array]


def _spectral_fractions(
    energy_bins_ev: np.ndarray,
    spectrum: np.ndarray,
) -> dict[str, float]:
    """Use exact EnergyFilter-boundary accounting without invented spectra."""
    return spectral_fractions(energy_bins_ev, spectrum)


def _peaking_metrics(power_density: np.ndarray) -> dict[str, float]:
    values = np.asarray(power_density, dtype=float)
    maximum = float(np.max(values))
    if maximum <= 0.0:
        return {
            "maximum_W_cm3": 0.0,
            "mean_active_W_cm3": 0.0,
            "max_to_mean_active": 0.0,
        }

    active = values > 1.0e-9 * maximum
    mean_active = float(np.mean(values[active]))
    return {
        "maximum_W_cm3": maximum,
        "mean_active_W_cm3": mean_active,
        "max_to_mean_active": maximum / mean_active,
    }


def _relative_error_metrics(
    mean: np.ndarray,
    std: np.ndarray,
) -> dict[str, float]:
    mean = np.asarray(mean, dtype=float)
    std = np.asarray(std, dtype=float)

    max_mean = float(np.max(np.abs(mean)))
    if max_mean <= 0.0:
        return {
            "median_relative_error": 0.0,
            "p95_relative_error": 0.0,
            "max_relative_error": 0.0,
        }

    mask = np.abs(mean) > 1.0e-8 * max_mean
    rel = np.zeros_like(mean, dtype=float)
    rel[mask] = np.abs(std[mask] / mean[mask])
    valid = rel[mask]

    return {
        "median_relative_error": float(np.median(valid)),
        "p95_relative_error": float(np.percentile(valid, 95.0)),
        "max_relative_error": float(np.max(valid)),
    }


def main() -> int:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    metadata = json.loads(
        args.power_metadata.read_text(encoding="utf-8")
    )
    source_rate = float(metadata["source_rate_per_s"])
    if source_rate <= 0.0:
        raise ValueError("source_rate_per_s must be positive")

    with openmc.StatePoint(args.statepoint) as sp:
        photon_transport = bool(sp.photon_transport)
        heating_score = heating_score_for_transport(photon_transport)
        if metadata.get("power_normalization_score", "heating-local") != heating_score:
            raise ValueError(
                "OpenMC diagnostic heating score differs from power normalization; "
                "regenerate the mesh using this transport mode"
            )
        mesh_tally = sp.get_tally(name="nerva_3d_neutronics")
        local_heating, mesh = _mesh_score(mesh_tally, "heating-local")
        local_heating_std, _ = _mesh_score(
            mesh_tally, "heating-local", value="std_dev"
        )
        total_heating, _ = _mesh_score(mesh_tally, "heating")
        total_heating_std, _ = _mesh_score(
            mesh_tally, "heating", value="std_dev"
        )
        heating = total_heating if photon_transport else local_heating
        heating_std = total_heating_std if photon_transport else local_heating_std
        absorption, _ = _mesh_score(
            mesh_tally,
            "absorption",
        )
        nu_fission, _ = _mesh_score(
            mesh_tally,
            "nu-fission",
        )

        dimension = np.asarray(mesh.dimension, dtype=int)
        lower_left = np.asarray(mesh.lower_left, dtype=float)
        upper_right = np.asarray(mesh.upper_right, dtype=float)
        spacing = (upper_right - lower_left) / dimension
        cell_volume_cm3 = float(np.prod(spacing))

        power_density = (
            heating * EV_TO_J * source_rate / cell_volume_cm3
        )
        power_density_std = (
            heating_std * EV_TO_J * source_rate / cell_volume_cm3
        )
        total_heating_power_density = (
            total_heating
            * EV_TO_J
            * source_rate
            / cell_volume_cm3
        )
        total_heating_power_density_std = (
            total_heating_std
            * EV_TO_J
            * source_rate
            / cell_volume_cm3
        )
        absorption_rate = (
            absorption * source_rate / cell_volume_cm3
        )
        nu_fission_rate = (
            nu_fission * source_rate / cell_volume_cm3
        )

        material_tally = sp.get_tally(name="nerva_material_transport")
        material_filter = material_tally.find_filter(
            openmc.MaterialFilter
        )
        material_bins = list(material_filter.bins)
        material_names = list(_MATERIAL_ORDER[: len(material_bins)])

        material_rows: list[dict[str, float | str | int]] = []
        for score in (
            "flux",
            "absorption",
            "fission",
            "nu-fission",
            "heating",
            "heating-local",
        ):
            mean = _tally_values(
                material_tally,
                score,
            ).reshape(-1)
            std = _tally_values(
                material_tally,
                score,
                value="std_dev",
            ).reshape(-1)

            if len(mean) != len(material_names):
                raise ValueError(
                    f"material tally length {len(mean)} != "
                    f"expected {len(material_names)}"
                )

            for i, name in enumerate(material_names):
                if score in ("heating", "heating-local"):
                    value_scaled = (
                        float(mean[i]) * EV_TO_J * source_rate
                    )
                    std_scaled = (
                        float(std[i]) * EV_TO_J * source_rate
                    )
                    units = "W"
                else:
                    value_scaled = float(mean[i]) * source_rate
                    std_scaled = float(std[i]) * source_rate
                    units = (
                        "tracklength-cm/s"
                        if score == "flux"
                        else "reactions/s"
                    )

                material_rows.append(
                    {
                        "material": name,
                        "material_bin": int(material_bins[i]),
                        "score": score,
                        "value": value_scaled,
                        "std_dev": std_scaled,
                        "units": units,
                    }
                )

        material_energy = sp.get_tally(
            name="nerva_material_energy_transport"
        )
        material_energy_filter = material_energy.find_filter(
            openmc.EnergyFilter
        )
        material_energy_bins = np.asarray(
            material_energy_filter.bins,
            dtype=float,
        )
        material_energy_values = {}
        material_energy_std = {}
        energy_scores = (
            "flux", "absorption", "fission", "nu-fission", "heating-local"
        ) + (("heating",) if photon_transport else ())
        for score in energy_scores:
            values = np.asarray(
                _tally_values(material_energy, score),
                dtype=float,
            )
            std = np.asarray(
                _tally_values(
                    material_energy,
                    score,
                    value="std_dev",
                ),
                dtype=float,
            )
            if values.shape != (
                len(material_names),
                len(material_energy_bins),
            ):
                raise ValueError(
                    f"material-energy {score} shape {values.shape} "
                    f"!= {(len(material_names), len(material_energy_bins))}"
                )
            if score in ("heating", "heating-local"):
                values = values * EV_TO_J * source_rate
                std = std * EV_TO_J * source_rate
            else:
                values = values * source_rate
                std = std * source_rate
            material_energy_values[score] = values
            material_energy_std[score] = std

        try:
            particle_heating_tally = sp.get_tally(
                name="nerva_particle_heating"
            )
        except LookupError:
            particle_heating_rows = []
        else:
            particle_filter = particle_heating_tally.find_filter(
                openmc.ParticleFilter
            )
            particles = [str(v) for v in particle_filter.bins]
            particle_mean = _tally_values(
                particle_heating_tally,
                "heating",
            ).reshape(-1) * EV_TO_J * source_rate
            particle_std = _tally_values(
                particle_heating_tally,
                "heating",
                value="std_dev",
            ).reshape(-1) * EV_TO_J * source_rate
            particle_heating_rows = [
                {
                    "particle": particles[i],
                    "heating_W": float(particle_mean[i]),
                    "std_dev_W": float(particle_std[i]),
                }
                for i in range(len(particles))
            ]

        fuel_spec = sp.get_tally(name="nerva_fuel_spectrum")
        hydrogen_spec = sp.get_tally(
            name="nerva_hydrogen_spectrum"
        )

        energy_filter = fuel_spec.find_filter(openmc.EnergyFilter)
        energy_bins = np.asarray(energy_filter.bins, dtype=float)

        fuel_flux = _tally_values(
            fuel_spec,
            "flux",
        ).reshape(-1) * source_rate
        fuel_absorption = _tally_values(
            fuel_spec,
            "absorption",
        ).reshape(-1) * source_rate
        fuel_fission = _tally_values(
            fuel_spec,
            "fission",
        ).reshape(-1) * source_rate
        fuel_nu_fission = _tally_values(
            fuel_spec,
            "nu-fission",
        ).reshape(-1) * source_rate

        hydrogen_flux = _tally_values(
            hydrogen_spec,
            "flux",
        ).reshape(-1) * source_rate
        hydrogen_absorption = _tally_values(
            hydrogen_spec,
            "absorption",
        ).reshape(-1) * source_rate
        hydrogen_heating = (
            _tally_values(
                hydrogen_spec,
                heating_score,
            ).reshape(-1)
            * EV_TO_J
            * source_rate
        )

        axial_tally = sp.get_tally(name="nerva_axial_transport")
        axial_heating, axial_mesh = _mesh_score(
            axial_tally,
            heating_score,
        )
        axial_flux, _ = _mesh_score(
            axial_tally,
            "flux",
        )
        axial_fission, _ = _mesh_score(
            axial_tally,
            "fission",
        )
        axial_nu_fission, _ = _mesh_score(
            axial_tally,
            "nu-fission",
        )

        axial_dimension = np.asarray(
            axial_mesh.dimension,
            dtype=int,
        )
        axial_lower = np.asarray(axial_mesh.lower_left, dtype=float)
        axial_upper = np.asarray(axial_mesh.upper_right, dtype=float)
        axial_spacing = (
            axial_upper - axial_lower
        ) / axial_dimension
        axial_cell_volume = float(np.prod(axial_spacing))

        axial_power = (
            axial_heating.reshape(-1)
            * EV_TO_J
            * source_rate
        )
        axial_flux_rate = (
            axial_flux.reshape(-1)
            * source_rate
            / axial_cell_volume
        )
        axial_fission_rate = (
            axial_fission.reshape(-1)
            * source_rate
            / axial_cell_volume
        )
        axial_nu_fission_rate = (
            axial_nu_fission.reshape(-1)
            * source_rate
            / axial_cell_volume
        )

        z_centers = (
            axial_lower[2]
            + (
                np.arange(axial_dimension[2], dtype=float)
                + 0.5
            )
            * axial_spacing[2]
        )

        try:
            leakage = sp.get_tally(
                name="nerva_vacuum_boundary_current"
            )
        except LookupError:
            leakage_rows = []
        else:
            surface_filter = leakage.find_filter(
                openmc.SurfaceFilter
            )
            surface_bins = list(surface_filter.bins)
            current = _tally_values(
                leakage,
                "current",
            ).reshape(-1) * source_rate
            current_std = _tally_values(
                leakage,
                "current",
                value="std_dev",
            ).reshape(-1) * source_rate

            leakage_rows = [
                {
                    "surface_bin": int(surface_bins[i]),
                    "signed_current_per_s": float(current[i]),
                    "std_dev_per_s": float(current_std[i]),
                }
                for i in range(len(surface_bins))
            ]

        keff_mean, keff_std = _keff_pair(sp)
        entropy = _entropy_history(sp)

        k_generation = np.asarray(
            getattr(sp, "k_generation", []), dtype=float
        )
        n_inactive = int(getattr(sp, "n_inactive", 0))
        n_batches = int(getattr(sp, "n_batches", 0))
        generations_per_batch = int(
            getattr(sp, "generations_per_batch", 1)
        )
        k_batch_mean = batch_average_generation_k(
            k_generation,
            batches=n_batches,
            generations_per_batch=generations_per_batch,
        )
        active_k_batch_mean = k_batch_mean[n_inactive:]
        entropy_array = np.asarray(entropy, dtype=float)
        active_entropy = (
            entropy_array[n_inactive:]
            if entropy_array.size > n_inactive
            else np.asarray([], dtype=float)
        )


    with (args.output / "convergence_history.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "batch",
                "active",
                "k_batch_mean",
                "source_entropy",
            )
        )
        n_history = max(
            len(k_batch_mean),
            len(entropy),
        )
        for i in range(n_history):
            writer.writerow(
                (
                    i + 1,
                    int(i >= n_inactive),
                    (
                        k_batch_mean[i]
                        if i < len(k_batch_mean)
                        else ""
                    ),
                    (
                        entropy[i]
                        if i < len(entropy)
                        else ""
                    ),
                )
            )

    with (args.output / "material_transport.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "material",
                "material_bin",
                "score",
                "value",
                "std_dev",
                "units",
            ],
        )
        writer.writeheader()
        writer.writerows(material_rows)


    with (args.output / "material_energy_transport.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "material",
                "energy_low_eV",
                "energy_high_eV",
                "score",
                "value",
                "std_dev",
                "units",
            )
        )
        for m, material_name in enumerate(material_names):
            for e, (elow, ehigh) in enumerate(material_energy_bins):
                for score in energy_scores:
                    units = (
                        "W"
                        if score in ("heating", "heating-local")
                        else (
                            "tracklength-cm/s"
                            if score == "flux"
                            else "reactions/s"
                        )
                    )
                    writer.writerow(
                        (
                            material_name,
                            elow,
                            ehigh,
                            score,
                            material_energy_values[score][m, e],
                            material_energy_std[score][m, e],
                            units,
                        )
                    )

    with (args.output / "particle_heating.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=(
                "particle",
                "heating_W",
                "std_dev_W",
            ),
        )
        writer.writeheader()
        writer.writerows(particle_heating_rows)

    with (args.output / "spectra.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "energy_low_eV",
                "energy_high_eV",
                "fuel_flux_per_s",
                "fuel_absorption_per_s",
                "fuel_fission_per_s",
                "fuel_nu_fission_per_s",
                "hydrogen_flux_per_s",
                "hydrogen_absorption_per_s",
                "hydrogen_heating_W",
            )
        )
        for i, (elow, ehigh) in enumerate(energy_bins):
            writer.writerow(
                (
                    elow,
                    ehigh,
                    fuel_flux[i],
                    fuel_absorption[i],
                    fuel_fission[i],
                    fuel_nu_fission[i],
                    hydrogen_flux[i],
                    hydrogen_absorption[i],
                    hydrogen_heating[i],
                )
            )

    with (args.output / "axial_profile.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "z_cm",
                "power_W",
                "flux_cm2_s",
                "fission_rate_cm3_s",
                "nu_fission_rate_cm3_s",
            )
        )
        for i, z_cm in enumerate(z_centers):
            writer.writerow(
                (
                    z_cm,
                    axial_power[i],
                    axial_flux_rate[i],
                    axial_fission_rate[i],
                    axial_nu_fission_rate[i],
                )
            )

    with (args.output / "leakage_current.csv").open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "surface_bin",
                "signed_current_per_s",
                "std_dev_per_s",
            ],
        )
        writer.writeheader()
        writer.writerows(leakage_rows)

    np.savez_compressed(
        args.output / "openmc_diagnostics.npz",
        power_density_w_cm3=power_density,
        power_density_std_w_cm3=power_density_std,
        total_heating_power_density_w_cm3=(
            total_heating_power_density
        ),
        total_heating_power_density_std_w_cm3=(
            total_heating_power_density_std
        ),
        absorption_rate_cm3_s=absorption_rate,
        nu_fission_rate_cm3_s=nu_fission_rate,
        energy_bins_ev=energy_bins,
        fuel_flux_spectrum_per_s=fuel_flux,
        fuel_absorption_spectrum_per_s=fuel_absorption,
        fuel_fission_spectrum_per_s=fuel_fission,
        fuel_nu_fission_spectrum_per_s=fuel_nu_fission,
        hydrogen_flux_spectrum_per_s=hydrogen_flux,
        hydrogen_absorption_spectrum_per_s=hydrogen_absorption,
        hydrogen_heating_spectrum_w=hydrogen_heating,
        z_centers_cm=z_centers,
        axial_power_w=axial_power,
        axial_flux_cm2_s=axial_flux_rate,
        axial_fission_rate_cm3_s=axial_fission_rate,
        axial_nu_fission_rate_cm3_s=axial_nu_fission_rate,
        entropy=np.asarray(entropy, dtype=float),
        k_generation=k_generation,
        k_batch_mean=k_batch_mean,
        material_energy_bins_ev=material_energy_bins,
        material_energy_flux_x_source_rate=(
            material_energy_values["flux"]
        ),
        material_energy_absorption_per_s=(
            material_energy_values["absorption"]
        ),
        material_energy_fission_per_s=(
            material_energy_values["fission"]
        ),
        material_energy_nu_fission_per_s=(
            material_energy_values["nu-fission"]
        ),
        material_energy_heating_w=(
            material_energy_values[heating_score]
        ),
    )

    material_power = {
        row["material"]: float(row["value"])
        for row in material_rows
        if row["score"] == heating_score
    }
    material_power_total = sum(material_power.values())
    material_local_heating_sum = sum(
        float(row["value"]) for row in material_rows
        if row["score"] == "heating-local"
    )

    material_total_heating = {
        row["material"]: float(row["value"])
        for row in material_rows
        if row["score"] == "heating"
    }
    material_total_heating_sum = sum(material_total_heating.values())

    mesh_local_heating_w = float(
        np.sum(local_heating) * EV_TO_J * source_rate
    )
    mesh_total_heating_w = float(
        np.sum(total_heating_power_density) * cell_volume_cm3
    )
    nonlocal_heating_difference_w = (
        mesh_total_heating_w - mesh_local_heating_w
    )
    nonlocal_heating_fraction = (
        nonlocal_heating_difference_w / mesh_total_heating_w
        if mesh_total_heating_w != 0.0
        else 0.0
    )

    axial_positive = axial_power[axial_power > 0.0]
    if axial_positive.size:
        axial_peaking = float(
            np.max(axial_positive) / np.mean(axial_positive)
        )
    else:
        axial_peaking = 0.0

    summary = {
        "statepoint": str(args.statepoint),
        "power_metadata": str(args.power_metadata),
        "source_rate_per_s": source_rate,
        "photon_transport": photon_transport,
        "power_normalization_score": heating_score,
        "keff": {
            "mean": keff_mean,
            "std_dev": keff_std,
            "interpretation": (
                "reported diagnostic only; no automatic tuning/calibration"
            ),
        },
        "entropy_history": entropy,
        "entropy_last": None if not entropy else entropy[-1],
        "source_convergence": {
            "inactive_batches": n_inactive,
            "generations_per_batch": generations_per_batch,
            "per_batch_k_serial_correlation": (
                analyze_correlated_history(
                    k_batch_mean, inactive=n_inactive
                )
            ),
            "entropy_serial_correlation": (
                analyze_correlated_history(
                    entropy_array, inactive=n_inactive
                ) if entropy_array.size else None
            ),
            "active_k_batch_metrics": _trend_metrics(
                active_k_batch_mean
            ),
            "active_entropy_metrics": _trend_metrics(
                active_entropy
            ),
            "interpretation": (
                "Trend diagnostics only. No k-effective target or automatic "
                "criticality tuning is applied. Serial-correlation-adjusted "
                "effective samples remain diagnostic, not proof of source convergence."
            ),
        },
        "mesh_peaking": _peaking_metrics(power_density),
        "axial_power_peaking": axial_peaking,
        "mesh_heating_relative_error": _relative_error_metrics(
            heating,
            heating_std,
        ),
        "energy_deposition": {
            "mesh_heating_local_W": mesh_local_heating_w,
            "mesh_heating_W": mesh_total_heating_w,
            "heating_minus_heating_local_W": (
                nonlocal_heating_difference_w
            ),
            "heating_minus_local_fraction": (
                nonlocal_heating_fraction
            ),
            "material_heating_local_sum_W": material_local_heating_sum,
            "material_heating_sum_W": material_total_heating_sum,
            "interpretation": (
                "heating-local deposits secondary photon energy locally; "
                "heating reflects transport-aware energy deposition when "
                "compatible neutron/photon data are used"
            ),
        },
        "material_power_W": material_power,
        "material_total_heating_W": material_total_heating,
        "material_power_fractions": {
            key: (
                value / material_power_total
                if material_power_total > 0.0
                else 0.0
            )
            for key, value in material_power.items()
        },
        "neutron_spectrum_definition": {
            "thermal_upper_boundary_eV": ENERGY_LIMITS_EV[1],
            "fast_lower_boundary_eV": ENERGY_LIMITS_EV[2],
            "filter_minimum_energy_eV": float(energy_bins[0, 0]),
            "filter_maximum_energy_eV": float(energy_bins[-1, 1]),
            "fraction_normalization": (
                "Fraction of neutron fluence tallied inside OpenMC EnergyFilter "
                "range; not a fraction of all energies outside the filter"
            ),
            "boundary_mixed_bins_accepted": False,
        },
        "fuel_flux_spectral_fractions": _spectral_fractions(
            energy_bins,
            fuel_flux,
        ),
        "hydrogen_flux_spectral_fractions": _spectral_fractions(
            energy_bins,
            hydrogen_flux,
        ),
        "vacuum_boundary_current": leakage_rows,
        "particle_heating_W": {
            row["particle"]: row["heating_W"]
            for row in particle_heating_rows
        },
        "particle_heating_std_W": {
            row["particle"]: row["std_dev_W"]
            for row in particle_heating_rows
        },
        "material_energy_matrix": {
            "materials": material_names,
            "energy_groups": len(material_energy_bins),
            "csv": "material_energy_transport.csv",
        },
        "mesh": {
            "dimension": [int(v) for v in dimension],
            "lower_left_cm": [float(v) for v in lower_left],
            "upper_right_cm": [float(v) for v in upper_right],
            "cell_volume_cm3": cell_volume_cm3,
        },
        "model_status": (
            "OpenMC diagnostics for the non-calibrated low-enrichment "
            "NERVA-derived demonstrator; not a historical benchmark"
        ),
    }

    (args.output / "openmc_diagnostics.json").write_text(
        json.dumps(summary, indent=2) + "\n",
        encoding="utf-8",
    )

    print("Advanced NERVA OpenMC diagnostics written:")
    print(f"  k_eff: {keff_mean} +/- {keff_std}")
    print(
        f"  3-D max/mean-active peaking: "
        f"{summary['mesh_peaking']['max_to_mean_active']:.4f}"
    )
    print(f"  axial peaking: {axial_peaking:.4f}")
    print(
        f"  heating p95 relative error: "
        f"{summary['mesh_heating_relative_error']['p95_relative_error']:.4f}"
    )
    print(f"  output: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
