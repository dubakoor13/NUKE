"""Criticality search: find the control state that makes the core exactly critical.

A coupled core that reports ``k_eff = 1.023`` is a reactor that is not critical;
it is a reactor described by a number. Closing that gap is a root-find on the
control parameter (drum angle or enrichment) against a target eigenvalue, and
it is what turns "we computed k" into "here is the critical configuration".

Design rules:

* No damping, no damping-free optimism. If the objective is not monotone over
  the bracket, the search reports that instead of returning a number that
  happens to sit in a sign change.
* Every evaluation is recorded with its ``k`` and its uncertainty, so a
  reported result carries its own evidence trail.
* Terminal convergence is never claimed on a statistical tie: a Monte Carlo
  eigenvalue carries its own uncertainty, and an interval narrower than that
  uncertainty is not a better answer.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Callable

from .transport_backend import CoreState, TransportBackend


class CriticalitySearchError(ValueError):
    """Raised when the search cannot be set up or is not well posed."""


@dataclass(frozen=True)
class Evaluation:
    """One objective evaluation, kept as evidence."""

    parameter: float
    k_eff: float
    k_sigma: float


@dataclass(frozen=True)
class SearchResult:
    converged: bool
    reason: str
    parameter_name: str
    parameter_value: float
    k_eff: float
    k_sigma: float
    iterations: int
    bracket: tuple[float, float] | None
    history: tuple[Evaluation, ...]

    @property
    def critical_within_uncertainty(self) -> bool:
        """True when the achieved k is within one sigma of the target (1.0)."""
        return abs(self.k_eff - 1.0) <= max(self.k_sigma, 1e-12)


def _bisect(objective: Callable[[float], Evaluation], lo: float, hi: float,
            target: float, tolerance: float, max_iterations: int
            ) -> tuple[bool, str, float, Evaluation, list[Evaluation]]:
    """Bisection on a bracketed monotone root, recording every evaluation."""
    history: list[Evaluation] = []
    f_lo = objective(lo)
    history.append(f_lo)
    f_hi = objective(hi)
    history.append(f_hi)
    if (f_lo.k_eff - target) * (f_hi.k_eff - target) > 0.0:
        raise CriticalitySearchError(
            f"objective has the same sign at both ends of the bracket "
            f"[{lo}, {hi}]: k(lo)={f_lo.k_eff:.4f}, k(hi)={f_hi.k_eff:.4f}, "
            f"target={target}. Widen the bracket or change the parameter."
        )

    value = 0.5 * (lo + hi)
    last = f_lo
    for iteration in range(1, max_iterations + 1):
        value = 0.5 * (lo + hi)
        last = objective(value)
        history.append(last)
        error = last.k_eff - target
        # A Monte Carlo eigenvalue cannot be located more finely than its own
        # statistical uncertainty; stop rather than pretend otherwise.
        interval = 0.5 * (hi - lo)
        if abs(error) <= tolerance or interval <= tolerance:
            return True, (f"|k-target| {abs(error):.3g} <= tol {tolerance} "
                          f"or interval {interval:.3g} <= tol"), value, last, history
        if (error > 0.0) == (f_lo.k_eff - target > 0.0):
            lo = value
            f_lo = last
        else:
            hi = value
            f_hi = last
    return False, f"reached max_iterations={max_iterations}", value, last, history


def critical_control_state(
    backend: TransportBackend,
    base_state: CoreState,
    parameter: str,
    bounds: tuple[float, float],
    *,
    target_k: float = 1.0,
    tolerance: float = 1.0e-4,
    max_iterations: int = 60,
) -> SearchResult:
    """Find the control-parameter value that makes the core critical.

    ``parameter`` must be one of ``drum_angle_deg`` or ``enrichment_wt_percent``.
    The drum angle is *not* periodic here: the bracket must lie inside a single
    monotone pass of the worth curve, which is the caller's responsibility and
    is checked by the sign test.
    """
    backend.require_ready()
    allowed = {"drum_angle_deg", "enrichment_wt_percent"}
    if parameter not in allowed:
        raise CriticalitySearchError(
            f"unsupported search parameter {parameter!r}; expected one of {sorted(allowed)}"
        )
    lo, hi = bounds
    if not (math.isfinite(lo) and math.isfinite(hi)):
        raise CriticalitySearchError("search bounds must be finite")
    if lo == hi:
        raise CriticalitySearchError("search bounds must differ")
    if lo > hi:
        lo, hi = hi, lo
    if parameter == "enrichment_wt_percent":
        # CoreState enforces the < 20 wt% demonstration cap; catch it here so
        # the message is about the search, not about a constructor.
        if hi >= 20.0:
            raise CriticalitySearchError(
                f"enrichment upper bound {hi} wt% violates the <20 wt% cap on the "
                f"demonstration core; a HEU core requires its own evidence"
            )
    if not math.isfinite(target_k) or target_k <= 0.0:
        raise CriticalitySearchError("target k must be finite and positive")

    def objective(value: float) -> Evaluation:
        state: CoreState = replace(base_state, **{parameter: value})
        result = backend.run(state)
        return Evaluation(parameter=value, k_eff=result.k_eff,
                          k_sigma=result.k_sigma)

    converged, reason, value, last, history = _bisect(
        objective, lo, hi, target_k, tolerance, max_iterations)

    return SearchResult(
        converged=converged,
        reason=reason,
        parameter_name=parameter,
        parameter_value=value,
        k_eff=last.k_eff,
        k_sigma=last.k_sigma,
        iterations=len(history),
        bracket=(lo, hi),
        history=tuple(history),
    )


def drum_worth_curve(backend: TransportBackend, base_state: CoreState,
                     angles: list[float]) -> list[tuple[float, float, float]]:
    """Evaluate k at a set of drum angles: ``[(angle, k, sigma), ...]``.

    Useful before a search, and as the monotonicity evidence a search claims.
    """
    curve = []
    for angle in angles:
        result = backend.run(replace(base_state, drum_angle_deg=angle))
        curve.append((float(angle), result.k_eff, result.k_sigma))
    return curve


def check_monotone(curve: list[tuple[float, float, float]]) -> bool:
    """True when k changes in one direction only across the supplied angles."""
    signs = {
        1 if b[1] > a[1] else -1
        for a, b in zip(curve, curve[1:])
        if b[1] != a[1]
    }
    return len(signs) <= 1
