"""Control worth, excess reactivity and shutdown margin.

These are the operability quantities of a core. A criticality search answers
"where is k = 1"; a control-worth analysis answers the questions a designer
actually asks:

* How much reactivity does the drum bank hold, and how is it distributed?
* How much excess reactivity is loaded, and how much remains as margin?
* Is the core shut down with the drums fully inserted?

Everything is measured by transport perturbation. The one internal consistency
check worth leaning on is the fundamental theorem of calculus: numerically
integrating the *differential* worth must reproduce the *integral* worth. If
those two disagree, one of them is wrong.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, replace

from .reactivity_coefficients import PCM, to_pcm
from .transport_backend import CoreState, TransportBackend

# Emrich (2023) Table 11.1, p.204: 235U delayed fraction. Used only to express
# worth in dollars, and flagged as a thermal-spectrum value.
BETA_U235_THERMAL = 0.0065


class ControlWorthError(ValueError):
    """Raised when a worth analysis is not well posed."""


@dataclass(frozen=True)
class WorthPoint:
    """The core's multiplication at one drum angle."""

    angle_deg: float
    k_eff: float
    k_sigma: float


@dataclass(frozen=True)
class WorthCurve:
    """A drum worth curve with the reference angle it is measured against."""

    reference_angle_deg: float
    k_reference: float
    points: tuple[WorthPoint, ...]

    def __post_init__(self) -> None:
        if not self.points:
            raise ControlWorthError("a worth curve needs at least one point")
        angles = [point.angle_deg for point in self.points]
        if len(set(angles)) != len(angles):
            raise ControlWorthError(
                "duplicate drum angles in a worth curve; each angle must be "
                "evaluated once"
            )

    @property
    def total_worth(self) -> float:
        """Peak-to-peak reactivity swing across the curve (dk/k)."""
        values = [point.k_eff for point in self.points]
        return max(values) - min(values)

    @property
    def total_worth_pcm(self) -> float:
        return to_pcm(self.total_worth)

    @property
    def total_worth_dollars(self) -> float:
        return self.total_worth / BETA_U235_THERMAL

    def integral_worth_at(self, angle_deg: float) -> float:
        """Reactivity at an angle relative to the reference, in dk/k."""
        for point in self.points:
            if point.angle_deg == angle_deg:
                return point.k_eff - self.k_reference
        raise ControlWorthError(f"angle {angle_deg} is not in this curve")


def measure_worth_curve(
    backend: TransportBackend, state: CoreState,
    angles: tuple[float, ...],
    reference_angle_deg: float | None = None,
) -> WorthCurve:
    """Evaluate k over a set of drum angles."""
    if not angles:
        raise ControlWorthError("at least one drum angle is required")
    for angle in angles:
        if not math.isfinite(angle):
            raise ControlWorthError(f"drum angle must be finite, got {angle!r}")
    if reference_angle_deg is None:
        reference_angle_deg = angles[0]
    reference = backend.run(replace(state, drum_angle_deg=reference_angle_deg))
    points = []
    for angle in angles:
        result = backend.run(replace(state, drum_angle_deg=angle))
        points.append(WorthPoint(angle_deg=angle, k_eff=result.k_eff,
                                 k_sigma=result.k_sigma))
    return WorthCurve(reference_angle_deg=reference_angle_deg,
                      k_reference=reference.k_eff,
                      points=tuple(sorted(points, key=lambda p: p.angle_deg)))


@dataclass(frozen=True)
class DifferentialPoint:
    angle_deg: float
    dk_per_deg: float

    @property
    def pcm_per_deg(self) -> float:
        return to_pcm(self.dk_per_deg)


def measure_differential_worth(
    backend: TransportBackend, state: CoreState,
    angles: tuple[float, ...], perturbation_deg: float = 1.0,
) -> tuple[DifferentialPoint, ...]:
    """Local dk/dtheta at each angle, by central difference."""
    if not math.isfinite(perturbation_deg) or perturbation_deg <= 0.0:
        raise ControlWorthError("angular perturbation must be finite and positive")
    out = []
    for angle in angles:
        plus = backend.run(replace(state, drum_angle_deg=angle + perturbation_deg))
        minus = backend.run(replace(state, drum_angle_deg=angle - perturbation_deg))
        out.append(DifferentialPoint(
            angle_deg=angle,
            dk_per_deg=(plus.k_eff - minus.k_eff) / (2.0 * perturbation_deg),
        ))
    return tuple(out)


def integrate_differential_worth(
    differential: tuple[DifferentialPoint, ...]
) -> float:
    """Trapezoid integral of the differential worth over angle, in dk/k.

    Used to check the differential curve against the measured total worth.
    """
    if len(differential) < 2:
        raise ControlWorthError("integration needs at least two points")
    ordered = sorted(differential, key=lambda point: point.angle_deg)
    total = 0.0
    for left, right in zip(ordered, ordered[1:]):
        width = right.angle_deg - left.angle_deg
        total += 0.5 * (left.dk_per_deg + right.dk_per_deg) * width
    return total


@dataclass(frozen=True)
class OperabilityAssessment:
    """Excess reactivity and shutdown margin for a drum bank."""

    excess_reactivity: float        # k_withdrawn - 1
    shutdown_reactivity: float      # 1 - k_inserted
    k_withdrawn: float
    k_inserted: float
    k_sigma: float

    @property
    def excess_pcm(self) -> float:
        return to_pcm(self.excess_reactivity)

    @property
    def shutdown_margin_pcm(self) -> float:
        return to_pcm(self.shutdown_reactivity)

    @property
    def excess_dollars(self) -> float:
        return self.excess_reactivity / BETA_U235_THERMAL

    @property
    def shutdown_margin_dollars(self) -> float:
        return self.shutdown_reactivity / BETA_U235_THERMAL

    @property
    def is_shutdown(self) -> bool:
        """True when the fully inserted core is subcritical."""
        return self.k_inserted < 1.0

    @property
    def is_shutdown_with_sigma(self) -> bool:
        """Conservative shutdown: subcritical even one sigma high."""
        return self.k_inserted + self.k_sigma < 1.0

    @property
    def is_excess(self) -> bool:
        """True when the withdrawn core is supercritical, as it must be."""
        return self.k_withdrawn > 1.0


def assess_operability(
    backend: TransportBackend, state: CoreState,
    *, withdrawn_angle_deg: float, inserted_angle_deg: float,
) -> OperabilityAssessment:
    """Measure excess reactivity and shutdown margin for a drum bank.

    The withdrawn state must be supercritical (otherwise the core cannot reach
    power) and the inserted state must be subcritical (otherwise the bank is not
    a shutdown device). Both violations are reported, not hidden, but they are
    conditions on the *design*, so they are surfaced as flags rather than raised.
    """
    withdrawn = backend.run(replace(state, drum_angle_deg=withdrawn_angle_deg))
    inserted = backend.run(replace(state, drum_angle_deg=inserted_angle_deg))
    return OperabilityAssessment(
        excess_reactivity=withdrawn.k_eff - 1.0,
        shutdown_reactivity=1.0 - inserted.k_eff,
        k_withdrawn=withdrawn.k_eff,
        k_inserted=inserted.k_eff,
        k_sigma=max(withdrawn.k_sigma, inserted.k_sigma),
    )


@dataclass(frozen=True)
class ReactivityComponent:
    name: str
    reactivity: float
    evidence: str

    @property
    def pcm(self) -> float:
        return to_pcm(self.reactivity)


@dataclass(frozen=True)
class ReactivityBalance:
    """A signed reactivity ledger that must close on the intended state."""

    components: tuple[ReactivityComponent, ...]

    @property
    def total(self) -> float:
        return math.fsum(component.reactivity for component in self.components)

    @property
    def total_pcm(self) -> float:
        return to_pcm(self.total)

    def residual_to(self, target: float) -> float:
        """How far the ledger is from a target reactivity."""
        return self.total - target

    def as_text(self) -> str:
        width = max(len(component.name) for component in self.components)
        lines = [f"{'component':<{width}}  {'pcm':>12}  evidence"]
        for component in self.components:
            lines.append(f"{component.name:<{width}}  {component.pcm:>+12.2f}  "
                         f"{component.evidence}")
        lines.append(f"{'TOTAL':<{width}}  {self.total_pcm:>+12.2f}")
        return "\n".join(lines)


def build_reactivity_balance(excess: float, defect: float,
                             worth_inserted: float,
                             intended_margin: float = 0.0,
                             **extra: float) -> ReactivityBalance:
    """Assemble a reactivity ledger.

    Sign convention: positive means reactivity *added* to the core.

    * ``excess``      - the reactivity loaded at cold, drums withdrawn (positive)
    * ``defect``      - reactivity lost heating cold -> hot (entered negative)
    * ``worth_inserted`` - worth of the drums when inserted (entered negative)
    """
    components = [
        ReactivityComponent("excess reactivity (cold, withdrawn)", excess,
                            f"{to_pcm(excess):+.1f} pcm measured"),
        ReactivityComponent("temperature defect (cold -> hot)", -abs(defect),
                            f"{to_pcm(defect):+.1f} pcm measured"),
        ReactivityComponent("control drums inserted", -abs(worth_inserted),
                            f"{to_pcm(worth_inserted):+.1f} pcm measured"),
    ]
    for name, value in extra.items():
        components.append(ReactivityComponent(name, value, "caller supplied"))
    if intended_margin:
        components.append(ReactivityComponent("intended margin", -abs(intended_margin),
                                             "design target"))
    balance = ReactivityBalance(components=tuple(components))
    if not math.isfinite(balance.total):
        raise ControlWorthError("reactivity ledger did not produce a finite total")
    return balance
