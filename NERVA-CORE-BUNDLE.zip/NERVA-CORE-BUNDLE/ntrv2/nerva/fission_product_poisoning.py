"""Fission-product poisoning: xenon-135 and samarium-149.

This is the depletion physics that was missing. It is implemented here
independently of ``openmc.deplete`` because the physics is a small, closed set of
linear decay/burnup equations that can be solved exactly and verified offline -
and because ``openmc.deplete`` cannot be imported on a machine without
``libopenmc``, which left the whole poisoning problem unimplemented.

All equations follow Emrich (2023) Ch. 13 "Fuel burnup and transmutation",
pp.256-259, with the numbering preserved:

* Eq. (13.16)/(13.17) iodine and xenon rate equations
* Eq. (13.20)/(13.21) equilibrium iodine and xenon concentrations
* Eq. (13.22) equilibrium xenon *absorption*, which is flux dependent
* Eq. (13.23)/(13.24) post-shutdown iodine and xenon
* Eq. (13.25) xenon derivative at the instant of shutdown
* Eq. (13.26)/(13.27) promethium and samarium rate equations
* Eq. (13.30)/(13.31) equilibrium promethium and samarium

Data provenance is split honestly. The cross-sections and fission yields are
quoted by the book and are cited. The **decay constants are not** - the book
refers to them through Figures 13.4 and 13.6, which are figures, not tabulated
values - so they are supplied by the caller through :class:`PoisoningConstants`
and are flagged as external when they do not come from the supplied documents.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

# Thermal neutron speed at 0.025 eV, used to quote cross-sections as 2200 m/s
# values (Emrich quotes both cross-sections at 0.025 eV).
THERMAL_NEUTRON_SPEED_CM_S = 2.2e5


class PoisoningError(ValueError):
    """Raised when poisoning data or inputs are missing or inconsistent."""


@dataclass(frozen=True)
class PoisoningConstants:
    """Data required by the xenon and samarium models.

    Every field carries its provenance separately, because the book supplies
    some of these and not others and conflating them would make the whole set
    look equally well founded.
    """

    # From Emrich (2023) p.256 / p.258.
    sigma_xe_cm2: float      # 2.7e6 b at 0.082 eV resonance -> 2200 m/s value
    gamma_xe: float          # direct fission yield of 135Xe
    gamma_i: float           # yield to 135I via 135Te (book: gamma_Te)
    sigma_sm_cm2: float      # ~40,800 b at 0.025 eV
    gamma_pm: float          # yield to 149Pm via 149Nd (book: gamma_Nd)

    # NOT in the supplied documents (Figures 13.4/13.6 only).
    lambda_i_s: float
    lambda_xe_s: float
    lambda_pm_s: float

    source_cited: str = "emrich2023 Ch.13 pp.256-259"
    source_external: str = "EXTERNAL evaluated data - not in the supplied documents"

    def __post_init__(self) -> None:
        for name in ("sigma_xe_cm2", "gamma_xe", "gamma_i", "sigma_sm_cm2",
                     "gamma_pm", "lambda_i_s", "lambda_xe_s", "lambda_pm_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise PoisoningError(f"{name} must be finite and positive, got {value!r}")
        for name in ("gamma_xe", "gamma_i", "gamma_pm"):
            if not 0.0 < getattr(self, name) < 1.0:
                raise PoisoningError(f"{name} must be a fraction in (0, 1)")

    @property
    def xenon_rise_threshold_flux(self) -> float:
        """Flux above which xenon *increases* after shutdown (Eq. 13.25).

        The derivative is ``Sigma_f phi (sigma phi - gamma_Xe lambda_Xe) /
        (sigma phi + lambda_Xe)``, so the sign flips at ``sigma phi = gamma_Xe
        lambda_Xe``.
        """
        return self.gamma_xe * self.lambda_xe_s / self.sigma_xe_cm2

    def describe(self) -> str:
        return (f"sigma_Xe={self.sigma_xe_cm2:.3e} cm2  gamma_Xe={self.gamma_xe}  "
                f"gamma_I={self.gamma_i}  sigma_Sm={self.sigma_sm_cm2:.3e} cm2  "
                f"gamma_Pm={self.gamma_pm}")


# The standard evaluated decay constants, offered as a convenience with an
# explicit external provenance tag. 135I: 6.57 h; 135Xe: 9.14 h; 149Pm: 53.08 h.
STANDARD_DECAY_CONSTANTS = PoisoningConstants(
    sigma_xe_cm2=2.7e-18,      # Emrich p.256: 2.7e6 b
    gamma_xe=0.003,            # Emrich p.256
    gamma_i=0.064,             # Emrich p.256 (gamma_Te)
    sigma_sm_cm2=4.08e-20,     # Emrich p.258: 40,800 b
    gamma_pm=0.0113,           # Emrich p.258 (gamma_Nd)
    lambda_i_s=math.log(2.0) / (6.57 * 3600.0),
    lambda_xe_s=math.log(2.0) / (9.14 * 3600.0),
    lambda_pm_s=math.log(2.0) / (53.08 * 3600.0),
)


@dataclass(frozen=True)
class CorePoisoningInputs:
    """Core quantities the poisoning model needs."""

    macroscopic_fission_xs_cm_inv: float
    neutron_flux_cm2_s: float

    def __post_init__(self) -> None:
        for name in ("macroscopic_fission_xs_cm_inv", "neutron_flux_cm2_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0.0:
                raise PoisoningError(f"{name} must be finite and positive, got {value!r}")

    @property
    def fission_rate_density_cm3_s(self) -> float:
        return self.macroscopic_fission_xs_cm_inv * self.neutron_flux_cm2_s


# ------------------------------------------------------------------ equilibrium


def equilibrium_iodine(inputs: CorePoisoningInputs,
                       constants: PoisoningConstants) -> float:
    """Eq. (13.20): N_I(inf) = gamma_I Sigma_f phi / lambda_I."""
    return constants.gamma_i * inputs.fission_rate_density_cm3_s / constants.lambda_i_s


def equilibrium_xenon(inputs: CorePoisoningInputs,
                      constants: PoisoningConstants) -> float:
    """Eq. (13.21): N_Xe(inf) = (gamma_I + gamma_Xe) Sigma_f phi / (sigma phi + lambda)."""
    numerator = ((constants.gamma_i + constants.gamma_xe)
                 * inputs.fission_rate_density_cm3_s)
    denominator = (constants.sigma_xe_cm2 * inputs.neutron_flux_cm2_s
                   + constants.lambda_xe_s)
    return numerator / denominator


def equilibrium_xenon_absorption(inputs: CorePoisoningInputs,
                                 constants: PoisoningConstants) -> float:
    """Eq. (13.22): equilibrium xenon absorption rate per unit flux.

    ``Sigma_Xe_a = sigma N_Xe(inf) = (gamma_I + gamma_Xe) Sigma_f / (1 +
    lambda_Xe/(sigma phi))``. Independent of flux only at very high flux; below
    that the poisoning is flux dependent, which is the point the book makes.
    """
    return constants.sigma_xe_cm2 * equilibrium_xenon(inputs, constants)


def equilibrium_promethium(inputs: CorePoisoningInputs,
                           constants: PoisoningConstants) -> float:
    """Eq. (13.30): N_Pm(inf) = gamma_Pm Sigma_f phi / lambda_Pm."""
    return (constants.gamma_pm * inputs.fission_rate_density_cm3_s
            / constants.lambda_pm_s)


def equilibrium_samarium(inputs: CorePoisoningInputs,
                         constants: PoisoningConstants) -> float:
    """Eq. (13.31): N_Sm(inf) = gamma_Pm Sigma_f / sigma_Sm.

    Note this is **independent of flux**: samarium is burned only by absorption
    and produced at a rate proportional to the fission rate, so the flux cancels.
    """
    return constants.gamma_pm * inputs.macroscopic_fission_xs_cm_inv \
        / constants.sigma_sm_cm2


# ---------------------------------------------------------------- transients


def iodine_after_shutdown(iodine_at_shutdown: float, time_since_shutdown_s: float,
                          constants: PoisoningConstants) -> float:
    """Eq. (13.23)."""
    if time_since_shutdown_s < 0.0:
        raise PoisoningError("time since shutdown cannot be negative")
    return iodine_at_shutdown * math.exp(-constants.lambda_i_s * time_since_shutdown_s)


def xenon_after_shutdown(xenon_at_shutdown: float, iodine_at_shutdown: float,
                         time_since_shutdown_s: float,
                         constants: PoisoningConstants) -> float:
    """Eq. (13.24).

    An iodine precursor source feeds xenon while the xenon itself decays, so the
    concentration can rise before it falls - the classic post-shutdown xenon
    peak.
    """
    if time_since_shutdown_s < 0.0:
        raise PoisoningError("time since shutdown cannot be negative")
    t = time_since_shutdown_s
    li, lx = constants.lambda_i_s, constants.lambda_xe_s
    if abs(li - lx) < 1e-15:
        # Degenerate case: the closed form divides by (li - lx).
        xenon_from_iodine = li * iodine_at_shutdown * t * math.exp(-lx * t)
    else:
        xenon_from_iodine = (li * iodine_at_shutdown / (li - lx)
                             * (math.exp(-lx * t) - math.exp(-li * t)))
    return (xenon_from_iodine
            + xenon_at_shutdown * math.exp(-lx * t))


def xenon_derivative_at_shutdown(inputs: CorePoisoningInputs,
                                 constants: PoisoningConstants) -> float:
    """Eq. (13.25): dN_Xe/dt evaluated immediately after shutdown.

    Positive means xenon is *rising* when the reactor shuts down.
    """
    sigma_phi = constants.sigma_xe_cm2 * inputs.neutron_flux_cm2_s
    gamma_lambda = constants.gamma_xe * constants.lambda_xe_s
    return inputs.fission_rate_density_cm3_s * (sigma_phi - gamma_lambda) / (
        sigma_phi + constants.lambda_xe_s)


@dataclass(frozen=True)
class ShutdownXenonHistory:
    """Post-shutdown xenon behaviour, summarised."""

    times_s: tuple[float, ...]
    xenon: tuple[float, ...]
    equilibrium_xenon: float
    peak_xenon: float
    peak_time_s: float
    rises_after_shutdown: bool

    @property
    def peak_over_equilibrium(self) -> float:
        return self.peak_xenon / self.equilibrium_xenon


def shutdown_xenon_history(
    inputs: CorePoisoningInputs, constants: PoisoningConstants,
    *, horizon_s: float = 60.0 * 3600.0, samples: int = 600,
) -> ShutdownXenonHistory:
    """Track xenon from a long equilibrium burn through shutdown.

    The core is assumed to have been at equilibrium at this flux, then shut down
    at t = 0.
    """
    if not math.isfinite(horizon_s) or horizon_s <= 0.0:
        raise PoisoningError("horizon must be finite and positive")
    if samples < 2:
        raise PoisoningError("at least two samples are required")

    xenon0 = equilibrium_xenon(inputs, constants)
    iodine0 = equilibrium_iodine(inputs, constants)
    times = [horizon_s * index / (samples - 1) for index in range(samples)]
    values = [xenon_after_shutdown(xenon0, iodine0, t, constants) for t in times]
    peak_xenon = max(values)
    peak_index = values.index(peak_xenon)
    return ShutdownXenonHistory(
        times_s=tuple(times),
        xenon=tuple(values),
        equilibrium_xenon=xenon0,
        peak_xenon=peak_xenon,
        peak_time_s=times[peak_index],
        rises_after_shutdown=xenon_derivative_at_shutdown(inputs, constants) > 0.0,
    )


# ------------------------------------------------------------- reactivity worth


@dataclass(frozen=True)
class PoisonReactivity:
    """Reactivity worth of a poison inventory, in absolute dk/k.

    ``worth_per_atom_barn`` converts an absorber inventory into reactivity.
    It is supplied by the caller because it depends on the core's importance
    function, which this module does not have. Supplying it explicitly keeps the
    nuclear-data part and the core-specific part separate.
    """

    xenon_absorption: float
    samarium_absorption: float
    worth_per_absorption_per_cm3: float

    @property
    def total_reactivity(self) -> float:
        return ((self.xenon_absorption + self.samarium_absorption)
                * self.worth_per_absorption_per_cm3)

    @property
    def xenon_reactivity(self) -> float:
        return self.xenon_absorption * self.worth_per_absorption_per_cm3

    @property
    def samarium_reactivity(self) -> float:
        return self.samarium_absorption * self.worth_per_absorption_per_cm3

    @property
    def total_pcm(self) -> float:
        return self.total_reactivity / 1.0e-5

    def describe(self) -> str:
        return (f"xenon {self.xenon_reactivity/1e-5:+8.1f} pcm  "
                f"samarium {self.samarium_reactivity/1e-5:+8.1f} pcm  "
                f"total {self.total_pcm:+8.1f} pcm")


def poison_reactivity(inputs: CorePoisoningInputs, constants: PoisoningConstants,
                      worth_per_absorption_per_cm3: float) -> PoisonReactivity:
    """Reactivity tied up in equilibrium xenon and samarium."""
    if not math.isfinite(worth_per_absorption_per_cm3):
        raise PoisoningError("poison worth coefficient must be finite")
    return PoisonReactivity(
        xenon_absorption=equilibrium_xenon_absorption(inputs, constants),
        samarium_absorption=(constants.sigma_sm_cm2
                             * equilibrium_samarium(inputs, constants)),
        worth_per_absorption_per_cm3=worth_per_absorption_per_cm3,
    )


# ------------------------------------------------------- time integration


@dataclass(frozen=True)
class PoisonInventory:
    """Iodine, xenon, promethium and samarium number densities [1/cm3]."""

    iodine: float
    xenon: float
    promethium: float
    samarium: float

    def __post_init__(self) -> None:
        for name in ("iodine", "xenon", "promethium", "samarium"):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 0.0:
                raise PoisoningError(
                    f"{name} inventory must be finite and non-negative, got {value!r}"
                )

    def absorption_cm_inv(self, constants: PoisoningConstants) -> float:
        """Total poison macroscopic absorption, sigma_Xe N_Xe + sigma_Sm N_Sm."""
        return (constants.sigma_xe_cm2 * self.xenon
                + constants.sigma_sm_cm2 * self.samarium)

    @classmethod
    def equilibrium(cls, inputs: CorePoisoningInputs,
                    constants: PoisoningConstants) -> PoisonInventory:
        return cls(
            iodine=equilibrium_iodine(inputs, constants),
            xenon=equilibrium_xenon(inputs, constants),
            promethium=equilibrium_promethium(inputs, constants),
            samarium=equilibrium_samarium(inputs, constants),
        )


@dataclass(frozen=True)
class _PoisonRates:
    """Time derivatives of the poison inventories.

    Deliberately a distinct type from :class:`PoisonInventory`: inventories must
    be non-negative, but **derivatives are legitimately negative** (iodine decays,
    xenon is burned). Reusing the inventory type for rates made the integrator
    raise the moment any rate went negative.
    """

    iodine: float
    xenon: float
    promethium: float
    samarium: float

    def __post_init__(self) -> None:
        for name in ("iodine", "xenon", "promethium", "samarium"):
            value = getattr(self, name)
            if not math.isfinite(value):
                raise PoisoningError(f"{name} rate must be finite, got {value!r}")


def _poison_derivatives(inventory: PoisonInventory, inputs: CorePoisoningInputs,
                        constants: PoisoningConstants) -> _PoisonRates:
    """Right-hand sides of Eqs. (13.16), (13.17), (13.26) and (13.27)."""
    fission = inputs.fission_rate_density_cm3_s
    flux = inputs.neutron_flux_cm2_s
    d_iodine = constants.gamma_i * fission - constants.lambda_i_s * inventory.iodine
    d_xenon = (constants.gamma_xe * fission
               + constants.lambda_i_s * inventory.iodine
               - (constants.sigma_xe_cm2 * flux + constants.lambda_xe_s)
               * inventory.xenon)
    d_promethium = (constants.gamma_pm * fission
                    - constants.lambda_pm_s * inventory.promethium)
    d_samarium = (constants.lambda_pm_s * inventory.promethium
                  - constants.sigma_sm_cm2 * flux * inventory.samarium)
    return _PoisonRates(d_iodine, d_xenon, d_promethium, d_samarium)


def integrate_poisoning(
    inputs: CorePoisoningInputs, constants: PoisoningConstants,
    initial: PoisonInventory | None = None, *,
    duration_s: float, dt_s: float, sample_every: int = 1,
) -> tuple[PoisonInventory, list[tuple[float, PoisonInventory]]]:
    """Integrate the four-state poison system with classical RK4.

    Needed for a core-life march, where the poison inventory is still building
    up rather than at equilibrium. Returns the final inventory plus a sampled
    history of ``(time, inventory)``.
    """
    if not math.isfinite(duration_s) or duration_s <= 0.0:
        raise PoisoningError("duration must be finite and positive")
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise PoisoningError("timestep must be finite and positive")
    if sample_every < 1:
        raise PoisoningError("sample_every must be at least 1")

    state = initial or PoisonInventory(0.0, 0.0, 0.0, 0.0)
    steps = int(round(duration_s / dt_s))
    history: list[tuple[float, PoisonInventory]] = [(0.0, state)]
    for index in range(steps):
        k1 = _poison_derivatives(state, inputs, constants)
        half = dt_s / 2.0
        k2 = _poison_derivatives(_shift(state, k1, half), inputs, constants)
        k3 = _poison_derivatives(_shift(state, k2, half), inputs, constants)
        k4 = _poison_derivatives(_shift(state, k3, dt_s), inputs, constants)
        state = PoisonInventory(
            state.iodine + dt_s / 6.0 * (k1.iodine + 2 * k2.iodine + 2 * k3.iodine + k4.iodine),
            state.xenon + dt_s / 6.0 * (k1.xenon + 2 * k2.xenon + 2 * k3.xenon + k4.xenon),
            state.promethium + dt_s / 6.0 * (k1.promethium + 2 * k2.promethium + 2 * k3.promethium + k4.promethium),
            state.samarium + dt_s / 6.0 * (k1.samarium + 2 * k2.samarium + 2 * k3.samarium + k4.samarium),
        )
        if (index + 1) % sample_every == 0:
            history.append(((index + 1) * dt_s, state))
    return state, history


def _shift(inventory: PoisonInventory, derivative: _PoisonRates,
           dt: float) -> PoisonInventory:
    """Advance the inventory by one RK stage, clamping at zero.

    Clamping is a guard against a transient negative from a large step; the
    inventories are concentrations and cannot go below zero.
    """
    return PoisonInventory(
        max(0.0, inventory.iodine + dt * derivative.iodine),
        max(0.0, inventory.xenon + dt * derivative.xenon),
        max(0.0, inventory.promethium + dt * derivative.promethium),
        max(0.0, inventory.samarium + dt * derivative.samarium),
    )
