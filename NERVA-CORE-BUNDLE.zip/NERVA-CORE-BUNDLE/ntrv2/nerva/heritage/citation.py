"""Provenance primitives: a citation and a value that cannot exist without one."""
from __future__ import annotations

from dataclasses import dataclass, field

# Documents this registry is allowed to cite. A citation naming anything else
# is rejected, which keeps typos and invented sources out of the data files.
KNOWN_DOCUMENTS: dict[str, str] = {
    "emrich2023": (
        "Emrich, W.J. Jr., Principles of Nuclear Rocket Propulsion, "
        "Butterworth-Heinemann, 2023"
    ),
    "uf-ntp-2009": (
        "Charmeau, A., Cunningham, B., Anghaie, S., Ultrahigh Specific Impulse "
        "Nuclear Thermal Propulsion, Final Report, DOE Award DE-FG07-05ID14699, "
        "University of Florida, 2009"
    ),
}

# What kind of claim a number makes. This is the field that prevents a
# design target from being quoted as a measurement.
KINDS = (
    "measured",       # observed in a test
    "design-target",  # a specification or goal, not an observation
    "derived",        # computed from cited inputs by cited equations
    "assumed",        # NOT heritage data; must be named assumed_* and flagged
)

MIN_QUOTE_CHARS = 12


class ProvenanceError(ValueError):
    """Raised when a heritage value is uncited, mis-cited, or mislabelled."""


@dataclass(frozen=True)
class Citation:
    """Where a heritage value comes from, precisely enough to re-check it."""

    document: str
    section: str
    page: int
    locator: str
    quote: str

    def __post_init__(self) -> None:
        # Validate at construction: an invalid citation must not be able to
        # exist even transiently, so no caller can hold an unverified one.
        self.validate()

    def validate(self) -> None:
        if self.document not in KNOWN_DOCUMENTS:
            raise ProvenanceError(
                f"unknown document {self.document!r}; "
                f"known: {sorted(KNOWN_DOCUMENTS)}"
            )
        if not self.section.strip():
            raise ProvenanceError("citation needs a section")
        if not isinstance(self.page, int) or self.page < 1:
            raise ProvenanceError(f"citation page must be a positive int, got {self.page!r}")
        if not self.locator.strip():
            raise ProvenanceError("citation needs a locator (equation, table, figure)")
        if len(self.quote.strip()) < MIN_QUOTE_CHARS:
            raise ProvenanceError(
                f"citation quote too short ({len(self.quote.strip())} chars) to "
                f"support a heritage claim"
            )

    def as_dict(self) -> dict:
        return {
            "document": self.document,
            "section": self.section,
            "page": self.page,
            "locator": self.locator,
            "quote": self.quote,
        }

    def describe(self) -> str:
        return f"{self.document} p{self.page} [{self.locator}]"

    @classmethod
    def from_dict(cls, payload: dict) -> Citation:
        missing = {"document", "section", "page", "locator", "quote"} - set(payload)
        if missing:
            raise ProvenanceError(f"citation missing fields: {sorted(missing)}")
        citation = cls(
            document=payload["document"],
            section=payload["section"],
            page=payload["page"],
            locator=payload["locator"],
            quote=payload["quote"],
        )
        citation.validate()
        return citation


@dataclass(frozen=True)
class SourcedValue:
    """One heritage number, inseparable from the document that states it."""

    name: str
    value: float
    unit: str
    kind: str
    citation: Citation
    uncertainty: float | None = None
    note: str = ""

    def __post_init__(self) -> None:
        # Same rule as Citation: a value with no provenance cannot be built.
        self.validate()

    def validate(self) -> None:
        if not self.name.strip():
            raise ProvenanceError("sourced value needs a name")
        if not isinstance(self.value, (int, float)):
            raise ProvenanceError(f"{self.name}: value must be numeric, got {type(self.value)}")
        if not self.unit.strip():
            raise ProvenanceError(f"{self.name}: unit must be explicit")
        if self.kind not in KINDS:
            raise ProvenanceError(f"{self.name}: kind {self.kind!r} not in {KINDS}")
        self.citation.validate()
        if self.uncertainty is not None:
            if not isinstance(self.uncertainty, (int, float)) or self.uncertainty < 0:
                raise ProvenanceError(f"{self.name}: uncertainty must be >= 0")
        # An invented number may only enter under an assumed_ name, so no
        # reader can mistake it for a measured or design value.
        if self.kind == "assumed" and not self.name.startswith("assumed_"):
            raise ProvenanceError(
                f"{self.name}: kind='assumed' requires an 'assumed_' name prefix"
            )

    def as_dict(self) -> dict:
        payload = {
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "kind": self.kind,
            "citation": self.citation.as_dict(),
            "note": self.note,
        }
        if self.uncertainty is not None:
            payload["uncertainty"] = self.uncertainty
        return payload

    @classmethod
    def from_dict(cls, payload: dict) -> SourcedValue:
        missing = {"name", "value", "unit", "kind", "citation"} - set(payload)
        if missing:
            raise ProvenanceError(f"sourced value missing fields: {sorted(missing)}")
        entry = cls(
            name=payload["name"],
            value=payload["value"],
            unit=payload["unit"],
            kind=payload["kind"],
            citation=Citation.from_dict(payload["citation"]),
            uncertainty=payload.get("uncertainty"),
            note=payload.get("note", ""),
        )
        entry.validate()
        return entry
