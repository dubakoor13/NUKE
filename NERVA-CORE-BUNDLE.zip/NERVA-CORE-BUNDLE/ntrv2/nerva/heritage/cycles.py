"""Nuclear thermal rocket cycle methods (Emrich 2023, Ch. 3), pp.23-27.

The book defines three cycles and gives a closed energy balance for each.
Equation numbers are preserved so any disagreement with the text is easy to
find:

* Eq. (3.1) hot bleed  - the cycle NERVA actually flew (p.23)
* Eq. (3.2) cold bleed - never implemented in any rocket engine (p.24)
* expander            - all flow drives the turbine, no bleed dump (p.26)

Sign/convention note
--------------------
Enthalpies are always specific static enthalpies [J/kg] and mass flows are
always positive [kg/s]. Pump work appears on the left as an enthalpy *rise*;
turbine work appears on the right as an enthalpy *drop*. Every function
returns the residual ``lhs - rhs`` so a satisfied balance is exactly zero,
which makes convergence and regression tests unambiguous.
"""
from __future__ import annotations

import math


def _positive(name: str, value: float) -> None:
    if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} must be finite and positive, got {value!r}")


def _check_split(m_total: float, m_bleed: float) -> None:
    _positive("total mass flow", m_total)
    if not math.isfinite(m_bleed) or m_bleed < 0.0:
        raise ValueError(f"bleed mass flow cannot be negative, got {m_bleed!r}")
    if m_bleed > m_total:
        raise ValueError(
            f"bleed mass flow {m_bleed} exceeds total mass flow {m_total}; "
            f"a bleed branch may not consume the whole propellant stream"
        )


# ------------------------------------------------------------------ hot bleed


def mixed_bleed_enthalpy(m_warm: float, h_warm: float,
                         m_hot: float, h_hot: float) -> float:
    """Mass-weighted mixture enthalpy entering the turbine (p.24).

        h5 = (m_warm*h3 + m_hot*h4) / (m_warm + m_hot)

    The book writes this as the definition of h5 under Eq. (3.1).
    """
    if not math.isfinite(m_warm) or not math.isfinite(m_hot):
        raise ValueError("bleed mass flows must be finite")
    if m_warm < 0.0 or m_hot < 0.0:
        raise ValueError("bleed mass flows cannot be negative")
    total = m_warm + m_hot
    if total <= 0.0:
        raise ValueError("at least one bleed branch must carry flow")
    if not math.isfinite(h_warm) or not math.isfinite(h_hot):
        raise ValueError("bleed enthalpies must be finite")
    return (m_warm * h_warm + m_hot * h_hot) / total


def hot_bleed_energy_balance(m_total: float, h1: float, h2: float,
                             m_warm: float, h3: float,
                             m_hot: float, h4: float,
                             h6: float) -> float:
    """Residual of Eq. (3.1), the HOT BLEED cycle used by NERVA.

        m_total (h2 - h1) = m_bleed (h5 - h6)
        m_bleed = m_warm + m_hot
        h5      = (m_warm h3 + m_hot h4) / m_bleed

    The mixture enthalpy h5 is computed here rather than supplied, because a
    caller-supplied mixture enthalpy is the easiest place for a cycle model to
    silently stop conserving energy.
    """
    _positive("total mass flow", m_total)
    m_bleed = m_warm + m_hot
    _check_split(m_total, m_bleed)
    h5 = mixed_bleed_enthalpy(m_warm, h3, m_hot, h4)
    pump_work_per_kg = h2 - h1
    turbine_work_per_kg = h5 - h6
    if pump_work_per_kg <= 0.0:
        raise ValueError("pump enthalpy rise must be positive for a pump to do work")
    if turbine_work_per_kg <= 0.0:
        raise ValueError("turbine enthalpy drop must be positive for the turbine to do work")
    return m_total * pump_work_per_kg - m_bleed * turbine_work_per_kg


def hot_bleed_fraction(m_total: float, h1: float, h2: float,
                       h3: float, h4: float, h6: float,
                       hot_fraction_of_bleed: float) -> float:
    """Solve Eq. (3.1) for the total bleed fraction ``m_bleed / m_total``.

    ``hot_fraction_of_bleed`` is ``m_hot / m_bleed`` in [0, 1]; the remainder
    is warm bleed taken from the reactor inlet. Because the hot branch carries
    much more enthalpy per unit mass, a small hot fraction dramatically raises
    the turbine work available, which is exactly why the hot bleed cycle has
    the high efficiency the book describes on p.23.
    """
    _positive("total mass flow", m_total)
    if not 0.0 <= hot_fraction_of_bleed <= 1.0:
        raise ValueError("hot fraction of bleed must lie in [0, 1]")
    pump_work_per_kg = h2 - h1
    if pump_work_per_kg <= 0.0:
        raise ValueError("pump enthalpy rise must be positive")
    h5 = hot_fraction_of_bleed * h4 + (1.0 - hot_fraction_of_bleed) * h3
    turbine_work_per_kg = h5 - h6
    if turbine_work_per_kg <= 0.0:
        raise ValueError("bleed mixture has no enthalpy to give the turbine")
    fraction = pump_work_per_kg / turbine_work_per_kg
    if fraction > 1.0:
        raise ValueError(
            f"required bleed fraction {fraction:.3f} exceeds 1.0; this cycle "
            f"cannot close at the stated operating point"
        )
    return fraction


# ----------------------------------------------------------------- cold bleed


def cold_bleed_energy_balance(m_total: float, h1: float, h2: float,
                              m_bleed: float, h3: float, h4: float) -> float:
    """Residual of Eq. (3.2), the COLD BLEED cycle (p.24).

        m_total (h2 - h1) = m_bleed (h3 - h4)

    Emrich notes this cycle "has never been implemented in any rocket engine
    of any kind to date". It is implemented here for comparison only; its
    output must never be presented as NERVA behaviour.
    """
    _positive("total mass flow", m_total)
    _check_split(m_total, m_bleed)
    pump_work_per_kg = h2 - h1
    turbine_work_per_kg = h3 - h4
    if pump_work_per_kg <= 0.0:
        raise ValueError("pump enthalpy rise must be positive")
    if turbine_work_per_kg <= 0.0:
        raise ValueError("turbine enthalpy drop must be positive")
    return m_total * pump_work_per_kg - m_bleed * turbine_work_per_kg


def cold_bleed_fraction(m_total: float, h1: float, h2: float,
                        h3: float, h4: float) -> float:
    """Bleed fraction implied by Eq. (3.2)."""
    _positive("total mass flow", m_total)
    pump_work_per_kg = h2 - h1
    turbine_work_per_kg = h3 - h4
    if pump_work_per_kg <= 0.0:
        raise ValueError("pump enthalpy rise must be positive")
    if turbine_work_per_kg <= 0.0:
        raise ValueError("turbine enthalpy drop must be positive")
    fraction = pump_work_per_kg / turbine_work_per_kg
    if fraction > 1.0:
        raise ValueError(
            f"required bleed fraction {fraction:.3f} exceeds 1.0; the "
            f"cold-bleed cycle cannot close at this operating point (this is "
            f"the limitation described on p.24)"
        )
    return fraction


# -------------------------------------------------------------------- expander


def expander_energy_balance(h1: float, h2: float, h3: float, h4: float) -> float:
    """Residual of the EXPANDER cycle balance (p.26).

    No propellant is dumped, so the whole stream passes the turbine and the
    mass flows cancel:

        h2 - h1 = h3 - h4

    i.e. the pump work must be supplied entirely by regenerative heat picked
    up in the nozzle and chamber cooling circuits. That equality is what caps
    the achievable chamber pressure, and is the reason the book describes the
    expander cycle as low-pressure.
    """
    pump_work_per_kg = h2 - h1
    turbine_work_per_kg = h3 - h4
    if pump_work_per_kg <= 0.0:
        raise ValueError("pump enthalpy rise must be positive")
    if turbine_work_per_kg <= 0.0:
        raise ValueError("turbine enthalpy drop must be positive")
    return pump_work_per_kg - turbine_work_per_kg


def expander_available_turbine_work(m_total: float, h3: float, h4: float) -> float:
    """Total turbine power available with no bleed dump [W]."""
    _positive("total mass flow", m_total)
    drop = h3 - h4
    if drop <= 0.0:
        raise ValueError("regenerative enthalpy rise must exceed the turbine drop")
    return m_total * drop
