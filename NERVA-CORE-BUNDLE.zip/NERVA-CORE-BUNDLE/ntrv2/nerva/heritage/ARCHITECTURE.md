# NERVA heritage architecture — the permanent design

**Status:** Stage 1 landed and verified offline. 33/33 checks pass.

---

## The design principle

A propulsion model must keep two kinds of number permanently separate:

| | What it is | Where it lives | How it is trusted |
|---|---|---|---|
| **Method** | An equation fixed by physics — head, specific speed, energy balance, kinetics | Code: `ntr/nerva/heritage/*.py` | Verified against a textbook's own **worked example** |
| **Heritage data** | A value describing real hardware — a dimension, a test temperature, a thrust | `ntr/nerva/heritage/data/*.json` | Every value carries document + page + locator + verbatim quote |

They are never mixed. A formula may be written without permission from anyone; a *number about NERVA* may only enter through a citation.

This is what makes the model permanently maintainable: when better historical data arrives, you edit JSON. You do not touch physics code, and you cannot accidentally leave a stale constant behind.

## The verification oracle

The supplied documents contain **fully worked examples with printed answers**. This is what makes blind development safe — a chapter's methods can be checked to the book's own precision, with no OpenMC, no cross sections, and no network.

Demonstrated on Emrich (2023) Ch. 10, pp. 178–179 — a complete liquid-hydrogen pump design problem:

| Quantity | Code | Book | Rel. error |
|---|---|---|---|
| NPSH required | 513.78 m | 514 m | 0.04% |
| Pump head | 9230.9 m | 9230 m | 0.01% |
| Thoma parameter σ | 0.055659 | 0.0557 | 0.07% |
| Volume flow | 0.30014 m³/s | 0.3 m³/s | 0.05% |
| Shaft speed | 4760.6 rad/s | 4760 rad/s | 0.01% |
| Shaft speed | 45 460 rpm | 45 500 rpm | 0.09% |
| Impeller diameter | 0.16427 m | 0.164 m | 0.16% |
| Pump shaft power | 2.4199 MW | 2.42 MW | 0.00% |

Residual error is the book's own 3–4 significant-figure rounding. Reproduce with:

```
python -m ntr.nerva.validate_heritage_turbomachinery   # 17/17
python -m ntr.nerva.validate_heritage_registry         # 16/16
```

---

## Emrich (2023) chapter map — the build order

The book's structure *is* the module plan. Each chapter yields one module plus one worked-example verification.

| Ch. | Title | Pages | Module | Status |
|---|---|---|---|---|
| 1–2 | Introduction, rocket engine fundamentals | 1–34 | `engine_performance` (exists) | pre-existing |
| **3** | **Nuclear rocket engine cycles** | ~24–34 | `heritage/cycles.py` | methods partly landed (Eq. 3.2) |
| 5–8 | Nuclear structure, cross sections, transport, diffusion | ~90–175 | transport backend (OpenMC) | out of scope for offline work |
| **9** | **Thermal** | ~160–175 | `thermal`, `solve_thermal` (exist) | needs worked-example check |
| **10** | **Turbomachinery** | 175–201 | `heritage/turbomachinery.py` | **✅ landed + verified** |
| **11** | **Nuclear reactor kinetics** | 202–228 | `heritage/kinetics.py` | **next** — reactivity feedback |
| 12 | Nuclear rocket stability | 229–? | `stability.py` | later |
| **13** | **Fuel burnup and transmutation** | ~240–? | `depletion` driver | queued |
| 14 | Radiation shielding | — | — | out of scope |
| **15** | **Materials for NTR** | ~300–330 | `heritage/materials.json` | queued — worked example on p.322 |
| **16** | **Nuclear rocket engine testing** | ~330–400 | acceptance benchmarks | queued |
| 18 | Advanced concepts | — | — | out of scope |

Ch. 10 also carries a **turbine** worked example on pp. 198–199 (Eq. 10.7 rotor stress, efficiency contours) — that is the next verification target for `turbomachinery.py`.

---

## What these two documents do NOT contain

Stated plainly, because inventing these would be the only unforgivable failure:

| Missing datum | Consequence | Resolution |
|---|---|---|
| **Tie-tube / support-element dimensions** | Docs mention "support elements" (p.25, cycle prose) but give **no dimensions**. Zero hits for "tie tube" in either PDF. | `NervaConfig` keeps its existing values, flagged **unsourced surrogate**, not heritage |
| **Pump head–flow–efficiency curves** | Ch. 10 gives design *equations* and efficiency *contour figures* (Fig. 10.5, 10.10) — figures, not digitised data | Solver + `CycleCharacteristics` contract; values must be transcribed from the figures or sourced externally |
| **Turbine characteristic map** | Same — Fig. 10.10 is a contour plot, not a table | Same contract |
| **Per-element temperature feedback coefficients** | Ch. 11 gives the kinetics *equations*; coefficients come from transport + evaluated data | Implemented from equations; coefficients are computed, never assumed |
| **Historical XE-Prime / NRX test points at station level** | Ch. 16 discusses testing; no full state-station table | Requires NASA CR documents (e.g. NTRS 19680007802) |

Next sourcing targets, in priority order:

1. **NASA CR documents** for tie-tube/support-element geometry and the NERVA state-station map.
2. **Digitised Fig. 10.5 / 10.10** pump and turbine contours from Emrich, if no tabulated maps are available.
3. **NASA nuclear data** (HDF5 cross sections) for any actual transport run.

---

## Why "assumed" is a first-class label

`SourcedValue.kind` must be one of `measured`, `design-target`, `derived`, `assumed`. An `assumed` value **must** be named `assumed_*`, and the registry enforces this at construction time — an invented number physically cannot be stored under a name that looks like hardware data.

The registry also refuses to build invalid objects at all: `Citation.__post_init__` and `SourcedValue.__post_init__` validate immediately, so an uncited value cannot exist even transiently in memory. That hole was found by its own validator and fixed.

---

## Roadmap to completion

| Stage | Deliverable | Verifiable offline? | Status |
|---|---|---|---|
| 1 | Heritage registry + turbomachinery methods (Ch. 10) | **yes** | **✅ 17/17 + 16/16** |
| 2 | `heritage/kinetics.py` point kinetics + feedback closure (Ch. 11) | **yes** | **✅ 41/41** |
| 3 | `heritage/cycles.py` hot/cold bleed + expander (Ch. 3) | **yes** | **✅ 18/18** |
| 4 | `transport_backend.py` — mock + OpenMC adapter seam | mock yes | **✅ 25/25** |
| 5 | `coupled_core.py` — coupled loop + critical-power solve | yes (mock) | **✅ 32/32** |
| 6 | `criticality_search.py` — k=1 by drum angle / enrichment | yes (analytic) | **✅ included** |
| 7 | `depletion_driver.py` — `openmc.deplete` wiring | partial — needs `libopenmc` | **✅ 22/22 (units + refusal)** |
| 8 | `cycle_closure.py` — pump operating point, replaces frozen ref | yes (synthetic curves) | **✅ 26/26** |
| 9 | `acceptance_gates.py` — evidence-driven 8-gate evaluation | yes | **✅ 19/19** |
| 10 | `preflight.py` + `doctor` — environment readiness | yes | **✅ runs, exit 0** |

All ten stages are delivered. Nine are fully verifiable on this machine; Stage 7's
*execution* needs `libopenmc`, so its unit handling, provenance and refusal path
are verified instead.

---

## Verified — 324 offline checks across 15 suites

```
validate_heritage_registry        16/16   validate_transport_backend      25/25
validate_heritage_turbomachinery  17/17   validate_coupled_core           32/32
validate_heritage_kinetics        41/41   validate_cycle_closure          34/34
validate_heritage_cycles          18/18   validate_depletion_driver       22/22
validate_property_providers       10/10*  validate_acceptance_gates       20/20
validate_thermochemistry          16/16   validate_numerical_independence 16/16
validate_nozzle_closure           25/25   validate_determinism             9/9
validate_cea_oracle               23/23
```

`*` 22/22 on Python 3.10, where CoolProp is present and the hot-gas checks run.

### Property and thermochemistry coverage (honest matrix)

| Envelope | Provider | Verified |
|---|---|---|
| Liquid H2 < 33 K | RocketProps (vendored) | ✅ 71.07 kg/m3 vs Emrich's 71.3 (0.33%) |
| Hot gaseous H2 | CoolProp (Python 3.10 only) | ✅ R=4127 J/kg-K, gamma 1.395, Pr 0.674 |
| H2 <-> 2H equilibrium | `nasa_hydrogen` NASA-7 | ✅ Le Chatelier, alpha(T,P) |
| Full mechanism equilibrium | Cantera | ⚠️ written, refuses (not installed) |
| CEA parity | `cea` package or `cea2.exe` | ⚠️ deck/parser verified; backend refuses |

### Nozzle closure (gate 5)

Given chamber 2500 K / 4.5 MPa and 30 kg/s, the throat area is **solved** so the
nozzle passes exactly that flow:

```
A_t = 321.82 cm2   Isp = 875.3 s   thrust = 257.5 kN   residual = 2.6e-11
```

Isp 875 s sits in the nuclear-thermal range and frozen chemistry differs from
equilibrium (870.7 vs 875.3 s), as it must. A 100:1 nozzle at sea level is
refused rather than reported, because it is genuinely grossly over-expanded.

## Reactor core physics layer

The core-design layer a reactor engineer works in. Before these modules the
model could report `k` at one state; it could not say how `k` *responds*, could
not be shut down, and could not answer "what happens next".

| Module | Provides | Verified |
|---|---|---|
| `reactivity_coefficients.py` | Doppler, coolant and reflector coefficients; enrichment worth; power coefficient; temperature defect | **28/28** |
| `control_worth.py` | Drum worth curves, differential worth, excess reactivity, shutdown margin, dollars, reactivity ledger | **23/23** |
| `kinetics_transient.py` | Coupled point kinetics + thermal feedback; power as a **solved result over time** | **26/26** |
| `core_metrics.py` | Radial/axial/total peaking factors, fissile inventory, specific power, burnup rate | **26/26** |

### Coefficients are measured, not assumed

Every coefficient is a central difference of `k` under symmetric transport
perturbation, with uncertainty propagated as `sqrt(s+^2 + s-^2)/(2 dX)`. Against
the linear surrogate the recovery is exact (`rel < 1e-10`), and the measured
temperature defect equals the summed contributions to machine precision.

On the surrogate: Doppler **-1.000 pcm/K**, coolant **-0.200 pcm/K**, reflector
**-0.050 pcm/K**, drum **+20.000 pcm/deg**, enrichment **+2000 pcm/wt%**.

### The transient reproduces two analytic oracles

| Oracle | Result |
|---|---|
| Prompt jump `1/(1-rho/beta)` | 2% agreement at rho = 0.5-2 mK |
| Closed-form steady power `P_ref - rho/slope` | 10.1000 vs 10.1006 MW; 10.2500 vs 10.2517 |
| Energy conservation | residual **3.3e-9** of deposited energy |
| Timestep independence | dt = 10 ms vs 2.5 ms agree to 1e-4 |

Three real bugs were found by these tests: the prompt-jump relation was missing
the prompt-lifetime factor (a factor-of-1e4 error), the closed-form steady power
omitted the reference-power offset (0.1 MW predicted for a 10 MW core), and the
energy accumulation mixed quadratures.

### Worth and margin

```
withdrawn +40 deg  k=1.017723  excess  +1772.3 pcm (+2.7266 $)
inserted  -60 deg  k=0.997723  margin   +227.7 pcm (+0.3503 $)
travel worth 2400 pcm > excess 1772 pcm  -> the bank can shut the core down
```

The differential worth profile integrates back to the analytic total worth, and
the reactivity ledger closes to **+0.000000000 pcm**. Peaking factors reproduce
the analytic cosine axial factor `pi/2 = 1.570796` exactly.

## Reactor core physics layer (complete)

| Module | Provides | Verified |
|---|---|---|
| `reactivity_coefficients.py` | Doppler, coolant, reflector, **void/density**, enrichment; power coefficient; temperature defect | **32/32** |
| `control_worth.py` | Drum worth curves, differential worth, excess reactivity, shutdown margin, dollars, ledger | **23/23** |
| `kinetics_transient.py` | Coupled point kinetics + thermal feedback; power solved over time | **26/26** |
| `core_metrics.py` | Peaking factors, fissile inventory, specific power, burnup rate | **26/26** |
| `spatial_core.py` | **Per-element temperature feedback**; spatial reactivity penalty | **26/26** |
| `delayed_parameters.py` | Mixture delayed fraction; the beta_eff budget | **23/23** |
| `startup.py` | Subcritical multiplication, source power, 1/M extrapolation | **26/26** |
| `fission_product_poisoning.py` | Xe-135 and Sm-149 kinetics, equilibrium, post-shutdown peak, worth | **34/34** |
| `core_stability.py` | Linear stability of the lumped core, two-region spatial kinetics, tilt modes | **30/30** |
| `core_life.py` | Burnup, poison buildup, reactivity versus EFPD, end of life, life ledger | **26/26** |
| `shielding.py` | Gamma point kernels, Taylor buildup, slab attenuation, dose, shield sizing | **63/63** |
| `control_system.py` | Drum drive, PID regulation with anti-windup, independent latching protection, scram | **63/63** |

### Gamma transport, shielding, control and decay — the four asked-about domains

| Domain | State |
|---|---|
| **Gamma transport** | **wired.** OpenMC transports photons natively (`photon.cpp`, bremsstrahlung, secondary photons) but `NervaConfig.photon_transport` defaulted off and was unreachable. `CoreState.photon_transport` now carries it through to the backend. |
| **Shielding** | **implemented.** Emrich Ch. 14 pp.267-270: narrow-beam attenuation (14.7), uncollided point kernel (14.8), Taylor buildup (14.10), point kernel (14.12), semi-infinite slab in exponential-integral form (14.19/14.21). **Table 14.1 is transcribed**: A, alpha, beta for water, liquid hydrogen, beryllium, graphite, iron, lead, tungsten and uranium at 1-10 MeV. |
| **Control system** | **implemented.** Rate- and travel-limited drum actuator, PID regulator with anti-windup, deadband, and a **separate** latching protection system with scram. The separation is deliberate: a protection channel that shares the regulator's state is not independent. |
| **Material decay / activation** | **NOT implemented.** Needs activation cross sections and a decay-data library, both gated on `libopenmc`/`openmc.data`. Only the fission-product subset (I/Xe/Pm/Sm) is modelled. |

Two conventions had to be got right in the shielding work, and both were wrong
first time:

* Emrich's `E_n(x)` is `int_1^inf exp(-x t)/t^n dt`, **not** the
  mathematical-physics `int_x^inf`. Only the first has `E2(0) = 1`, which
  Eq. (14.21) requires. Verified against numerical quadrature to 8 digits.
* **Buildup factors grow** with optical thickness (they start at exactly 1 at
  zero thickness and increase as scattering accumulates). Asserting that they
  decrease was the opposite of the physics.

### Poison worth is now measured, not supplied

`fission_product_poisoning` originally demanded a caller-supplied worth
coefficient. `CoreState` now carries `poison_absorption_cm_inv` and
`reactivity_coefficients.poison_worth` measures `dk/d(Sigma_a)` by the same
transport perturbation as every other coefficient — **-4.000e+03 pcm per 1/cm**,
recovered to `1e-12`.

### Core life

A point-depletion march over fissile inventory and I/Xe/Pm/Sm buildup:

```
start : excess +2000.0 pcm, burnup  0.00%
end   : excess    -7.0 pcm, burnup 20.39%, 3.58 EFPD at end of life
ledger: excess +2000.0, poison -988.7, burnup -1018.3, total -7.0 pcm
2x excess -> 10.3 EFPD (life scales with loaded reactivity)
```

Verified against independent facts: fission rate reproduces the thermal power
exactly; fissile consumption is **105.2 g per full-power day** against the
textbook ~105 g/MWd; the poison integrator relaxes to the closed-form Ch. 13
equilibrium (iodine and xenon to 0.000%, samarium still 23.7% at 200 h — which
is correct, since its 53 h precursor makes it the slowest, exactly as the book
notes on p.259, and it reaches 0.000% given 4000 h).

Three bugs were caught here: derivatives were returned as a `PoisonInventory`,
which forbids negative values (but rates are legitimately negative); an early
break left the history containing only the `t=0` point; and the march recorded
its state after already advancing a step, so it started at +1838 pcm instead of
the loaded +2000 pcm.

### Depletion physics — closed without `openmc.deplete`

`openmc.deplete` cannot be imported without `libopenmc`, which left poisoning
entirely unimplemented. The physics is a closed set of linear decay/burnup
equations, so it is implemented directly from Emrich Ch. 13 (Eqs. 13.16-13.32)
and verified against the book itself:

* the closed-form equilibrium concentrations are **exact fixed points** of the
  ODEs - two independent sections of the book agreeing to `1e-12`;
* samarium equilibrium is **flux-independent** (Eq. 13.31), confirmed across five
  decades of flux;
* a post-shutdown xenon peak of **4.53x equilibrium at 10.2 h**;
* the xenon-rise threshold computes to **2.34e10 n/cm2/s**.

**Documented discrepancy, not hidden:** the book states the xenon-rise threshold
is "about 3e11" (p.257); this implementation gives 2.34e10, a factor of ~13. The
likely cause is the decay constants, which the book gives only through Figures
13.4/13.6 and which are therefore supplied as flagged-external data. The
disagreement is printed in the suite output and asserted nowhere.

### Core stability and spatial kinetics — closed

Eigenvalue analysis of the linearised core, with an exact oracle: with feedback
zeroed, the neutron block's eigenvalues reproduce the **seven Inhour roots**
(1 positive at 9.2e-17 /s, 6 negative bounded by the slowest pole). A
negative-feedback core is stable at **-1.23e-2 /s**; a positive-feedback core is
unstable at **+2.38e-1 /s** with a **2.91 s doubling time**.

Two-region nodal kinetics resolves **9 symmetric and 9 antisymmetric modes**, and
coupling measurably lifts the degeneracy (2 repeated eigenvalues coupled vs 10
decoupled).

**A maths error was caught here:** an earlier version reported a xenon
oscillation *period* from the two-state iodine/xenon loop. That loop has
discriminant `(lambda_i - lambda_xe - sigma*phi)^2`, a perfect square, so it is
**never** oscillatory at any flux. Xenon oscillation is inherently spatial and
needs the two-region model. The module now proves the non-oscillation instead of
inventing a period.

### Spatial feedback — the last fidelity gap, closed

`CoreState` carried a scalar fuel temperature; `spatial_core` carries one per
element and the transport solve sees the whole distribution. The decisive test
is an identity, not a plausibility check:

* with `spatial_distribution_coefficient_per_k = 0`, the spatial solve
  reproduces the lumped solve to **1.000865617184458 vs 1.000865617184458**;
* with a nonzero coefficient the penalty equals `-alpha_dist*(T_peak-T_mean)`
  exactly (**+6.101095e-05** for a 152.5 K peak-above-mean);
* a uniform-only backend is **refused**, so a spatial study can never silently
  degrade to a lumped one.

Averaging is explicit: `uniform_equivalent(weighting="arithmetic"|"power")`,
because the two means differ by tens of kelvin on a 1.4-peaked core and that
difference is a modelling choice, not a detail.

### Void coefficient

`dk/d(rho_coolant)` measured at **+300 pcm per kg/m3**, and the same slope is
recovered at both liquid (71 kg/m3) and gas (0.5 kg/m3) densities. Refuses when
the state carries no density rather than returning a confident zero.

### Subcritical multiplication

`M = 1/(1-k)` exact at k = 0, 0.5, 0.9, 0.99, 0.999; the reactivity form agrees;
and a synthetic approach-to-criticality sequence extrapolates the true critical
position to **1500.000 vs 1500.0**.

### beta_eff is not overclaimed

Mixture combination by **fission share** is exact, and an unsourced nuclide
constant is flagged on the result (`has_unsourced_input`). The importance
correction is a required, explicit input: an unweighted beta can never be
presented as an effective one.

## Current honest status: 2 of 8 acceptance gates met

| Gate | Status | Blocking gap |
|---|---|---|
| 1 Reference traceability | PARTIAL | no declared NASA baseline; 1 unresolved conflict |
| 2 Neutronics evidence | **NOT MET** | no real transport run |
| 3 Thermal coupling | PARTIAL | converges; deposition synthetic |
| 4 Hydraulic closure | PARTIAL | pump solved and wired; curves synthetic |
| 5 Shaft/flow closure | PARTIAL | shaft + **nozzle** close; curves synthetic |
| 6 Numerical independence | **MET** | — |
| 7 Historical validation | **NOT MET** | no external benchmark |
| 8 Reproducible handoff | **MET** | — |

### Numerical independence (gate 6) — how it was earned

| Study | Result |
|---|---|
| Axial grid refinement, 8→128 nodes | Δp changes 1.35e4 → 7.01e3 → 3.60e3 → 1.82e3 Pa, ratio **1.92** (first order) |
| Timestep halving, RK4 vs 32x reference | errors 5.01e-11 → 4.36e-15, observed order **3.88** |
| Picard relaxation 0.3→0.9 | k spread **1.85e-9**, T spread **1.77e-4 K** |

Two of these metrics were wrong on the first attempt and were corrected:
outlet temperature is an *analytically* grid-independent energy balance (it
reported 1e-12 agreement and proved nothing), so the discretisation-sensitive
pressure drop is used instead; and starting the integrator on the eigen-mode
made RK4 exact for any timestep, so a physical step insertion against a refined
reference is used.

### Determinism (gate 8)

Fingerprint `4a0a7b953dd6f0a6…` over heritage counts, Inhour root, coupled
k_eff and fuel temperature, pump operating point and grid pressure drops,
identical across **three independent processes**. Monte Carlo transport is *not*
claimed deterministic and is not fingerprinted.

### Stages 4–6 — the reactor actually closes

This is the answer to "can it simulate a proper core". Power is no longer an
input; it is solved:

```
P = 9.8217e+06 W   →  k = 0.99999922     (|k-1| = 7.8e-7, tolerance 1e-6)
```

The fixed-power loop converges in **9 iterations** to |dT| = 0.016 K and
|dk| = 4.0e-7, and the drum-angle search lands on the analytic linear solution
within its k-tolerance budget (3.3e-5 deg against a 5.0e-5 deg allowance).

Verified properties:

| Property | Evidence |
|---|---|
| Thermal closure conserves energy | residual **0.000e+00 W** on the outlet state |
| Physical temperature ordering | T_fuel 2169 K > T_wall 1402 K > T_H2 1104 K, Re = 2.2e5 |
| Power solved from criticality | P = 9.82 MW at k = 1 to 7.8e-7 |
| Independent re-evaluation agrees | 0.99999922 vs 0.99999922 |
| Emergent dk/dT is negative | −1.000e-5 /K |
| Non-convergence is reported, never hidden | `converged=False` + reason |
| Unbracketed criticality refused | explanatory message, no number returned |
| OpenMC backend refuses without data | `PreflightError` naming executable + cross sections |
| Mock can never claim to be physics | `synthetic=True`, `is_physics=False`, provenance warning |

Two bugs were found by these tests and fixed: the thermal conservation check
summed bulk **mean** temperatures (accounting for only half the enthalpy rise,
reporting a 50% energy defect for a conservative closure), and the mock's power
shape was temperature-independent, which made the coupling loop degenerate in a
single pass.

### Ch. 11 (kinetics) — what the 41 checks establish

| Check | Result |
|---|---|
| Σβᵢ reproduces the printed composite β | 0.006500 vs 0.0065, exact |
| Composite λ from the p.191 identity | 0.076447 vs 0.0764, 0.061% |
| ρ = 0 ⟹ ω = 0 exactly | exact at L = 0, 1e-4, 1e-3 |
| One-group solver vs analytic quadratic | agree to 1e-13 (12 cases) |
| Six-group limit ω/ρ → 1/Σ(βᵢ/λᵢ) | converges monotonically to 11.7610 |
| Eigen-solution satisfies implemented RHS | max residual 1e-10 |
| Inhour residual at solved root | 1e-12 |
| RK4 integration reaches predicted period | 0.194% |
| ω → (ρ−β)/L above prompt critical | 0.61% at 2β → 0.0077% at 10β |
| Negative Doppler reduces reactivity | ✔ |

Four of the first-run failures were **bad test premises, not code defects**, and
fixing them mattered: a six-group reactor is *not* equivalent to a one-group
reactor with the composite λ, so comparing them was never a valid oracle. The
honest tests are the one-group solver vs its own quadratic, and the
six-group ω/ρ → 1/Σ(βᵢ/λᵢ) limit.

### Ch. 3 (cycles) — what the 18 checks establish

The book's qualitative efficiency claim is made quantitative and tested:
**for equal pump work the hot-bleed cycle needs less bleed flow than the
cold-bleed cycle** (0.0758 vs 0.2000), and increasing the hot fraction reduces
required bleed monotonically. Both cycle balances close to 0.00e+00 residual.

Heritage flags now prevent mislabelling: `nerva.cycle_is_hot_bleed = 1` and
`cold_bleed.ever_implemented = 0`, both cited. A model closing on the
cold-bleed balance is modelling a different engine, and the registry says so.

---

## Full-suite state (last verified run)

**36 suites, 934/934 checks passing.** 348 modules under `ntr/nerva/`, of which
150 are `validate_*.py` harnesses.

```
validate_heritage_registry          validate_kinetics_transient
validate_heritage_turbomachinery    validate_core_metrics
validate_heritage_kinetics          validate_spatial_core
validate_heritage_cycles            validate_delayed_parameters
validate_property_providers         validate_startup
validate_thermochemistry            validate_fission_product_poisoning
validate_nozzle_closure             validate_core_stability
validate_cea_oracle                 validate_core_life
validate_transport_backend          validate_shielding_control
validate_coupled_core               validate_flow_stability
validate_cycle_closure              validate_diffusion
validate_depletion_driver           validate_decay
validate_acceptance_gates           validate_diffusion_backend
validate_numerical_independence     validate_material_properties
validate_determinism                validate_xenon_spatial
validate_reactivity_coefficients    validate_adjoint
validate_control_worth              validate_diffusion_2d
validate_baseline                   validate_historical_presets
```

### The declared baseline (gate 1)

`ntr/nerva/baseline.py` declares **one** engine — XE-Prime / XE0 — because it is
the only NERVA engine with two independent sources pinning the same quantities:
NASA TM-105252 Table 3 (as-tested figures) and Emrich Appendix III Tables
III.1/III.2 (full-power test data). The other three presets are design studies
with nothing to check against.

The cross-check is not decorative. Declaring a baseline is only *evidence* if
the declared values survive comparison with the second source:

| Quantity | Preset | XE0 measured | Error | Tol |
|---|---|---|---|---|
| Thermal power | 1140 MW | 1137 MW | +0.264% | 1% |
| Chamber temperature | 2280.56 K | 2278 K | +0.112% | 1% |
| Chamber pressure | 3.901 MPa | 3.81 MPa | +2.390% | 5% |
| Thrust flow | 31.842 kg/s | 31.98 kg/s | −0.431% | 2% |

Worst case 2.39%. Tolerances are stated as judgement about *measurement and
definition* quality, fixed before the residuals were computed, and the gate
refuses the baseline if any comparison leaves tolerance — so a future edit that
breaks agreement cannot keep claiming a baseline.

Two traps this exposed, both now tested:

- **The station trap.** The preset flow must be compared to the nozzle-chamber
  flow (31.98 kg/s), not the tank outlet (36.15 kg/s), because the difference is
  the 2.46 kg/s diluent bleed plus the 0.87 kg/s hot bleed. Comparing to the
  wrong station reports a spurious −11.9%, and the validator asserts that this
  wrong comparison really does fail.
- **The resolved-conflict trap.** `validate_acceptance_gates` previously
  asserted that an *unresolved* conflict was reported. That turned fixing a
  conflict into a test failure. It now asserts the gate agrees with the
  registry in either direction.

The p.17 prose "about 55 inches" is superseded: it sits 5.8% above two precise
sources that agree with each other to 0.06% (Table III.2 core length 132 cm,
TM-105252 active length 52.0 in = 132.08 cm). The prose entry is retained, with
the discrepancy and the precedence stated, and is never used in a calculation.

### What is done vs what is not

| Layer | State |
|---|---|
| Textbook physics (Ch. 3, 8, 10, 11, 12, 13, 14, 15) | implemented, oracle-checked |
| Core neutronics design (feedback, control, kinetics, spatial, life) | implemented, self-consistent |
| Cycle / thermal / nozzle closure | implemented, energy-conserving |
| Transport seam (mock + OpenMC adapter) | implemented; OpenMC adapter untested — no data |
| Depletion execution | implemented against `openmc.deplete` API; never run |
| CEA / CoolProp property backends | implemented; CEA never run, CoolProp absent from py3.14 |
| Hot-H₂ corrosion / fuel mass loss | **not implemented** — no data in either source |
| Two-phase H₂ / CHF | **not implemented** — no data in either source |
| Acceptance gates | 3/8 met offline; 1 more needs a source document, 4 need the machine |

### The honest split

~95% of the code that can be written without a working OpenMC install and
cross-section library is written. ~40% of the *physics* is validated against an
external oracle (the book's worked examples, printed tables, analytic
identities, and now the XE0 test data).

The remaining validation is not a coding task — it is a run on a machine with
`openmc.exe`, HDF5 cross sections, and CoolProp in one interpreter.

Nothing in the package fabricates a heritage number to close a gap: where data
does not exist, the module raises or reports `synthetic=True`, and the audit
trail says why.
