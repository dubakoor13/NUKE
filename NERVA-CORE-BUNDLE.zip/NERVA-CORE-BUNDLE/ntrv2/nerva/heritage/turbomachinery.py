"""Turbomachinery and cycle methods, testable with no data files.

Every equation here is a *method*: its form is fixed by physics and is taken
verbatim from Emrich (2023), Chapter 10 "Turbomachinery" and Chapter 3
"Nuclear rocket engine cycles". Because the book supplies a fully worked pump
design example with published answers, this module can be verified offline
and to full printed precision - see ``validate_heritage_turbomachinery``.

Emrich's own numbering is preserved in the docstrings so any disagreement
between this code and the book is trivial to locate.

All functions are pure: no state, no I/O, no hidden constants beyond the
standard gravitational acceleration, which is an explicit argument.
"""
from __future__ import annotations

import math

# Standard gravitational acceleration used throughout Emrich's worked examples.
G0_EMRICH = 9.8


def _check_positive(**values: float) -> None:
    for name, value in values.items():
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"{name} must be a finite number, got {value!r}")
        if value <= 0.0:
            raise ValueError(f"{name} must be positive, got {value!r}")


# ---------------------------------------------------------------- pump hydraulics


def volume_flow(mdot: float, rho: float) -> float:
    """Q = mdot / rho  [m3/s]  (Emrich p.178, Eq. 10.4 in effect)."""
    _check_positive(mdot=mdot, rho=rho)
    return mdot / rho


def pump_head(pe: float, pa: float, rho: float, g: float = G0_EMRICH) -> float:
    """H = (Pe - Pa) / (g rho)  [m]  (Eq. 10.3)."""
    _check_positive(rho=rho, g=g)
    if pe <= pa:
        raise ValueError("pump discharge pressure must exceed suction pressure")
    return (pe - pa) / (g * rho)


def npsh_required(ps: float, pv: float, rho: float, g: float = G0_EMRICH) -> float:
    """Hsr = (Ps - Pv) / (g rho)  [m]  (Eq. 10.2).

    ``ps`` is the inlet stagnation pressure and ``pv`` the vapor pressure.
    Note the book writes ``Ps`` for the pump-inlet pressure; it is not the
    discharge pressure used by :func:`pump_head`.
    """
    _check_positive(rho=rho, g=g)
    if ps <= pv:
        raise ValueError(
            "inlet pressure must exceed vapour pressure; "
            "the pump would cavitate at the inlet"
        )
    return (ps - pv) / (g * rho)


def thoma_parameter(hsr: float, head: float) -> float:
    """sigma = Hsr / H  (Emrich p.178, Eq. 3 of the worked example)."""
    _check_positive(hsr=hsr, head=head)
    return hsr / head


# ---------------------------------------------------------------- pump similarity


def pump_specific_speed(omega: float, q: float, head: float,
                        g: float = G0_EMRICH) -> float:
    """ns = omega sqrt(Q) / (g H)^(3/4)  (Eq. 10.1, dimensional form)."""
    _check_positive(omega=omega, q=q, head=head, g=g)
    return omega * math.sqrt(q) / (g * head) ** 0.75


def omega_from_specific_speed(ns: float, q: float, head: float,
                              g: float = G0_EMRICH) -> float:
    """Invert Eq. 10.1: omega = ns (g H)^(3/4) / sqrt(Q)  [rad/s]."""
    _check_positive(ns=ns, q=q, head=head, g=g)
    return ns * (g * head) ** 0.75 / math.sqrt(q)


def pump_specific_diameter(diameter: float, q: float, head: float,
                           g: float = G0_EMRICH) -> float:
    """ds = D (g H)^(1/4) / sqrt(Q)  (Eq. 10.1, diameter form)."""
    _check_positive(diameter=diameter, q=q, head=head, g=g)
    return diameter * (g * head) ** 0.25 / math.sqrt(q)


def diameter_from_specific_diameter(ds: float, q: float, head: float,
                                    g: float = G0_EMRICH) -> float:
    """Invert the specific-diameter definition: D = ds sqrt(Q) / (g H)^(1/4)."""
    _check_positive(ds=ds, q=q, head=head, g=g)
    return ds * math.sqrt(q) / (g * head) ** 0.25


def rad_per_s_to_rpm(omega: float) -> float:
    """Convert angular velocity [rad/s] to revolutions per minute."""
    _check_positive(omega=omega)
    return omega * 60.0 / (2.0 * math.pi)


# ---------------------------------------------------------------- pump power


def pump_shaft_power(q: float, pe: float, pa: float, eta_pump: float) -> float:
    """W = Q (Pe - Pa) / eta_p  [W]  (Eq. 10.6 rearranged).

    This is the form Emrich evaluates in the worked example.
    """
    _check_positive(q=q, eta_pump=eta_pump)
    if not 0.0 < eta_pump <= 1.0:
        raise ValueError(f"pump efficiency must be in (0, 1], got {eta_pump}")
    if pe <= pa:
        raise ValueError("pump discharge pressure must exceed suction pressure")
    return q * (pe - pa) / eta_pump


def pump_efficiency(rho: float, q: float, head: float, w: float,
                    g: float = G0_EMRICH) -> float:
    """eta_p = g rho Q H / W  (Eq. 10.6)."""
    _check_positive(rho=rho, q=q, head=head, w=w, g=g)
    eta = g * rho * q * head / w
    if eta > 1.0:
        raise ValueError(
            f"implied pump efficiency {eta:.3f} exceeds 1; shaft power is "
            f"too small for the stated head and flow"
        )
    return eta


# ---------------------------------------------------------------- turbine


def turbine_power(mdot: float, h_in: float, h_out: float,
                  eta_turbine: float = 1.0) -> float:
    """W = eta_t mdot (h_in - h_out)  [W], positive when the turbine expands.

    Emrich (p.179) describes the turbine as extracting energy from the heated
    propellant; the efficiency factor is applied to the isentropic enthalpy
    drop. Passing raw static enthalpies with the default efficiency of 1.0
    gives the ideal (no-loss) work.
    """
    _check_positive(mdot=mdot, eta_turbine=eta_turbine)
    if not 0.0 < eta_turbine <= 1.0:
        raise ValueError(f"turbine efficiency must be in (0, 1], got {eta_turbine}")
    drop = h_in - h_out
    if drop <= 0.0:
        raise ValueError(
            "turbine inlet enthalpy must exceed outlet enthalpy; "
            "an expanding turbine cannot add enthalpy to the flow"
        )
    return eta_turbine * mdot * drop


def rotor_stress(xi: float, s_factor: float, rho_rotor: float,
                 omega: float, radius: float) -> float:
    """sigma = xi S rho_r u^2 R^2  [Pa]  (Eq. 10.7).

    ``u`` is the rotational speed [rad/s] rather than a rim speed; the book
    writes ``u2`` as the square of the rotational speed, so the caller passes
    one angular velocity and this function squares it once.
    """
    _check_positive(xi=xi, rho_rotor=rho_rotor, omega=omega, radius=radius)
    if s_factor < 0.0:
        raise ValueError("rotor geometric stress factor cannot be negative")
    return xi * s_factor * rho_rotor * omega ** 2 * radius ** 2


# Cycle energy balances live in ``heritage.cycles`` (Emrich Ch. 3), which owns
# the hot-bleed, cold-bleed and expander cycles. This module owns only the
# machinery itself. Keeping cycle bookkeeping out of here prevents the same
# balance being implemented twice and drifting.
