"""Source-linked heritage data for the NERVA-derived model.

This package exists because a propulsion model must never conflate two very
different kinds of number:

* **Method** - an equation whose form is fixed by physics (head, specific
  speed, energy balance). It can live in code and be tested against a
  textbook's own worked examples, with no data files at all.
* **Heritage data** - a value that describes real historical hardware
  (a dimension, a test-point temperature, a thrust). It is only as good as
  the document it came from, so it must carry a citation.

Every heritage value in this package is a :class:`~.citation.SourcedValue`
and carries a document, a page, a locator and a verbatim quote. There is no
path through the loader that admits an uncited number, and a deliberately
invented value must be declared ``kind="assumed"`` under an ``assumed_``
name so it can never be mistaken for hardware data.

What this package deliberately does NOT contain: tie-tube/support-element
dimensions, pump head-flow curves, or turbine characteristic maps. Those are
not in the two supplied documents (see ``REQUIRED_EXTERNAL.md``) and are
left as explicit, named gaps rather than filled with plausible fiction.
"""

from .citation import Citation, SourcedValue, ProvenanceError
from .registry import HeritageRegistry, load_registry

__all__ = [
    "Citation",
    "SourcedValue",
    "ProvenanceError",
    "HeritageRegistry",
    "load_registry",
]
