"""Registry of heritage values with enforced provenance."""
from __future__ import annotations

import json
from pathlib import Path

from .citation import ProvenanceError, SourcedValue


class HeritageRegistry:
    """A keyed collection of :class:`SourcedValue` entries.

    The registry is deliberately strict:

    * duplicate names are rejected (silent overwrite hides a data error)
    * ``get`` never returns a raw float, so callers cannot lose the citation
    * ``require`` lists every missing name at once instead of failing on the
      first one, which makes a half-transcribed dataset diagnosable in one run
    """

    def __init__(self) -> None:
        self._entries: dict[str, SourcedValue] = {}

    def add(self, entry: SourcedValue) -> None:
        entry.validate()
        if entry.name in self._entries:
            raise ProvenanceError(f"duplicate heritage entry: {entry.name}")
        self._entries[entry.name] = entry

    def get(self, name: str) -> SourcedValue:
        try:
            return self._entries[name]
        except KeyError:
            raise KeyError(
                f"heritage value {name!r} is not defined; "
                f"{len(self._entries)} entries available"
            ) from None

    def value(self, name: str) -> float:
        """Numeric value, only via an explicit call that the citation exists."""
        return self.get(name).value

    def require(self, names: list[str]) -> None:
        missing = [name for name in names if name not in self._entries]
        if missing:
            raise KeyError(f"missing required heritage values: {missing}")

    def __contains__(self, name: object) -> bool:
        return name in self._entries

    def __len__(self) -> int:
        return len(self._entries)

    def __iter__(self):
        return iter(self._entries.values())

    def names(self) -> list[str]:
        return sorted(self._entries)

    def of_kind(self, kind: str) -> list[SourcedValue]:
        return [entry for entry in self if entry.kind == kind]

    def to_dict(self) -> dict:
        return {
            "entries": [entry.as_dict() for entry in sorted(self, key=lambda e: e.name)],
        }

    @classmethod
    def from_dict(cls, payload: dict) -> HeritageRegistry:
        if "entries" not in payload:
            raise ProvenanceError("registry payload must contain 'entries'")
        registry = cls()
        for raw in payload["entries"]:
            registry.add(SourcedValue.from_dict(raw))
        return registry


def load_registry(path: str | Path) -> HeritageRegistry:
    """Load a registry from JSON on disk."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return HeritageRegistry.from_dict(payload)
