"""Point reactor kinetics methods (Emrich 2023, Ch. 11), with no hidden data.

The delayed-neutron group constants are *data*, so they are not hardcoded
here: :func:`u235_delayed_groups` reads them from the cited heritage registry
(Table 11.1, p.204). This module contains only methods.

Equation numbering follows the book:

* Eq. (11.3)  dn/dt = (rho - beta)/L * n + sum(lambda_i * C_i)
* Eq. (11.4)  dC_i/dt = beta_i/L * n - lambda_i * C_i
* Eq. (11.9)  rho = omega*L + sum(omega*beta_i/(omega + lambda_i))   [Inhour]
* Eq. (11.11/11.12) one-group form
* composite   1/lambda = (1/beta) * sum(beta_i/lambda_i)

Reactivity feedback is the piece the delivered model lacked: with
:func:`reactivity_with_feedback`, temperature becomes an input to reactivity
instead of power being an externally prescribed number.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

GROUPS = 6


@dataclass(frozen=True)
class DelayedGroups:
    """Six-group delayed neutron data (dimensionless beta, 1/s lambda)."""

    beta: tuple[float, ...]
    lam: tuple[float, ...]

    def __post_init__(self) -> None:
        if len(self.beta) != len(self.lam):
            raise ValueError("beta and lambda group counts must match")
        if len(self.beta) < 1:
            raise ValueError("need at least one delayed group")
        for value in (*self.beta, *self.lam):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"delayed group constants must be finite and positive, got {value!r}")

    @property
    def n_groups(self) -> int:
        return len(self.beta)

    @property
    def beta_total(self) -> float:
        return math.fsum(self.beta)

    def composite_decay_constant(self) -> float:
        """One-group equivalent 1/lambda = (1/beta) sum(beta_i/lambda_i) (p.191)."""
        weighted = math.fsum(b / l for b, l in zip(self.beta, self.lam))
        return self.beta_total / weighted

    def one_group(self) -> DelayedGroups:
        """Collapse six groups to the composite single group of pp.191-192."""
        return DelayedGroups(
            beta=(self.beta_total,),
            lam=(self.composite_decay_constant(),),
        )


def u235_delayed_groups(registry) -> DelayedGroups:
    """Read the six-group 235U data from the cited heritage registry."""
    beta = tuple(
        registry.value(f"u235.delayed.beta.group{i}") for i in range(1, GROUPS + 1)
    )
    lam = tuple(
        registry.value(f"u235.delayed.lambda.group{i}") for i in range(1, GROUPS + 1)
    )
    return DelayedGroups(beta=beta, lam=lam)


def dollars(reactivity: float, groups: DelayedGroups) -> float:
    """Reactivity in dollars: rho / beta. Prompt critical at exactly 1.0."""
    if groups.beta_total <= 0.0:
        raise ValueError("beta must be positive")
    return reactivity / groups.beta_total


def inhour_reactivity(omega: float, lifetime: float,
                      groups: DelayedGroups) -> float:
    """Eq. (11.9): the reactivity corresponding to time constant omega."""
    if not math.isfinite(omega):
        raise ValueError("omega must be finite")
    if lifetime < 0.0:
        raise ValueError("prompt neutron lifetime cannot be negative")
    for lam in groups.lam:
        if abs(omega + lam) < 1e-15:
            raise ValueError(
                f"omega = {omega!r} is a pole of the Inhour equation "
                f"(omega = -{lam!r}); the solution is not physical here"
            )
    return omega * lifetime + math.fsum(
        omega * b / (omega + lam) for b, lam in zip(groups.beta, groups.lam)
    )


def solve_period_constant(reactivity: float, lifetime: float,
                          groups: DelayedGroups) -> float:
    """Invert the Inhour equation for omega [1/s].

    ``f(omega) = rho - inhour(omega)`` is strictly decreasing in ``omega``
    (every term ``omega*beta/(omega+lambda)`` and ``omega*L`` is increasing),
    so the root is unique and bisection is safe and cannot wander onto a
    spurious branch.

    For ``rho > 0`` the root is positive and bounded below by ``rho/1`` scaled
    by the group structure; for ``rho < 0`` it lies in ``(-lambda_min, 0)``
    because ``f -> +inf`` as ``omega -> -lambda_min+`` and ``f(0) = rho < 0``.
    """
    if not math.isfinite(reactivity):
        raise ValueError("reactivity must be finite")
    if lifetime < 0.0:
        raise ValueError("prompt neutron lifetime cannot be negative")
    if reactivity == 0.0:
        return 0.0

    def excess(omega: float) -> float:
        return reactivity - inhour_reactivity(omega, lifetime, groups)

    if reactivity > 0.0:
        lo = 0.0                    # excess(0) = rho > 0
        hi = max(1.0, reactivity / max(lifetime, 1e-12))
        for _ in range(200):
            if excess(hi) < 0.0:
                break
            hi *= 2.0
        else:
            raise ValueError("failed to bracket the supercritical Inhour root")
    else:
        lam_min = min(groups.lam)
        lo = -lam_min * (1.0 - 1e-12)   # excess -> +inf just above the pole
        hi = 0.0                        # excess(0) = rho < 0

    for _ in range(300):
        mid = 0.5 * (lo + hi)
        if excess(mid) > 0.0:
            lo = mid
        else:
            hi = mid
        if hi - lo <= 1e-15 * max(1.0, abs(mid)):
            break
    return 0.5 * (lo + hi)


def one_group_omega_exact(reactivity: float, lifetime: float,
                          groups: DelayedGroups) -> float:
    """Closed-form positive root for the ONE-group model (derived from 11.11/11.12).

    Eliminating C from Eqs. (11.11) and (11.12) gives

        L*omega^2 + (L*lambda + beta - rho)*omega - lambda*rho = 0

    This exists purely as an independent oracle for
    :func:`solve_period_constant`; it is not used by the solver.
    """
    single = groups.one_group()
    beta = single.beta_total
    lam = single.lam[0]
    a = lifetime
    b = lifetime * lam + beta - reactivity
    c = -lam * reactivity
    if a == 0.0:
        if b == 0.0:
            raise ValueError("degenerate one-group quadratic")
        return -c / b
    disc = b * b - 4.0 * a * c
    if disc < 0.0:
        raise ValueError("one-group quadratic has no real root")
    root = math.sqrt(disc)
    candidates = [(-b + root) / (2.0 * a), (-b - root) / (2.0 * a)]
    positive = [candidate for candidate in candidates if candidate > 0.0]
    return max(positive) if positive else max(candidates)


def stable_period(omega: float) -> float:
    """Reactor period P = 1/omega [s]. Positive omega means a rising power."""
    if not math.isfinite(omega):
        raise ValueError("omega must be finite")
    if omega == 0.0:
        raise ValueError("a critical reactor has no finite period")
    return 1.0 / omega


def point_kinetics_rhs(n: float, precursors, reactivity: float,
                       lifetime: float, groups: DelayedGroups):
    """Eqs. (11.3) and (11.4) as an explicit first-order system.

    Returns ``(dn/dt, [dC_i/dt, ...])``.
    """
    if lifetime <= 0.0:
        raise ValueError("point kinetics requires a positive prompt lifetime")
    if n < 0.0:
        raise ValueError("neutron population cannot be negative")
    if len(precursors) != groups.n_groups:
        raise ValueError("precursor vector length must match the delayed groups")
    dn = (reactivity - groups.beta_total) / lifetime * n + math.fsum(
        lam * c for lam, c in zip(groups.lam, precursors)
    )
    dc = [
        b / lifetime * n - lam * c
        for b, lam, c in zip(groups.beta, groups.lam, precursors)
    ]
    return dn, dc


def equilibrium_precursors(n0: float, lifetime: float,
                           groups: DelayedGroups) -> list[float]:
    """Precursor concentrations for a critical steady state at ``n0`` (Eq. 11.4 = 0)."""
    return [b / (lifetime * lam) * n0 for b, lam in zip(groups.beta, groups.lam)]


def reactivity_with_feedback(rho_external: float, alphas, temperatures,
                             reference_temperatures) -> float:
    """Total reactivity including temperature feedback.

        rho = rho_ext + sum(alpha_i * (T_i - T_i0))

    This is the closure the delivered model lacked: it turns temperature into
    an input to reactivity instead of leaving power externally prescribed.
    Coefficients are supplied by the caller (computed from transport), never
    assumed here.
    """
    if len(alphas) != len(temperatures) or len(alphas) != len(reference_temperatures):
        raise ValueError("alphas, temperatures and references must have equal length")
    feedback = math.fsum(
        float(alpha) * (float(t) - float(t0))
        for alpha, t, t0 in zip(alphas, temperatures, reference_temperatures)
    )
    return rho_external + feedback


def integrate_point_kinetics(n0: float, precursors, reactivity: float,
                             lifetime: float, groups: DelayedGroups,
                             dt: float, steps: int) -> tuple[list[float], list[list[float]]]:
    """Integrate Eqs. (11.3) and (11.4) with classical RK4.

    Returns ``(neutron_history, precursor_history)`` including the initial
    state as element zero. RK4 is used because it is fourth-order accurate,
    which makes a timestep-refinement study produce an unambiguous observed
    order near 4 - a first-order scheme would not distinguish "converged" from
    "discretisation-limited".
    """
    if not math.isfinite(dt) or dt <= 0.0:
        raise ValueError("dt must be finite and positive")
    if steps < 1:
        raise ValueError("steps must be at least 1")
    if len(precursors) != groups.n_groups:
        raise ValueError("precursor vector length must match the delayed groups")

    n_history = [float(n0)]
    c_history = [[float(value) for value in precursors]]
    n = float(n0)
    c = [float(value) for value in precursors]

    for _ in range(steps):
        k1n, k1c = point_kinetics_rhs(n, c, reactivity, lifetime, groups)
        k2n, k2c = point_kinetics_rhs(n + 0.5 * dt * k1n,
                                      [ci + 0.5 * dt * ki for ci, ki in zip(c, k1c)],
                                      reactivity, lifetime, groups)
        k3n, k3c = point_kinetics_rhs(n + 0.5 * dt * k2n,
                                      [ci + 0.5 * dt * ki for ci, ki in zip(c, k2c)],
                                      reactivity, lifetime, groups)
        k4n, k4c = point_kinetics_rhs(n + dt * k3n,
                                      [ci + dt * ki for ci, ki in zip(c, k3c)],
                                      reactivity, lifetime, groups)
        n += dt / 6.0 * (k1n + 2.0 * k2n + 2.0 * k3n + k4n)
        c = [ci + dt / 6.0 * (a + 2.0 * b + 2.0 * d + e)
             for ci, a, b, d, e in zip(c, k1c, k2c, k3c, k4c)]
        if n < 0.0:
            raise ValueError(
                f"neutron population went negative at step {len(n_history)}; "
                f"the timestep is too large for this reactivity"
            )
        n_history.append(n)
        c_history.append(list(c))

    return n_history, c_history
