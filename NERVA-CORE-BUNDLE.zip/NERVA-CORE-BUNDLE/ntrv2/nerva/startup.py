"""Subcritical multiplication and approach to criticality.

Below criticality a reactor is a multiplier, not a source: a fixed neutron source
of strength ``S`` produces a steady population amplified by

    M = 1 / (1 - k_eff)

This is the physics every startup procedure is built on. The measured count rate
rises as ``1/(1-k)`` as the control bank is withdrawn, and the inverse-count
plot ``1/CR`` against bank position is linear in the worth, which is how the
critical position is predicted *before* reaching it.

Absent from the delivered model entirely. It matters here because a nuclear
thermal rocket is started from a subcritical state and the approach-to-critical
extrapolation is a safety-critical quantity.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


class StartupError(ValueError):
    """Raised when a startup quantity is not defined for the given state."""


def subcritical_multiplication(k_eff: float) -> float:
    """M = 1 / (1 - k), defined only for a subcritical core.

    Refuses at or above criticality: at k = 1 the multiplication is formally
    infinite, and returning a large number there would misrepresent a critical
    core as a very subcritical one.
    """
    if not math.isfinite(k_eff):
        raise StartupError(f"k_eff must be finite, got {k_eff!r}")
    if k_eff >= 1.0:
        raise StartupError(
            f"k_eff = {k_eff:.6f} is at or above critical; subcritical "
            f"multiplication is undefined there (it diverges as 1/(1-k))"
        )
    if k_eff < 0.0:
        raise StartupError(
            f"k_eff = {k_eff:.6f} is negative, which is not physical for a "
            f"multiplying assembly. k = 0 is the legitimate no-fission limit "
            f"(M = 1) and is allowed."
        )
    return 1.0 / (1.0 - k_eff)


def multiplication_from_reactivity(reactivity: float) -> float:
    """M = 1/(1-k) expressed through reactivity, where k = 1/(1-rho).

    Substituting gives M = -(1 - rho)/rho. For rho = -0.1 this yields M = 11,
    consistent with k = 0.909 and 1/(1-k) = 11.
    """
    if not math.isfinite(reactivity):
        raise StartupError(f"reactivity must be finite, got {reactivity!r}")
    if reactivity >= 0.0:
        raise StartupError(
            f"reactivity {reactivity:+.3e} is not negative; the core is not "
            f"subcritical"
        )
    # Every negative reactivity is admissible: rho -> 0- gives k -> 1 (M -> inf)
    # and rho -> -inf gives k -> 0 (M -> 1), so there is no lower bound to
    # enforce. rho = -1 is simply k = 0.5, M = 2.
    return -(1.0 - reactivity) / reactivity


def steady_source_power(source_strength_per_s: float, k_eff: float,
                        energy_per_fission_j: float = 3.204e-11) -> float:
    """Steady fission power driven by a fixed neutron source [W].

    Fission rate = S * M, so power = S*M*E_f. This is the observable that a
    startup count rate is proportional to.
    """
    if not math.isfinite(source_strength_per_s) or source_strength_per_s <= 0.0:
        raise StartupError("source strength must be finite and positive")
    if not math.isfinite(energy_per_fission_j) or energy_per_fission_j <= 0.0:
        raise StartupError("energy per fission must be finite and positive")
    return source_strength_per_s * subcritical_multiplication(k_eff) * energy_per_fission_j


@dataclass(frozen=True)
class ApproachPoint:
    """One step of an approach-to-criticality measurement."""

    parameter: float
    k_eff: float
    multiplication: float
    count_rate: float

    @property
    def inverse_count_rate(self) -> float:
        return 1.0 / self.count_rate


def approach_to_criticality(
    parameters: list[float],
    k_effects: list[float],
    *,
    base_k: float,
    count_rate_at_unit_multiplier: float = 1.0,
) -> tuple[ApproachPoint, ...]:
    """Build an approach-to-criticality sequence.

    ``parameters`` are whatever is being moved (drum angle, bank position);
    ``k_effects`` are the changes in k that each step contributes. The result
    carries the measured count rate, whose *inverse* is linear in the parameter
    for a core whose worth is linear in that parameter - which is the basis of
    the classic 1/M extrapolation.
    """
    if len(parameters) != len(k_effects):
        raise StartupError(
            f"parameter and k-effect lists must match in length, got "
            f"{len(parameters)} and {len(k_effects)}"
        )
    if not parameters:
        raise StartupError("at least one approach point is required")
    if not math.isfinite(count_rate_at_unit_multiplier) or \
            count_rate_at_unit_multiplier <= 0.0:
        raise StartupError("count rate at unit multiplier must be positive")

    points: list[ApproachPoint] = []
    for parameter, effect in zip(parameters, k_effects):
        k_eff = base_k + effect
        multiplication = subcritical_multiplication(k_eff)
        points.append(ApproachPoint(
            parameter=float(parameter),
            k_eff=k_eff,
            multiplication=multiplication,
            count_rate=multiplication * count_rate_at_unit_multiplier,
        ))
    return tuple(points)


def extrapolate_critical_parameter(points: tuple[ApproachPoint, ...]) -> float:
    """Linear 1/M extrapolation: where does 1/CR reach zero?

    Returns the parameter value at which criticality is predicted, from a least
    squares fit of ``1/CR`` against the parameter. Requires at least two points
    whose inverse count rates differ; a flat set carries no information about
    the critical position and is refused rather than returning a parameter value
    that was never measured.
    """
    if len(points) < 2:
        raise StartupError("at least two points are needed for an extrapolation")
    xs = [point.parameter for point in points]
    ys = [point.inverse_count_rate for point in points]
    n = len(points)
    mean_x = math.fsum(xs) / n
    mean_y = math.fsum(ys) / n
    sxx = math.fsum((x - mean_x) ** 2 for x in xs)
    sxy = math.fsum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    if sxx <= 0.0:
        raise StartupError(
            "all approach points share the same parameter value; the critical "
            "position cannot be extrapolated"
        )
    slope = sxy / sxx
    if abs(slope) < 1e-30:
        raise StartupError(
            "inverse count rate does not vary with the parameter; no critical "
            "position can be extrapolated from these measurements"
        )
    intercept = mean_y - slope * mean_x
    # 1/CR = 0  ->  x = -intercept / slope
    return -intercept / slope
