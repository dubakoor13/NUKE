"""Pump operating point and cycle closure, replacing the frozen reference.

The delivered model fixed the pump at an independently solved steady value:
``dual_header_tie.py`` integrates ``dM/dt = mdot_pump_ref - ...`` with a frozen
``mdot_pump_ref`` and ``h_pump_ref``. Its own docstring admits it: "The pump
flow, pump delivered stagnation enthalpy and engine/core outlet demand are
still fixed at the independently solved steady shaft-cycle reference."

This module closes that loop. Given pump head-flow-speed characteristics, a
system resistance curve and the shaft power available from the turbine, it
solves the actual operating point and returns a :class:`PumpBoundary` that a
dynamic header can consume in place of the frozen constants.

Provenance rule
---------------
Pump and turbine characteristic curves for NERVA hardware are **not** in the
supplied documents (Emrich Ch. 10 gives the design *equations* and efficiency
*contour figures*, not digitised maps). So the characteristics are an injected
data contract with a mandatory ``source`` string:

* a ``SYNTHETIC`` source is permitted, but the object reports
  ``is_heritage = False`` and no result derived from it may be quoted as NERVA
  performance;
* a non-synthetic source must be a real citation, and the loader refuses an
  empty or placeholder one.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

SYNTHETIC_PREFIX = "SYNTHETIC"


class CharacteristicsError(ValueError):
    """Raised when pump/turbine characteristics are missing or unusable."""


@dataclass(frozen=True)
class PumpCharacteristics:
    """Affinity-law pump characteristic with a mandatory provenance tag.

    Head curve at speed ``omega``:  H = a*omega^2 - b*Q^2
    Shaft speed at design:          ``omega_design`` (rad/s)
    Efficiency:                     constant ``eta_pump`` (Emrich Eq. 10.6 form)
    """

    shutoff_head_coefficient_m_s2: float   # 'a'   [m / (rad/s)^2]
    head_loss_coefficient_s2_m5: float     # 'b'   [m / (m3/s)^2]
    omega_design_rad_s: float
    eta_pump: float
    source: str
    note: str = ""

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        if not math.isfinite(self.shutoff_head_coefficient_m_s2) or \
                self.shutoff_head_coefficient_m_s2 <= 0.0:
            raise CharacteristicsError("shutoff head coefficient must be positive")
        if not math.isfinite(self.head_loss_coefficient_s2_m5) or \
                self.head_loss_coefficient_s2_m5 < 0.0:
            raise CharacteristicsError("head loss coefficient must be non-negative")
        if not math.isfinite(self.omega_design_rad_s) or self.omega_design_rad_s <= 0.0:
            raise CharacteristicsError("design shaft speed must be positive")
        if not 0.0 < self.eta_pump <= 1.0:
            raise CharacteristicsError("pump efficiency must lie in (0, 1]")
        if not self.source.strip():
            raise CharacteristicsError(
                "pump characteristics require a source; an unsourced curve is "
                "an invented curve"
            )
        if len(self.source.strip()) < 4:
            raise CharacteristicsError("source string is too short to be a citation")

    @property
    def is_heritage(self) -> bool:
        """False for a synthetic illustrative curve."""
        return not self.source.strip().upper().startswith(SYNTHETIC_PREFIX)

    def head_m(self, omega: float, volume_flow_m3_s: float) -> float:
        if omega <= 0.0:
            raise CharacteristicsError("shaft speed must be positive")
        if volume_flow_m3_s < 0.0:
            raise CharacteristicsError("volume flow cannot be negative")
        head = (self.shutoff_head_coefficient_m_s2 * omega ** 2
                - self.head_loss_coefficient_s2_m5 * volume_flow_m3_s ** 2)
        return head

    def shaft_power_w(self, omega: float, volume_flow_m3_s: float,
                      density_kg_m3: float, g: float) -> float:
        """W = rho*g*Q*H / eta_p  (Emrich Eq. 10.6)."""
        head = self.head_m(omega, volume_flow_m3_s)
        if head <= 0.0:
            return 0.0
        return density_kg_m3 * g * volume_flow_m3_s * head / self.eta_pump


@dataclass(frozen=True)
class SystemResistance:
    """Passive hydraulic path the pump must drive: H_sys = H_static + k*Q^2."""

    static_head_m: float
    resistance_coefficient_s2_m5: float
    source: str = "SYNTHETIC illustrative system curve"

    def __post_init__(self) -> None:
        if not math.isfinite(self.static_head_m) or self.static_head_m < 0.0:
            raise CharacteristicsError("static head must be finite and non-negative")
        if not math.isfinite(self.resistance_coefficient_s2_m5) or \
                self.resistance_coefficient_s2_m5 <= 0.0:
            raise CharacteristicsError("resistance coefficient must be positive")
        if not self.source.strip():
            raise CharacteristicsError("system resistance requires a source")

    @property
    def is_heritage(self) -> bool:
        return not self.source.strip().upper().startswith(SYNTHETIC_PREFIX)

    def head_m(self, volume_flow_m3_s: float) -> float:
        return (self.static_head_m
                + self.resistance_coefficient_s2_m5 * volume_flow_m3_s ** 2)


@dataclass(frozen=True)
class PumpBoundary:
    """What a dynamic header needs: solved flow, pressure and enthalpy.

    This is the drop-in replacement for ``mdot_pump_ref`` / ``h_pump_ref``.
    """

    mass_flow_kg_s: float
    volume_flow_m3_s: float
    head_m: float
    discharge_pressure_pa: float
    suction_pressure_pa: float
    enthalpy_rise_j_kg: float
    delivered_stagnation_enthalpy_j_kg: float
    shaft_power_required_w: float
    shaft_speed_rad_s: float
    shaft_speed_rpm: float
    operating_point_residual_m: float
    shaft_power_residual_w: float
    is_heritage: bool
    provenance: dict = field(default_factory=dict)


def operating_volume_flow(pump: PumpCharacteristics, system: SystemResistance,
                          omega: float) -> float:
    """Intersection of the pump head curve and the system resistance curve.

        a*omega^2 - b*Q^2 = H_static + k*Q^2
        Q = sqrt((a*omega^2 - H_static) / (b + k))

    Raises if the pump cannot overcome the static head at this speed - that is
    a real operating limit, not a numerical nuisance.
    """
    if omega <= 0.0:
        raise CharacteristicsError("shaft speed must be positive")
    available = pump.shutoff_head_coefficient_m_s2 * omega ** 2 - system.static_head_m
    if available <= 0.0:
        raise CharacteristicsError(
            f"pump shutoff head {pump.shutoff_head_coefficient_m_s2 * omega**2:.3f} m "
            f"does not exceed the static head {system.static_head_m:.3f} m at "
            f"omega={omega:.3f} rad/s; no operating point exists"
        )
    denominator = pump.head_loss_coefficient_s2_m5 + system.resistance_coefficient_s2_m5
    if denominator <= 0.0:
        raise CharacteristicsError("combined resistance must be positive")
    return math.sqrt(available / denominator)


def solve_pump_boundary(
    pump: PumpCharacteristics,
    system: SystemResistance,
    *,
    available_shaft_power_w: float,
    density_kg_m3: float,
    suction_pressure_pa: float,
    suction_enthalpy_j_kg: float,
    mechanical_efficiency: float = 1.0,
    g: float = 9.80665,
    speed_lower_rad_s: float = 1.0,
    speed_upper_rad_s: float | None = None,
    power_tolerance_w: float = 1.0,
    max_iterations: int = 200,
) -> PumpBoundary:
    """Solve the shaft speed at which pump demand equals turbine supply.

    The pump absorbs shaft power that rises monotonically with speed (both the
    head and the flow grow with ``omega``), so the residual

        f(omega) = shaft_power_required(omega) - eta_mech * available_power

    is monotone and has at most one root. Bisection is therefore safe and the
    solution is unique.

    Nothing here is a NERVA prediction unless ``pump.is_heritage`` and
    ``system.is_heritage`` are both true.
    """
    if not math.isfinite(available_shaft_power_w) or available_shaft_power_w <= 0.0:
        raise CharacteristicsError("available shaft power must be positive")
    if not math.isfinite(density_kg_m3) or density_kg_m3 <= 0.0:
        raise CharacteristicsError("density must be positive")
    if not 0.0 < mechanical_efficiency <= 1.0:
        raise CharacteristicsError("mechanical efficiency must lie in (0, 1]")
    if not math.isfinite(suction_pressure_pa) or suction_pressure_pa <= 0.0:
        raise CharacteristicsError("suction pressure must be positive")

    target = mechanical_efficiency * available_shaft_power_w

    def required(omega: float) -> float:
        q = operating_volume_flow(pump, system, omega)
        return pump.shaft_power_w(omega, q, density_kg_m3, g)

    hi = speed_upper_rad_s or 10.0 * pump.omega_design_rad_s
    lo = speed_lower_rad_s
    # The pump may not be able to lift the static head at low speed; raise the
    # lower bound until a physical operating point exists.
    for _ in range(60):
        try:
            required(lo)
        except CharacteristicsError:
            lo *= 1.5
            if lo >= hi:
                raise CharacteristicsError(
                    "no shaft speed in the search range can overcome the static head"
                ) from None
        else:
            break

    f_lo = required(lo) - target
    f_hi = required(hi) - target
    if f_lo > 0.0:
        raise CharacteristicsError(
            f"the pump already demands more than the supplied shaft power at "
            f"the minimum speed {lo:.3f} rad/s; the turbine cannot drive this "
            f"cycle"
        )
    if f_hi < 0.0:
        raise CharacteristicsError(
            f"even at {hi:.3f} rad/s the pump demands less than the supplied "
            f"{target:.4g} W; the shaft is over-powered and the cycle needs a "
            f"governing limit"
        )

    for _ in range(max_iterations):
        mid = 0.5 * (lo + hi)
        f_mid = required(mid) - target
        if abs(f_mid) <= power_tolerance_w:
            lo = hi = mid
            break
        if f_mid < 0.0:
            lo = mid
        else:
            hi = mid

    omega = 0.5 * (lo + hi)
    volume_flow = operating_volume_flow(pump, system, omega)
    head = pump.head_m(omega, volume_flow)
    shaft_power = pump.shaft_power_w(omega, volume_flow, density_kg_m3, g)
    system_head = system.head_m(volume_flow)
    mass_flow = density_kg_m3 * volume_flow
    # The fluid gains g*H of specific enthalpy; the *shaft* work is larger by
    # 1/eta_p, and the difference is the pump's internal loss.
    enthalpy_rise = g * head

    return PumpBoundary(
        mass_flow_kg_s=mass_flow,
        volume_flow_m3_s=volume_flow,
        head_m=head,
        discharge_pressure_pa=suction_pressure_pa + density_kg_m3 * g * head,
        suction_pressure_pa=suction_pressure_pa,
        enthalpy_rise_j_kg=enthalpy_rise,
        delivered_stagnation_enthalpy_j_kg=suction_enthalpy_j_kg + enthalpy_rise,
        shaft_power_required_w=shaft_power,
        shaft_speed_rad_s=omega,
        shaft_speed_rpm=omega * 60.0 / (2.0 * math.pi),
        operating_point_residual_m=head - system_head,
        shaft_power_residual_w=shaft_power - target,
        is_heritage=pump.is_heritage and system.is_heritage,
        provenance={
            "pump_source": pump.source,
            "system_source": system.source,
            "is_heritage": pump.is_heritage and system.is_heritage,
            "warning": (
                ""
                if (pump.is_heritage and system.is_heritage)
                else "characteristics are SYNTHETIC; results are illustrative "
                     "cycle closure only, never NERVA performance"
            ),
        },
    )


def header_pump_delivery(boundary: PumpBoundary) -> tuple[float, float]:
    """Adapt a solved boundary into the tuple the dynamic header already takes.

    ``advance_dual_header_tie`` accepts
    ``pump_delivery_override=(mass_flow_kg_s, stagnation_enthalpy_j_kg)``. This
    function produces exactly that pair from a solved operating point, so
    replacing the frozen reference is a one-line change at the call site:

        step = advance_dual_header_tie(..., pump_delivery_override=
                                       header_pump_delivery(boundary))

    The override path is validated by the legacy solver itself (it raises on a
    non-2-tuple or a non-positive flow), and this function pre-checks the same
    contract so a bad boundary fails here rather than deep inside a timestep.
    """
    mass_flow = boundary.mass_flow_kg_s
    enthalpy = boundary.delivered_stagnation_enthalpy_j_kg
    if not (math.isfinite(mass_flow) and mass_flow > 0.0):
        raise CharacteristicsError(
            f"pump boundary carries an unusable mass flow {mass_flow!r}"
        )
    if not math.isfinite(enthalpy):
        raise CharacteristicsError(
            f"pump boundary carries an unusable stagnation enthalpy {enthalpy!r}"
        )
    return (float(mass_flow), float(enthalpy))


def load_pump_map(path: str | Path) -> tuple[PumpCharacteristics, SystemResistance, float, float]:
    """Load a pump map, system curve and fluid inputs from JSON.

    Each curve must carry a ``source``. A file without one is rejected, because
    an unsourced pump curve is an invented pump curve - the exact failure this
    module exists to prevent.

    The working-fluid density and the shaft mechanical efficiency are also
    required here rather than being computed from CoolProp, because mixing a
    CoolProp enthalpy reference with the model's own reference is a silent
    error the legacy code explicitly warns against.
    """
    import json  # noqa: PLC0415 - only needed on this path

    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    for key in ("pump", "system", "fluid"):
        if key not in payload:
            raise CharacteristicsError(f"pump map {path} lacks a {key!r} section")
    pump_payload = payload["pump"]
    system_payload = payload["system"]
    fluid_payload = payload["fluid"]
    pump = PumpCharacteristics(
        shutoff_head_coefficient_m_s2=float(pump_payload["shutoff_head_coefficient_m_s2"]),
        head_loss_coefficient_s2_m5=float(pump_payload["head_loss_coefficient_s2_m5"]),
        omega_design_rad_s=float(pump_payload["omega_design_rad_s"]),
        eta_pump=float(pump_payload["eta_pump"]),
        source=str(pump_payload.get("source", "")),
        note=str(pump_payload.get("note", "")),
    )
    system = SystemResistance(
        static_head_m=float(system_payload["static_head_m"]),
        resistance_coefficient_s2_m5=float(system_payload["resistance_coefficient_s2_m5"]),
        source=str(system_payload.get("source", "")),
    )
    density = float(fluid_payload["density_kg_m3"])
    if not math.isfinite(density) or density <= 0.0:
        raise CharacteristicsError(f"fluid density must be positive, got {density!r}")
    efficiency = float(fluid_payload.get("mechanical_efficiency", 0.95))
    if not 0.0 < efficiency <= 1.0:
        raise CharacteristicsError(
            f"mechanical efficiency must lie in (0, 1], got {efficiency!r}"
        )
    return pump, system, density, efficiency


def pump_boundary_from_shaft(shaft, pump: PumpCharacteristics,
                             system: SystemResistance, *,
                             suction_pressure_pa: float,
                             suction_enthalpy_j_kg: float,
                             density_kg_m3: float,
                             mechanical_efficiency: float = 0.95,
                             g: float = 9.80665) -> PumpBoundary:
    """Solve the pump operating point from the shaft's delivered power.

    ``shaft`` is a ``turbine_bleed_cycle.ShaftClosedPoint``: its
    ``turbine_shaft_delivered_power_w`` is the power actually available to
    drive the pump, so the pump flow and enthalpy become outputs of the shaft
    balance rather than frozen inputs.
    """
    available = float(shaft.turbine_shaft_delivered_power_w)
    if available <= 0.0:
        raise CharacteristicsError(
            f"shaft delivers no power to the pump ({available!r} W); the "
            f"turbine cannot drive this cycle"
        )
    return solve_pump_boundary(
        pump, system,
        available_shaft_power_w=available,
        density_kg_m3=density_kg_m3,
        suction_pressure_pa=suction_pressure_pa,
        suction_enthalpy_j_kg=suction_enthalpy_j_kg,
        mechanical_efficiency=mechanical_efficiency,
        g=g,
        speed_upper_rad_s=4.0 * pump.omega_design_rad_s,
    )


def resolve_pump_override(pump_map_path, shaft, *, suction_pressure_pa: float,
                          suction_enthalpy_j_kg: float):
    """Return the ``pump_delivery_override`` for a dynamic header, or ``None``.

    Returning ``None`` when no map is supplied is deliberate: it preserves the
    legacy behaviour exactly (the frozen reference), so wiring this in cannot
    change an existing result. Supplying a map is what replaces the frozen
    reference with a solved operating point.

    ``suction_enthalpy_j_kg`` must come from the *model's own* reference frame
    (for the dynamic header that is ``engine_tie_reservoirs(shaft)``), so that
    the override differs from the frozen value only by the pump head term.
    """
    if pump_map_path is None:
        return None
    pump, system, density, efficiency = load_pump_map(pump_map_path)
    boundary = pump_boundary_from_shaft(
        shaft, pump, system,
        suction_pressure_pa=suction_pressure_pa,
        suction_enthalpy_j_kg=suction_enthalpy_j_kg,
        density_kg_m3=density,
        mechanical_efficiency=efficiency,
    )
    return header_pump_delivery(boundary)


def illustrative_characteristics(speed_rad_s: float = 500.0,
                                 design_head_m: float = 9000.0,
                                 design_flow_m3_s: float = 0.30,
                                 static_head_m: float = 100.0,
                                 eta_pump: float = 0.75) -> tuple[PumpCharacteristics, SystemResistance]:
    """Build a SYNTHETIC pump/system pair for exercising the closure.

    The numbers are chosen so the design point lands near Emrich's worked
    example (p.178: H = 9230 m, Q = 0.3 m3/s, eta = 0.8) purely so the module
    is exercised on realistic magnitudes. They are **not** a transcription of
    that example and are explicitly labelled synthetic.
    """
    if design_head_m <= static_head_m:
        raise CharacteristicsError("design head must exceed the static head")
    # Shutoff head is the design head plus the losses at design flow, split
    # evenly between the pump's own curve and the system resistance.
    excess = design_head_m - static_head_m
    pump_loss = 0.5 * excess
    system_loss = 0.5 * excess
    a = design_head_m / speed_rad_s ** 2
    b = pump_loss / design_flow_m3_s ** 2
    k = system_loss / design_flow_m3_s ** 2
    return (
        PumpCharacteristics(
            shutoff_head_coefficient_m_s2=a,
            head_loss_coefficient_s2_m5=b,
            omega_design_rad_s=speed_rad_s,
            eta_pump=eta_pump,
            source="SYNTHETIC illustrative affinity curve for closure testing",
            note="Replace with digitised NERVA pump characteristics before any "
                 "claim about the engine cycle",
        ),
        SystemResistance(
            static_head_m=static_head_m,
            resistance_coefficient_s2_m5=k,
            source="SYNTHETIC illustrative system curve for closure testing",
        ),
    )
