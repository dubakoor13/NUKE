"""Verify decay chains, activation and decay heat.

The closed-form Bateman solution is checked against its own defining ODEs (the
derivatives must balance), against the numerical integrator, and against
elementary limits (a single parent must decay exponentially). Activation is
checked against the saturation identity ``A_inf = N sigma phi`` and against
``dN/dt = 0`` at saturation.

Nuclide data below is SYNTHETIC: real half-lives are not in the supplied
documents, so these are round numbers chosen to make the arithmetic legible, and
every one carries an explicit test source.
"""
from __future__ import annotations

import math

from .decay import (
    ActivationParameters,
    DecayChain,
    DecayError,
    DecayHeatContribution,
    Nuclide,
    activated_atoms,
    activity_after_irradiation,
    bateman_activity,
    cooling_time_to_activity,
    decay_heat,
    decay_heat_from_chain,
    integrate_chain,
    saturation_activity,
    time_to_saturation,
)

TEST_SOURCE = "SYNTHETIC test data for unit checks"

A = Nuclide("A", half_life_s=3600.0, decay_energy_mev=1.0, source=TEST_SOURCE)
B = Nuclide("B", half_life_s=7200.0, decay_energy_mev=2.0, source=TEST_SOURCE)
C = Nuclide("C", half_life_s=14400.0, decay_energy_mev=0.5, source=TEST_SOURCE)
CHAIN = DecayChain(members=(A, B, C))


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- single nuclide -------------------------------------------------
    print("single-nuclide decay:")
    lam = A.decay_constant_per_s
    results.append(_report("decay constant is ln2/T",
                           abs(lam - math.log(2.0) / 3600.0) < 1e-18,
                           f"lambda = {lam:.6e} /s"))
    results.append(_report("one half-life leaves half",
                           abs(A.remaining_fraction(3600.0) - 0.5) < 1e-15,
                           f"{A.remaining_fraction(3600.0):.12f}"))
    results.append(_report("two half-lives leave a quarter",
                           abs(A.remaining_fraction(7200.0) - 0.25) < 1e-15,
                           f"{A.remaining_fraction(7200.0):.12f}"))
    results.append(_report("mean lifetime is 1/lambda",
                           abs(A.mean_lifetime_s - 1.0 / lam) < 1e-12,
                           f"{A.mean_lifetime_s:.2f} s"))
    results.append(_report("Bateman index 0 reduces to simple decay",
                           abs(bateman_activity(CHAIN, 0, 1.0e20, 3600.0)
                               - 1.0e20 * math.exp(-lam * 3600.0))
                           / 1.0e20 < 1e-15, "exp(-lambda t)"))

    # ---- the two-member chain against its ODE --------------------------
    print("\nBateman solution satisfies the defining ODEs:")
    n0 = 1.0e20
    worst_balance = 0.0
    for time in (0.0, 1800.0, 3600.0, 10800.0):
        step = 1.0
        parent = bateman_activity(CHAIN, 0, n0, time)
        daughter = bateman_activity(CHAIN, 1, n0, time)
        parent_rate = ((bateman_activity(CHAIN, 0, n0, time + step)
                        - bateman_activity(CHAIN, 0, n0, time - step)) / (2 * step)
                       if time > 0 else -A.decay_constant_per_s * n0)
        daughter_rate = ((bateman_activity(CHAIN, 1, n0, time + step)
                          - bateman_activity(CHAIN, 1, n0, time - step)) / (2 * step)
                         if time > 0 else A.decay_constant_per_s * n0)
        # dN_A/dt = -lambda_A N_A
        balance_a = abs(parent_rate + A.decay_constant_per_s * parent) / max(
            abs(parent_rate), 1e-30)
        # dN_B/dt = lambda_A N_A - lambda_B N_B
        rhs_b = A.decay_constant_per_s * parent - B.decay_constant_per_s * daughter
        balance_b = abs(daughter_rate - rhs_b) / max(abs(rhs_b), 1e-30)
        worst_balance = max(worst_balance, balance_a, balance_b)
        print(f"    t={time:7.0f} s: N_A={parent:.4e}  N_B={daughter:.4e}  "
              f"residual {max(balance_a, balance_b):.2e}")
    results.append(_report("parent and daughter rates match the ODEs",
                           worst_balance < 1e-6, f"worst {worst_balance:.2e}"))

    # ---- numerical against closed form ---------------------------------
    print("\nRK4 integration agrees with the closed form:")
    numeric = integrate_chain(CHAIN, (n0, 0.0, 0.0), duration_s=10800.0, dt_s=10.0)
    analytic = tuple(bateman_activity(CHAIN, index, n0, 10800.0)
                     for index in range(CHAIN.length))
    print("    analytic " + "  ".join(f"{value:.6e}" for value in analytic))
    print("    numeric  " + "  ".join(f"{value:.6e}" for value in numeric))
    worst = max(abs(n - a) / max(a, 1e-30) for n, a in zip(numeric, analytic))
    results.append(_report("numerical matches analytic to 1e-6",
                           worst < 1e-6, f"worst relative {worst:.2e}"))
    # All three members are radioactive here, so the total abundance must FALL.
    # Conservation only holds when the chain terminates in a stable nuclide -
    # which is the next check.
    results.append(_report("total atoms fall when every member decays",
                           math.fsum(numeric) < n0,
                           f"{math.fsum(numeric):.4e} < {n0:.1e}"))
    stable_end = Nuclide("C_stable", half_life_s=math.inf, decay_energy_mev=0.0,
                         source=TEST_SOURCE)
    stable_chain = DecayChain(members=(A, B, stable_end))
    stable_numeric = integrate_chain(stable_chain, (n0, 0.0, 0.0),
                                     duration_s=108000.0, dt_s=20.0)
    results.append(_report("a stable terminus conserves total atoms",
                           abs(math.fsum(stable_numeric) - n0) / n0 < 1e-9,
                           f"sum {math.fsum(stable_numeric):.6e}"))

    # ---- degeneracy ----------------------------------------------------
    print("\ndegenerate decay constants are refused, not divided by zero:")
    twin = Nuclide("A2", half_life_s=A.half_life_s, decay_energy_mev=1.0,
                   source=TEST_SOURCE)
    degenerate = DecayChain(members=(A, twin))
    try:
        bateman_activity(degenerate, 1, n0, 3600.0)
    except DecayError:
        results.append(True)
        print("  [PASS] closed form refuses when lambda_A == lambda_B")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED degenerate chain in the closed form")
    numeric_degenerate = integrate_chain(degenerate, (n0, 0.0),
                                        duration_s=7200.0, dt_s=5.0)
    results.append(_report("the integrator still handles the degenerate case",
                           all(value >= 0.0 for value in numeric_degenerate)
                           and math.isfinite(math.fsum(numeric_degenerate)),
                           f"{len(numeric_degenerate)} members, finite"))

    # ---- activation ----------------------------------------------------
    print("\nneutron activation:")
    params = ActivationParameters(target_atoms=1.0e22, sigma_cm2=1.0e-24,
                                  flux_cm2_s=1.0e14)
    rate = params.production_rate_per_s
    print(f"    production rate R = {rate:.4e} /s")
    results.append(_report("R = N sigma phi",
                           abs(rate - 1.0e22 * 1.0e-24 * 1.0e14) / rate < 1e-15,
                           f"{rate:.4e}"))
    results.append(_report("saturation activity equals R",
                           abs(saturation_activity(params) - rate) / rate < 1e-15,
                           f"{rate:.4e} Bq"))
    long_run = activated_atoms(params, A, irradiation_s=100.0 * A.half_life_s)
    saturated = rate / A.decay_constant_per_s
    print(f"    N after 100 half-lives = {long_run:.4e} vs N_sat {saturated:.4e}")
    results.append(_report("atoms saturate at R/lambda",
                           abs(long_run - saturated) / saturated < 1e-12,
                           "within 1e-12"))
    results.append(_report("saturation is independent of the half-life",
                           abs(saturation_activity(ActivationParameters(
                               target_atoms=1.0e22, sigma_cm2=1.0e-24,
                               flux_cm2_s=1.0e14)) - rate) < 1e-6,
                           "A_inf depends on N sigma phi only"))
    activity = activity_after_irradiation(params, A, irradiation_s=4 * 3600.0)
    expected = (A.decay_constant_per_s
                * activated_atoms(params, A, 4 * 3600.0))
    results.append(_report("activity = lambda N after irradiation",
                           abs(activity - expected) / expected < 1e-15,
                           f"{activity:.4e} Bq"))
    cooled = activity_after_irradiation(params, A, 4 * 3600.0, cooling_s=3600.0)
    results.append(_report("cooling for one half-life halves the activity",
                           abs(cooled / activity - 0.5) < 1e-14,
                           f"ratio {cooled/activity:.12f}"))
    t99 = time_to_saturation(params, A, 0.99)
    print(f"    time to 99% saturation = {t99:.1f} s = {t99/3600:.3f} h")
    results.append(_report("time to 99% saturation is ln(100)/lambda",
                           abs(t99 - math.log(100.0) / A.decay_constant_per_s) < 1e-9,
                           f"{t99:.2f} s"))
    results.append(_report("one half-life gives exactly 50% saturation",
                           abs(activated_atoms(params, A, A.half_life_s)
                               / saturated - 0.5) < 1e-15, "50%"))
    cooling = cooling_time_to_activity(A, activity, activity / 8.0)
    results.append(_report("cooling to an eighth takes three half-lives",
                           abs(cooling - 3.0 * A.half_life_s) < 1e-9,
                           f"{cooling:.1f} s"))

    # ---- decay heat ----------------------------------------------------
    print("\ndecay heat:")
    contribution = DecayHeatContribution(nuclide=A, activity_bq=1.0e15)
    joules = A.decay_energy_mev * 1.602176634e-13
    print(f"    1e15 Bq of a 1 MeV emitter -> {contribution.heat_w:.4f} W")
    results.append(_report("heat = activity x energy per decay",
                           abs(contribution.heat_w - 1.0e15 * joules) < 1e-12,
                           f"{contribution.heat_w:.4f} W"))
    total = decay_heat([DecayHeatContribution(A, 1.0e15),
                        DecayHeatContribution(B, 1.0e15)])
    expected_total = 1.0e15 * (A.decay_energy_mev + B.decay_energy_mev) * 1.602176634e-13
    results.append(_report("contributions sum",
                           abs(total - expected_total) / expected_total < 1e-15,
                           f"{total:.4f} W"))
    chain_heat = decay_heat_from_chain(CHAIN, n0, 3600.0)
    results.append(_report("chain heat is positive and finite",
                           math.isfinite(chain_heat) and chain_heat > 0.0,
                           f"{chain_heat:.6e} W"))
    later = decay_heat_from_chain(CHAIN, n0, 108000.0)
    results.append(_report("decay heat falls with time",
                           later < chain_heat,
                           f"{later:.3e} < {chain_heat:.3e} W"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid inputs are rejected:")
    guards = [
        ("zero half-life", lambda: Nuclide("X", half_life_s=0.0,
                                           source=TEST_SOURCE)),
        ("nuclide without a source", lambda: Nuclide("X", half_life_s=1.0,
                                                     source="")),
        ("negative decay energy", lambda: Nuclide("X", half_life_s=1.0,
                                                  decay_energy_mev=-1.0,
                                                  source=TEST_SOURCE)),
        ("single-member chain", lambda: DecayChain(members=(A,))),
        ("chain index out of range", lambda: bateman_activity(CHAIN, 5, 1.0, 1.0)),
        ("negative time", lambda: bateman_activity(CHAIN, 1, 1.0, -1.0)),
        ("zero flux", lambda: ActivationParameters(1e22, 1e-24, 0.0)),
        ("target above initial in cooling",
         lambda: cooling_time_to_activity(A, 1.0, 2.0)),
        ("fraction of one", lambda: time_to_saturation(params, A, 1.0)),
        ("abundance count mismatch", lambda: integrate_chain(CHAIN, (1.0,), 1.0, 1.0)),
        ("zero duration", lambda: integrate_chain(CHAIN, (1.0, 0.0, 0.0), 0.0, 1.0)),
        ("empty decay heat", lambda: decay_heat([])),
    ]
    for label, fn in guards:
        try:
            fn()
        except (DecayError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: decay chains, activation and decay heat are exact and consistent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
