"""Validate the expanded NERVA OpenMC diagnostics configuration."""

from __future__ import annotations

import openmc

from .config import NervaConfig
from .model import build_model
from .postprocess_openmc_diagnostics import (
    _peaking_metrics,
    _spectral_fractions,
)


def main() -> int:
    config = NervaConfig(
        core_rings=3,
        particles=100,
        batches=12,
        inactive=4,
        photon_transport=False,
        diagnostic_energy_groups=16,
        axial_mesh_bins=24,
        entropy_mesh_xy=6,
        entropy_mesh_z=4,
    )
    model = build_model(config, assembly="reactor")

    assert model.settings.run_mode == "eigenvalue"
    assert model.settings.photon_transport is False
    assert model.settings.entropy_mesh is not None
    # A mesh refinement changes only tally discretization. Geometry and
    # reactor composition are left untouched by this config control.
    mesh = next(t for t in model.tallies if t.name == "nerva_3d_neutronics")
    assert tuple(mesh.find_filter(openmc.MeshFilter).mesh.dimension) == (48, 48, 24)
    from dataclasses import replace
    refined_cfg = replace(config, heating_mesh_dimension=(96, 96, 48))
    refined = build_model(refined_cfg, assembly="reactor")
    finer = next(t for t in refined.tallies if t.name == "nerva_3d_neutronics")
    assert tuple(finer.find_filter(openmc.MeshFilter).mesh.dimension) == (96, 96, 48)
    assert len(refined.geometry.get_all_cells()) == len(model.geometry.get_all_cells())
    for bad_shape in ((4, 4), (0, 48, 24), (32, 32, 0), (48., 48, 24)):
        try:
            replace(config, heating_mesh_dimension=bad_shape).validate()
        except ValueError as exc:
            assert "heating_mesh_dimension" in str(exc)
        else:
            raise AssertionError("invalid mesh tally dimensions accepted")

    tallies = {t.name: t for t in model.tallies}
    required = {
        "nerva_3d_neutronics",
        "nerva_3d_fuel_heating",
        "nerva_3d_tie_heating",
        "nerva_3d_fuel_hydrogen_heating",
        "nerva_3d_tie_hydrogen_heating",
        "nerva_3d_tie_supply_hydrogen_heating",
        "nerva_3d_tie_return_hydrogen_heating",
        "nerva_fuel_sector_01_instances",
        "nerva_fuel_sector_01_axial_instances",
        "nerva_fuel_sector_19_instances",
        "nerva_fuel_sector_19_axial_instances",
        "nerva_hydrogen_channel_01_instances",
        "nerva_hydrogen_channel_01_axial_instances",
        "nerva_hydrogen_channel_19_instances",
        "nerva_hydrogen_channel_19_axial_instances",
        "nerva_material_transport",
        "nerva_material_energy_transport",
        "nerva_fuel_spectrum",
        "nerva_hydrogen_spectrum",
        "nerva_axial_transport",
        "nerva_vacuum_boundary_current",
    }
    missing = required - set(tallies)
    assert not missing, f"missing diagnostics tallies: {sorted(missing)}"

    fuel_sector_integrated = {
        name
        for name in tallies
        if name.startswith("nerva_fuel_sector_")
        and name.endswith("_instances")
        and "_axial_" not in name
    }
    fuel_sector_axial = {
        name
        for name in tallies
        if name.startswith("nerva_fuel_sector_")
        and name.endswith("_axial_instances")
    }
    assert len(fuel_sector_integrated) == 19
    assert len(fuel_sector_axial) == 19
    assert any(
        name.startswith("nerva_tie_axial_instance_")
        for name in tallies
    )

    mesh_scores = set(tallies["nerva_3d_neutronics"].scores)
    assert {
        "flux",
        "absorption",
        "fission",
        "nu-fission",
        "heating",
        "heating-local",
        "kappa-fission",
    } <= mesh_scores

    material_filter = tallies[
        "nerva_material_transport"
    ].find_filter(openmc.MaterialFilter)
    assert len(material_filter.bins) == 9

    energy_filter = tallies[
        "nerva_fuel_spectrum"
    ].find_filter(openmc.EnergyFilter)
    assert len(energy_filter.bins) == 16
    # Every reported thermal/epithermal/fast fraction must be exactly
    # bin-aligned, independent of diagnostic neutron group count.
    from .neutron_energy_groups import diagnostic_energy_edges
    import numpy as np
    for n in (8, 16, 80):
        edges = diagnostic_energy_edges(n)
        assert len(edges) == n + 1
        assert np.any(edges == 0.625)
        assert np.any(edges == 1.0e5)
        bins = np.column_stack((edges[:-1], edges[1:]))
        fractions = _spectral_fractions(bins, np.ones(n))
        assert np.isclose(sum(fractions.values()), 1., rtol=0, atol=1e-12)
    np.testing.assert_allclose(
        np.asarray(energy_filter.bins),
        np.column_stack(
            (diagnostic_energy_edges(16)[:-1],
             diagnostic_energy_edges(16)[1:])
        ),
        rtol=1e-11, atol=0,
    )

    axial_filter = tallies[
        "nerva_axial_transport"
    ].find_filter(openmc.MeshFilter)
    assert tuple(axial_filter.mesh.dimension) == (1, 1, 24)

    # Pure postprocessing helper checks.
    peak = _peaking_metrics(
        __import__("numpy").array([1.0, 2.0, 4.0])
    )
    assert peak["max_to_mean_active"] > 1.0

    bins = __import__("numpy").array(
        [
            [1.0e-5, 0.625],
            [0.625, 1.0e5],
            [1.0e5, 2.0e7],
        ]
    )
    fractions = _spectral_fractions(
        bins,
        __import__("numpy").array([1.0, 2.0, 3.0]),
    )
    assert abs(sum(fractions.values()) - 1.0) < 1.0e-12

    trigger_config = NervaConfig(
        core_rings=3,
        particles=100,
        batches=12,
        inactive=4,
        tally_rel_err_trigger=0.25,
        trigger_max_batches=30,
        trigger_batch_interval=2,
        diagnostic_energy_groups=16,
        axial_mesh_bins=24,
    )
    trigger_model = build_model(
        trigger_config,
        assembly="reactor",
    )
    assert trigger_model.settings.trigger_active is True
    assert trigger_model.settings.trigger_max_batches == 30
    assert trigger_model.settings.trigger_batch_interval == 2
    trigger_tally = next(
        tally
        for tally in trigger_model.tallies
        if tally.name == "nerva_3d_neutronics"
    )
    assert len(trigger_tally.triggers) == 1
    assert trigger_tally.triggers[0].trigger_type == "rel_err"

    photon_config = NervaConfig(
        core_rings=3,
        particles=100,
        batches=12,
        inactive=4,
        photon_transport=True,
        diagnostic_energy_groups=16,
        axial_mesh_bins=24,
    )
    photon_model = build_model(
        photon_config,
        assembly="reactor",
    )
    photon_tallies = {t.name for t in photon_model.tallies}
    assert "nerva_particle_heating" in photon_tallies
    # All cell, mesh and Distribcell thermal partitions must score
    # transported photon deposition if gamma tracking is enabled.
    for tally in photon_model.tallies:
        if "heating-local" in tally.scores:
            assert "heating" in tally.scores, tally.name
    assert "heating" not in tallies["nerva_3d_fuel_heating"].scores
    assert trigger_tally.triggers[0].scores == ["heating-local"]
    photon_trigger_model = build_model(
        NervaConfig(
            core_rings=3,
            particles=100,
            batches=12,
            inactive=4,
            photon_transport=True,
            tally_rel_err_trigger=0.25,
            trigger_max_batches=30,
            trigger_batch_interval=2,
        ),
        assembly="core",
    )
    photon_trigger_tally = next(
        t for t in photon_trigger_model.tallies
        if t.name == "nerva_3d_neutronics"
    )
    assert photon_trigger_tally.triggers[0].scores == ["heating"]


    print("Expanded NERVA OpenMC diagnostics validation: PASS")
    print(f"  tallies: {len(tallies)}")
    print("  material-resolved transport: enabled")
    print("  fuel/H2 spectra: enabled")
    print("  axial transport: enabled")
    print("  vacuum leakage current: enabled")
    print("  entropy mesh: enabled")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
