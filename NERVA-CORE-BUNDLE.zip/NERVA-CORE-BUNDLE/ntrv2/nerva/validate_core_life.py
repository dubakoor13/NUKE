"""Verify core life: burnup, poison buildup and reactivity versus time.

Checks that tie the model to independent facts:

* the fission rate must reproduce the thermal power exactly;
* the poison integrator must relax to the closed-form equilibrium of Ch. 13;
* one MWd of burnup must consume ~1.05 g of fissile mass;
* the reactivity ledger must decline monotonically and reach end of life where
  the initial excess is exactly consumed.
"""
from __future__ import annotations

import math

from .core_life import (
    ENERGY_PER_FISSION_J,
    CoreLifeError,
    CoreLifeParameters,
    ledger_total,
    life_reactivity_ledger,
    march_core_life,
)
from .fission_product_poisoning import (
    STANDARD_DECAY_CONSTANTS,
    CorePoisoningInputs,
    PoisonInventory,
    equilibrium_iodine,
    equilibrium_promethium,
    equilibrium_samarium,
    equilibrium_xenon,
    integrate_poisoning,
)

C = STANDARD_DECAY_CONSTANTS
INPUTS = CorePoisoningInputs(macroscopic_fission_xs_cm_inv=0.05,
                             neutron_flux_cm2_s=1.0e14)

PARAMS = CoreLifeParameters(
    initial_fissile_mass_kg=1.85,
    thermal_power_w=1.0e8,
    macroscopic_fission_xs_cm_inv=0.05,
    neutron_flux_cm2_s=1.0e14,
    initial_excess_reactivity=0.02,
    # -3 dk/k per 1/cm gives roughly -1100 pcm of equilibrium poison worth at
    # this flux, which is the right order for a core carrying 2000 pcm of excess.
    # An earlier value of -40 made poison worth ~15000 pcm and ended the core's
    # life in 0.1 EFPD.
    poison_worth_per_cm=-3.0,
    # -0.027 dk/k per kg consumed exhausts the remaining ~1000 pcm over roughly
    # 20% burnup, about 3.5 EFPD at this specific power (54 kW/g).
    burnup_worth_per_kg=-2.7e-2,
)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []

    # ---- basic consistency --------------------------------------------
    print("fission rate reproduces the thermal power:")
    energy = PARAMS.fission_rate_per_s * ENERGY_PER_FISSION_J
    results.append(_report("power = fission rate x energy per fission",
                           abs(energy - PARAMS.thermal_power_w)
                           / PARAMS.thermal_power_w < 1e-12,
                           f"{energy:.6e} W"))

    one_day_kg = (PARAMS.fission_rate_per_s * 86400.0
                  / PARAMS.fissile_atoms * PARAMS.initial_fissile_mass_kg)
    print(f"    fissile consumption: {one_day_kg*1000:.4f} g per full-power day")
    # 1 MWd fissions about 1.05 g of fissile mass; 100 MWd -> ~105 g.
    expected_kg = 1.0e8 / 1e6 * 1.05e-3
    results.append(_report("consumption matches ~1.05 g per MWd",
                           abs(one_day_kg - expected_kg) / expected_kg < 0.02,
                           f"{one_day_kg*1000:.3f} g vs expected ~{expected_kg*1000:.2f} g"))

    # ---- the poison integrator reaches equilibrium ---------------------
    print("\npoison integrator relaxes to the Ch.13 equilibrium:")
    final, history = integrate_poisoning(
        INPUTS, C, None, duration_s=200 * 3600.0, dt_s=600.0, sample_every=100)
    targets = {
        "iodine": equilibrium_iodine(INPUTS, C),
        "xenon": equilibrium_xenon(INPUTS, C),
        "promethium": equilibrium_promethium(INPUTS, C),
        "samarium": equilibrium_samarium(INPUTS, C),
    }
    for name, target in targets.items():
        got = getattr(final, name)
        relative = abs(got - target) / target
        print(f"    {name:11} integrated {got:.4e}  equilibrium {target:.4e}  "
              f"({relative*100:.3f}%)")
        # Samarium-149 lags behind: its precursor 149Pm has a 53 h half-life and
        # its own burnup timescale is comparable, so 200 h is not enough for it.
        # Emrich notes samarium equilibrium can take far longer than xenon's.
        tolerance = 0.35 if name in ("promethium", "samarium") else 0.02
        results.append(_report(f"{name} approaching equilibrium within {tolerance*100:.0f}%",
                               relative < tolerance, f"{relative*100:.3f}%"))

    # Samarium needs much longer, and does converge given the time.
    long_final, _ = integrate_poisoning(
        INPUTS, C, None, duration_s=4000 * 3600.0, dt_s=3600.0)
    sm_relative = abs(long_final.samarium
                      - targets["samarium"]) / targets["samarium"]
    print(f"    samarium after 4000 h: {sm_relative*100:.3f}% from equilibrium")
    results.append(_report("samarium converges given enough time",
                           sm_relative < 0.02, f"{sm_relative*100:.3f}%"))
    sm_relative_200h = abs(final.samarium
                           - targets["samarium"]) / targets["samarium"]
    xe_relative_200h = abs(final.xenon - targets["xenon"]) / targets["xenon"]
    print(f"    at 200 h: xenon {xe_relative_200h*100:.3f}% from equilibrium, "
          f"samarium {sm_relative_200h*100:.3f}%")
    results.append(_report("samarium is slower to equilibrate than xenon",
                           sm_relative_200h > xe_relative_200h,
                           "as Emrich notes on p.259"))
    results.append(_report("history is sampled", len(history) > 5,
                           f"{len(history)} samples"))
    results.append(_report("xenon rises monotonically while power is on",
                           all(b.xenon >= a.xenon
                               for (_, a), (_, b) in zip(history, history[1:])),
                           "monotone buildup"))

    # ---- the core-life march ------------------------------------------
    print("\ncore life march:")
    result = march_core_life(PARAMS, C, duration_days=3000.0, dt_s=7200.0)
    first, last = result.points[0], result.points[-1]
    print(f"    start : excess {first.net_reactivity/1e-5:+8.1f} pcm, "
          f"burnup {first.burnup_fraction*100:5.2f}%")
    print(f"    end   : excess {last.net_reactivity/1e-5:+8.1f} pcm, "
          f"burnup {last.burnup_fraction*100:5.2f}%, "
          f"EFPD {last.effective_full_power_days:.1f}")
    print(f"    end of life: {result.end_of_life_days} EFPD  ({result.reason})")
    results.append(_report("a finite core life is found",
                           result.has_finite_life is True,
                           f"{result.end_of_life_days:.2f} EFPD"
                           if result.has_finite_life else "none"))
    results.append(_report("fissile mass decreases monotonically",
                           all(b.fissile_mass_kg < a.fissile_mass_kg
                               for a, b in zip(result.points, result.points[1:])),
                           f"{first.fissile_mass_kg:.4f} -> "
                           f"{last.fissile_mass_kg:.4f} kg"))
    results.append(_report("poison reactivity is a loss (negative)",
                           all(point.poison_reactivity <= 1e-15
                               for point in result.points),
                           f"most negative {result.peak_poison_reactivity/1e-5:.0f} pcm"))
    results.append(_report("burnup reactivity is a loss (negative)",
                           all(point.burnup_reactivity <= 1e-15
                               for point in result.points),
                           f"final {last.burnup_reactivity/1e-5:.0f} pcm"))
    results.append(_report("net reactivity declines monotonically",
                           all(b.net_reactivity <= a.net_reactivity
                               for a, b in zip(result.points, result.points[1:])),
                           "no spurious recovery"))
    results.append(_report("poison reached equilibrium during the march",
                           result.converged_to_poison_equilibrium is True,
                           "within 5% of closed form"))

    # ---- end of life is where the excess is consumed -------------------
    print("\nend of life coincides with the excess being consumed:")
    excess = PARAMS.initial_excess_reactivity
    consumed = -(last.poison_reactivity + last.burnup_reactivity
                 + PARAMS.controllable_reactivity)
    print(f"    excess {excess/1e-5:+.1f} pcm   consumed {consumed/1e-5:+.1f} pcm")
    results.append(_report("loss terms account for the initial excess",
                           abs(consumed - excess) / abs(excess) < 0.05,
                           f"ratio {consumed/excess:.4f}"))

    # ---- the ledger ----------------------------------------------------
    print("\nlife-cycle reactivity ledger:")
    entries = life_reactivity_ledger(last, excess)
    total = ledger_total(entries)
    width = max(len(entry.name) for entry in entries)
    for entry in entries:
        print(f"    {entry.name:<{width}}  {entry.pcm:+9.1f} pcm")
    print(f"    {'TOTAL':<{width}}  {total/1e-5:+9.1f} pcm")
    results.append(_report("ledger total equals the net reactivity",
                           abs(total - last.net_reactivity) < 1e-15,
                           f"{total/1e-5:+.3f} pcm"))
    # The core is critical at the start of life, so the ledger starts positive.
    start_entries = life_reactivity_ledger(first, excess)
    results.append(_report("the ledger starts near the loaded excess",
                           abs(ledger_total(start_entries) - excess)
                           / abs(excess) < 0.05,
                           f"{ledger_total(start_entries)/1e-5:+.1f} pcm"))

    # ---- a longer-lived core -------------------------------------------
    print("\nlife scales with the loaded excess:")
    doubled = march_core_life(
        CoreLifeParameters(
            initial_fissile_mass_kg=PARAMS.initial_fissile_mass_kg,
            thermal_power_w=PARAMS.thermal_power_w,
            macroscopic_fission_xs_cm_inv=PARAMS.macroscopic_fission_xs_cm_inv,
            neutron_flux_cm2_s=PARAMS.neutron_flux_cm2_s,
            initial_excess_reactivity=2.0 * PARAMS.initial_excess_reactivity,
            poison_worth_per_cm=PARAMS.poison_worth_per_cm,
            burnup_worth_per_kg=PARAMS.burnup_worth_per_kg,
            controllable_reactivity=PARAMS.controllable_reactivity),
        C, duration_days=3000.0, dt_s=7200.0)
    print(f"    2x excess -> {doubled.end_of_life_days:.1f} EFPD  "
          f"(vs {result.end_of_life_days:.1f})")
    results.append(_report("doubling the excess lengthens the life",
                           doubled.end_of_life_days > result.end_of_life_days,
                           f"{doubled.end_of_life_days:.1f} > "
                           f"{result.end_of_life_days:.1f} EFPD"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid parameters are rejected:")
    guards = [
        ("zero fissile mass", lambda: CoreLifeParameters(
            initial_fissile_mass_kg=0.0, thermal_power_w=1e8,
            macroscopic_fission_xs_cm_inv=0.05, neutron_flux_cm2_s=1e14,
            initial_excess_reactivity=0.02, poison_worth_per_cm=-40.0,
            burnup_worth_per_kg=-2e-3)),
        ("positive poison worth", lambda: CoreLifeParameters(
            initial_fissile_mass_kg=1.85, thermal_power_w=1e8,
            macroscopic_fission_xs_cm_inv=0.05, neutron_flux_cm2_s=1e14,
            initial_excess_reactivity=0.02, poison_worth_per_cm=+40.0,
            burnup_worth_per_kg=-2e-3)),
        ("zero duration", lambda: march_core_life(PARAMS, C, duration_days=0.0)),
        ("zero march timestep", lambda: march_core_life(PARAMS, C, dt_s=0.0)),
        ("zero integration duration",
         lambda: integrate_poisoning(INPUTS, C, None, duration_s=0.0, dt_s=1.0)),
        ("negative initial inventory",
         lambda: PoisonInventory(-1.0, 0.0, 0.0, 0.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (CoreLifeError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: core life, burnup and poison buildup are consistent and closed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
