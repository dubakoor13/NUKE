"""Verify reactivity coefficients against an exactly-known response.

The analytic surrogate backend is linear in every state variable, so its
derivative is known exactly from its own coefficients. A central difference must
recover those coefficients to machine precision - that is a genuine oracle, not
a self-consistency check.

The tests also confirm the properties that matter for core safety: Doppler is
negative, the coefficients add, and the temperature defect equals the sum of the
individual contributions.
"""
from __future__ import annotations

import math

from .reactivity_coefficients import (
    PCM,
    CoefficientError,
    from_pcm,
    fuel_temperature_coefficient,
    coolant_temperature_coefficient,
    drum_worth_gradient,
    void_coefficient,
    poison_worth,
    enrichment_worth,
    power_coefficient,
    reflector_temperature_coefficient,
    temperature_defect,
    to_pcm,
)
from .transport_backend import CoreState, MockCoefficients, MockTransportBackend

# The surrogate's true derivatives: k is linear in each of these.
DOPPLER_PER_K = -1.0e-5
COOLANT_PER_K = -2.0e-6
REFLECTOR_PER_K = -5.0e-7
DRUM_PER_DEG = 2.0e-4
ENRICHMENT_PER_WT = 2.0e-2
DENSITY_PER_KGM3 = 3.0e-3
POISON_PER_CM = -4.0e-2

# "Exact" means exact to the arithmetic, not to an arbitrary digit count. The
# difference k(d+dT) - k(d-dT) for the smallest coefficient above is about
# 2.5e-5, and a double-precision subtraction of two numbers near 1.02 carries
# an absolute error near 1e-16, so a relative floor of ~4e-12 is unavoidable.
# 1e-10 still demonstrates exact recovery while staying above that floor.
EXACT_TOL = 1.0e-10

COEFFS = MockCoefficients(
    k_reference=1.02,
    fuel_temperature_coefficient_per_k=DOPPLER_PER_K,
    hydrogen_temperature_coefficient_per_k=COOLANT_PER_K,
    drum_coefficient_per_deg=DRUM_PER_DEG,
    enrichment_coefficient_per_wt_percent=ENRICHMENT_PER_WT,
    reflector_temperature_coefficient_per_k=REFLECTOR_PER_K,
    coolant_density_coefficient_per_kg_m3=DENSITY_PER_KGM3,
    poison_absorption_coefficient_per_cm_inv=POISON_PER_CM,
    reference_fuel_temperature_k=293.6,
    reference_hydrogen_temperature_k=293.6,
)

STATE = CoreState(fuel_temperature_k=1200.0, hydrogen_temperature_k=900.0,
                  reflector_temperature_k=500.0, drum_angle_deg=0.0,
                  enrichment_wt_percent=5.0)


def _report(label: str, ok: bool, detail: str) -> bool:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label:<56} {detail}")
    return ok


def main() -> int:
    results: list[bool] = []
    backend = MockTransportBackend(coefficients=COEFFS, element_count=7,
                                   radial_peaking=1.30,
                                   shape_temperature_sensitivity_per_k=0.0,
                                   k_uncertainty=1e-4)

    # ---- exact recovery of the known derivative -----------------------
    print("central difference recovers the exactly-known derivative:")
    doppler = fuel_temperature_coefficient(backend, STATE)
    print(f"    {doppler.describe()}")
    relative = abs(doppler.value_per_unit - DOPPLER_PER_K) / abs(DOPPLER_PER_K)
    results.append(_report("Doppler coefficient is exact",
                           relative < EXACT_TOL,
                           f"measured {doppler.value_per_unit:.12e} vs true "
                           f"{DOPPLER_PER_K:.1e} (rel {relative:.1e})"))

    coolant = coolant_temperature_coefficient(backend, STATE)
    print(f"    {coolant.describe()}")
    relative = abs(coolant.value_per_unit - COOLANT_PER_K) / abs(COOLANT_PER_K)
    results.append(_report("coolant coefficient is exact",
                           relative < EXACT_TOL,
                           f"rel {relative:.1e}"))

    reflector = reflector_temperature_coefficient(backend, STATE)
    print(f"    {reflector.describe()}")
    relative = abs(reflector.value_per_unit - REFLECTOR_PER_K) / abs(REFLECTOR_PER_K)
    results.append(_report("reflector coefficient is exact",
                           relative < EXACT_TOL, f"rel {relative:.1e}"))

    drum = drum_worth_gradient(backend, STATE)
    print(f"    {drum.describe()}")
    relative = abs(drum.value_per_unit - DRUM_PER_DEG) / abs(DRUM_PER_DEG)
    results.append(_report("drum gradient is exact", relative < EXACT_TOL,
                           f"rel {relative:.1e}"))

    enrichment = enrichment_worth(backend, STATE)
    print(f"    {enrichment.describe()}")
    relative = (abs(enrichment.value_per_unit - ENRICHMENT_PER_WT)
                / abs(ENRICHMENT_PER_WT))
    results.append(_report("enrichment worth is exact", relative < EXACT_TOL,
                           f"rel {relative:.1e}"))

    # ---- safety-relevant signs ----------------------------------------
    print("\ncoefficient signs (negative means self-limiting):")
    for name, result in (("Doppler", doppler), ("coolant", coolant),
                         ("reflector", reflector)):
        results.append(_report(f"{name} coefficient is negative",
                               result.is_negative,
                               f"{result.pcm_per_unit:+.3f} pcm/K"))
    results.append(_report("drum worth is positive (positive control)",
                           drum.value_per_unit > 0.0,
                           f"{drum.pcm_per_unit:+.2f} pcm/deg"))
    results.append(_report("enrichment worth is positive",
                           enrichment.value_per_unit > 0.0,
                           f"{enrichment.pcm_per_unit:+.1f} pcm/wt%"))

    # ---- units ---------------------------------------------------------
    print("\nunits and conversions:")
    results.append(_report("1 pcm is 1e-5 in dk/k",
                           abs(PCM - 1.0e-5) < 1e-20, f"{PCM}"))
    results.append(_report("to_pcm / from_pcm round-trips",
                           abs(from_pcm(to_pcm(0.0123)) - 0.0123) < 1e-18,
                           "0.0123 dk/k <-> 1230 pcm"))
    results.append(_report("Doppler in pcm/K matches the value",
                           abs(doppler.pcm_per_unit - DOPPLER_PER_K / PCM) < 1e-9,
                           f"{doppler.pcm_per_unit:+.4f} pcm/K"))

    # ---- perturbation independence ------------------------------------
    print("\nresult is independent of the perturbation size (linear response):")
    for perturbation in (5.0, 25.0, 100.0):
        probe = fuel_temperature_coefficient(backend, STATE, perturbation_k=perturbation)
        print(f"    dT={perturbation:6.1f} K -> {probe.pcm_per_unit:+.6f} pcm/K")
        results.append(_report(f"dT={perturbation:g} K gives the same slope",
                               abs(probe.value_per_unit - DOPPLER_PER_K)
                               / abs(DOPPLER_PER_K) < EXACT_TOL, "exact"))

    # ---- additivity and the temperature defect ------------------------
    print("\ncoefficients add up to the temperature defect:")
    cold_state = CoreState(fuel_temperature_k=293.6, hydrogen_temperature_k=293.6,
                           reflector_temperature_k=293.6, drum_angle_deg=0.0,
                           enrichment_wt_percent=5.0)
    hot_state = STATE
    defect = temperature_defect(backend, cold_state, hot_state)
    print(f"    k_cold={defect.k_cold:.9f}  k_hot={defect.k_hot:.9f}  "
          f"defect={defect.pcm:+.2f} pcm")
    predicted = (DOPPLER_PER_K * (hot_state.fuel_temperature_k
                                  - cold_state.fuel_temperature_k)
                 + COOLANT_PER_K * (hot_state.hydrogen_temperature_k
                                    - cold_state.hydrogen_temperature_k)
                 + REFLECTOR_PER_K * (hot_state.reflector_temperature_k
                                      - cold_state.reflector_temperature_k))
    # alpha = dk/dT, so integrating gives k_hot - k_cold; the defect is defined
    # the other way round (k_cold - k_hot), hence the sign flip.
    predicted_defect = -predicted
    discrepancy = abs(defect.defect - predicted_defect)
    results.append(_report("defect equals the summed contributions",
                           discrepancy < 1e-15,
                           f"measured {defect.defect:.12e} vs predicted "
                           f"{predicted_defect:.12e}"))
    results.append(_report("hot core is less reactive than cold",
                           defect.defect > 0.0, f"{defect.pcm:+.2f} pcm"))

    # ---- void / coolant density coefficient ---------------------------
    print("\nvoid (coolant density) coefficient:")
    dense_state = STATE.with_changes(coolant_density_kg_m3=2.0)
    void = void_coefficient(backend, dense_state)
    print(f"    {void.describe()}")
    relative = abs(void.value_per_unit - DENSITY_PER_KGM3) / abs(DENSITY_PER_KGM3)
    results.append(_report("void coefficient is exact", relative < EXACT_TOL,
                           f"rel {relative:.1e}"))
    results.append(_report("void coefficient is positive (denser H2 adds reactivity)",
                           void.value_per_unit > 0.0,
                           f"{void.pcm_per_unit:+.3f} pcm per kg/m3"))
    liquid = void_coefficient(backend, STATE.with_changes(
        coolant_density_kg_m3=71.0), perturbation_kg_m3=7.1)
    gas = void_coefficient(backend, STATE.with_changes(
        coolant_density_kg_m3=0.5), perturbation_kg_m3=0.05)
    print(f"    liquid (71 kg/m3): {liquid.pcm_per_unit:+.3f} pcm per kg/m3")
    print(f"    gas    (0.5 kg/m3): {gas.pcm_per_unit:+.3f} pcm per kg/m3")
    results.append(_report("liquid and gas densities give the same slope",
                           abs(liquid.value_per_unit - gas.value_per_unit)
                           / abs(DENSITY_PER_KGM3) < EXACT_TOL,
                           "response is linear in density"))
    try:
        void_coefficient(backend, STATE)
    except CoefficientError:
        results.append(True)
        print("  [PASS] refused when the state carries no coolant density")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED a state without a coolant density")

    # ---- poison worth --------------------------------------------------
    print("\nfission-product poison worth:")
    poisoned = STATE.with_changes(poison_absorption_cm_inv=1.0e-3)
    poison = poison_worth(backend, poisoned)
    print(f"    {poison.describe()}")
    relative = abs(poison.value_per_unit - POISON_PER_CM) / abs(POISON_PER_CM)
    results.append(_report("poison worth is exact", relative < EXACT_TOL,
                           f"rel {relative:.1e}"))
    results.append(_report("poison worth is negative (an absorber)",
                           poison.value_per_unit < 0.0,
                           f"{poison.pcm_per_unit:+.3e} pcm per 1/cm"))
    try:
        poison_worth(backend, STATE)
    except CoefficientError:
        results.append(True)
        print("  [PASS] refused when the state carries no poison loading")
    else:
        results.append(False)
        print("  [FAIL] ACCEPTED a state without poison loading")

    # ---- power coefficient --------------------------------------------
    print("\npower coefficient assembled from the parts:")
    power = power_coefficient(doppler, coolant,
                              dT_fuel_per_watt=2.0e-7,
                              dT_coolant_per_watt=1.0e-7)
    print(f"    doppler part  {power.doppler_per_watt:+.4e} /W")
    print(f"    coolant part  {power.coolant_per_watt:+.4e} /W")
    print(f"    total         {power.pcm_per_mw:+.2f} pcm/MW")
    expected = (DOPPLER_PER_K * 2.0e-7) + (COOLANT_PER_K * 1.0e-7)
    results.append(_report("power coefficient equals the sum of parts",
                           abs(power.value_per_watt - expected) < 1e-20,
                           f"{power.value_per_watt:.6e} /W"))
    results.append(_report("total power coefficient is negative",
                           power.is_negative, f"{power.pcm_per_mw:+.2f} pcm/MW"))
    results.append(_report("parts decompose the total",
                           abs((power.doppler_per_watt + power.coolant_per_watt)
                               - power.value_per_watt) < 1e-24,
                           "doppler + coolant = total"))

    # ---- uncertainty propagation --------------------------------------
    print("\nuncertainty is propagated from the two eigenvalue sigmas:")
    noisy = MockTransportBackend(coefficients=COEFFS, k_uncertainty=2.0e-3)
    probe = fuel_temperature_coefficient(noisy, STATE, perturbation_k=25.0)
    expected_sigma = math.hypot(2.0e-3, 2.0e-3) / (2.0 * 25.0)
    results.append(_report("sigma matches sqrt(s+^2+s-^2)/(2*dT)",
                           abs(probe.uncertainty_per_unit - expected_sigma) < 1e-18,
                           f"{probe.pcm_uncertainty:.4f} pcm/K"))
    tighter = fuel_temperature_coefficient(noisy, STATE, perturbation_k=100.0)
    results.append(_report("a larger perturbation reduces the sigma",
                           tighter.pcm_uncertainty < probe.pcm_uncertainty,
                           f"{probe.pcm_uncertainty:.4f} -> "
                           f"{tighter.pcm_uncertainty:.4f} pcm/K"))
    results.append(_report("the measured slope stays exact despite noise",
                           abs(tighter.value_per_unit - DOPPLER_PER_K)
                           / abs(DOPPLER_PER_K) < EXACT_TOL, "exact"))

    # ---- guards --------------------------------------------------------
    print("\ninvalid perturbations are rejected:")
    guards = [
        ("zero perturbation",
         lambda: fuel_temperature_coefficient(backend, STATE, perturbation_k=0.0)),
        ("negative perturbation",
         lambda: fuel_temperature_coefficient(backend, STATE, perturbation_k=-5.0)),
        ("perturbation drives temperature negative",
         lambda: fuel_temperature_coefficient(
             backend, CoreState(fuel_temperature_k=10.0,
                                hydrogen_temperature_k=900.0),
             perturbation_k=25.0)),
        ("non-finite thermal scaling",
         lambda: power_coefficient(doppler, coolant,
                                   dT_fuel_per_watt=float("nan"),
                                   dT_coolant_per_watt=0.0)),
    ]
    for label, fn in guards:
        try:
            fn()
        except (CoefficientError, ValueError):
            results.append(True)
            print(f"  [PASS] rejected {label}")
        else:
            results.append(False)
            print(f"  [FAIL] ACCEPTED {label}")

    failed = results.count(False)
    print(f"\n{len(results) - failed}/{len(results)} checks passed")
    if failed:
        return 1
    print("PASS: reactivity coefficients are measured correctly and propagate "
          "uncertainty")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
