"""Verify the declared NERVA baseline and its cross-check.

The point of these checks is that the baseline machinery must be able to say
NO. A comparison framework that can only ever report agreement is decoration,
so several checks below construct a deliberately wrong comparison and assert it
is reported as a disagreement.

Run: python -m ntr.nerva.validate_baseline
"""

from __future__ import annotations

import json
import math
from dataclasses import replace
from pathlib import Path

from .baseline import (
    DECLARED_BASELINE,
    BaselineComparison,
    BaselineComparison,
    baseline_report,
)
from .historical_presets import PRESETS, XE_PRIME

PASSED = 0
FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASSED
    if condition:
        PASSED += 1
    else:
        FAILED.append(f"{name}: {detail}")


def _registry_entries() -> dict[str, float]:
    path = Path(__file__).parent / "heritage" / "data" / "emrich2023_nerva.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {e["name"]: e["value"] for e in payload["entries"]}


def _registry_units() -> dict[str, str]:
    path = Path(__file__).parent / "heritage" / "data" / "emrich2023_nerva.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {e["name"]: e.get("unit", "") for e in payload["entries"]}


def main() -> int:
    entries = _registry_entries()
    baseline = DECLARED_BASELINE

    # --- the declaration itself -------------------------------------------
    check("baseline has a key", bool(baseline.key), "empty key")
    check("baseline key resolves to a real preset",
          baseline.key in PRESETS, f"{baseline.key} not in {sorted(PRESETS)}")
    check("declared preset is the one held",
          baseline.preset is PRESETS[baseline.key], "preset identity differs")
    check("baseline names an engine designation",
          "XE0" in baseline.engine_designation, baseline.engine_designation)
    check("baseline cites a primary source",
          bool(baseline.source_title) and bool(baseline.source_url),
          "missing source title or url")
    check("baseline states why this engine",
          len(baseline.rationale) > 100, "rationale too thin to be a decision record")
    check("baseline names what it is cross-checked against",
          "Table III.1" in baseline.cross_checked_against,
          baseline.cross_checked_against)

    # --- the comparisons ---------------------------------------------------
    comps = baseline.comparisons()
    check("four quantities are compared", len(comps) == 4, f"got {len(comps)}")
    check("all comparisons agree with measurement", baseline.all_agree,
          "; ".join(c.describe() for c in comps if not c.agrees))

    for c in comps:
        check(f"tolerance declared for {c.quantity}", c.tolerance > 0.0,
              f"tolerance {c.tolerance}")
        check(f"tolerance is a judgement, not a rubber stamp ({c.quantity})",
              c.tolerance <= 0.10, f"{c.tolerance} is too loose to mean anything")
        check(f"measured source is cited for {c.quantity}",
              "emrich2023 p.413" in c.measured_source, c.measured_source)
        check(f"station is named for {c.quantity}",
              bool(c.station), "no station")

    # --- the comparisons must trace to the heritage registry ---------------
    # If these drift apart, the module is asserting numbers no source backs.
    measured_checks = {
        "thermal power": ("xe0.reactor_power", "MW", 1.0),
        "chamber temperature": ("xe0.nozzle_chamber_temperature", "K", 1.0),
        "chamber pressure": ("xe0.nozzle_chamber_pressure", "MPa", 1.0),
        "thrust flow": ("xe0.thrust_flow", "kg/s", 1.0),
    }
    units = _registry_units()
    for c in comps:
        key, unit, scale = measured_checks[c.quantity]
        check(f"{c.quantity} measured value matches the cited registry entry",
              key in entries and math.isclose(c.measured_value,
                                             entries[key] / scale, rel_tol=1e-12),
              f"registry {entries.get(key)} vs module {c.measured_value}")
        check(f"{c.quantity} is compared in the unit the source printed",
              units.get(key) == unit and c.unit == unit,
              f"registry {units.get(key)!r}, module {c.unit!r}, expected {unit!r}")

    # --- the 12% trap ------------------------------------------------------
    # The preset flow must be compared to the thrust flow (31.98 kg/s), not to
    # the tank outlet (36.15 kg/s). Using the tank outlet would report a 12%
    # disagreement that is purely a station-definition error.
    flow = next(c for c in comps if c.quantity == "thrust flow")
    check("flow is compared against thrust flow, not tank outlet",
          math.isclose(flow.measured_value, 31.98), f"{flow.measured_value}")
    if "xe0.total_flow" in entries:
        wrong = BaselineComparison(
            quantity="thrust flow (WRONG STATION)", preset_value=flow.preset_value,
            measured_value=entries["xe0.total_flow"], unit="kg/s",
            tolerance=flow.tolerance, station="tank outlet",
            measured_source=flow.measured_source)
        check("comparing to tank outlet really would fail",
              not wrong.agrees,
              "the station trap does not actually change the verdict; "
              "either the data or this test is wrong")
        print(f"NOTE: comparing against the tank outlet ({entries['xe0.total_flow']} kg/s) "
              f"would report {wrong.relative_error * 100:+.1f}% -- this is why the "
              f"station matters.")

    # --- the machinery must be able to say NO ------------------------------
    bad = replace(flow, preset_value=flow.measured_value * 1.30)
    check("an out-of-tolerance comparison is reported as disagreeing",
          not bad.agrees, "a 30% error was accepted")
    check("the disagreement text is not silent",
          "DISAGREES" in bad.describe(), bad.describe())

    perfect = replace(flow, preset_value=flow.measured_value)
    check("an exact comparison agrees with zero error",
          perfect.agrees and abs(perfect.relative_error) < 1e-15,
          f"{perfect.relative_error}")

    # A baseline whose cross-check fails must not be usable as evidence.
    from .acceptance_gates import Evidence, _probe_baseline
    ev = Evidence()
    _probe_baseline(ev)
    check("gate probe accepts the real baseline", ev.baseline_declared,
          ev.baseline_variant)
    check("gate probe records the cross-check in its message",
          "cross-checked" in ev.baseline_variant, ev.baseline_variant)

    # --- report ------------------------------------------------------------
    text = baseline_report()
    check("report names the engine", "XE0" in text, "no engine designation")
    check("report shows each comparison", text.count("[ok]") == 4,
          f"{text.count('[ok]')} ok lines")
    check("report states the worst error",
          "worst relative error" in text, "no worst-case figure")

    print(f"\nBaseline: {baseline.name} / {baseline.engine_designation}")
    print(f"  cross-checked against {baseline.cross_checked_against}")
    print(f"  worst relative error {baseline.worst_relative_error * 100:.3f}%")
    print(f"  preset flow {XE_PRIME.hydrogen_mass_flow_kg_s:.4f} kg/s compared to "
          f"thrust flow {flow.measured_value} kg/s")

    total = PASSED + len(FAILED)
    if FAILED:
        print(f"\nFAILED {len(FAILED)} of {total} checks:")
        for f in FAILED:
            print(f"  - {f}")
        return 1
    print(f"\nPASS: {PASSED}/{total} checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
