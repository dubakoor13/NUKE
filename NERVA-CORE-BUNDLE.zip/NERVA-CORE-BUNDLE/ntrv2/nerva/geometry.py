"""OpenMC geometry construction for the NERVA-derived model."""

from __future__ import annotations

import openmc

from .config import NervaConfig
from .layout import axial_hex_coordinates, coolant_channel_positions, is_tie_tube_site, mixed_core_counts


def build_fuel_element_universe(
    config: NervaConfig,
    materials: dict[str, openmc.Material],
) -> openmc.Universe:
    """Build one hexagonal fuel element with 19 coated coolant channels."""
    inner_hex = openmc.model.HexagonalPrism(
        edge_length=config.inner_fuel_edge_length_cm,
        orientation="y",
        boundary_type="transmission",
    )
    outer_hex = openmc.model.HexagonalPrism(
        edge_length=config.fuel_edge_length_cm,
        orientation="y",
        boundary_type="transmission",
    )

    positions = coolant_channel_positions(config)
    outer_cylinders = []
    cells = []
    for index, (x, y) in enumerate(positions, start=1):
        inner = openmc.ZCylinder(
            x0=x,
            y0=y,
            r=config.channel_radius_cm,
            name=f"coolant channel {index} inner",
        )
        outer = openmc.ZCylinder(
            x0=x,
            y0=y,
            r=config.coated_channel_radius_cm,
            name=f"coolant channel {index} coating outer",
        )
        outer_cylinders.append(outer)
        cells.extend((
            openmc.Cell(
                name=f"hydrogen channel {index}",
                fill=materials["hydrogen"],
                region=-inner,
            ),
            openmc.Cell(
                name=f"ZrC channel coating {index}",
                fill=materials["zrc"],
                region=+inner & -outer,
            ),
        ))

    fuel_region = -inner_hex
    for outer in outer_cylinders:
        fuel_region &= +outer

    # Partition the fuel matrix into 19 nearest-channel Voronoi sectors.
    # All sectors use the same fuel material and all internal planes are
    # transmission boundaries, so this increases scoring resolution without
    # changing the material layout or adding a physical interface.
    pair_planes: dict[tuple[int, int], openmc.Plane] = {}
    for i in range(len(positions)):
        xi, yi = positions[i]
        for j in range(i + 1, len(positions)):
            xj, yj = positions[j]
            a = xj - xi
            b = yj - yi
            d = 0.5 * (
                xj * xj
                + yj * yj
                - xi * xi
                - yi * yi
            )
            pair_planes[(i, j)] = openmc.Plane(
                a=a,
                b=b,
                c=0.0,
                d=d,
                name=(
                    f"fuel channel Voronoi boundary "
                    f"{i + 1:02d}-{j + 1:02d}"
                ),
            )

    for i in range(len(positions)):
        # Build a fresh Boolean expression for every sector. OpenMC
        # Intersection implements in-place &=, so reusing fuel_region here
        # would mutate the shared base expression and create gaps.
        sector_region = -inner_hex
        for outer in outer_cylinders:
            sector_region &= +outer

        for j in range(len(positions)):
            if i == j:
                continue
            if i < j:
                sector_region &= -pair_planes[(i, j)]
            else:
                sector_region &= +pair_planes[(j, i)]

        cells.append(
            openmc.Cell(
                name=f"fuel matrix channel sector {i + 1:02d}",
                fill=materials["fuel"],
                region=sector_region,
            )
        )
    cells.append(
        openmc.Cell(
            name="outer ZrC coating",
            fill=materials["zrc"],
            # The enclosing HexLattice already clips this universe to its
            # own hexagonal pitch. Re-applying the mathematically coincident
            # outer prism leaves floating-point slivers at the lattice
            # boundary where OpenMC loses neutrons (surfaces 8-12).
            # Fill every point outside the inner fuel hex in this universe.
            region=+inner_hex,
        )
    )
    return openmc.Universe(
        name="NERVA-like 19-channel fuel element",
        cells=cells,
    )


def build_tie_tube_universe(
    config: NervaConfig,
    materials: dict[str, openmc.Material],
) -> openmc.Universe:
    """Build a NERVA-derived coaxial tie/support element.

    The radial stack follows the public NASA tie-tube cross section. Small
    manufacturing/cold-condition gaps are represented as void regions.
    """
    inner_hex = openmc.model.HexagonalPrism(
        edge_length=config.inner_fuel_edge_length_cm,
        orientation="y",
        boundary_type="transmission",
    )
    outer_hex = openmc.model.HexagonalPrism(
        edge_length=config.fuel_edge_length_cm,
        orientation="y",
        boundary_type="transmission",
    )

    supply = openmc.ZCylinder(r=config.tie_inner_tube_inner_radius_cm)
    inner_tube_outer = openmc.ZCylinder(r=config.tie_inner_tube_outer_radius_cm)
    zrh_inner = openmc.ZCylinder(r=config.tie_zrh_inner_radius_cm)
    zrh_outer = openmc.ZCylinder(r=config.tie_zrh_outer_radius_cm)
    outer_tube_inner = openmc.ZCylinder(r=config.tie_outer_tube_inner_radius_cm)
    outer_tube_outer = openmc.ZCylinder(r=config.tie_outer_tube_outer_radius_cm)
    zrc_inner = openmc.ZCylinder(r=config.tie_zrc_inner_radius_cm)
    zrc_outer = openmc.ZCylinder(r=config.tie_zrc_outer_radius_cm)
    graphite_inner = openmc.ZCylinder(r=config.tie_graphite_inner_radius_cm)

    cells = [
        openmc.Cell(
            name="tie-tube hydrogen supply",
            fill=materials["hydrogen"],
            region=-supply,
        ),
        openmc.Cell(
            name="tie-tube inner Inconel tube",
            fill=materials["inconel"],
            region=+supply & -inner_tube_outer,
        ),
        openmc.Cell(
            name="tie-tube inner cold gap",
            region=+inner_tube_outer & -zrh_inner,
        ),
        openmc.Cell(
            name="tie-tube ZrH moderator",
            fill=materials["zrh"],
            region=+zrh_inner & -zrh_outer,
        ),
        openmc.Cell(
            name="tie-tube hydrogen return",
            fill=materials["hydrogen"],
            region=+zrh_outer & -outer_tube_inner,
        ),
        openmc.Cell(
            name="tie-tube outer Inconel tube",
            fill=materials["inconel"],
            region=+outer_tube_inner & -outer_tube_outer,
        ),
        openmc.Cell(
            name="tie-tube outer cold gap",
            region=+outer_tube_outer & -zrc_inner,
        ),
        openmc.Cell(
            name="tie-tube ZrC sleeve",
            fill=materials["zrc"],
            region=+zrc_inner & -zrc_outer,
        ),
        openmc.Cell(
            name="tie-tube liner-to-graphite gap",
            region=+zrc_outer & -graphite_inner,
        ),
        openmc.Cell(
            name="tie-tube graphite filler",
            fill=materials["graphite"],
            region=+graphite_inner & -inner_hex,
        ),
        openmc.Cell(
            name="tie-tube outer ZrC coating",
            fill=materials["zrc"],
            # The enclosing HexLattice already clips this universe to its
            # own hexagonal pitch. Re-applying the mathematically coincident
            # outer prism leaves floating-point slivers at the lattice
            # boundary where OpenMC loses neutrons (surfaces 8-12).
            # Fill every point outside the inner fuel hex in this universe.
            region=+inner_hex,
        ),
    ]

    return openmc.Universe(
        name="NERVA-like coaxial tie/support element",
        cells=cells,
    )


def _finite_lattice_geometry(
    config: NervaConfig,
    lattice: openmc.HexLattice,
    core_radius_cm: float,
    outer_radius_cm: float,
    materials: dict[str, openmc.Material],
    name: str,
) -> openmc.Geometry:
    half_length = 0.5 * config.active_length_cm
    zmin = openmc.ZPlane(z0=-half_length, boundary_type="vacuum")
    zmax = openmc.ZPlane(z0=half_length, boundary_type="vacuum")
    core_cylinder = openmc.ZCylinder(r=core_radius_cm)
    outer_cylinder = openmc.ZCylinder(
        r=outer_radius_cm,
        boundary_type="vacuum",
    )
    axial_region = +zmin & -zmax

    lattice_cell = openmc.Cell(
        name=name,
        fill=lattice,
        region=-core_cylinder & axial_region,
    )
    reflector_cell = openmc.Cell(
        name="beryllium radial reflector",
        fill=materials["reflector"],
        region=+core_cylinder & -outer_cylinder & axial_region,
    )

    root = openmc.Universe(cells=[lattice_cell, reflector_cell])
    return openmc.Geometry(root)


def build_cluster_geometry(
    config: NervaConfig,
    materials: dict[str, openmc.Material],
) -> openmc.Geometry:
    """Build the seven-position cluster: six fuel elements around one tie tube."""
    fuel_universe = build_fuel_element_universe(config, materials)
    tie_universe = build_tie_tube_universe(config, materials)

    filler_universe = openmc.Universe(
        name="cluster outer filler universe",
        cells=[
            openmc.Cell(
                name="cluster outer filler",
                fill=materials["reflector"],
            )
        ],
    )

    lattice = openmc.HexLattice(name="six-fuel one-tie cluster")
    lattice.center = (0.0, 0.0)
    lattice.pitch = (config.fuel_flat_to_flat_cm,)
    lattice.orientation = "y"
    lattice.universes = [
        [fuel_universe] * 6,
        [tie_universe],
    ]
    lattice.outer = filler_universe

    return _finite_lattice_geometry(
        config=config,
        lattice=lattice,
        core_radius_cm=config.cluster_radius_cm,
        outer_radius_cm=config.cluster_reflector_outer_radius_cm,
        materials=materials,
        name="finite six-fuel one-tie cluster",
    )



def build_mixed_core_geometry(
    config: NervaConfig,
    materials: dict[str, openmc.Material],
) -> openmc.Geometry:
    """Build an SNRE-style mixed fuel/tie-tube lattice.

    A three-color triangular-lattice pattern assigns one color to tie tubes and
    the other two to fuel. Interior tie tubes therefore have six fuel
    neighbors, while interior fuel elements have three tie-tube neighbors.
    """
    fuel_universe = build_fuel_element_universe(config, materials)
    tie_universe = build_tie_tube_universe(config, materials)

    filler_universe = openmc.Universe(
        name="mixed-core outer filler universe",
        cells=[
            openmc.Cell(
                name="mixed-core outer filler",
                fill=materials["reflector"],
            )
        ],
    )

    lattice = openmc.HexLattice(name="SNRE-style mixed fuel tie-tube lattice")
    lattice.center = (0.0, 0.0)
    lattice.pitch = (config.fuel_flat_to_flat_cm,)
    lattice.orientation = "y"

    rings = []
    for ring_index in range(config.core_rings - 1, 0, -1):
        rings.append([fuel_universe] * (6 * ring_index))
    rings.append([fuel_universe])
    lattice.universes = rings

    for index in axial_hex_coordinates(config.core_rings - 1):
        ring_index, within_index = lattice.get_universe_index(index)
        if is_tie_tube_site(index):
            rings[ring_index][within_index] = tie_universe

    lattice.universes = rings
    lattice.outer = filler_universe

    return _finite_lattice_geometry(
        config=config,
        lattice=lattice,
        core_radius_cm=config.core_radius_cm,
        outer_radius_cm=config.reflector_outer_radius_cm,
        materials=materials,
        name="finite SNRE-style mixed core",
    )

def build_core_geometry(
    config: NervaConfig,
    materials: dict[str, openmc.Material],
) -> openmc.Geometry:
    """Build the original small all-fuel demonstrator surrounded by Be."""
    fuel_universe = build_fuel_element_universe(config, materials)

    filler_cell = openmc.Cell(
        name="outer lattice filler",
        fill=materials["reflector"],
    )
    filler_universe = openmc.Universe(
        name="outer lattice filler universe",
        cells=[filler_cell],
    )

    lattice = openmc.HexLattice(name="NERVA-like fuel lattice")
    lattice.center = (0.0, 0.0)
    lattice.pitch = (config.fuel_flat_to_flat_cm,)
    lattice.orientation = "y"

    rings = []
    for ring_index in range(config.core_rings - 1, 0, -1):
        rings.append([fuel_universe] * (6 * ring_index))
    rings.append([fuel_universe])
    lattice.universes = rings
    lattice.outer = filler_universe

    return _finite_lattice_geometry(
        config=config,
        lattice=lattice,
        core_radius_cm=config.core_radius_cm,
        outer_radius_cm=config.reflector_outer_radius_cm,
        materials=materials,
        name="finite NERVA-like all-fuel core",
    )


def cluster_summary(config: NervaConfig) -> dict[str, float | int]:
    return {
        "fuel_elements": 6,
        "tie_tubes": 1,
        "fuel_coolant_channels": 6 * 19,
        "tie_tube_hydrogen_passages": 2,
        "active_length_cm": config.active_length_cm,
        "cluster_radius_cm": config.cluster_radius_cm,
        "reflector_outer_radius_cm": config.cluster_reflector_outer_radius_cm,
    }



def mixed_core_summary(config: NervaConfig) -> dict[str, float | int]:
    fuel_elements, tie_tubes = mixed_core_counts(config.core_rings)
    return {
        "fuel_elements": fuel_elements,
        "tie_tubes": tie_tubes,
        "fuel_coolant_channels": 19 * fuel_elements,
        "tie_tube_hydrogen_passages": 2 * tie_tubes,
        "active_length_cm": config.active_length_cm,
        "core_radius_cm": config.core_radius_cm,
        "reflector_outer_radius_cm": config.reflector_outer_radius_cm,
    }

def geometry_summary(config: NervaConfig) -> dict[str, float | int]:
    n_elements = 1 + 3 * config.core_rings * (config.core_rings - 1)
    return {
        "fuel_elements": n_elements,
        "tie_tubes": 0,
        "coolant_channels_per_element": 19,
        "total_coolant_channels": 19 * n_elements,
        "active_length_cm": config.active_length_cm,
        "core_radius_cm": config.core_radius_cm,
        "reflector_outer_radius_cm": config.reflector_outer_radius_cm,
    }
