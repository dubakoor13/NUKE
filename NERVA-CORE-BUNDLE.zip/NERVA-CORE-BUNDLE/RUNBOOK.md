# NERVA core bundle — verification runbook

Everything here runs **offline**. No nuclear data, no OpenMC executable, no
network is required for the suite that ships with this bundle.

## 1. Check the environment

```powershell
$env:PYTHONPATH = "<bundle root>"
python -m ntr.nerva.doctor
```

Expect `numpy`, `h5py`, `pandas`, heritage datasets and theory suites READY.
`CoolProp`, `openmc executable`, `evaluated cross sections`, `openmc.deplete`
will be MISSING on a bare machine. That is expected: those gate only the
capabilities named next to them, not the offline suite.

## 2. Run the full verification suite

```powershell
pwsh -File run_suite.ps1
```

Expected on a clean machine: **36/36 suites, 934 checks**.

If temporary-directory creation fails with `PermissionError: [WinError 5]`,
that is the ACL trap, not a code defect. Point the suite at a plain directory:

```powershell
pwsh -File run_suite.ps1 -Temp D:\tmp\nerva-acl
```

`audit\run_with_temp.py` contains the underlying fix (forcing `0o777`/`0o666`
on `os.mkdir`/`os.open`, since `tempfile` requests owner-only modes that some
sandboxes refuse).

## 3. Check the acceptance gates

```powershell
python -m ntr.nerva.acceptance_gates
```

Expected offline: **3/8 gates met, 3 partial, 2 not met.**

Gates 2 (neutronics evidence) and 7 (historical validation) cannot be earned
without a real transport run. Gates 3, 4, 5 are partial because their inputs are
synthetic — the closure maths is verified, but closed-on-synthetic-inputs is not
validation, and the gate says so rather than rounding up.

## 4. Read the declared baseline

```powershell
python -m ntr.nerva.baseline
```

This prints the one engine everything is measured against (XE-Prime / XE0) and
its cross-check against the full-power test data. Exit code is 1 if the
cross-check ever fails.

## 5. What to do first on a machine with real OpenMC

In this order:

1. `python -m ntr.nerva.doctor` — confirm the transport backend goes READY.
2. Swap `MockTransportBackend` for `OpenMCTransportBackend` in
   `coupled_core.solve_coupled_core` and re-run the P = 9.82 MW case.
3. Re-run `acceptance_gates`; gates 2 and 7 should move.

Step 2 is the single highest-value substitution in the whole package: it
converts the feedback coefficients from *self-consistent* to *measured against
transport*, which is the largest remaining unknown.

## Environment notes

- Tested on CPython 3.14.6 (stdlib + numpy/scipy/h5py/pandas).
- Minimum is Python 3.11 (the code uses `X | Y` unions and PEP 604 syntax).
- `CoolProp` is optional and only reachable through `property_providers`;
  without it that provider reports unavailable rather than inventing hydrogen
  properties.
- On Windows, use the `py` launcher if `python` is not on PATH.
