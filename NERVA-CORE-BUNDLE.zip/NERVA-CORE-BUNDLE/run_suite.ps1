<#
.SYNOPSIS
    Run every NERVA verification suite from this bundle.

.DESCRIPTION
    Works regardless of where the bundle is unpacked, because it derives the
    package root from its own location. Under the DSH file sandbox (or any
    constrained environment) temporary directories must be created permissively;
    the -Temp switch handles that.

    Exit code is 0 only when every suite passes.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File run_suite.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File run_suite.ps1 -Temp D:\tmp\acltest

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File run_suite.ps1 -PythonExe C:\Python314\python.exe
#>
param(
    [string]$PythonExe = "",
    [string]$Temp = ""
)

$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PYTHONPATH = $root
$env:PYTHONDONTWRITEBYTECODE = "1"
$env:PYTHONIOENCODING = "utf-8"

if ($Temp -ne "") {
    New-Item -ItemType Directory -Force -Path $Temp | Out-Null
    $env:TEMP = $Temp
    $env:TMP = $Temp
}

if ($PythonExe -eq "") {
    $candidates = @("python", "python3", "py")
    foreach ($c in $candidates) {
        $found = Get-Command $c -ErrorAction SilentlyContinue
        if ($found) { $PythonExe = $found.Source; break }
    }
}
if ($PythonExe -eq "") {
    Write-Host "No Python interpreter found. Pass -Python <path>."
    exit 2
}

Write-Host "interpreter : $PythonExe"
Write-Host "bundle root : $root"
Write-Host ("temp        : " + $env:TEMP)
Write-Host ""

# ORDERING MATTERS. validate_acceptance_gates is an aggregator: gates 6 and 8
# read evidence records that validate_numerical_independence and
# validate_determinism WRITE into .\build\. On a cold checkout those records do
# not exist yet, so running the aggregator first makes it fail for a reason that
# has nothing to do with the code. It therefore runs last.
$suites = @(
    "validate_heritage_registry", "validate_heritage_turbomachinery",
    "validate_heritage_kinetics", "validate_heritage_cycles",
    "validate_property_providers", "validate_thermochemistry",
    "validate_nozzle_closure", "validate_cea_oracle",
    "validate_transport_backend", "validate_coupled_core",
    "validate_cycle_closure", "validate_depletion_driver",
    "validate_numerical_independence", "validate_determinism",
    "validate_reactivity_coefficients",
    "validate_control_worth", "validate_kinetics_transient",
    "validate_core_metrics", "validate_spatial_core",
    "validate_delayed_parameters", "validate_startup",
    "validate_fission_product_poisoning", "validate_core_stability",
    "validate_core_life", "validate_shielding_control",
    "validate_flow_stability", "validate_diffusion",
    "validate_decay", "validate_diffusion_backend",
    "validate_material_properties", "validate_xenon_spatial",
    "validate_adjoint", "validate_diffusion_2d",
    "validate_baseline", "validate_historical_presets",
    "validate_acceptance_gates"
)

$passed = 0
$total = 0
$checks = 0
$failures = @()

Push-Location $root
foreach ($m in $suites) {
    $out = & $PythonExe -m "ntr.nerva.$m" 2>&1
    $total = $total + 1
    $line = ($out | Select-String -Pattern "(\d+)/(\d+) checks passed" |
             Select-Object -First 1).Line
    if ($line -and $line -match "(\d+)/(\d+)") {
        $checks = $checks + [int]$Matches[1]
    }
    if ($LASTEXITCODE -eq 0) {
        $passed = $passed + 1
    } else {
        $failures = $failures + $m
        Write-Host ("FAIL  " + $m)
    }
}
Pop-Location

Write-Host ""
Write-Host ("RESULT: {0}/{1} suites | {2} checks" -f $passed, $total, $checks)
if ($failures.Count -gt 0) {
    Write-Host ("failing suites: " + ($failures -join ", "))
    exit 1
}
Write-Host "All suites passed."
exit 0
