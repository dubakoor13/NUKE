"""Search the extracted PDF corpus with page citations."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

CORPUS = Path(r"D:\wiyan\CODES\HYBSIM_MK1\NUKE-main\nerva-audit\corpus")


def load(docs: list[str] | None = None):
    for path in sorted(CORPUS.glob("*.jsonl")):
        key = path.stem
        if docs and key not in docs:
            continue
        with path.open(encoding="utf-8") as fh:
            for line in fh:
                rec = json.loads(line)
                flat = re.sub(r"\s+", " ", rec["text"])
                yield rec["doc"], rec["page"], flat


def search(pattern: str, docs=None, context: int = 220, limit: int = 40) -> None:
    rx = re.compile(pattern, re.IGNORECASE)
    hits = 0
    for doc, page, flat in load(docs):
        for match in rx.finditer(flat):
            start = max(0, match.start() - context // 2)
            snippet = flat[start:match.end() + context]
            print(f"\n[{doc} p{page}] {snippet.strip()}")
            hits += 1
            if hits >= limit:
                print(f"\n... (limit {limit} reached)")
                return
    if not hits:
        print("no matches")


def terms(pattern: str, docs=None, limit: int = 60) -> None:
    """Page-level hit counts, cheapest way to find where a topic lives."""
    rx = re.compile(pattern, re.IGNORECASE)
    results = []
    for doc, page, flat in load(docs):
        count = len(rx.findall(flat))
        if count:
            results.append((count, doc, page))
    results.sort(reverse=True)
    print(f"top pages for /{pattern}/ :")
    for count, doc, page in results[:limit]:
        print(f"  {count:3}x  {doc} p{page}")


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "search":
        search(sys.argv[2], limit=int(sys.argv[3]) if len(sys.argv) > 3 else 40)
    elif mode == "terms":
        terms(sys.argv[2])
