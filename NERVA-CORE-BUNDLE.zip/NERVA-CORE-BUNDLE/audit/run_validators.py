"""Execute nerva validator modules as subprocesses; classify outcomes.

Pass A runs on a Python that has openmc/pandas/h5py (no CoolProp).
Pass B retries CoolProp-blocked modules on an interpreter that has CoolProp.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"D:\wiyan\CODES\HYBSIM_MK1\NUKE-main\NUKE-main")
WORK = Path(r"D:\wiyan\CODES\HYBSIM_MK1\.dsh-tmp\nerva-audit\work")
TEMPDIR = Path(r"D:\wiyan\CODES\HYBSIM_MK1\NUKE-main\.nerva-audit-tmp")

MISSING = re.compile(r"ModuleNotFoundError: No module named '([^']+)'")
FILEMISS = re.compile(r"FileNotFoundError|No such file or directory")
DATAMISS = re.compile(
    r"OPENMC_CROSS_SECTIONS|cross_sections\.xml|Could not find any cross section|"
    r"no .*xml file found|Nuclear data|no statepoint",
    re.IGNORECASE,
)


def classify(rc: int, out: str) -> tuple[str, str]:
    """Return (verdict, detail) for one run."""
    if rc == 0:
        return "PASS", ""
    match = MISSING.search(out)
    if match:
        return "BLOCKED_DEP", match.group(1)
    if DATAMISS.search(out):
        return "BLOCKED_DATA", "needs nuclear data / statepoint"
    if FILEMISS.search(out):
        return "BLOCKED_ARTIFACT", "needs an input/build artifact"
    if "AssertionError" in out or "assert" in out:
        return "FAIL_ASSERT", ""
    if "Traceback" in out:
        return "FAIL_ERROR", ""
    return "FAIL_OTHER", ""


def run_one(exe: str, module: str, timeout: int, bootstrap: str | None = None) -> dict:
    cwd = WORK / module
    cwd.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["TEMP"] = str(TEMPDIR)
    env["TMP"] = str(TEMPDIR)
    env.pop("OPENMC_CROSS_SECTIONS", None)
    TEMPDIR.mkdir(parents=True, exist_ok=True)
    target = [exe, bootstrap, f"ntr.nerva.{module}"] if bootstrap else [exe, "-m", f"ntr.nerva.{module}"]
    try:
        proc = subprocess.run(
            target,
            cwd=str(cwd), env=env, capture_output=True, text=True,
            timeout=timeout, errors="replace",
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        verdict, detail = classify(proc.returncode, out)
        tail = [ln for ln in out.strip().splitlines() if ln.strip()][-3:]
        return {
            "module": module, "returncode": proc.returncode,
            "verdict": verdict, "detail": detail, "tail": tail,
        }
    except subprocess.TimeoutExpired:
        return {
            "module": module, "returncode": None,
            "verdict": "TIMEOUT", "detail": f">{timeout}s", "tail": [],
        }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--timeout", type=int, default=180)
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--bootstrap", default=None)
    args = ap.parse_args()

    if args.only:
        modules = args.only
    else:
        modules = sorted(p.stem for p in (ROOT / "ntr" / "nerva").glob("validate_*.py"))

    rows = []
    counts: dict[str, int] = {}
    for i, module in enumerate(modules, 1):
        row = run_one(args.exe, module, args.timeout, args.bootstrap)
        rows.append(row)
        counts[row["verdict"]] = counts.get(row["verdict"], 0) + 1
        print(f"[{i}/{len(modules)}] {row['verdict']:<16} {module}"
              f"{('  <- ' + row['detail']) if row['detail'] else ''}", flush=True)

    Path(args.out).write_text(json.dumps(rows, indent=1), encoding="utf-8")
    print("\n=== TOTALS ===")
    for verdict, count in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {verdict:<18} {count}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
