"""Bootstrap: neutralize tempfile's restrictive modes/perms, then run a nerva
module as __main__.

The DSH sandbox denies (WinError 5) any path whose ACL is owner-only, which is
exactly what tempfile.mkdtemp(0o700) / mkstemp(0o600) / _resetperms produce.
This shim forces permissive modes so scratch files work. It changes no physics
and modifies no repository code.
"""
from __future__ import annotations

import os
import runpy
import sys
import tempfile

_os_mkdir = os.mkdir
_os_open = os.open


def _mkdir(path, mode=0o777, *args, **kwargs):
    return _os_mkdir(path, 0o777, *args, **kwargs)


def _open(path, flags, mode=0o666, *args, **kwargs):
    return _os_open(path, flags, 0o666, *args, **kwargs)


os.mkdir = _mkdir
os.open = _open
if hasattr(tempfile, "_resetperms"):
    tempfile._resetperms = lambda *a, **k: None

module = sys.argv[1]
sys.argv = [module, *sys.argv[2:]]
runpy.run_module(module, run_name="__main__", alter_sys=True)
