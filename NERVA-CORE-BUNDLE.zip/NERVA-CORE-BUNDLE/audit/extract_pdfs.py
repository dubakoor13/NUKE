"""Extract PDF text to a page-indexed JSONL corpus so every value can be cited.

Output records: {"doc": str, "page": int, "text": str}
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pymupdf  # PyMuPDF >= 1.24 exposes pymupdf; fitz is the legacy alias

BASE = Path(r"D:\wiyan\CODES\HYBSIM_MK1\NUKE-main\NUKE-main")
OUT = Path(r"D:\wiyan\CODES\HYBSIM_MK1\NUKE-main\nerve-audit\corpus")

DOCS = {
    "emrich2023": "William J. Emrich Jr. - Principles of Nuclear Rocket Propulsion-Butterworth-Heinemann (2023).pdf",
    "uf-ntp-2009": "NTP_nerva.pdf",
}


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    for key, filename in DOCS.items():
        path = BASE / filename
        if not path.exists():
            print(f"MISSING: {path}")
            continue
        doc = pymupdf.open(path)
        target = OUT / f"{key}.jsonl"
        total = 0
        with target.open("w", encoding="utf-8") as fh:
            for index in range(doc.page_count):
                text = doc[index].get_text()
                total += len(text)
                fh.write(json.dumps({"doc": key, "page": index + 1, "text": text},
                                    ensure_ascii=False) + "\n")
        print(f"{key}: {doc.page_count} pages, {total:,} chars -> {target.name} "
              f"({target.stat().st_size // 1024} KB)")
        doc.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
