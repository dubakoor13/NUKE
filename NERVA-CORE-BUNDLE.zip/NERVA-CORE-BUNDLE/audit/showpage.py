"""Print specific corpus pages for reading.

Usage: python showpage.py emrich2023 16 17 39 40
       python showpage.py uf-ntp-2009 203-217
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

CORPUS = Path(__file__).resolve().parent / "corpus"

LIGATURES = {"\ufb01": "fi", "\ufb02": "fl", "\ufb00": "ff", "\ufb03": "ffi",
             "\ufb04": "ffl", "\u2019": "'", "\u201c": '"', "\u201d": '"',
             "\u2013": "-", "\u2014": "-", "\u2212": "-"}


def clean(text: str) -> str:
    for bad, good in LIGATURES.items():
        text = text.replace(bad, good)
    return re.sub(r"\s+", " ", text).strip()


def parse_pages(parts: list[str]) -> set[int]:
    want: set[int] = set()
    for part in parts:
        if "-" in part:
            lo, hi = part.split("-", 1)
            want.update(range(int(lo), int(hi) + 1))
        else:
            want.add(int(part))
    return want


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    doc = sys.argv[1]
    want = parse_pages(sys.argv[2:])
    width = 2400
    path = CORPUS / f"{doc}.jsonl"
    with path.open(encoding="utf-8") as fh:
        for line in fh:
            rec = json.loads(line)
            if rec["page"] in want:
                print(f"\n===== {doc} p{rec['page']} =====")
                print(clean(rec["text"])[:width])
    return 0


if __name__ == "__main__":
    sys.exit(main())
