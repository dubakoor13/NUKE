# NERVA offline validation audit — reproduced on HYBSIM_MK1

**Date:** 2026-02-19
**Target audited:** `NUKE-main\NUKE-main` — OpenMC `develop` snapshot `68657f2` + `ntr/nerva/` (278 modules, ~56,300 LOC)
**Question answered:** which of the folder's own green-CI claims actually reproduce on this machine, and where exactly does it stop.

---

## Headline

| Claim tested | Result |
|---|---|
| `ntr/nerva` Python API imports | **276 / 277 modules import cleanly** (only `webapp.py` needs `streamlit`). **Zero** import errors, zero syntax defects. |
| `validate_*` suite | **112 / 114 pass** with the right interpreter. |
| `run_*` CLI entry points | **28 / 28** respond to `--help`. |
| OpenMC model export | **4 / 4** configurations produce valid `geometry/materials/settings/tallies/plots.xml`. |
| Actual neutron transport | **impossible here** — no `openmc.exe`, no nuclear data. |

The folder is *far* healthier than its 30–40% self-rating implies about its code. The missing 60–70% is physics and hardware data, **not** broken software.

---

## Environment actually found on this machine

Probing beat guessing — the first three interpreters all looked wrong:

| Interpreter | Packages present | Can run |
|---|---|---|
| `Python 3.14` (`pythoncore-3.14-64`) | numpy, scipy, **pandas, h5py, openmc 0.16.1.dev25, lxml** | everything except CoolProp |
| `Python 3.10` | numpy, scipy, pandas, **CoolProp 6.8.0** | everything using CoolProp |
| `Python 3.12` (base) | numpy, scipy only | little |
| `SSME\mcc\.venv` | numpy 2.5.3, scipy | little |

**There is no single interpreter with both OpenMC and CoolProp.** The suite is split across 3.14 and 3.10, which is why a naive run reports ~42 spurious failures.

Also confirmed absent:

- `openmc.exe` — `shutil.which('openmc')` → `None`; `openmc.run()` raises `FileNotFoundError: [WinError 2]`.
- `OPENMC_CROSS_SECTIONS` — unset; no `cross_sections.xml` anywhere on `C:` or `D:`.
- `cea` (NASA CEA) — absent from every interpreter.
- Shell network — `pypi.org`, `github.com`, `anl.box.com` all fail (`WebException`), so nothing can be installed or downloaded from inside the shell.

---

## Blocking sandbox defect found (and diagnosed)

On the first pass, 42 validators failed with an identical error:

```
PermissionError: [WinError 5] Access is denied:
  'C:\Users\MYHP~1\AppData\Local\Temp\dsh-...\tmpXXXX'
```

**This is not a code defect.** The DSH sandbox denies any path whose ACL is owner-only, and `tempfile` creates scratch paths with exactly those modes: `mkdtemp(0o700)`, `mkstemp(0o600)`, plus `_resetperms` chmod. Every validator that writes a scratch statepoint or provenance file therefore died before running a single equation.

Rewriting only the file modes unlocks it. See `run_with_temp.py` — it forces `os.mkdir`/`os.open` to permissive modes and neutralizes `tempfile._resetperms`. It changes **no** physics and modifies **no** repository code. Applying it turned 42 failures into 0:

| Pass | PASS | BLOCKED_DEP | FAIL_OTHER |
|---|---|---|---|
| no shim | 48 | 22 | 43 |
| with shim | **91** | 22 | 1 |

**This almost certainly also explains the `tdk` test #19 failure documented in the workspace `README.md`.** The note there blames pytest's `tmp_path` fixture generically; the actual cause is the owner-only ACL that `tempfile` applies, and `run_with_temp.py` is the workaround.

---

## Final per-validator result

Reproduce with:

```
python  .\nerva-audit\run_validators.py ^
        --exe  "C:\Users\MY HP\AppData\Local\Python\pythoncore-3.14-64\python.exe" ^
        --bootstrap .\nerva-audit\run_with_temp.py ^
        --out  .\nerva-audit\results.json
```

| Verdict | Count | Meaning |
|---|---|---|
| **PASS** | **112** | executed and all internal assertions held |
| `FAIL_OTHER` | 1 | `validate_analysis_outputs` — requires a positional `analysis_root` argument; not a defect |
| `BLOCKED_DEP` | 1 | `validate_nasa_cea_rocket` — needs the `cea` package, unavailable offline |

Full per-module table: `nerva_validate_audit.csv`.

The 21 CoolProp-dependent validators all pass on 3.10 — including every distributed tie solver, header model, pump shaft, turbine admission, regenerative cooling, two-phase and hot-LH2 case. The physics validators are not the fragile part of this repo.

---

## Model export evidence

Generated with `python -m ntr.nerva.build_model --assembly <cfg> --rings 8`. Every configuration produced a complete, parseable OpenMC input deck:

| Configuration | Cells | Surfaces | Materials | Tallies | Input size |
|---|---|---|---|---|---|
| `cluster` (1 tie + 6 fuel) | 72 | 234 | 9 | 107 | 63 KB |
| `core` (all-fuel) | 61 | 219 | 9 | 89 | 58 KB |
| `mixed-core` (SNRE-style) | 72 | 234 | 9 | 107 | 64 KB |
| `reactor` (Be reflector + 12 drums + vessel) | **97** | **271** | 9 | 107 | 71 KB |

Artifacts retained in `nerva-audit\xml-export\`. This is a real constructive-solid-geometry core built through the OpenMC Python API — not a stub.

---

## What the audit does and does not establish

**Established:** the software executes, the model builds, the equations are internally consistent, and 112 regression suites pass on this machine. That matches the folder's own `NERVA_STATUS_HANDOFF.md` claim ("implemented" + "numerically verified").

**Not established, and unchanged by this audit:**

1. **No transport ever ran here.** No executable, no cross sections. Every "real core" result in the repo's CI (`nerva-real-core-transport.yml`, which pulls a prebuilt OpenMC binary *and* the NNDC archive) is unverifiable from this machine.
2. **Passing validators are synthetic.** Per the handoff doc, the deposition arrays and operating conditions are synthetic inputs. Internal conservation closure is not NASA validation.
3. **The core is 5 wt% LEU**, hard-capped below 20 wt% (`config.py:40`, `config.py:220`). Not NERVA fuel.
4. **No depletion** — `openmc.deplete` appears 0 times in 278 modules.
5. **No temperature feedback** — `resolved_openmc_feedback.py:5` states power is externally prescribed and material feedback is uniform.

---

## Bottom line

For the chosen path — *keep 5% LEU, make it self-consistent* — the blocker is **exactly one thing**: a per-element temperature → cross-section feedback loop with a criticality search, so that power becomes a solved result instead of an input.

Everything it would rest on already works: the geometry builds, the heating tallies exist, the thermal solvers pass their regressions, the Picard coupling harness is present and tested. What's missing is the outer iteration that closes `T → Σ → k → P → T`.

It still cannot be *run* as a reactor here until an `openmc.exe` and a cross-section library exist — but that is an install problem, not a software problem.
